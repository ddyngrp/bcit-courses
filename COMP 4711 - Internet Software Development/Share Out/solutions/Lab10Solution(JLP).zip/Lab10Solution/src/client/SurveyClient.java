package client;

import org.apache.xmlrpc.*;
import org.apache.xmlrpc.client.*;
import java.net.*;
import java.util.*;

public class SurveyClient {

    public final static int PORT = 2000;

    public static void main(String[] args) {
        try {
            // Specify the server
            XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
            config.setServerURL(new URL("http://localhost:" + PORT));
            // Setup the client
            XmlRpcClient client = new XmlRpcClient();
            client.setConfig(config);

            int voteNum = 0;
            Scanner sc = new Scanner(System.in);
            // Create a request
            Vector params = new Vector();
            // away we go
            do {
                // Make a request and print the result
                params.clear();
                Object[] result = (Object[]) client.execute("survey.survey", params);
                System.out.println("\n");
                for (int i = 0; i < result.length; i++) {
                    if (i > 0) {
                        System.out.print("" + i + ". ");
                    }
                    System.out.println((String) result[i]);
                }

                System.out.print("Your vote: ");
                voteNum = sc.nextInt();

                if ((voteNum > 0) && (voteNum < 99)) {
                    params.clear();
                    params.add(voteNum);
                    Object answer = client.execute("survey.vote", params);
                    System.out.println(" best so far: # " + (Integer) answer);
                }
            } while (voteNum < 99);
            params.clear();
            Object answer = client.execute("survey.report", params);
            System.out.println("\nSurvey says: \n" + (String) answer);
        } catch (java.net.MalformedURLException ex) {
            System.out.println("Incorrect URL for XML-RPC server format: " + ex.getMessage());
        } catch (XmlRpcException ex) {
            System.out.println("XML-RPC Exception: " + ex.getMessage());
        } catch (java.io.IOException ex) {
            System.out.println("IO Exception: " + ex.getMessage());
        }
    }
}
