//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 class Sc51497dedb5c0712f20ccaa9831c0365; class Sbfb2e2ba99d3682ec36c46fd64074a1c; class S6d6cbe6673721b1104d6dcb8de7beb6a; 

#if 0
 void S08daf3cffde9494817beacb119734154(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const Sbfb2e2ba99d3682ec36c46fd64074a1c &S6796631def6265d61f7c203b1fb16e31, const Sbfb2e2ba99d3682ec36c46fd64074a1c 
&S35c67bea19936aebe5fcb453b281e126, mint S413a37d4b34cc0215a41e782fed855df, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&Scb936760b4518be9f27828a839a24eb3, const char *Sba1bbd9d6e7521e0ae2e9fbf13591229, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&Sf6a5b0eb74a5e4dd2dfa4a4e2a03788f, bool Se5ad2a57ff16a611ff83b570f39d0794, S6d6cbe6673721b1104d6dcb8de7beb6a 
&Sb74bba6aff72a12e23dd72208b2e2b5b, S6d6cbe6673721b1104d6dcb8de7beb6a &S86d1d8133cc0a67e774856827f0c2432); 

#endif
 S6d6cbe6673721b1104d6dcb8de7beb6a Sb2c78df047f33611acd498d16e9a8ca7(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const Sbfb2e2ba99d3682ec36c46fd64074a1c &S6796631def6265d61f7c203b1fb16e31, 
const Sbfb2e2ba99d3682ec36c46fd64074a1c &Sa799663d486bf7777dafd20d21c0ce7e, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&Scb936760b4518be9f27828a839a24eb3); void S021cabe4be5d68b20bb66af0f87b45fd(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sbfb2e2ba99d3682ec36c46fd64074a1c &S655215778b8a2d1850f1d59bb2cbc69d, 
mint S413a37d4b34cc0215a41e782fed855df, bool S423e2fb948c007843f9bbebd04308408, muint Se4ab1533b682ad6cef70683471d494b0); 
S6d6cbe6673721b1104d6dcb8de7beb6a S0678694722d6bd073382ddb2fdfacc38(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, mint S413a37d4b34cc0215a41e782fed855df, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&Sc22377b5b326edb2bea57e372f1c01af); void S4f84eda71868496cb0305813b87a54fe(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const Sbfb2e2ba99d3682ec36c46fd64074a1c &Sbe38087c699e0c38c220185e999eb6b7, 
const Sbfb2e2ba99d3682ec36c46fd64074a1c &Sa799663d486bf7777dafd20d21c0ce7e, mint S413a37d4b34cc0215a41e782fed855df, 
S6d6cbe6673721b1104d6dcb8de7beb6a &Sf9026cd719d281bb58823dcc3fa18891); bool Scb7b4b335d858bf89b493e5b82d7d6a7(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e);

