
import org.jdom.filter.Filter;
import org.jdom.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A00702683
 */
public class WhoFilter implements Filter {

    public boolean matches(Object obj) {
        return (obj instanceof Element) &&
                (((Element)obj).getText().contains("Doctor Who")) &&
                (((Element)obj).getName().equals("title"));
    }

}
