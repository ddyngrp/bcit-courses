
/**
 * Write a description of interface Mammal here.
 * 
 * @author Steffen L. Norgren
 * @version 2007.08.17
 */

public interface Mammal
{
    public abstract String getFurColour();
}
