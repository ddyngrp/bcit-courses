//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S6a9cb4afaddd91a14c8b773a09b25a57.h"

#include "S8c35dc3541dc5a9aa957381ceea6ca02.h"
  S20537bba367ba02b62a55f16c233866c::S20537bba367ba02b62a55f16c233866c(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sd52d2261900a32d63729ba78632c53b9 *Sb18a5c39d4e9c730bb94642a96f0fc84, 
muint Sb8fd7b0f8c4773d952fcfbbb8de7d043) { S6ec129777c16ed8568398f5726365a75 = &Scc2faae6b412ac43b64129b402c4b88e; 
S057e8d652f08fa6cc73b9dd3f3070c01 = Sb18a5c39d4e9c730bb94642a96f0fc84; Sb79d4a4ac05ebdb8cb70e6b5594e9473 
= Sb8fd7b0f8c4773d952fcfbbb8de7d043;     Sf0775c5214bdb3bfeb225761cda48e90 = S057e8d652f08fa6cc73b9dd3f3070c01->S462e82da38ead8547e0e63986bc970f6(Scc2faae6b412ac43b64129b402c4b88e, 
Sb79d4a4ac05ebdb8cb70e6b5594e9473, Sc164ff2a53efde35e4ae3fa7e5f46241) - 1; }   S20537bba367ba02b62a55f16c233866c::~S20537bba367ba02b62a55f16c233866c() 
{ Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e = *S6ec129777c16ed8568398f5726365a75; 
 delete S057e8d652f08fa6cc73b9dd3f3070c01; }           bool S20537bba367ba02b62a55f16c233866c::Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, uint64 S3d7bef5b94828f4c5b1e6804605daa54) {     while (S3d7bef5b94828f4c5b1e6804605daa54 
> Sf0775c5214bdb3bfeb225761cda48e90) { Sf0775c5214bdb3bfeb225761cda48e90 = S057e8d652f08fa6cc73b9dd3f3070c01->Sf55a4bb3cc5e6d68a058741563d1fec6(Scc2faae6b412ac43b64129b402c4b88e, 
Sc164ff2a53efde35e4ae3fa7e5f46241) - 1;  }  if (S3d7bef5b94828f4c5b1e6804605daa54 == Sf0775c5214bdb3bfeb225761cda48e90) 
{  Sf0775c5214bdb3bfeb225761cda48e90 = S057e8d652f08fa6cc73b9dd3f3070c01->Sf55a4bb3cc5e6d68a058741563d1fec6(Scc2faae6b412ac43b64129b402c4b88e, 
Sc164ff2a53efde35e4ae3fa7e5f46241) - 1;  return true; }  return false; } 

