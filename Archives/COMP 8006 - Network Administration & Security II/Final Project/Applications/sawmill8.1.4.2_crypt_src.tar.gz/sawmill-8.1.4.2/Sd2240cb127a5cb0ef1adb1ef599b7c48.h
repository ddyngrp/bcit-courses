//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Saf9554afa798d4a6e64216ddfb9be51f
 
#define Saf9554afa798d4a6e64216ddfb9be51f
 
#include "Scae613df5f8d33d29ffa329e57180663.h"
 class Se81224bcdcaa5d93469a5f6703d8bef8 : public Se95419184494485796fb04318437d0ef { private: char 
*S38ebe8412478a4b48249ac0b051c92f5; char Sb413b2dfcacf6b2bf07e7d6cf09c075d; char **S33875bb87cdd4f3fc608e038bd1448a9; 
mint S24186671208ebbf9c25b4e7a5cdde20e; mint Sf524d8a248793b2815a4ee5cf7c290b2; bool S6b97ca72bcff7ead25fc3e4946cfed0e; 
virtual void S6c52b36a5530b8c11dc0ab0e4eb17ee0(void); virtual void Sbd48403dc68e63f93b65f43083cfa74d(void); 
public: Se81224bcdcaa5d93469a5f6703d8bef8(Sc51497dedb5c0712f20ccaa9831c0365 &S6ec129777c16ed8568398f5726365a75, 
mint S9803bb85cf26fa79e0ac7e0e2e3c6492, const char *S21b42b84730c9a64978bb6d2fe7ef91e, bool S28b6362a102d62bf05137e0eb93d6b62) 
: Se95419184494485796fb04318437d0ef(S6ec129777c16ed8568398f5726365a75, S9803bb85cf26fa79e0ac7e0e2e3c6492, 
S21b42b84730c9a64978bb6d2fe7ef91e, S28b6362a102d62bf05137e0eb93d6b62) { }; virtual ~Se81224bcdcaa5d93469a5f6703d8bef8(void); 
virtual void S5224d940a63f99e95f980c0c01ba8e8c(void); };  
#endif


