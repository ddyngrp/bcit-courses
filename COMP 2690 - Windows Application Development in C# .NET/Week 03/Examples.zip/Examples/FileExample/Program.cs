using System;
using System.Collections.Generic;
using System.Text;

// Grab this namespace for the StreamReader class.
using System.IO;

namespace FileExample
{
	class Program
	{
		static void Main(string[] args)
		{
			// This object lets you read from a file.
			StreamReader streamReader; 

			// Prompt for a path/filename.
			string path;
			Console.Write("Enter a path and filename: ");
			path = Console.ReadLine();

			if (File.Exists(path))
			{
				// Read entire file line-by-line and display to the screen.
				try
				{
					// Attempt to open the file.  It will throw
					// an exception if there is a problem opening it, 
					// hence the try/catch block.
					streamReader = new StreamReader(path);

					// Peek returns the ASCII value of the next character in 
					// the file *without* advancing the file position.
					// 
					// This lets us see whether we've reached the end of the
					// file yet.
					while (streamReader.Peek() > 0)
					{
						// Read a line at a time, printing it to the screen.
						Console.WriteLine(streamReader.ReadLine());
					}

					// Don't forget to close the file when you're finished with it!
					streamReader.Close();
				}
				catch (Exception ex)
				{
					Console.WriteLine("\n" + ex.Message + "\n");
				}

			}
			else
			{
				Console.WriteLine("\nFile not found.\n");
			}
		}
	}
}
