/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Iterator;
import java.util.List;
import org.jdom.filter.Filter;
import org.jdom.*;

/**
 *
 * @author A00702683
 */
public class NewsFilter implements Filter {

    public boolean matches(Object obj) {
        
        if(!(obj instanceof Element))
            return false;
        
        Element elem = (Element)obj;
        
        if(!elem.getName().equals("programme"))
            return false;
        
        List items = elem.getChildren("category");
        
        for (Iterator iter=items.iterator(); iter.hasNext(); ) {
            Element catagory = (Element) iter.next();
            if(catagory.getText().equalsIgnoreCase("news"))
                return true;
        }

        return false;
    }

}
