//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#include "sconfig.h"

#include "Sa7896d28d72adcedf1ef75940052f6ab.h"

#include "S87ef078de51e5fe6a830bf07b61f4b49.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "S3e3af11e108aa6fefb5a12f010f7b40b.h"
  Sca83f2ba77404931369c15fc6db8dc03::Sca83f2ba77404931369c15fc6db8dc03(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) : S6ebd5941df466d9a1c9cc8263c03ef42(Scc2faae6b412ac43b64129b402c4b88e, 
"%filtered_sessions", true) { S0850770ccc1d710b184b98f64fc06607 = &Scc2faae6b412ac43b64129b402c4b88e; 
Saacb9dc4c09242bfd4043bbe6215dcf9::Saf7777c899740c60aa002deaa131bdf3(Scc2faae6b412ac43b64129b402c4b88e, 
true); Sde98bde6aca3d1974bc059249c4c2367 = S1972132661dc42f064d385e65c57a15b;  if (Scc2faae6b412ac43b64129b402c4b88e.Sd0a48d8cd7acc4d46c42c68ead89b986) 
{ S4fa4ca5d73e74ca8109426dbef6c2220("FilteredSessionsTable is not yet implemented for SQL"); }  S83b1913201260a0e8936f053b2521dd8 
= Sc3057ef3d8b0af864991d43b59105f43(Scc2faae6b412ac43b64129b402c4b88e, "");   Sce5116eda522bbb06414836b849d40ad(Scc2faae6b412ac43b64129b402c4b88e, 
S83b1913201260a0e8936f053b2521dd8);    S19da4f598a63b4147f0a78d613bef8bc(Scc2faae6b412ac43b64129b402c4b88e); 
    S9868cb1be8057ba4e855f7cfe406826b = Sde98bde6aca3d1974bc059249c4c2367->S94ab9c60f47cbc5c0babe3433f98d2b0(Scc2faae6b412ac43b64129b402c4b88e, 
NULL, &Sc2e84de451e770a258d44ae986661000);   S27f70072e3629dc7386ef32e0adec247 = 0;  Sc1ff708c3bf2ae7a9a53cb4e17f82299 
= MUINT_MAX;  S2e77d62f54f5345260eed258380c5e60 = 0; for (int Seb9d419135e896279ecc7721147bbd03 = 0; 
Seb9d419135e896279ecc7721147bbd03 < S0973a79a8d06417efd08650d3b5d404f; Seb9d419135e896279ecc7721147bbd03++) 
Sdc27b03abaddd77c9f37372f5c6d774f[Seb9d419135e896279ecc7721147bbd03] = MUINT_MAX;  S753adcc3059bb2a4935cd898d156d75d 
= new unsigned char[Sde98bde6aca3d1974bc059249c4c2367->Sd4a82e4a4b4eabffbd560ca09cf56253]; Sb26c464d2391c8093d206e633c157810 
= MUINT_MAX; Sfc0717eabeeea61514d4a32b0ce82f64 = MUINT_MAX;  Sf61df9a34d3e7be4b45a312fb0de239e = NULL; 
}   void Sca83f2ba77404931369c15fc6db8dc03::Sbfa089fba13d139b03b9b7305503e516(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to clear read-only sessions table"); 
}   Sca83f2ba77404931369c15fc6db8dc03::~Sca83f2ba77404931369c15fc6db8dc03(void) { }   void Sca83f2ba77404931369c15fc6db8dc03::Sbb3816bd614474e27aec873aed072563(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
long Sb79d4a4ac05ebdb8cb70e6b5594e9473) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to set integer cell in read-only sessions table"); 
}  void Sca83f2ba77404931369c15fc6db8dc03::S615a269ca4651401d526ebd237a876b4(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
long Sb79d4a4ac05ebdb8cb70e6b5594e9473) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to add set value to cell in read-only filtered sessions table"); 
}  void Sca83f2ba77404931369c15fc6db8dc03::Sae437b16a5ebd9e286529032c51ec7e6(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint S45ac028d65de68b656f6beed47bb05e0, muint S3d8ee3c332e6fb56e9e256ddfaf2c5fc, 
S6ebd5941df466d9a1c9cc8263c03ef42 *S912a86dae5c9ea4933c953a2e42a4975, muint S3bef84d37aac181254529ae3c4ebf131, 
muint S24cb89260942843611814af34d983181) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to call set method FilteredSessionsTable::MergeSetCell() on table which does not support sets"); 
} Sd52d2261900a32d63729ba78632c53b9 *Sca83f2ba77404931369c15fc6db8dc03::Sa43e3b1574c5ad83319defc22277b4fa(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sb75b130e2cafe73a5d4d59707f8293fe) { S4fa4ca5d73e74ca8109426dbef6c2220("Internal: Attempt to call set method FilteredSessionsTable::GetSetColumnIntegerLists() on table which does not support sets"); 
return NULL; } muint Sca83f2ba77404931369c15fc6db8dc03::S86cb4008f0393187e56e0a95e210c377(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sf1bb612fb103904163f3361e636db355, muint Sb75b130e2cafe73a5d4d59707f8293fe) 
{ S4fa4ca5d73e74ca8109426dbef6c2220("Internal: Attempt to call set method FilteredSessionsTable::GetSetCellListNum() on table which does not support sets"); 
return 0; } void Sca83f2ba77404931369c15fc6db8dc03::S370235c3e90e5c23da1818f88e0f7c10(unsigned long 
S0a8436e51d8c251e031c1a94c2317002) { Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e 
= *S0850770ccc1d710b184b98f64fc06607; S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to set the number of rows in read-only sessions table"); 
}   void Sca83f2ba77404931369c15fc6db8dc03::Saff6ebce1c848809f8fd751968dfd7ab(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sf1bb612fb103904163f3361e636db355) {  if (Sc1ff708c3bf2ae7a9a53cb4e17f82299 
== Sf1bb612fb103904163f3361e636db355) return;  for (int Seb9d419135e896279ecc7721147bbd03 = 0; Seb9d419135e896279ecc7721147bbd03 
< S0973a79a8d06417efd08650d3b5d404f; Seb9d419135e896279ecc7721147bbd03++) {  if (Sdc27b03abaddd77c9f37372f5c6d774f[Seb9d419135e896279ecc7721147bbd03] 
== Sf1bb612fb103904163f3361e636db355) {  S46befded556f051bb87f2e7e9275303f S2d52a66db075bc21bcbfea667c35646b 
= Sdd4a0cecc04301dcde1aabeef81876fa; muint S6c6ded861e61d1c5d6fc71220acf2693 = Sc1ff708c3bf2ae7a9a53cb4e17f82299; 
 Sdd4a0cecc04301dcde1aabeef81876fa = S1048085e695303ce48801dec5000012c[Seb9d419135e896279ecc7721147bbd03]; 
Sc1ff708c3bf2ae7a9a53cb4e17f82299 = Sdc27b03abaddd77c9f37372f5c6d774f[Seb9d419135e896279ecc7721147bbd03]; 
 S1048085e695303ce48801dec5000012c[Seb9d419135e896279ecc7721147bbd03] = S2d52a66db075bc21bcbfea667c35646b; 
Sdc27b03abaddd77c9f37372f5c6d774f[Seb9d419135e896279ecc7721147bbd03] = S6c6ded861e61d1c5d6fc71220acf2693; 
S00eef647dbe0d8ace508947072e65cb9[Seb9d419135e896279ecc7721147bbd03] = S2e77d62f54f5345260eed258380c5e60; 
S2e77d62f54f5345260eed258380c5e60++; return; }  }    muint Sb81e12e22bbef89f13021c787785ff25 = MUINT_MAX; 
muint Sd12edf24c6fd59358a44dc55d2c290f7 = 0; for (int Seb9d419135e896279ecc7721147bbd03 = 0; Seb9d419135e896279ecc7721147bbd03 
< S0973a79a8d06417efd08650d3b5d404f; Seb9d419135e896279ecc7721147bbd03++) { if (S00eef647dbe0d8ace508947072e65cb9[Seb9d419135e896279ecc7721147bbd03] 
< MUINT_MAX) { Sd12edf24c6fd59358a44dc55d2c290f7 = Seb9d419135e896279ecc7721147bbd03; Sb81e12e22bbef89f13021c787785ff25 
= S00eef647dbe0d8ace508947072e65cb9[Seb9d419135e896279ecc7721147bbd03]; } }  S1048085e695303ce48801dec5000012c[Sd12edf24c6fd59358a44dc55d2c290f7] 
= Sdd4a0cecc04301dcde1aabeef81876fa; Sdc27b03abaddd77c9f37372f5c6d774f[Sd12edf24c6fd59358a44dc55d2c290f7] 
= Sc1ff708c3bf2ae7a9a53cb4e17f82299; S00eef647dbe0d8ace508947072e65cb9[Sd12edf24c6fd59358a44dc55d2c290f7] 
= S2e77d62f54f5345260eed258380c5e60; S2e77d62f54f5345260eed258380c5e60++;  if (S27f70072e3629dc7386ef32e0adec247 
!= Sf1bb612fb103904163f3361e636db355) S3cb892668f9be265f2770ff577b23c58(Scc2faae6b412ac43b64129b402c4b88e, 
S9868cb1be8057ba4e855f7cfe406826b, Sf1bb612fb103904163f3361e636db355*sizeof(S46befded556f051bb87f2e7e9275303f)); 
 S6d77c71cf5341a9cef03bc416c7ed98e(Scc2faae6b412ac43b64129b402c4b88e, S9868cb1be8057ba4e855f7cfe406826b, 
&Sdd4a0cecc04301dcde1aabeef81876fa, sizeof(S46befded556f051bb87f2e7e9275303f));  S27f70072e3629dc7386ef32e0adec247 
= Sf1bb612fb103904163f3361e636db355 + 1; Sc1ff708c3bf2ae7a9a53cb4e17f82299 = Sf1bb612fb103904163f3361e636db355; 
}   long Sca83f2ba77404931369c15fc6db8dc03::Se6c2454c6dceabfb0190c4f07f3001d8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
bool S7f267dec6d167e17b050dd3ffb3632f3) {   Saff6ebce1c848809f8fd751968dfd7ab(Scc2faae6b412ac43b64129b402c4b88e, 
Sf1bb612fb103904163f3361e636db355); switch (Sb75b130e2cafe73a5d4d59707f8293fe) { case 0: return Sdd4a0cecc04301dcde1aabeef81876fa.S4b7806f187f5053bedde5e64eff508d8; 
case 1: return Sdd4a0cecc04301dcde1aabeef81876fa.S1f5572c0a2a449314af162f3111ac1a4; case 2: return Sdd4a0cecc04301dcde1aabeef81876fa.S7cbe297527960e8cb172ccdd72c74787; 
case 3: return Sdd4a0cecc04301dcde1aabeef81876fa.S655215778b8a2d1850f1d59bb2cbc69d;  case 4: { muint 
S1fc93a9b8467b97cbac1d3361e084776 = Sf61df9a34d3e7be4b45a312fb0de239e->S61713411d9fb531ac57e263d1c0bb5d4(Scc2faae6b412ac43b64129b402c4b88e, 
Sdd4a0cecc04301dcde1aabeef81876fa.S7bd6a62728eeda2c3d5a2eba798d106b, Sdd4a0cecc04301dcde1aabeef81876fa.S6bdb1bb4397e5e2cbb88e098ed02bd75); 
return S1fc93a9b8467b97cbac1d3361e084776; }  case 5: {  if (Sf1bb612fb103904163f3361e636db355 + 1 == 
Sc2e84de451e770a258d44ae986661000) return 0;  time_t S6256c6feee8bee48afaf313f4ba24173 = Sdd4a0cecc04301dcde1aabeef81876fa.S7cbe297527960e8cb172ccdd72c74787; 
time_t Sf68e4980868bf6ce44f13f3974ae2d13 = Sdd4a0cecc04301dcde1aabeef81876fa.S4b7806f187f5053bedde5e64eff508d8; 
  Saff6ebce1c848809f8fd751968dfd7ab(Scc2faae6b412ac43b64129b402c4b88e, Sf1bb612fb103904163f3361e636db355 
+ 1); time_t Scae2f7c31ac563437e58244953eb3ec9 = Sdd4a0cecc04301dcde1aabeef81876fa.S7cbe297527960e8cb172ccdd72c74787; 
time_t S13151e77d7a11c2ae09979173ca75942 = Sdd4a0cecc04301dcde1aabeef81876fa.S4b7806f187f5053bedde5e64eff508d8; 
  if (Sf68e4980868bf6ce44f13f3974ae2d13 != S13151e77d7a11c2ae09979173ca75942) return 0;  return Scae2f7c31ac563437e58244953eb3ec9 
- S6256c6feee8bee48afaf313f4ba24173; }  default: { S4fa4ca5d73e74ca8109426dbef6c2220("Unknown column number " 
<< Sb75b130e2cafe73a5d4d59707f8293fe << " in filtered session table"); } }  return 0;  }   void Sca83f2ba77404931369c15fc6db8dc03::Se2cf07af861e42f6dec3d594d9b0883a(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
double Sb79d4a4ac05ebdb8cb70e6b5594e9473) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to set float cell in read-only sessions table"); 
}   double Sca83f2ba77404931369c15fc6db8dc03::S0d28f1f7e5f1d88f4cd82df506322020(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe) 
{ S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to get float value from a session column in a filtered sessions table, but there are no float columns in the session part of the table"); 
return 0;  }   void Sca83f2ba77404931369c15fc6db8dc03::Sdeee17eb25d8e8090c1658211db68411(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, vector<S84cb5f9994c76e5bc79552e3fd79e2cc> &Sddae8602054f3a89fe990e06e544f1b7) 
{ S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to sort read-only session table"); }   const char *Sca83f2ba77404931369c15fc6db8dc03::Sa3432f70164f1da8313f905fc022afd7(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe) 
{  switch (S2491c907014e8f06df3a64feafb24d54[Sb75b130e2cafe73a5d4d59707f8293fe]) { case S20455266fffbadb179968122830543be: 
 return Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, Se6c2454c6dceabfb0190c4f07f3001d8(Scc2faae6b412ac43b64129b402c4b88e, 
Sf1bb612fb103904163f3361e636db355, Sb75b130e2cafe73a5d4d59707f8293fe)); case Sc92eef5f070ee905a8f2f5986d152a83: 
return S3576d97d2cc7eb56d2535748c45053eb(Scc2faae6b412ac43b64129b402c4b88e, S0d28f1f7e5f1d88f4cd82df506322020(Scc2faae6b412ac43b64129b402c4b88e, 
Sf1bb612fb103904163f3361e636db355, Sb75b130e2cafe73a5d4d59707f8293fe)); case S73abb4a6ab2e923f8b9f6a34940601df: 
{  mint S3a726456978463ecd85dd4ae31baa068 = Se6c2454c6dceabfb0190c4f07f3001d8(Scc2faae6b412ac43b64129b402c4b88e, 
Sf1bb612fb103904163f3361e636db355, Sb75b130e2cafe73a5d4d59707f8293fe);  return S1ecb2f2f4a04cf5861918291022bd266->S5779434f47c9981238e5143445128993(Scc2faae6b412ac43b64129b402c4b88e, 
S257039134728c2e83ea1fb71c13017ea[Sb75b130e2cafe73a5d4d59707f8293fe], S3a726456978463ecd85dd4ae31baa068); 
} case S961a6d5aa8226f241f53c7f059210f15: { S4fa4ca5d73e74ca8109426dbef6c2220("Internal Error: Attempt to get custom itemnum value from main table"); 
} default: { S4fa4ca5d73e74ca8109426dbef6c2220("Internal Error: Unknown table column type " << S2491c907014e8f06df3a64feafb24d54[Sf1bb612fb103904163f3361e636db355] 
<< " in GetCellValueAsString()"); } }  return NULL;  }   void Sca83f2ba77404931369c15fc6db8dc03::Se7998206b675d30b2506d58d2ac7ab48(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
const char *Sb79d4a4ac05ebdb8cb70e6b5594e9473) { S4fa4ca5d73e74ca8109426dbef6c2220("Attempt to set cell as string in read-only main table"); 
}   void Sca83f2ba77404931369c15fc6db8dc03::Sce5116eda522bbb06414836b849d40ad(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S7ca5d44c3992eca4f11ed4ee768968cd *S83b1913201260a0e8936f053b2521dd8) 
{ S7ca5d44c3992eca4f11ed4ee768968cd *S90b0c0045f9ac6699112fabe5f1822d7;  S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("ssession_id", 
""); S90b0c0045f9ac6699112fabe5f1822d7 = S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("ssession_id"); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", "int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", "int"); 
 S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("ssession_user", ""); S90b0c0045f9ac6699112fabe5f1822d7 
= S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("ssession_user"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("field_name", S8553c9554ef395b408d59b14905a4f16(Sf3d402fb6121ed5b8a3da5206059010a->Sf1b8e1d64277ef6f2ff40c2184d001dc)->S50725c229541d49fe591346687d603e6(Scc2faae6b412ac43b64129b402c4b88e)); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", "string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", 
"database_itemnum");  S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("ssession_date_time", 
""); S90b0c0045f9ac6699112fabe5f1822d7 = S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("ssession_date_time"); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", "int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("field_name", 
S8553c9554ef395b408d59b14905a4f16(Sf3d402fb6121ed5b8a3da5206059010a->S29452b04c373f8e81788b2cd73dcf536)->S50725c229541d49fe591346687d603e6(Scc2faae6b412ac43b64129b402c4b88e)); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", "int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", "int"); 
 S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("ssession_page", ""); S90b0c0045f9ac6699112fabe5f1822d7 
= S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("ssession_page"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("field_name", S8553c9554ef395b408d59b14905a4f16(Sf3d402fb6121ed5b8a3da5206059010a->S1d27c8d98ff5b76fac0537cc3e56aecc)->S50725c229541d49fe591346687d603e6(Scc2faae6b412ac43b64129b402c4b88e)); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", "string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"string"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", 
"database_itemnum");  S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("_main_table_row_number", 
""); S90b0c0045f9ac6699112fabe5f1822d7 = S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("_main_table_row_number"); 
S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", "int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", "int"); 
 S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("ssession_duration", ""); S90b0c0045f9ac6699112fabe5f1822d7 
= S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("ssession_duration"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("data_type", "int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"int"); S90b0c0045f9ac6699112fabe5f1822d7->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", "int"); 
}  
#endif


