//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S495d8a25466e91c8ca089b4d90f961cd
 
#define S495d8a25466e91c8ca089b4d90f961cd
 typedef enum { Sebabd13042fe0d81b44a17cbffe9dd66, S2f98d95a137e75b7c4a9d71153c81bc7, Sd447f161d7eeeceadfd3ad983e389fd6, 
Seefe9b90581fe5714b6b0a3b1eafd62b, S8d8781c85674c9da449a67a717c995ba, Sa58c59266f43e8d7fc376380fe2bf6a9, 
Sf008bc62e9793b9e53aef36c61cdd1e5, S1756b1f8319cadd6d0e9b258f7204519, S9d6c21096136ee0b62ffd072a651f74c, 
Sdbbfc89e44d5aaeefb137c6df8eb7be1, Sdc63fff850164ad7ceb7dc257fb81dd4, S4c18cbc528e093cbb040831a88a764e9, 
S929048a6405f40d20ec495364b0e5c86, Sa0fda781b9f24a70c2fc5e56f632a18d, S5e2b6a5e75122bf02102f256475f4ed1, 
S06858f22d340843812153551ccc17d9c, Se2a68395b91e1c7469849288f0e1cced, S51d782ece3525dd64ca27478b67711a1, 
S3d1da061e967e921465e4579e65631dc, S8be6aebae1f7b0d35a2c7071231e8a95, S9e3ec9ad7cad3e76e408061d2d473d0f 
} Sca447eeae093033752b6b03c25ed709c; 
#endif


