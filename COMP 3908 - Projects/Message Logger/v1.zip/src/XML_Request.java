/*
 * XML_Request.java
 *
 * MLogger, 2008
 * Confidential and proprietary.
 */
package src; 
 public interface XML_Request {

    public String toString();

}
