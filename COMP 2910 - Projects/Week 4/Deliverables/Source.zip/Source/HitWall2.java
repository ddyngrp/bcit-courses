import lejos.nxt.*;
import lejos.subsumption.*;

public class HitWall2 implements Behavior {
	
   TouchSensor touch;
   
   public HitWall2()
   {
	   touch = new TouchSensor(SensorPort.S3);
   }
   
   public boolean takeControl() {
      return touch.isPressed();
   }

   public void suppress() {
      Motor.A.stop();
      Motor.B.stop();
   }

   public void action() {
      // Back up:
      Motor.A.backward();
      Motor.B.backward();
      try{Thread.sleep(1000);}catch(Exception e) {}
      // Rotate by causing only one wheel to stop:
      Motor.B.stop();
      try{Thread.sleep(300);}catch(Exception e) {}
	  Motor.A.forward();
	  Motor.B.forward();
	  try{Thread.sleep(500);}catch(Exception e) {}
	  Motor.B.stop();
      try{Thread.sleep(300);}catch(Exception e) {}
   }
}


