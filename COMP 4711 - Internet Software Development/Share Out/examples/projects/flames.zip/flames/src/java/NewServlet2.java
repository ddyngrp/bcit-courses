/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.*;
import java.net.*;

import java.sql.DatabaseMetaData;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author HP_Administrator
 */
public class NewServlet2 extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String[] elements;
        boolean errors = true;
        PrintWriter out = response.getWriter();
        String ls_path = getServletContext().getRealPath("/") + "schedule.xml";        
        
        File schedFile = new File(ls_path);
        schedFile.delete();
        
        ls_path = getServletContext().getRealPath("/") + "update.xml";
        File updatedFile = new File(ls_path);        
        updatedFile.renameTo(schedFile);
        
        errors = false;        

        // NOTES ... parse the HTML, looking for the relevant schedule bits, using a tool like
        // the Swing HTML parser (http://java.sun.com/products/jfc/tsc/articles/bookmarks/)
        // or the sourceforge HTML parser project (http://htmlparser.sourceforge.net/)
        // in order to build your updated schedule XML document
        
        // HINT probably looking for a <div> with a specific ID or class, in order to
        // isolate your schedule data

        if (errors) {
            // this output should only ever happen if there is an error
            // processing the URL above            
            try {
                out.println("Link has errors");
                out.println("<br/>" + request.getParameter("url"));
            } finally {
                out.close();
            }
        } else {
            response.sendRedirect("schedule.jsp"); // this should be a link to your "database" updater
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
