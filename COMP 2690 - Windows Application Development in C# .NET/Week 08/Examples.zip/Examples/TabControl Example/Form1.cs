using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace TabControl_Example
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			loadDefaultOptions();
		}

		private void tabOptions_Selecting(object sender, TabControlCancelEventArgs e)
		{
			if (tabOptions.SelectedTab == tabAdvanced)
			{
				if (MessageBox.Show("Are you sure you wish to change advanced options?",
						"Advanced Options",
						MessageBoxButtons.YesNo,
						MessageBoxIcon.Question) == DialogResult.No)
				{
					// Don't allow the tab change.
					e.Cancel = true;
				}
			}

		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			showOptionsSummary();
		}

		private void showOptionsSummary()
		{
			StringBuilder sb = new StringBuilder();

			// Notice that each control is inside a TabPage container control,
			// however, it is not necessary to refer to the TabPage or the TabControl
			// control at all in order to refer to each control inside the tab.
			// The TabControl and its TabPage controls are just containers, like the
			// GroupBox.
			sb.Append("General Options\n\n");
			sb.Append("Autosave: ");
			sb.Append(chkAutoSave.Checked ? "Yes" : "No");
			sb.Append("\nPrompt on exit: ");
			sb.Append(chkPromptOnExit.Checked ? "Yes" : "No");
			sb.Append("\nOpen each document in a separate window: ");
			sb.Append(chkNewWindow.Checked ? "Yes" : "No");

			sb.Append("\n\nAdvanced Options\n\n");
			sb.Append("Connection port: ");
			sb.Append(txtPort.Text);
			sb.Append("\nTimeout: ");
			sb.Append(txtTimeoutSeconds.Text);
			sb.Append(" seconds");

			MessageBox.Show(sb.ToString(),
					"All Options",
					MessageBoxButtons.OK,
					MessageBoxIcon.Information);

			Application.Exit();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void loadDefaultOptions()
		{
			chkAutoSave.Checked = true;
			chkNewWindow.Checked = false;
			chkPromptOnExit.Checked = true;

			txtPort.Text = "6200";
			txtTimeoutSeconds.Text = "15";
		}

		private void tabOptions_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Set focus to the correct control, depending on the newly selected
			// tab.
			if (tabOptions.SelectedTab == tabGeneral)
			{
				btnOK.Select();
			}
			else if (tabOptions.SelectedTab == tabAdvanced)
			{
				txtPort.Select();
				txtPort.SelectAll();
			}
			else
			{
				// Make the program crash and inform the programmer how to fix the problem.
				Debug.Assert(false, "Did you add a new tab to the Options form?");
			}
		}
	}
}