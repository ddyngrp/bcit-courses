namespace TabControl_Example
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabOptions = new System.Windows.Forms.TabControl();
			this.tabGeneral = new System.Windows.Forms.TabPage();
			this.tabAdvanced = new System.Windows.Forms.TabPage();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.chkAutoSave = new System.Windows.Forms.CheckBox();
			this.chkPromptOnExit = new System.Windows.Forms.CheckBox();
			this.chkNewWindow = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtTimeoutSeconds = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabOptions.SuspendLayout();
			this.tabGeneral.SuspendLayout();
			this.tabAdvanced.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabOptions
			// 
			this.tabOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tabOptions.Controls.Add(this.tabGeneral);
			this.tabOptions.Controls.Add(this.tabAdvanced);
			this.tabOptions.Location = new System.Drawing.Point(2, 4);
			this.tabOptions.Name = "tabOptions";
			this.tabOptions.SelectedIndex = 0;
			this.tabOptions.Size = new System.Drawing.Size(293, 162);
			this.tabOptions.TabIndex = 0;
			this.tabOptions.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabOptions_Selecting);
			this.tabOptions.SelectedIndexChanged += new System.EventHandler(this.tabOptions_SelectedIndexChanged);
			// 
			// tabGeneral
			// 
			this.tabGeneral.Controls.Add(this.chkNewWindow);
			this.tabGeneral.Controls.Add(this.chkPromptOnExit);
			this.tabGeneral.Controls.Add(this.chkAutoSave);
			this.tabGeneral.Location = new System.Drawing.Point(4, 22);
			this.tabGeneral.Name = "tabGeneral";
			this.tabGeneral.Padding = new System.Windows.Forms.Padding(3);
			this.tabGeneral.Size = new System.Drawing.Size(285, 136);
			this.tabGeneral.TabIndex = 0;
			this.tabGeneral.Text = "General";
			this.tabGeneral.UseVisualStyleBackColor = true;
			// 
			// tabAdvanced
			// 
			this.tabAdvanced.Controls.Add(this.txtTimeoutSeconds);
			this.tabAdvanced.Controls.Add(this.txtPort);
			this.tabAdvanced.Controls.Add(this.label3);
			this.tabAdvanced.Controls.Add(this.label2);
			this.tabAdvanced.Controls.Add(this.label1);
			this.tabAdvanced.Location = new System.Drawing.Point(4, 22);
			this.tabAdvanced.Name = "tabAdvanced";
			this.tabAdvanced.Padding = new System.Windows.Forms.Padding(3);
			this.tabAdvanced.Size = new System.Drawing.Size(285, 136);
			this.tabAdvanced.TabIndex = 1;
			this.tabAdvanced.Text = "Advanced";
			this.tabAdvanced.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOK.Location = new System.Drawing.Point(136, 184);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 0;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(217, 184);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 1;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// chkAutoSave
			// 
			this.chkAutoSave.AutoSize = true;
			this.chkAutoSave.Location = new System.Drawing.Point(14, 13);
			this.chkAutoSave.Name = "chkAutoSave";
			this.chkAutoSave.Size = new System.Drawing.Size(71, 17);
			this.chkAutoSave.TabIndex = 0;
			this.chkAutoSave.Text = "&Autosave";
			this.chkAutoSave.UseVisualStyleBackColor = true;
			// 
			// chkPromptOnExit
			// 
			this.chkPromptOnExit.AutoSize = true;
			this.chkPromptOnExit.Location = new System.Drawing.Point(14, 36);
			this.chkPromptOnExit.Name = "chkPromptOnExit";
			this.chkPromptOnExit.Size = new System.Drawing.Size(238, 17);
			this.chkPromptOnExit.TabIndex = 1;
			this.chkPromptOnExit.Text = "&Prompt on exit when document needs saving";
			this.chkPromptOnExit.UseVisualStyleBackColor = true;
			// 
			// chkNewWindow
			// 
			this.chkNewWindow.AutoSize = true;
			this.chkNewWindow.Location = new System.Drawing.Point(14, 59);
			this.chkNewWindow.Name = "chkNewWindow";
			this.chkNewWindow.Size = new System.Drawing.Size(211, 17);
			this.chkNewWindow.TabIndex = 2;
			this.chkNewWindow.Text = "&Open each document in a new window";
			this.chkNewWindow.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Connection &port:";
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(98, 12);
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(84, 20);
			this.txtPort.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "&Timeout:";
			// 
			// txtTimeoutSeconds
			// 
			this.txtTimeoutSeconds.Location = new System.Drawing.Point(98, 37);
			this.txtTimeoutSeconds.Name = "txtTimeoutSeconds";
			this.txtTimeoutSeconds.Size = new System.Drawing.Size(84, 20);
			this.txtTimeoutSeconds.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(192, 40);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(47, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "seconds";
			// 
			// MainForm
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(298, 219);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.tabOptions);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Options";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.tabOptions.ResumeLayout(false);
			this.tabGeneral.ResumeLayout(false);
			this.tabGeneral.PerformLayout();
			this.tabAdvanced.ResumeLayout(false);
			this.tabAdvanced.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl tabOptions;
		private System.Windows.Forms.TabPage tabGeneral;
		private System.Windows.Forms.TabPage tabAdvanced;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.CheckBox chkNewWindow;
		private System.Windows.Forms.CheckBox chkPromptOnExit;
		private System.Windows.Forms.CheckBox chkAutoSave;
		private System.Windows.Forms.TextBox txtTimeoutSeconds;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
	}
}

