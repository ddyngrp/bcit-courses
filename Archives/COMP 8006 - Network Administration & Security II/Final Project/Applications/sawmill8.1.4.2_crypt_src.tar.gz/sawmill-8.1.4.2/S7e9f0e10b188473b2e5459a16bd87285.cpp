//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#if HAVE_STDIO_H
 
#include <stdio.h>

#endif
 
#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#include "Sf1b38ee82e539f0a109ddb2466f9f28c.h"

#include "Sb5a9bba78ccd5d7067282b6d680c50a0.h"

#include "S2b659cf002e8d20bd33ff44e6e3a8a70.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#include "S3397ee89749921f65da312dac746f43d.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S4251970c545ff7063c10e0ac5324e0d8.h"

#include "Se24e5f8f12be3c8abcb9e4f17d005c29.h"
  void S1156f273fe97f6e6d21e284541306ebb(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const S6d6cbe6673721b1104d6dcb8de7beb6a &S43f012de0c1d39bbffdace76cb72da3f, unsigned char *S5c383bcfd30422c8c49fa51fd58b3f46) 
{  if (S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, S43f012de0c1d39bbffdace76cb72da3f.c_str())) 
return; S49d5518cb68be5829037dbed2be45396(Sb58c26af62a2dca70604fc8563b509b8("security.image_file_permissions")); 
FILE *out = S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, S43f012de0c1d39bbffdace76cb72da3f.c_str(), 
"wb"); S49d5518cb68be5829037dbed2be45396(Sb58c26af62a2dca70604fc8563b509b8("security.default_permissions")); 
 while (!((*S5c383bcfd30422c8c49fa51fd58b3f46 == 0322) && (*(S5c383bcfd30422c8c49fa51fd58b3f46+1) == 
0322) && (*(S5c383bcfd30422c8c49fa51fd58b3f46+2) == 0322) && (*(S5c383bcfd30422c8c49fa51fd58b3f46+3) 
== 0322))) { fputc(*S5c383bcfd30422c8c49fa51fd58b3f46, out); S5c383bcfd30422c8c49fa51fd58b3f46++; } 
Sd33302a1daa8e684f02934fd9419ec83(Scc2faae6b412ac43b64129b402c4b88e, out); }   void Saa276ce72df4103c3b9cfe01cede6019(void) 
{ }   S9f4d4ea4917e0ea34880cb67e0e58e66 *S8fc5d6e45dccad33a0bd5a2777a4fe05(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S4a2a04382382aa701ba4cf97aea9cb82) {   S6d6cbe6673721b1104d6dcb8de7beb6a 
S9fcb91bf6b1d31b4a64256edc0b1bc10 = S386ab9f82f83ce53d791996ba5e7db8e() + "WebServerRoot" + Sfae98e901cdbf1a268ec544cd9457415; 
S6d6cbe6673721b1104d6dcb8de7beb6a Sa52d36295bcc64dfaafbb6e2bb321d76 = S4a2a04382382aa701ba4cf97aea9cb82; 
  if (Sa52d36295bcc64dfaafbb6e2bb321d76.S7c4c23c4982435c76bfd2635c357f6b7("picts/docs/")) Sa52d36295bcc64dfaafbb6e2bb321d76 
= S6d6cbe6673721b1104d6dcb8de7beb6a("picts/docs/") + S22bbd1db66323e9152a85ead057ada5c("miscellaneous.language") 
+ Sa52d36295bcc64dfaafbb6e2bb321d76.substr(10);  S6d6cbe6673721b1104d6dcb8de7beb6a Sa0d162d0c7d63be1d940ba4a2367fc5b 
= Sa52d36295bcc64dfaafbb6e2bb321d76; 
#ifdef WINDOWS
 Sa0d162d0c7d63be1d940ba4a2367fc5b.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
"/", "\\"); 
#endif
  if (!Sceac26d97cb4b0c5abb1c8ddd13a9d51("mime_images_buffer") && Sceac26d97cb4b0c5abb1c8ddd13a9d51("generate_mime_files") 
&& Sf4e3724a81d5a192e5b3e0178e8c5eb9("generate_mime_files")) S0dd528a42552b31ec5d309edca503524("mime_images_buffer", 
"");  if (Sceac26d97cb4b0c5abb1c8ddd13a9d51("mime_images_buffer")) {  S6d6cbe6673721b1104d6dcb8de7beb6a 
Sbc72ef85a90c23a5b875f7b25ea26837 = S9fcb91bf6b1d31b4a64256edc0b1bc10 + Sa0d162d0c7d63be1d940ba4a2367fc5b; 
 S1d08f7eee40c3832fec6f83b89d81caf(Scc2faae6b412ac43b64129b402c4b88e, Sbc72ef85a90c23a5b875f7b25ea26837, 
Sa0d162d0c7d63be1d940ba4a2367fc5b);  S9f4d4ea4917e0ea34880cb67e0e58e66 *Sa4629d176b019e697b0527efe5a4691f 
= Scbc391abb6d4fdeed1aa169c4ae8906b(Scc2faae6b412ac43b64129b402c4b88e, "cid:"); Sa4629d176b019e697b0527efe5a4691f->Sbb776973600322ab316306ef2d275ccf(Sf3b30746b2e126a24a80cf97adbd1cd5(Sa0d162d0c7d63be1d940ba4a2367fc5b)); 
return Sa4629d176b019e697b0527efe5a4691f; }   else { S6d6cbe6673721b1104d6dcb8de7beb6a S3673d3ae2d133274480183500d63f0af; 
 if (Sceac26d97cb4b0c5abb1c8ddd13a9d51("report_directory")) { S3673d3ae2d133274480183500d63f0af = S6d6cbe6673721b1104d6dcb8de7beb6a() 
+ S1f4253318ab0f0441ae748aa810c0f2a("report_directory") + Sfae98e901cdbf1a268ec544cd9457415;   } else 
{ S3673d3ae2d133274480183500d63f0af = Scc2faae6b412ac43b64129b402c4b88e.S01560544b2bb7101848668ad351b8922; 
}     if ((S3673d3ae2d133274480183500d63f0af == "") || (S3673d3ae2d133274480183500d63f0af == Sfae98e901cdbf1a268ec544cd9457415)) 
{ Sa0d162d0c7d63be1d940ba4a2367fc5b.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
Sfae98e901cdbf1a268ec544cd9457415, "/"); S9f4d4ea4917e0ea34880cb67e0e58e66 *Sfe27580179c730ee8bad6cd4294024b1 
= Scbc391abb6d4fdeed1aa169c4ae8906b(Scc2faae6b412ac43b64129b402c4b88e, "?getdirect+"); Sfe27580179c730ee8bad6cd4294024b1->Sbb776973600322ab316306ef2d275ccf(Sa0d162d0c7d63be1d940ba4a2367fc5b); 
   return Sfe27580179c730ee8bad6cd4294024b1; }    if (S3673d3ae2d133274480183500d63f0af != S9fcb91bf6b1d31b4a64256edc0b1bc10) 
{  S6d6cbe6673721b1104d6dcb8de7beb6a Sf385e0e83674d821f90c27f606871c8e = S9fcb91bf6b1d31b4a64256edc0b1bc10 
+ Sa0d162d0c7d63be1d940ba4a2367fc5b; S6d6cbe6673721b1104d6dcb8de7beb6a Sa427b77e4d4cd92e44f249966ef66fb0 
= S3673d3ae2d133274480183500d63f0af + Sa0d162d0c7d63be1d940ba4a2367fc5b;    if (!S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, 
Sf385e0e83674d821f90c27f606871c8e.c_str())) Sc8fe7315c00f47e225c1c57e6680f646(Sa0d162d0c7d63be1d940ba4a2367fc5b, 
"$lang_messages.ERROR_UNKNOWN_FILEREF_FILE"); bool S4265eab7a7d66355ba3a8e8f003beca2 = false;  struct 
Sf1d191eb7ff462ff10706409614a3aa6 S0658760efef5bd20e345a573358b86ef; int S45b57a2c303b51174d515768ecc71764 
= S10f8390ee4fa970520481d00746b4d93(Sa427b77e4d4cd92e44f249966ef66fb0.c_str(), &S0658760efef5bd20e345a573358b86ef); 
if (S45b57a2c303b51174d515768ecc71764 == -1) S4265eab7a7d66355ba3a8e8f003beca2 = true;  else { struct 
Sf1d191eb7ff462ff10706409614a3aa6 S31efa670386e0d40c48874d223f5c4a1; S45b57a2c303b51174d515768ecc71764 
= S10f8390ee4fa970520481d00746b4d93(Sf385e0e83674d821f90c27f606871c8e.c_str(), &S31efa670386e0d40c48874d223f5c4a1); 
if (S0658760efef5bd20e345a573358b86ef.st_mtime < S31efa670386e0d40c48874d223f5c4a1.st_mtime) S4265eab7a7d66355ba3a8e8f003beca2 
= true; }  if (S4265eab7a7d66355ba3a8e8f003beca2) { S4e5ad2e3038f5c0eb0973a77357e2b72(Scc2faae6b412ac43b64129b402c4b88e, 
Sa427b77e4d4cd92e44f249966ef66fb0.c_str(), Sb58c26af62a2dca70604fc8563b509b8("security.server_directory_permissions")); 
S88ff2bee8b51da7041b914b2e85434e5(Scc2faae6b412ac43b64129b402c4b88e, Sf385e0e83674d821f90c27f606871c8e, 
Sa427b77e4d4cd92e44f249966ef66fb0, true);  }  }     S9f4d4ea4917e0ea34880cb67e0e58e66 *Sfe27580179c730ee8bad6cd4294024b1 
= Scbc391abb6d4fdeed1aa169c4ae8906b(Scc2faae6b412ac43b64129b402c4b88e, ""); if (Sceac26d97cb4b0c5abb1c8ddd13a9d51("report_directory")) 
{ Sfe27580179c730ee8bad6cd4294024b1->Sbb776973600322ab316306ef2d275ccf(Sa52d36295bcc64dfaafbb6e2bb321d76); 
} else {  if (Scc2faae6b412ac43b64129b402c4b88e.S94b6bd5981d5c98bc4e8e05e30e3e902.length()) { Sfe27580179c730ee8bad6cd4294024b1->Sbb776973600322ab316306ef2d275ccf(Scc2faae6b412ac43b64129b402c4b88e.S94b6bd5981d5c98bc4e8e05e30e3e902.c_str()); 
}  else { Sfe27580179c730ee8bad6cd4294024b1->Sbb776973600322ab316306ef2d275ccf(Scc2faae6b412ac43b64129b402c4b88e.S8fc611eaf781ee0cc56b64b3b1c9c9aa.c_str()); 
} Sfe27580179c730ee8bad6cd4294024b1->Sbb776973600322ab316306ef2d275ccf(Sa52d36295bcc64dfaafbb6e2bb321d76); 
}  return Sfe27580179c730ee8bad6cd4294024b1; }  return Scbc391abb6d4fdeed1aa169c4ae8906b(Scc2faae6b412ac43b64129b402c4b88e); 
}   void Sb70e8a3e352da4e9f63471a932002c25(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Sb76a29c3706c674b0e811c2fd2e72bb1, muint &S277ea8dca82fb1297dfc55b1857dcfee, muint &S849b078f0a5b333bcc7e90f3a533cce3) 
{ Sa53016ce24e6d991fe9f96344f1f84ba();  
#if 0
  S6d6cbe6673721b1104d6dcb8de7beb6a Seaa450d8ca6853cce675e7051f5ff2c3 = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "WebServerRoot" + Sfae98e901cdbf1a268ec544cd9457415 + "picts" + Sac8114bb0f4643f20e24b476a28d7afe; 
 if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S7a98aeacf055d1948106d42ec2faa521 
== Seaa450d8ca6853cce675e7051f5ff2c3) return;  S6d6cbe6673721b1104d6dcb8de7beb6a S10b3a4fec8fcfd2e40a8624ddb104255 
= Seaa450d8ca6853cce675e7051f5ff2c3 + Sb76a29c3706c674b0e811c2fd2e72bb1; S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa9cf8e8e891a941f7e369de4308713b7 = Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S7a98aeacf055d1948106d42ec2faa521 
+ Sb76a29c3706c674b0e811c2fd2e72bb1;  if (!S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, 
S10b3a4fec8fcfd2e40a8624ddb104255.c_str())) Sc8fe7315c00f47e225c1c57e6680f646(Sb76a29c3706c674b0e811c2fd2e72bb1, 
"$lang_stats.ERROR_UNKNOWN_IMAGE_FILE");  if (!S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, 
Sa9cf8e8e891a941f7e369de4308713b7.c_str())) { FILE *S4e57831dfe5eeb25db31589b08d2fa9d = S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, 
S10b3a4fec8fcfd2e40a8624ddb104255.c_str(), "rb"); FILE *Sb1ea367ec783a4d158c937bc2452d8f1 = S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, 
Sa9cf8e8e891a941f7e369de4308713b7.c_str(), "wb"); while (true) { char S42cd98aae951105e9c10a2f8d5e61d1a 
= fgetc(S4e57831dfe5eeb25db31589b08d2fa9d); if (S42cd98aae951105e9c10a2f8d5e61d1a == EOF) break; fputc(S42cd98aae951105e9c10a2f8d5e61d1a, 
Sb1ea367ec783a4d158c937bc2452d8f1); } Sd33302a1daa8e684f02934fd9419ec83(Scc2faae6b412ac43b64129b402c4b88e, 
S4e57831dfe5eeb25db31589b08d2fa9d, S10b3a4fec8fcfd2e40a8624ddb104255.c_str()); Sd33302a1daa8e684f02934fd9419ec83(Scc2faae6b412ac43b64129b402c4b88e, 
Sb1ea367ec783a4d158c937bc2452d8f1, Sa9cf8e8e891a941f7e369de4308713b7.c_str()); } 
#endif
 } 

