//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S66eda1d40748343c9f453f1b36e168a7
 
#define S66eda1d40748343c9f453f1b36e168a7
 typedef void *S4673665870260a6a927871499a4441fa; class S6f1aca99a9b51fa4524099cdd063162b; class Sc51497dedb5c0712f20ccaa9831c0365; 
typedef void Sd8dc4e17d5d1560eaab0e15042065b71(void *); void S599b74f025e04cd0eaa04cdce33babc6(S4673665870260a6a927871499a4441fa 
S0ffdad806a67ca3d056fc98bc36136a5, int Sa29e8a9db3602caf729ecee3fab209d6); void S3b2e35290544af6997c8f7489ad887b6(S4673665870260a6a927871499a4441fa 
&S0ffdad806a67ca3d056fc98bc36136a5); S4673665870260a6a927871499a4441fa Se0179f6f891be04e60aa506e5f450b27(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sd8dc4e17d5d1560eaab0e15042065b71 *S1a716db23f47491edaab7f33f44a80d1, 
int Sa29e8a9db3602caf729ecee3fab209d6, void *Sc8353b64d6ed55646496b7e7bb8ea712); void S4b7fab3e42860ee3e9bb8fc8faba5725(S4673665870260a6a927871499a4441fa 
S0ffdad806a67ca3d056fc98bc36136a5); void Sd8c67ec4768107c629614b5cde8b0e89(S4673665870260a6a927871499a4441fa 
S0ffdad806a67ca3d056fc98bc36136a5); 
#endif


