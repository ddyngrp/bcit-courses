using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace SplitContainer_Example
{
	class Picture
	{
		private Image image;
		private string description;

		public Picture(Image image, string description)
		{
			this.image = image;
			this.description = description;
		}

		public Image Image { get { return image; } }
		public string Description { get { return description; } }
	}
}
