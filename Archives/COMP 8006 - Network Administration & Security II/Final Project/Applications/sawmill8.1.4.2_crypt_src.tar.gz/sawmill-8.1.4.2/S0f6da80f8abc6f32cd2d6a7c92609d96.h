//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Saf0bf844f7588dd261d4cce06bb36454
 
#define Saf0bf844f7588dd261d4cce06bb36454
 
#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"
 typedef struct { S6d6cbe6673721b1104d6dcb8de7beb6a Sc22377b5b326edb2bea57e372f1c01af; S6d6cbe6673721b1104d6dcb8de7beb6a 
See61a4478409ebe104351f43aff816ef; } S3f876a3a527030d1e1712d2c71750daf; 
#endif


