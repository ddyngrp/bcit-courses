using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace COMP2690.Bank
{
	public partial class MainForm : Form
	{
		List<BankAccount> accounts; 

		public MainForm()
		{
			InitializeComponent();
			accounts = new List<BankAccount>();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			refreshControls();
		}

		private void newToolStripMenuItem_Click(object sender, EventArgs e)
		{
			BankAccount newAccount = new BankAccount(0m);
			accounts.Add(newAccount);

			repopulateAccountsList();
			lstAccounts.SelectedItem = newAccount;
		}

		private void depositToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (lstAccounts.SelectedItem == null) return;

			BankAccount account = lstAccounts.SelectedItem as BankAccount;
			Debug.Assert(account != null);

			SingleValueInputForm dlg = new SingleValueInputForm();
			dlg.MustBeDecimalValue = true;

			dlg.Text = "Deposit";
			dlg.Prompt = "Enter amount";

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				// Assumption: dialog already validated input as a Decimal value.
				decimal amount = decimal.Parse(dlg.Input);

				account.Deposit(amount);
				repopulateAccountsList();
			}

			dlg.Dispose();
		}

		private void withdrawToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (lstAccounts.SelectedItem == null) return;

			BankAccount account = lstAccounts.SelectedItem as BankAccount;
			Debug.Assert(account != null);

			SingleValueInputForm dlg = new SingleValueInputForm();
			dlg.MustBeDecimalValue = true;

			dlg.Text = "Withdrawal";
			dlg.Prompt = "Enter amount";

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				// Assumption: dialog already validated input as a Decimal value.
				decimal amount = decimal.Parse(dlg.Input);

				try
				{
					account.Withdraw(amount);
					repopulateAccountsList();
				}
				catch(NoSufficientFundsException ex)
				{
					MessageBox.Show(
							string.Format("{0}\n\nYour account balance is {1:C}", 
							ex.Message, account.Balance), 
							"Withdrawal Error", MessageBoxButtons.OK, 
							MessageBoxIcon.Exclamation);
				}
			}

			dlg.Dispose();
		}

		private void refreshControls()
		{
			if (lstAccounts.SelectedItem != null)
			{
				BankAccount selectedAcct = lstAccounts.SelectedItem as BankAccount;
				Debug.Assert(selectedAcct != null, "Should have BankAccount objects in the ListBox");

				displayAccount(selectedAcct);

				depositToolStripMenuItem.Enabled
						= withdrawToolStripMenuItem.Enabled
						= true;
			}
			else
			{
				displayAccount(null);

				depositToolStripMenuItem.Enabled
						= withdrawToolStripMenuItem.Enabled
						= false;
			}
		}

		private void repopulateAccountsList()
		{
			lstAccounts.DataSource = null;
			lstAccounts.DataSource = accounts;
		}

		private void displayAccount(BankAccount acct)
		{
			if (acct == null)
			{
				lblAcctBalance.Text = "";
			}
			else
			{
				lblAcctBalance.Text = acct.Balance.ToString("C");
			}
		}

		private void lstAccounts_SelectedIndexChanged(object sender, EventArgs e)
		{
			refreshControls();
		}

		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

	}
}