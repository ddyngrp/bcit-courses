//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Scaba271a79b0191b5664f2609f9e8390
 
#define Scaba271a79b0191b5664f2609f9e8390
 
#include "sconfig.h"

#include "S4251970c545ff7063c10e0ac5324e0d8.h"
 
#if HAVE_NAMESPACES
 typedef std::map<muint, S6d6cbe6673721b1104d6dcb8de7beb6a, std::less<muint> > Sd647ebf64c6ee802286e45cf51452417; 

#else
 typedef map<muint, S6d6cbe6673721b1104d6dcb8de7beb6a, less<muint> > Sd647ebf64c6ee802286e45cf51452417; 

#endif
 
#endif


