/*
 * simple program to test NetworkServer
 */

public class NetworkServerTest
{
  public static void main(String[] args)
  {
	int port = 9998;
	if (args.length > 0)
	  port = Integer.parseInt(args[0]);
	NetworkServer nwserver = new NetworkServer(port, 50);
	nwserver.listen();
  }

}