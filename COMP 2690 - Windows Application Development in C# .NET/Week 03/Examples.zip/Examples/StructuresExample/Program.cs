using System;
using System.Collections.Generic;
using System.Text;

namespace StructuresExample
{
	struct Coordinates
	{
		public int x, y;
	}

	class Program
	{
		static void Main(string[] args)
		{
			Coordinates point;
			point.x = 10;
			point.y = 25;

			Console.WriteLine("Your coordinates are: " 
					+ point.x.ToString() + point.y.ToString());
		}
	}
}


