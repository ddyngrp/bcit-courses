//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#ifndef S4f5b96333401744b84256b205b86f468
 
#define S4f5b96333401744b84256b205b86f468
 
#include "S78ad491ac8a005c50b041106551db851.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class Sc9108e33c10c2d0b84c7e81f13e2c6e9; class Sd6f7c4eabcd2932aa8ec8ebde114ef05; 
class S69ea874c0a8d775fbb8debfe711290ba; class S4219b44ff72461b5d1a084c9fc0c9530; class Sd52d2261900a32d63729ba78632c53b9; 
class S47ee01bdff91de76dc3191e050894bdc { public: S69ea874c0a8d775fbb8debfe711290ba *Sc854ae7450f698921771bd3b6762b4ac; 
S4219b44ff72461b5d1a084c9fc0c9530 *Sf229ce52caf9c7884761b5712e2e7aa3; Sc9108e33c10c2d0b84c7e81f13e2c6e9 
*S857cc7f32fd834a869bbdb40f21041d7; S6d6cbe6673721b1104d6dcb8de7beb6a S63c35b026d2bf50ef83089148c033b69; 
Sd6f7c4eabcd2932aa8ec8ebde114ef05 *Sd67adcbe037dbfc50e19e91c3ba2c175; mint Sc112e445a5825ac3fdcb764ada5fdaea; 
muint S355c08222dee629cb3fa542f8e778585; muint *Sf3692b4d9c644ff1df5680b514340236; muint S576e10880f2d7aef2d9620ea07c34efc; 
 bool S111427314ac071f7d8bb3cdebca0f21a; S47ee01bdff91de76dc3191e050894bdc(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S69ea874c0a8d775fbb8debfe711290ba *S74e4a7f1eda412d1c4bfbca2ac2a0bd1, 
Sd6f7c4eabcd2932aa8ec8ebde114ef05 *S9730c2c069ec5c88c9396062b2964933, mint S9f12980884ca76febb580cc62c89e22c, 
bool S1b121bda95d5c5b4de6478cc12636d27); ~S47ee01bdff91de76dc3191e050894bdc(void);  muint S3ba8d7fd4ebfc8d7b7b8f255ed720c1d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058);   void 
S04732181a94655a3d0ccc488ef53049b(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058); void Sf9b02907e35f1eeb0fd7e005fa22ce24(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sd52d2261900a32d63729ba78632c53b9 **S7dcdf06bdfeb1ea43726851371254547, 
mint *S023522ef2120a8a248f096d2edf22690, unsigned char *S3676d63255376e1f324f2aa778beb0f8, Sd52d2261900a32d63729ba78632c53b9 
**Seb3e4054b7dfb85e09318bb7f3a19358, const unsigned char *Sc8544fed9d4f29a769bdcf028e98ef16);  void 
Se4647eff92ea1607560c91e3a88dd7e2(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
Sc9108e33c10c2d0b84c7e81f13e2c6e9 *S5e47a0171a6c5ebafcc9100650219a6e, unsigned char *S1e4a08dbbbb80e28b68408c0b2bd84d7, 
Sd52d2261900a32d63729ba78632c53b9 **S08cb02682f834cc4052b2976f44292df, const unsigned char *Sc8544fed9d4f29a769bdcf028e98ef16, 
mint **Sc2549d98f8f9dfbf56d623e3d06bb03e = NULL);                  };  
#endif
 
#endif


