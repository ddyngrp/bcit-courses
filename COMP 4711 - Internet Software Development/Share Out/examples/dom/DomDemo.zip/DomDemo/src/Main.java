/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import org.jdom.*;
import org.jdom.input.SAXBuilder;
import java.util.*;

/*
 * Demonstrate the same thing as SaxyDemo, but using DOM processing..
 *
 * We have a database of medical article citations (medsamp2008.xml),
 * and want to produce a list of articles published in 1999 (or some arbitrary year).
 * The publication date is inside a Year element, but Year elements are nested
 * inside several other elements (DateCreated, DateCompleted, DateRevised and PubDate).
 *
 */
public class Main {

    public static int YEARSOUGHT = 1999;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        int count = 0;
        SAXBuilder saxobj = new SAXBuilder();
        Document doc = saxobj.build("./medsamp2008.xml");
        Element root = doc.getRootElement();
        List citations = root.getChildren("MedlineCitation");
        for (Object c : citations) {
            Element e = (Element) c;
            List articles = e.getChildren("Article");
            for (Object c2 : articles) {
                Element article = (Element) c2;
                Element journal = article.getChild("Journal");
                String pubName = journal.getChildText("Title");
                String articleTitle = article.getChildText("ArticleTitle");
                Element pubDate = journal.getChild("JournalIssue").getChild("PubDate");
                int pubYear = 0;
                try {
                    pubYear = Integer.parseInt(pubDate.getChildText("Year"));
                } catch (NumberFormatException nfe) {
                }
                String pubMonth = pubDate.getChildText("Month");
                String datePublished = pubMonth + pubYear;
                if (pubYear == YEARSOUGHT) {
                    System.out.println(articleTitle + " (" + datePublished + " - " + pubName + ")");
                    count++;
                }
            }
        }
        System.out.println("" + count + " articles found");

    }
}
