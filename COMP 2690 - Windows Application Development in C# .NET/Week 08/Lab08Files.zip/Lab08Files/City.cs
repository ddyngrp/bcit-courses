using System;
using System.Collections.Generic;
using System.Text;

namespace Solution
{
	class City
	{
		private string name;
		private long population;

		public City(string name, long population)
		{
			this.name = name;
			this.population = population;
		}

		public string Name { get { return name; } }
		public long Population { get { return population; } }

		public override string ToString()
		{
			return Name;
		}
	}
}
