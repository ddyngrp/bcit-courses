import lejos.nxt.*;
public class  Wave
{
	public static void main(String[] args) throws Exception
	{
		Motor.A.forward();
		Motor.B.forward();
		Thread.sleep(5000);
		Motor.B.stop();
		Motor.A.forward();
		Thread.sleep(300);
		Motor.A.forward();
		Motor.B.forward();
		Thread.sleep(1000);
		Motor.A.stop();
		Motor.B.forward();
		Thread.sleep(200);
		Motor.A.forward();
		Motor.B.forward();
		Thread.sleep(3400);
		Motor.B.setSpeed(750);
		Motor.A.stop();
		Motor.B.forward();
		Thread.sleep(1300);
		Motor.A.forward();
		Motor.B.forward();
		Thread.sleep(5000);
	}
}
