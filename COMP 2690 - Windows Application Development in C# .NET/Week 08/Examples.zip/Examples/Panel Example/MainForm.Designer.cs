namespace Panel_Example
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.pnlFileAccess = new System.Windows.Forms.Panel();
			this.txtFile = new System.Windows.Forms.TextBox();
			this.btnBrowseForFile = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.chkReadOnly = new System.Windows.Forms.CheckBox();
			this.chkEnableFileAccess = new System.Windows.Forms.CheckBox();
			this.pnlFileAccess.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOK.Location = new System.Drawing.Point(137, 98);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 0;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.Location = new System.Drawing.Point(218, 98);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 1;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// pnlFileAccess
			// 
			this.pnlFileAccess.Controls.Add(this.chkReadOnly);
			this.pnlFileAccess.Controls.Add(this.label1);
			this.pnlFileAccess.Controls.Add(this.btnBrowseForFile);
			this.pnlFileAccess.Controls.Add(this.txtFile);
			this.pnlFileAccess.Location = new System.Drawing.Point(12, 34);
			this.pnlFileAccess.Name = "pnlFileAccess";
			this.pnlFileAccess.Size = new System.Drawing.Size(271, 45);
			this.pnlFileAccess.TabIndex = 2;
			// 
			// txtFile
			// 
			this.txtFile.Location = new System.Drawing.Point(35, 1);
			this.txtFile.Name = "txtFile";
			this.txtFile.Size = new System.Drawing.Size(204, 20);
			this.txtFile.TabIndex = 0;
			// 
			// btnBrowseForFile
			// 
			this.btnBrowseForFile.Location = new System.Drawing.Point(245, 0);
			this.btnBrowseForFile.Name = "btnBrowseForFile";
			this.btnBrowseForFile.Size = new System.Drawing.Size(26, 20);
			this.btnBrowseForFile.TabIndex = 1;
			this.btnBrowseForFile.Text = "...";
			this.btnBrowseForFile.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(3, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(26, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "&File:";
			// 
			// chkReadOnly
			// 
			this.chkReadOnly.AutoSize = true;
			this.chkReadOnly.Location = new System.Drawing.Point(165, 27);
			this.chkReadOnly.Name = "chkReadOnly";
			this.chkReadOnly.Size = new System.Drawing.Size(74, 17);
			this.chkReadOnly.TabIndex = 4;
			this.chkReadOnly.Text = "&Read only";
			this.chkReadOnly.UseVisualStyleBackColor = true;
			// 
			// chkEnableFileAccess
			// 
			this.chkEnableFileAccess.AutoSize = true;
			this.chkEnableFileAccess.Location = new System.Drawing.Point(12, 11);
			this.chkEnableFileAccess.Name = "chkEnableFileAccess";
			this.chkEnableFileAccess.Size = new System.Drawing.Size(59, 17);
			this.chkEnableFileAccess.TabIndex = 5;
			this.chkEnableFileAccess.Text = "&Enable";
			this.chkEnableFileAccess.UseVisualStyleBackColor = true;
			this.chkEnableFileAccess.CheckedChanged += new System.EventHandler(this.chkEnableFileAccess_CheckedChanged);
			// 
			// MainForm
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(295, 126);
			this.Controls.Add(this.chkEnableFileAccess);
			this.Controls.Add(this.pnlFileAccess);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.btnCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Panel Example";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.pnlFileAccess.ResumeLayout(false);
			this.pnlFileAccess.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Panel pnlFileAccess;
		private System.Windows.Forms.Button btnBrowseForFile;
		private System.Windows.Forms.TextBox txtFile;
		private System.Windows.Forms.CheckBox chkReadOnly;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox chkEnableFileAccess;
	}
}

