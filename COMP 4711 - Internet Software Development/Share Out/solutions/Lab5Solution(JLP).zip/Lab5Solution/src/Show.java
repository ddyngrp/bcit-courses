import java.util.*;
import org.jdom.*;
import org.jdom.input.*;
import java.io.*;

/**
     * ADT kinda class for a Show.
     * This makes the tvdata processing easier, but doesn't necessarily help the BBC processing.
     */
    public class Show {

        public String title;
        public String description;
        public int startsAt;
        public int endsAt;
        public String key;
        public String value;
        public Element source;

        public Show() {
        }

        public Show(Object x) {
            source = (Element) x;
            title = source.getChildText("title");
            description = source.getChildText("desc");
            String startCode = source.getAttributeValue("start");
            String endCode = source.getAttributeValue("stop");
            try {
                startsAt = Integer.parseInt(startCode.substring(8, 10));
                endsAt = Integer.parseInt(endCode.substring(8, 10));
            } catch (NumberFormatException nfe) {
                System.out.println("*** Error parsing program time attribute :(");
            //return; ignoring the error; assume midnite start; fix later
            }
            key = "" + startCode.substring(8, 10) + ":" + startCode.substring(10, 12) +
                    "-" + endCode.substring(8, 10) + ":" + endCode.substring(10, 12);
            value = title + " (" + description + ")";
        }

        /**
         * Determine if this show falls inside a specific viewing window
         */
        public boolean fallsInside(int windowStart, int windowEnd) {
            return (((startsAt >= windowStart) && (startsAt < windowEnd)) ||
                    ((endsAt > windowStart) && (endsAt <= windowEnd)));
        }
    }
