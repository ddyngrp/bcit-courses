/*
 * Model for an NHL division in a conference.
 * 
 * @author  Jim Parry
 */
package model;

import java.util.*;

public class Division {

    /** Division name */
    private String name = null;
    /** Map of the teams in the division */
    private SortedMap<String, Team> teams = null;
    /** The conference this division is in */
    private Conference conf = null;

    /** Convenience constructor */
    public Division(String name) {
        this.name = name;
        teams = new TreeMap<String, Team>();

    }

    /** Add a team to the division */
    public void add(Team team) {
        teams.put(team.getId(), team);
        team.setDivision(this);
        if (conf != null) {
            team.setConference(conf);
        }
    }

    /** Accessor for the division name */
    public String getName() {
        return name;
    }

    /** Accessor for the teams in the division */
    public SortedMap<String, Team> getTeams() {
        return teams;
    }

    /** Accessor for the division's conference */
    public Conference getConference() {
        return conf;
    }

    /** Mutator for the division's conference */
    public void setConference(Conference conf) {
        this.conf = conf;
        for (Team t : teams.values()) {
            t.setConference(conf);
        }
    }
}
