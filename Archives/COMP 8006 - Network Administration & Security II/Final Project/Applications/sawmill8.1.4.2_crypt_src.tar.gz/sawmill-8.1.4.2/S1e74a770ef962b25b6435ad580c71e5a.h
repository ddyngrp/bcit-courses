//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sbe1329837d4fb63484172133e75d2a1d
 
#define Sbe1329837d4fb63484172133e75d2a1d
 enum S4388f3bb63b9469ddbe629c458f0bde0 { Scca8a01913e53d1acc0c7065a3521744 = 0, Sff1ecf939b768ebe24c2929e8dc46582 
= 0, S73ef288f031afe578381b32889a98d32, Sad2fa7bff65dce7c6e9e49a446b09718, Sa5aa15bf25c8554468f4391137f21b86, 
S3eb79b1d3d588ec798c22bb8d06f5644, Se3026c321f0eb2d951d421003aee215c, Sa0d5e5309cdd11677d51c94912ddf3e0, 
S8a11244d85152ecf62245e96b5da7fdd, S5111d1aebca0c1774721a96817d1d3d1, S70014a87e58d9fafb8db1eb1fb1e7ad5, 
S1ea63fdead88de2267a54deb2eb078fa, S784f1242754e79557e0308fbd3d22206, Se84dbb85ecf98cde1fe7580e43115737, 
S600f9a0ab781d50a686e59165940506b, S92c28715f58faaeef93ca70ea8544c41, S9d5ddd2ae37d62e5fa6b1b2dac7ac2a9, 
S12b338f57d5efe65ea074e177aba2dbe, Sf4039e3ecad8d5018b84595b63c825bc, S8a3a6705b632d4d9524e33d0b42216e3, 
S9b531c4b258056a51d40e265a42d19c6, Sfae179642b6a9c72635c62a3ea7c4594, Sa54f9744f99615afd9243efe42602cea, 
S57fecd9096f970b1c38b2a34cc5532ea, S5f9221f67f2d1ddc8cf5a6c66218358d, S1420554fa018dc7d35c01038c34d93d0, 
S9a80e15f6364c36060cb92118e75c19c, S72c8909c5d3d79fa94faae6569c9d566, S820f630946304b5bfb9e17fcd74b8dd3, 
S48ebfd976efdc3a9c5c790644fd918cc, S7993398f612b68a9ea5dde97d8ebc3fe, Sd43a9a4aed6068f682906bb0103b616a, 
S834d680305a3eb8318b7e4cd14cb7bde, S224a505db1a16d87994b21dd33f3255d, Sc125f8d7f4dc814bad6c14fc398eb286, 
S694b1fe0b438bdca68361052b7b4ae32, Sb409072ba4061c75281ee9abd71a7b1e, S3083dbaecbccf30ee35247141d4f6692, 
S24bf758665888a0a70f6f2b9cf444f1f, Sf4bc4475bba9db7f6b627e376a1d9ac5, S23d05b6a13dba5e1cb6317d864f521f8, 
S97b842689c0b2c96cffc43ba557a3dfb, S69db65c67279774a2ac2aa1a2f16ce37 }; enum Sb742a45ae8e0a530b7a8d470d5b959d4 
{ Sb59bb68115ffa54a636ef7775f6819dd = 0, Sb044588ec09822b8f2e850a5461da106 = 0, S157f5cf7290119ff5c2e08aeba036fd6, 
S2dcbdd4b778df46d9f70a1a2cc07cb52, Sd5c4b9edb13f58598c4d8bd7bccb0f53, S2ca217250c503ea89c99608bb474bc54, 
 S08a7d8c43f6b6b257668802e221788fd, S3af95c68a7c71f4367bae4c37eada331, S815cd792ec215a8c0c200de198ddde81, 
S9a56bed96709477711445efaec76553e, Sd9a95bf0892b28bb09b7bf58ca93bed8, S63df83449b5ec40d08780b10f6850752, 
Sfb5560a15585c16776f1cc9d09818d48, S65a41c646bb20fd5701328ef2a3bfcb8, S225dfba4a29a182087e03b36fabbe0f2, 
S2db1e7eff6e7513b8fd169270c39b5ef,  Sdf4ed4d0c989996b29f4adbd1e8a3f43, Se0a5e2826f7c509ec2b958e276c9d59e, 
Se5c740d230aa9a362245433b854e055c, S36cf222f0430c58e30062e773a755736, S6d558342c8b0f8e741a467deae56bef1, 
S34d895da04f693412822c142c81d1769 }; 
#endif


