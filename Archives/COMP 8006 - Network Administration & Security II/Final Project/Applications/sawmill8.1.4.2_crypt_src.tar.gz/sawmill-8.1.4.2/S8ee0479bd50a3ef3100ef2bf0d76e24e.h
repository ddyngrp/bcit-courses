//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S9e2b79e42c4e61a0c510a3ab58d97043.h"
 
#ifdef HAVE_SQL
 
#include "S03bd42fa450e1f34accdab3519aa18f4.h"
 
#if HAVE_MYSQL
 
#include <mysql.h>

#endif
 
#if HAVE_ODBC
 
#include "S9e50772f407b906c9724d2a538d20b09.h"

#endif
 class Sa4cedc2a80e8808f9cdb167bbe571595; class Se39f63263396b6c01848402768749342; class S6ebd5941df466d9a1c9cc8263c03ef42; 
class Sf5a0553be469ff5d55bd2696158f5cb6 { private: Sc51497dedb5c0712f20ccaa9831c0365 *S39bf07e90ddd32c11a6ea142c0b9f7c0; 

#if HAVE_MYSQL
 Sf5a0553be469ff5d55bd2696158f5cb6(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
Sa4cedc2a80e8808f9cdb167bbe571595 *S83262ae0fa48e0f26c95f2f3bb5adb90, MYSQL_RES *S4fda5ae047165f197582065c9de0c91f); 
MYSQL_RES *S8f692a70087d9431e79bd2cdb86d289f; vector<S6d6cbe6673721b1104d6dcb8de7beb6a> Sf34b1e007b8627d55800c10c8a269632; 

#endif
 
#if USE_ODBC
 Sf5a0553be469ff5d55bd2696158f5cb6(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
Sa4cedc2a80e8808f9cdb167bbe571595 *S83262ae0fa48e0f26c95f2f3bb5adb90, HSTMT S43b17cf6038e6c30cd2d00beb01189da); 
SWORD Sd7b6e917ba18bb4d177d08673f0e6867; SWORD S52e2dfe22be87e2c1ce7114dad50c143; vector<S6d6cbe6673721b1104d6dcb8de7beb6a> 
Seded4033c7cfff1b0241c4e36c92eec8; 
#endif
 void S0764ad0545f517f5a6d8b19a181a41a1(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
Sf5a0553be469ff5d55bd2696158f5cb6(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
S6ebd5941df466d9a1c9cc8263c03ef42 *S988503e511c779f27e7de8bc2bd561bc); S6ebd5941df466d9a1c9cc8263c03ef42 
*S8c9414a871dc763296b033d2b2c1cbfd; muint S2e387b1b570e67d9fff174a12b9c0d26; S6c43f7b20963646dd7166569cdf65b11 
Sa7ff450b865f542bb9879436afa42160; Sa4cedc2a80e8808f9cdb167bbe571595 *S83262ae0fa48e0f26c95f2f3bb5adb90; 
 Se39f63263396b6c01848402768749342 *Sf1bb612fb103904163f3361e636db355; Se39f63263396b6c01848402768749342 
*Seec78c29259691b37970dec300fea692; S6d6cbe6673721b1104d6dcb8de7beb6a S802c9c3265fb1ae44b56b6f5b2475ae3; 
public: ~Sf5a0553be469ff5d55bd2696158f5cb6(void);  muint S0a8b92622f4630c264f0d505c34165d1(void); const 
char * Sa0c2f939d9208baccbd495e8547659a6(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
muint Sc3fba26389af88d3c0c66ea0757527ac); Se39f63263396b6c01848402768749342 *S2a08eb885d4113751fe7b94847acf2dc(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); S6c43f7b20963646dd7166569cdf65b11 Sbe1cba700a451a693ddb17424fbccddf(void) 
{ return Sa7ff450b865f542bb9879436afa42160; } S6d6cbe6673721b1104d6dcb8de7beb6a S231d7e9def80e60e25c7004b5910eb09(void) 
{ return S802c9c3265fb1ae44b56b6f5b2475ae3; } 
#if USE_ODBC
 HSTMT S43b17cf6038e6c30cd2d00beb01189da; 
#endif
 friend class Sa4cedc2a80e8808f9cdb167bbe571595; };  
#endif


