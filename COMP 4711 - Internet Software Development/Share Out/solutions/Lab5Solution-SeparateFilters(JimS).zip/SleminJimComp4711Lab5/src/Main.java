
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;
import org.jdom.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import org.jdom.input.SAXBuilder;

/**
 *
 * @author jim
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        who();
        when();
        where();
    }
    
    /**
     * Display the title & description of all Dr Who shows on BBC3.
     * How many shows of the total shown on BBC3 pertain to Dr Who?
     * Use the *title* element to test.
     */
    public static void who() {
        int whoCount = 0;
        int totCount = 0;
        //System.out.println("? of ? shows on BBC3 pertain to Dr Who");

        Document doc = null;

        SAXBuilder sb = new SAXBuilder();

        try {
            doc = sb.build(new File("data/bbc3.xml"));
        }
        catch (JDOMException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
        List progs = doc.getRootElement().getChildren("programme");

        totCount = progs.size();
        
        System.out.println("### Doctor Who Programmes ###");
        System.out.println();

        for (Iterator iter=progs.iterator(); iter.hasNext(); ) {
            Element prog = (Element) iter.next();

            if(!prog.getContent(new WhoFilter()).isEmpty())
            {
                System.out.println(prog.getChildText("title"));
                System.out.println(prog.getChildText("desc"));
                System.out.println();
                whoCount++;
            }
        }
        
        System.out.println("Found " + whoCount + " out of " + totCount + " Programmes");
        System.out.println();
    }
    
    /**
     * Display the title, description & air time of all shows on between 8 & 11pm (local time) on TVDATA.
     * Order the display by air time, so it looks like a real schedule
     */
    public static void when() {
        Document doc = null;

        SAXBuilder sb = new SAXBuilder();

        try {
            doc = sb.build(new File("data/tvdata.xml"));
        }
        catch (JDOMException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
        List progs = doc.getRootElement().getContent(new TimeFilter());
        
        TreeSet<Program> ts = new TreeSet<Program>();

        for (Iterator iter=progs.iterator(); iter.hasNext(); ) {
            Element e = (Element)iter.next();
            Program p = new Program();
            
            p.setStartDate(e.getAttributeValue("start"));
            p.setEndDate(e.getAttributeValue("stop"));
            p.setTitle(e.getChildText("title"));
            p.setDesc(e.getChildText("desc"));
            
            ts.add(p);
        }
        
        System.out.println("### 8-11 Programmes ###");
        System.out.println();
        
        for (Iterator iter=ts.iterator(); iter.hasNext(); ) {
            ((Program)iter.next()).print();
        }
    }
    
    /**
     * Display the title, description & air time of all news shows on TVDATA.
     * Use the category element to determine these.
     */
    public static void where() {
        Document doc = null;

        SAXBuilder sb = new SAXBuilder();

        try {
            doc = sb.build(new File("data/tvdata.xml"));
        }
        catch (JDOMException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
        List progs = doc.getRootElement().getContent(new NewsFilter());
        
        TreeSet<Program> ts = new TreeSet<Program>();

        for (Iterator iter=progs.iterator(); iter.hasNext(); ) {
            Element e = (Element)iter.next();
            Program p = new Program();
            
            p.setStartDate(e.getAttributeValue("start"));
            p.setEndDate(e.getAttributeValue("stop"));
            p.setTitle(e.getChildText("title"));
            p.setDesc(e.getChildText("desc"));
            
            ts.add(p);
        }
        
        System.out.println("### News Programmes ###");
        System.out.println();
        
        for (Iterator iter=ts.iterator(); iter.hasNext(); ) {
            ((Program)iter.next()).print();
        }
    }



}
