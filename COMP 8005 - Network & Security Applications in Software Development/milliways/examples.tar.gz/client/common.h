#ifndef _common_h
#define _common_h

#ifndef _client_h
#define _client_h

#include <stdlib.h>
#include <errno.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <signal.h>

#include <openssl/ssl.h>

#define CA_LIST         "root.pem"
#define HOST	   "localhost"
#define RANDOM        "random.pem"
#define PORT	    4433
#define BUFSIZZ          1024
#define TRUE               1
#define KEYFILE         "client.pem"
#define PASSWORD    "password"

extern BIO *bio_err;
int berr_exit (char *string);
int err_exit(char *string);

// Function Prototypes
SSL_CTX *initialize_ctx(char *keyfile, char *password);
void destroy_ctx(SSL_CTX *ctx);
void check_cert_chain (SSL *ssl, char *host);


#endif
#endif


