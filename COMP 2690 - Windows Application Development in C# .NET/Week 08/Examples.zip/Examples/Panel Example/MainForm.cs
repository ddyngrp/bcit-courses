using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Panel_Example
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			refreshControls();
		}

		private void chkEnableFileAccess_CheckedChanged(object sender, EventArgs e)
		{
			refreshControls();
		}

		private void refreshControls()
		{
			// Instead of disabling individual controls one-by-one
			// one can disable the panel, which disables all of the
			// control inside it.
			pnlFileAccess.Enabled = chkEnableFileAccess.Checked;
		}

	}
}