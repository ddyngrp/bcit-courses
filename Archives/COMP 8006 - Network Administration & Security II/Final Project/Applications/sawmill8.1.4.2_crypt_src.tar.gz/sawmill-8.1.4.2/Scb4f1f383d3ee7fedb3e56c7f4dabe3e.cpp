//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Scb4f1f383d3ee7fedb3e56c7f4dabe3e.h"

#include "Saccf68946c4b856ecacc27fdabbead0a.h"
  Sa55220e5099e8b1396b7c10181565148::Sa55220e5099e8b1396b7c10181565148(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S11502692d5c8b57bd211f972305b99fc *S60283a425cf987277e107f9b3baaaa7e, 
const char *Sb894a78d15d8e54b8299ddeb20bcc683, colnum_t Scee000c40d4a67cada9ac44e32b8a412, bool S895b58063c5f85665fca3f660ee6933b) 
{ S1a14215d7a9ed417e57c419037ad81b9 = S60283a425cf987277e107f9b3baaaa7e; S5ff35a91b07a476d5fb57059d1fe566d 
= Sb894a78d15d8e54b8299ddeb20bcc683; S8d119e3f5b4e0cec96d879952cc4fa84 = Scee000c40d4a67cada9ac44e32b8a412; 
Sfeb06f9a635180a72bfb22e7da93f878 = S895b58063c5f85665fca3f660ee6933b; }   Sa55220e5099e8b1396b7c10181565148::~Sa55220e5099e8b1396b7c10181565148(void) 
{ } 

