/*
 * Model for the "static" data in the NHL, namely the league conferences,
 * which contain divisions, which contain teams.
 * 
 * This data is made available so you have an opportunity to practice
 * JSPs without XML.
 *
 * @author Jim Parry
 */
package model;

import java.util.*;

public class Model {

    /** Singleton instance */
    private static Model instance = null;
    /** Map to hold the league conferences */
    private SortedMap<String, Conference> league = null;

    /** 
     * No argument constructor .
     * The "database" is populated by hard-coded statements.
     */
    private Model() {
        league = new TreeMap<String, Conference>();

        Conference eastern = new Conference("Eastern");

        Division div = new Division("Atlantic");
        div.add(new Team("penguins", "Pittsburgh", "Penguins"));
        div.add(new Team("devils", "New Jersey", "Devils"));
        div.add(new Team("flyers", "Philadelphia", "Flyers"));
        div.add(new Team("penguins", "Pittsburgh", "Penguins"));
        div.add(new Team("islanders", "New York", "Islanders"));
        eastern.add(div);

        div = new Division("Northeast");
        div.add(new Team("senators", "Ottawa", "Senators"));
        div.add(new Team("canadiens", "Montréal", "Canadiens"));
        div.add(new Team("bruins", "Boston", "Bruins"));
        div.add(new Team("sabres", "Buffalo", "Sabres"));
        div.add(new Team("mapleleafs", "Toronto", "Maple Leafs"));
        eastern.add(div);

        div = new Division("Southeast");
        div.add(new Team("capitals", "Washington", "Capitals"));
        div.add(new Team("hurricanes", "Carolina", "Hurricanes"));
        div.add(new Team("thrashers", "Atlanta", "Thrashers"));
        div.add(new Team("panthers", "Florida", "Panthers"));
        div.add(new Team("lightning", "Tampa Bay", "Lightning"));
        eastern.add(div);

        league.put(eastern.getName(), eastern);

        Conference western = new Conference("Western");
        div = new Division("Central");
        div.add(new Team("redwings", "Detroit", "Red Wings"));
        div.add(new Team("predators", "Nashville", "Predators"));
        div.add(new Team("bluejackets", "Columbus", "Blue Jackets"));
        div.add(new Team("blues", "St Louis", "Blues"));
        div.add(new Team("blackhawks", "Chicago", "Blackhawks"));
        western.add(div);

        div = new Division("Northwest");
        div.add(new Team("wild", "Minnesota", "Wild"));
        div.add(new Team("avalanche", "Colorado", "Avalanche"));
        div.add(new Team("flames", "Calgary", "Flames"));
        div.add(new Team("canucks", "Vancouver", "Canucks"));
        div.add(new Team("oilers", "Edmonton", "Oilers"));
        western.add(div);

        div = new Division("Pacific");
        div.add(new Team("stars", "Dallas", "Stars"));
        div.add(new Team("sharks", "San Jose", "Sharks"));
        div.add(new Team("ducks", "Anaheim", "Ducks"));
        div.add(new Team("coyotes", "Phoenix", "Coyotes"));
        div.add(new Team("kings", "Los Angeles", "Kings"));
        western.add(div);

        league.put(western.getName(), western);

    }

    /** Singleton factory method */
    public static Model getInstance() {
        if (instance == null) {
            instance = new Model();
        }
        return instance;
    }

    /** Accessor for the league "database" */
    public SortedMap getLeague() {
        return league;
    }
}
