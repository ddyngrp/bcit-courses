/*
 * MediaNode.java
 *
 * MLogger, 2008
 * Confidential and proprietary.
 */
 package src;
class MediaNode {
    
    /**
     * The previous node in the list.
     */
    private MediaNode prev;
    
    /**
     * The next node in the list.
     */
    private MediaNode next;
    
    /**
     * The MediaItem attached to this node.
     */
    private MediaItem item;
    
    /**
     * Constructor
     * @param prev The previous node in the list.
     * @param item The MediaItem to hold.
     * @param next The next node in the list.
     */
    MediaNode(MediaNode prev, MediaItem item, MediaNode next) {
        this.prev = prev;
        this.item = item;
        this.next = next;
    }
    
    /**
     * Constructor
     * @param item The MediaItem to hold.
     */
    MediaNode(MediaItem item) {
        this.prev = null;
        this.item = item;
        this.next = null;
    }
    
    /**
     * Sets the previous node (used for deleting nodes).
     * @param prev The new previous node.
     */
    public void prev(MediaNode prev) {
        this.prev = prev;
    }
    
    /**
     * Sets the next node (used for deleting nodes).
     * @param next The new next node.
     */
    public void next(MediaNode next) {
        this.next = next;
    }
    
    /**
     * Returns the previous node.
     * @return The previous node.
     */
    public MediaNode prev() {
        return this.prev;
    }
    
    /**
     * Returns the next node.
     * @return The next node.
     */
    public MediaNode next() {
        return this.next;
    }
    
    /**
     * Gets the associated MediaItem
     * @return The associated MediaItem.
     */
    public MediaItem item() {
        return this.item;
    }
    
    /**
     * Deletes the node (and updates the prev/next nodes' pointers).
     */
    public void delete() {
        if (this.prev != null)
            this.prev.next(this.next);
        if (this.next != null)
            this.next.prev(this.prev);
        this.item.delete();
    }
}
