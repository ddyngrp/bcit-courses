import java.util.ArrayList;
import java.util.Iterator;

/**
 * COMP 1409 final assignment. This is a very simple Blackjack game that does not involve betting. 
 * It is meant to be played by a single player and no dealer but could easily be extended to make it more
 * like a real Blackjack game.
 * The Game class manages the other classes that make up the application. This class has several
 * constants defined, and several suggested fields. You will need others. The play() method is 
 * what will start the game. Some private helper methods are suggested. You will need others.
 * 
 * @author Colleen Penrowley 
 * @version Fall 2005, revised Winter 2006, revised Fall 2006)
 */
public class Game
{
   /** Suggested constants for use throughout the game. To use one of these in another class, specify 
    * the Game class first, e.g. Game.ACE_LOW_VALUE.
    */
    public static final int ACE_LOW_VALUE = 1;      // bottom value for ace
    public static final int ACE_HIGH_VALUE = 11;    // top value for ace
    public static final int BLACKJACK = 21;         // instant win - to go over is to lose
  
    /* Some suggested fields */
    private Deck deck;                              // a deck of cards
    private InputReader reader;                     // keyboard reader
    private ArrayList<Card> hand;                   // the cards the player is holding
    
    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        // initialize fields
    }
    
  
    /**
     * This method holds the game logic. The user is repeatedly 
     * prompted to play another round. When the user has chosen to stop 
     * playing, the final tally of wins and losses is reported.
     * 
     */
    public void play()
    {

    }
    
    
    /*
     * Deal one card from the deck and put it into the player's hand.
     */
    private void dealCard()
    {
        // deal card to player
    }
    
   /*
    * Play out the player's turn.
    * The player may choose to hit or stand, unless the player's
    * cards total more than BLACKJACK, in which case the player
    * is "busted".
    */ 
    private void playerTurn()
    {
        // player's turn
        // an example of how to use the reader object:
        System.out.print("Your choice: hit or stand? ");
        String response = reader.readInputLine().trim().toLowerCase();
        if (response.equals("hit")) {// process response
        }
    }
    
     /*
     * Calculates and returns the value of the hand. An ace is worth ACE_HIGH_VALUE
     * unless it would cause a "bust", in which case it is worth ACE_LOW_VALUE.
     */
    private int getHandValue()
    {
        // calculate and return hand value
        return 0;      
    }
 
     /*
     * Shows the cards in the player's hand.
     */
    private void showHand()
    {
        System.out.println("your cards:");
        // show the cards
        System.out.println(); // blank line
    }
    
}

