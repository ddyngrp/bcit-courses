//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "S230eee6368f43217f41001b19455cd96.h"

#include "S03b4aa5755dc381488543322f8a56e0a.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S17be0f68f5d7d8233d466e33746ac31e.h"

#include "Scf163b9fe5fa9dd8c63f48cfe2ab82d9.h"

#include "S02fcdd96968d06dff4282c0596c3f5c3.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "Sb5a9bba78ccd5d7067282b6d680c50a0.h"

#include "S4355411c09c615a92dd538f6be660c77.h"

#include "Sd5d0864971a099befe0cde8fe198b302.h"
 
#define S3ab547cd176831b2ce519148371b87ea (10*60)
 
#define Sb0a8a8ca2c293896bda02f37a94eb039 1
  void S593b36d51a2ab411e5e4070dd153beeb(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{  if ((S38db5447d45d10d38fcd7373a171791e == NULL) && S3453986fad8ae18a4cddd52a6f55b49e) { S38db5447d45d10d38fcd7373a171791e 
= new S4673665870260a6a927871499a4441fa;  Sa14f2810aa7f7746ebe6af24ad45815a *Sabf3d14fa381d58378e8a24ceab26f58 
= new Sa14f2810aa7f7746ebe6af24ad45815a(); Sc51497dedb5c0712f20ccaa9831c0365 *S81d8023bad0fbdaf41f5784b84eb4712 
= new Sc51497dedb5c0712f20ccaa9831c0365(*Sabf3d14fa381d58378e8a24ceab26f58); Sabf3d14fa381d58378e8a24ceab26f58->Scc2faae6b412ac43b64129b402c4b88e 
= S81d8023bad0fbdaf41f5784b84eb4712; Sabf3d14fa381d58378e8a24ceab26f58->Sb6c28c9017c458b2c958c82f89ccac4a(*S81d8023bad0fbdaf41f5784b84eb4712); 
Sabf3d14fa381d58378e8a24ceab26f58->Sb6c28c9017c458b2c958c82f89ccac4a(*S81d8023bad0fbdaf41f5784b84eb4712); 
S709f8a104a477b9e6883c170d8a6a334(S6c52b36a5530b8c11dc0ab0e4eb17ee0(*S81d8023bad0fbdaf41f5784b84eb4712)); 
 *S38db5447d45d10d38fcd7373a171791e = Se0179f6f891be04e60aa506e5f450b27(*S81d8023bad0fbdaf41f5784b84eb4712, 
Sfb98b4de9b9b04b4122a263ec72417ed, 0, S81d8023bad0fbdaf41f5784b84eb4712); } }   void Sc65b3311b40bdc62b2c128b7490536e9(void) 
{ if (S38db5447d45d10d38fcd7373a171791e) { S4b7fab3e42860ee3e9bb8fc8faba5725(*S38db5447d45d10d38fcd7373a171791e); 
Sd8c67ec4768107c629614b5cde8b0e89(*S38db5447d45d10d38fcd7373a171791e); delete(S38db5447d45d10d38fcd7373a171791e); 
} }   void Sfb98b4de9b9b04b4122a263ec72417ed(void *S6ec129777c16ed8568398f5726365a75) { Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e = *((Sc51497dedb5c0712f20ccaa9831c0365 *) S6ec129777c16ed8568398f5726365a75); 
 while (true) { Sc8915d498d2314d711d0597b98175b2c = time(NULL);  Sdabbc88403786f6343d20582c7688fa2(Scc2faae6b412ac43b64129b402c4b88e, 
true);       { S0881d02b198c217be29da6f81deb98c6 Sb5a5b9f04fdc5a87418207da8752609b(S62c2fb294be1611fda99cf132ad0893a); 
Sf2b7e1c73ff979c548a0a824dbf33f6b(Scc2faae6b412ac43b64129b402c4b88e); }      S13e1dbf4c0a0768b069f6c2af5c30429(Sb0a8a8ca2c293896bda02f37a94eb039); 
}  } 

