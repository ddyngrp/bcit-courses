import lejos.nxt.*;
import lejos.subsumption.*;

public class HitWall3 implements Behavior {
	
   TouchSensor touch1;
   TouchSensor touch2;
   
   public HitWall3()
   {
	   touch1 = new TouchSensor(SensorPort.S3);
	   touch2 = new TouchSensor(SensorPort.S2);
   }
   
   public boolean takeControl() {
      return touch1.isPressed() && touch2.isPressed();
   }

   public void suppress() {
      Motor.A.stop();
      Motor.B.stop();
   }

   public void action() {
      // Back up:
      Motor.A.backward();
      Motor.B.backward();
      try{Thread.sleep(500);}catch(Exception e) {}
	  Motor.A.stop();
      try{Thread.sleep(2000);}catch(Exception e) {}
   }
}


