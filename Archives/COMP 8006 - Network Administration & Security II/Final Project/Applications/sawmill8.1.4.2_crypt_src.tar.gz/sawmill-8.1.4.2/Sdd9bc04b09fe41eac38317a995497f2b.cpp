//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sdd9bc04b09fe41eac38317a995497f2b.h"

#include "Sc854ae7450f698921771bd3b6762b4ac.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#if HAVE_STDLIB_H
 
#include <stdlib.h>

#endif
 
#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"
   
#ifdef USE_TEMP_MEMORY
 typedef struct { S458eeb274cb1cf7a201967c86fa29e20 S738741dad6ddfeb0eb4f282624c86289; muint size; } 
Sa99143ed58d137b2331f4bd30d533435; 
#endif
 
#ifdef S16830aeb3627cf4fa5550c804769f5a4
 typedef struct { void *Saec2f6eb44506ba469d3190ab26c46b4; muint size; S6d6cbe6673721b1104d6dcb8de7beb6a 
S4dd3cd014356e595626141c29c58e748; } Sef1bb8d0e026db2f9caca565916783aa; typedef struct { muint size; 
muint S0a01c142a16168fa48ac8d57ecb0bb2a; } S416b4c33a1d4ab990a9badcf35d1492b; muint Se37b8e044b450a51b654b85e5760a532 
= 0; muint Sef81be3a7a778d8fb3b2c19b361c3ae4 = 0; 
#include "S4251970c545ff7063c10e0ac5324e0d8.h"

#include "Secf36bf903121295607de79adb143b01.h"
Secf36bf903121295607de79adb143b01(Sef1bb8d0e026db2f9caca565916783aa) Sa8934b100c1e0a3bcc67ea2a21ca2d5f; 
S6f1aca99a9b51fa4524099cdd063162b S6273df09ce40f0640cdb4ecf69b2a5ee; void S001a7739bbbd45971b18e5386f06bdfb(void) 
{ S6273df09ce40f0640cdb4ecf69b2a5ee.Obtain(Scc2faae6b412ac43b64129b402c4b88e); S4251970c545ff7063c10e0ac5324e0d8(S6d6cbe6673721b1104d6dcb8de7beb6a, 
S416b4c33a1d4ab990a9badcf35d1492b, less<S6d6cbe6673721b1104d6dcb8de7beb6a>) S0f5b228fb186fa342f350f38800c9005; 
mint S5a9e08df47459288116593d0735508be = 0; mint S61d0714bd0fecd143204b0e1a0b83004 = 0; for (Secf36bf903121295607de79adb143b01(Sef1bb8d0e026db2f9caca565916783aa)::iterator 
Seb9d419135e896279ecc7721147bbd03 = Sa8934b100c1e0a3bcc67ea2a21ca2d5f.begin(); Seb9d419135e896279ecc7721147bbd03!= 
Sa8934b100c1e0a3bcc67ea2a21ca2d5f.end(); Seb9d419135e896279ecc7721147bbd03++) { S0f5b228fb186fa342f350f38800c9005[(*Seb9d419135e896279ecc7721147bbd03).S4dd3cd014356e595626141c29c58e748].size 
+= (*Seb9d419135e896279ecc7721147bbd03).size; S0f5b228fb186fa342f350f38800c9005[(*Seb9d419135e896279ecc7721147bbd03).S4dd3cd014356e595626141c29c58e748].S0a01c142a16168fa48ac8d57ecb0bb2a++; 
S5a9e08df47459288116593d0735508be += (*Seb9d419135e896279ecc7721147bbd03).size; S61d0714bd0fecd143204b0e1a0b83004++; 
} 
#define S3ea00b014bd6669431763eaad9eaf26d cout
 for (S4251970c545ff7063c10e0ac5324e0d8(S6d6cbe6673721b1104d6dcb8de7beb6a, S416b4c33a1d4ab990a9badcf35d1492b, 
less<S6d6cbe6673721b1104d6dcb8de7beb6a>)::iterator Seb9d419135e896279ecc7721147bbd03 = S0f5b228fb186fa342f350f38800c9005.begin(); 
Seb9d419135e896279ecc7721147bbd03!= S0f5b228fb186fa342f350f38800c9005.end(); Seb9d419135e896279ecc7721147bbd03++) 
{ S3ea00b014bd6669431763eaad9eaf26d << "Memory allocated by \"" << (*Seb9d419135e896279ecc7721147bbd03).first 
<< "\": " << (*Seb9d419135e896279ecc7721147bbd03).second.size << " bytes, " << (*Seb9d419135e896279ecc7721147bbd03).second.S0a01c142a16168fa48ac8d57ecb0bb2a 
<< " blocks" << endl; } S3ea00b014bd6669431763eaad9eaf26d << "Total memory allocated: " << S5a9e08df47459288116593d0735508be 
<< endl; S3ea00b014bd6669431763eaad9eaf26d << "Total blocks allocated: " << S61d0714bd0fecd143204b0e1a0b83004 
<< endl; S6273df09ce40f0640cdb4ecf69b2a5ee.Release(Scc2faae6b412ac43b64129b402c4b88e); } 
#endif
  void *S0587c9de6f2f8437f6bd75d24f8145ee(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
size_t size, const char *S4dd3cd014356e595626141c29c58e748, const char *Sa0d162d0c7d63be1d940ba4a2367fc5b, 
muint Se1dd4913bcd5094166b0c5335ee8f49c) { if (size == 0) size = 1;  unsigned char *Saec2f6eb44506ba469d3190ab26c46b4; 
Saec2f6eb44506ba469d3190ab26c46b4 = (unsigned char *) Sdd9bc04b09fe41eac38317a995497f2b(size);  if (Saec2f6eb44506ba469d3190ab26c46b4 
|| (size == 0)) { 
#ifdef S16830aeb3627cf4fa5550c804769f5a4
 S6273df09ce40f0640cdb4ecf69b2a5ee.Obtain(Scc2faae6b412ac43b64129b402c4b88e); Se37b8e044b450a51b654b85e5760a532 
+= size; Scc2faae6b412ac43b64129b402c4b88e.Se37b8e044b450a51b654b85e5760a532 += size; Sef1bb8d0e026db2f9caca565916783aa 
S2f93333d1d66d3a43c166a1aff231631; S2f93333d1d66d3a43c166a1aff231631.S4dd3cd014356e595626141c29c58e748 
= S4dd3cd014356e595626141c29c58e748; S2f93333d1d66d3a43c166a1aff231631.size = size; S2f93333d1d66d3a43c166a1aff231631.Saec2f6eb44506ba469d3190ab26c46b4 
= Saec2f6eb44506ba469d3190ab26c46b4; Sa8934b100c1e0a3bcc67ea2a21ca2d5f.push_back(S2f93333d1d66d3a43c166a1aff231631); 
if (size > 1000) Sef81be3a7a778d8fb3b2c19b361c3ae4++; S6273df09ce40f0640cdb4ecf69b2a5ee.Release(Scc2faae6b412ac43b64129b402c4b88e); 

#endif
 return Saec2f6eb44506ba469d3190ab26c46b4; }   if (S87f7aa029cab5ff8c6886317c4ae7c3a) { S7c0b383f1bacb0c74c82d85031ef3cb8(S87f7aa029cab5ff8c6886317c4ae7c3a); 
S87f7aa029cab5ff8c6886317c4ae7c3a = NULL; } Sd3b844a3dce8722fc71c3c8cadcf3d03(S973f3d3234e49ba97d7dd83d0441216a(Scc2faae6b412ac43b64129b402c4b88e, 
size), S4dd3cd014356e595626141c29c58e748, "$lang_messages.ERROR_OUT_OF_MEMORY2"); return NULL; }  void 
*Sfac441c5c15ab76df4023c1d5af71c5d(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
void *Saec2f6eb44506ba469d3190ab26c46b4, size_t size, const char *S4dd3cd014356e595626141c29c58e748, 
const char *Sa0d162d0c7d63be1d940ba4a2367fc5b, muint Se1dd4913bcd5094166b0c5335ee8f49c) { void *S7182dd9f2773b2ba66629d749aaae0ef 
= NULL;  S7182dd9f2773b2ba66629d749aaae0ef = Se983ffa8f5e980c41b978f6e674e72f1(Saec2f6eb44506ba469d3190ab26c46b4, 
size);  
#ifdef S16830aeb3627cf4fa5550c804769f5a4
 if (S7182dd9f2773b2ba66629d749aaae0ef) { S6273df09ce40f0640cdb4ecf69b2a5ee.Obtain(Scc2faae6b412ac43b64129b402c4b88e); 
if (Saec2f6eb44506ba469d3190ab26c46b4) { bool S50dd31b83e9ee2255d91f8cfbbed073f = false; for (Secf36bf903121295607de79adb143b01(Sef1bb8d0e026db2f9caca565916783aa)::iterator 
Seb9d419135e896279ecc7721147bbd03 = Sa8934b100c1e0a3bcc67ea2a21ca2d5f.begin(); Seb9d419135e896279ecc7721147bbd03!= 
Sa8934b100c1e0a3bcc67ea2a21ca2d5f.end(); Seb9d419135e896279ecc7721147bbd03++) {  if ((*Seb9d419135e896279ecc7721147bbd03).Saec2f6eb44506ba469d3190ab26c46b4 
== Saec2f6eb44506ba469d3190ab26c46b4) { (*Seb9d419135e896279ecc7721147bbd03).Saec2f6eb44506ba469d3190ab26c46b4 
= S7182dd9f2773b2ba66629d749aaae0ef; (*Seb9d419135e896279ecc7721147bbd03).size = size; S50dd31b83e9ee2255d91f8cfbbed073f 
= true; break; } } if (!S50dd31b83e9ee2255d91f8cfbbed073f) { S00d6a0a2d331762dfcf4df377a29d38a(); } 
}  else { Sef1bb8d0e026db2f9caca565916783aa S2f93333d1d66d3a43c166a1aff231631; S2f93333d1d66d3a43c166a1aff231631.S4dd3cd014356e595626141c29c58e748 
= S4dd3cd014356e595626141c29c58e748; S2f93333d1d66d3a43c166a1aff231631.size = size; S2f93333d1d66d3a43c166a1aff231631.Saec2f6eb44506ba469d3190ab26c46b4 
= S7182dd9f2773b2ba66629d749aaae0ef; Sa8934b100c1e0a3bcc67ea2a21ca2d5f.push_back(S2f93333d1d66d3a43c166a1aff231631); 
} S6273df09ce40f0640cdb4ecf69b2a5ee.Release(Scc2faae6b412ac43b64129b402c4b88e); } 
#endif
 if (S7182dd9f2773b2ba66629d749aaae0ef || (size == 0)) return S7182dd9f2773b2ba66629d749aaae0ef;  if 
(S87f7aa029cab5ff8c6886317c4ae7c3a) { S7c0b383f1bacb0c74c82d85031ef3cb8(S87f7aa029cab5ff8c6886317c4ae7c3a); 
S87f7aa029cab5ff8c6886317c4ae7c3a = NULL; } Sd3b844a3dce8722fc71c3c8cadcf3d03(S973f3d3234e49ba97d7dd83d0441216a(Scc2faae6b412ac43b64129b402c4b88e, 
size), S4dd3cd014356e595626141c29c58e748, "$lang_messages.ERROR_OUT_OF_MEMORY2"); return NULL; }  void 
S6ec917e546a7ba35c46dd8caa418a3a6(const void *Saec2f6eb44506ba469d3190ab26c46b4, const char *Sa0d162d0c7d63be1d940ba4a2367fc5b, 
muint Se1dd4913bcd5094166b0c5335ee8f49c) { 
#ifdef S16830aeb3627cf4fa5550c804769f5a4
 if (Saec2f6eb44506ba469d3190ab26c46b4) { S6273df09ce40f0640cdb4ecf69b2a5ee.Obtain(Scc2faae6b412ac43b64129b402c4b88e); 
bool S50dd31b83e9ee2255d91f8cfbbed073f = false; for (Secf36bf903121295607de79adb143b01(Sef1bb8d0e026db2f9caca565916783aa)::iterator 
Seb9d419135e896279ecc7721147bbd03 = Sa8934b100c1e0a3bcc67ea2a21ca2d5f.begin(); Seb9d419135e896279ecc7721147bbd03!= 
Sa8934b100c1e0a3bcc67ea2a21ca2d5f.end(); Seb9d419135e896279ecc7721147bbd03++) { if ((*Seb9d419135e896279ecc7721147bbd03).Saec2f6eb44506ba469d3190ab26c46b4 
== Saec2f6eb44506ba469d3190ab26c46b4) { Sa8934b100c1e0a3bcc67ea2a21ca2d5f.erase(Seb9d419135e896279ecc7721147bbd03); 
S50dd31b83e9ee2255d91f8cfbbed073f = true; break; } } S6273df09ce40f0640cdb4ecf69b2a5ee.Release(Scc2faae6b412ac43b64129b402c4b88e); 
if (!S50dd31b83e9ee2255d91f8cfbbed073f) { S00d6a0a2d331762dfcf4df377a29d38a(); } } 
#endif
 if (Saec2f6eb44506ba469d3190ab26c46b4) {  S7c0b383f1bacb0c74c82d85031ef3cb8((void *) Saec2f6eb44506ba469d3190ab26c46b4); 
 } } 

