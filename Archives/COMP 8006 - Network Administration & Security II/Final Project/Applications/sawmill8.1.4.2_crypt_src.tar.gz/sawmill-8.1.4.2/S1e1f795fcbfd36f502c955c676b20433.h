//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#ifndef Sfe3137a3c4793a1364bebc21a2cfceb9
 
#define Sfe3137a3c4793a1364bebc21a2cfceb9
 typedef enum { S9112fdbb5a26e648c62587f435086cf9, S5b4ad80226808224b7ac4cb021439e8e, Sbd2fd72beee3ba7bf5a6d8ac01378252 
} Se1a1e2f53c3904993c447828e57e3428; 
#endif
 
#endif


