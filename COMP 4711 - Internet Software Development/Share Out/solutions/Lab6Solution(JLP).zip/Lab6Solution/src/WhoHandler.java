
import java.util.SortedSet;
import java.util.TreeSet;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Collect elements from BBC TV data that pertain to Dr Who
 *
 * @author jim
 */
public class WhoHandler extends SuperHandler {

    public WhoHandler() {
        super();
    }

    /**
     * Apply appropriate filtering to select only those elements that
     * we are interested in.
     * This will distinguish one handler from another.
     * We only want Dr Who shows
     */
    public void condense() {
        SortedSet<Show> answer = new TreeSet<Show>();
        for (Show show : data) {
            if (show.title.contains("Doctor Who")) {
                answer.add(show);
                selected++;
            }
        }
        data = answer;
    }
}
