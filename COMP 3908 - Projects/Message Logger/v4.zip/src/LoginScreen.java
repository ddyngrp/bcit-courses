/*
 * LoginScreen.java
 *
 * Trusterra, 2003-2008
 * Confidential and proprietary.
 *@author Zhang,Mang(Edison)
 */


package src;
import net.rim.device.api.ui.container.FullScreen;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.PasswordEditField;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.decor.BorderFactory;
import net.rim.device.api.ui.XYEdges;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.container.HorizontalFieldManager;
import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.Screen;
import net.rim.device.api.ui.component.Status;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.ui.UiApplication;
import java.io.IOException;
/**
*LoginScreen class
* 
*LoginScreen class
*This is the login screen for memo logger. This screen is created when user 
*has image or audio objects attached to the MemoLogger and ready to send to the
*server. The purpose of this screen is for logging in the server.On this screen 
*components are editField, passwordEditField for capturing login information.
*
*/
class LoginScreen extends MainScreen {
    private HorizontalFieldManager buttonManager;
    
    /**
    *LoginScreen Constructor
    *This method creates LoginScreen object and add object fields on the screen.
    *
    *@param -mc	The media Controller that controlls all the media items.
    *
    */
    public LoginScreen(MediaController mc) {
        /*
        *Field manager for organize buttons and labelfield.
        */
        buttonManager = new HorizontalFieldManager(Manager.HORIZONTAL_SCROLL | FIELD_HCENTER);
        //title label       
        LabelField lf = new LabelField("Login Screen", FIELD_HCENTER);
        XYEdges edges = new XYEdges(1, 1, 1, 1);	//border for title
        lf.setBorder(BorderFactory.createSimpleBorder(edges));
        add(lf);
        //editfield for capturing username
        EditField edit = new EditField("Username: ", "",30,EDITABLE );
        add(edit);
        //passwordeditfield for capturing password
        PasswordEditField pass = new PasswordEditField("Password: ", "",30,EDITABLE);
        add(pass);
        //login button
        ButtonField bf = new ButtonField("Login");
        bf.setChangeListener(new LoginListener(mc, edit,pass));
        ButtonField lgCancel = new ButtonField("Cancel");
        lgCancel.setChangeListener(new LoginListener(mc, edit,pass));
        
        buttonManager.add(bf);
        buttonManager.add(lgCancel);

        add(buttonManager);
    }
} 
/**
*LoginListener class
*This class is for react when the button is pressed.
**/
final class  LoginListener implements FieldChangeListener{
    private EditField nameField;
    private PasswordEditField passField;
    private MediaController mc;
    /**
    *LoginListener Constructor
    *This method creates the LoginListener object and initialize passwordfield,
    *media controller, and editfield to process login.
    *
    *@param -mc	the media controller that controlls all the media items.
    *@param -nameField	the editfield for user to enter the username.
    *@param -passField	the password field for user to enter password.
    */
    public LoginListener(MediaController mc, EditField nameField, PasswordEditField passField){
      this.mc = mc;
      this.nameField = nameField;
      this.passField = passField;
    }
    /**
    *fieldChanged method
    *@param field	field object that is beging edit or accessed by the user.
    *@param context	context of the field.
    **/
    public void fieldChanged(Field field, int context){

        //where you pass login info to the server for checking
        ButtonField btn = (ButtonField) field;
        
        //LOGIN
        if(btn.getLabel().equals("Login")){
            XML_Login_Request  request  = new XML_Login_Request(this.nameField.getText(), this.passField.getText());
            XML_Login_Response response = new XML_Login_Response(XMLPost.postXMLData(request.toString()));
            System.out.println("SessionID: " + response.sessionID());
            mc.sessionID(response.sessionID());
            if (response.success()) {
            	Status.show("Login Succeeded.");
                UiApplication.getUiApplication().popScreen();
            } else {
            	Status.show("Login Failed.");
            }
        } else if (btn.getLabel().equals("Cancel")) {
            UiApplication.getUiApplication().popScreen();
        }
    }
}

