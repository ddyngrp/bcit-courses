//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S2135e51150c5df47f13987df5431edf6.h"

#include "S6c04980cbe475c3f0589b037cd017486.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Secf36bf903121295607de79adb143b01.h"

#include "Sf52e0ff1998ee8490500f35a382d089e.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "Se00f7d81e824b8a8baa31e30777a2666.h"

#include "Sc157c2f77b7c40e8e321884b9ff616a4.h"

#include "S5c686a55e1be1e5c2d8a4c8424ee6932.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S3397ee89749921f65da312dac746f43d.h"

#include "S65b54cd362bca037dc0b5544f5095c09.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "Sa95266e9d13052fad657d08a38e5729b.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "Sbc8ddaaaca8f488ac4989da3fc4f50fb.h"

#include "S908e73276c3e18281b9ec870e2fe14e1.h"

#include "S69cbc6dcce78dce7d38d16ca78e553b8.h"

#include "Sb5a9bba78ccd5d7067282b6d680c50a0.h"

#include "cc_regexp.h"

#include "Sf13bd1612a9c372751cea798950065b7.h"

#include "S7991bef1e51438ea84c452472ba836f3.h"

#include "S240e5310438334485f6155eaae9c0f75.h"
  void S20eef3f593c81168fda7b744ac0e88e4(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{  if (!Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sbeefb1163940cfc088f0d4ddf16405a5) 
{ S7ca5d44c3992eca4f11ed4ee768968cd *S025863a2613718024b19af9f17c80f8c = Sb96e04ee47495193c47f7004f4f555a1("spiders"); 
S02608d12463a6154737b28beeb690c00 S072a6ec1bff6fb07c715450f3e5ddf72; for (S7ca5d44c3992eca4f11ed4ee768968cd 
*Sd36ffc6a046f5680788487bbfa20c088 = S025863a2613718024b19af9f17c80f8c->Scf9a08b96fbb10815617bd2a33d4e51b(Scc2faae6b412ac43b64129b402c4b88e); 
Sd36ffc6a046f5680788487bbfa20c088; Sd36ffc6a046f5680788487bbfa20c088 = S025863a2613718024b19af9f17c80f8c->S8959a4733efe0c4c3118fe29974fb7a2(Scc2faae6b412ac43b64129b402c4b88e)) 
{ S072a6ec1bff6fb07c715450f3e5ddf72.Sc22377b5b326edb2bea57e372f1c01af = Sd36ffc6a046f5680788487bbfa20c088->S8a2ed7aca5cd2ae18fad1952bfe6c14b("label"); 
S072a6ec1bff6fb07c715450f3e5ddf72.See61a4478409ebe104351f43aff816ef = Sd36ffc6a046f5680788487bbfa20c088->S8a2ed7aca5cd2ae18fad1952bfe6c14b("substring"); 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S025863a2613718024b19af9f17c80f8c.push_back(S072a6ec1bff6fb07c715450f3e5ddf72); 
} Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sbeefb1163940cfc088f0d4ddf16405a5 
= true; }  
#if 0
   if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sbeefb1163940cfc088f0d4ddf16405a5) 
return;  S6d6cbe6673721b1104d6dcb8de7beb6a S4d29fd735539d227da70d5ec1e1f619c = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "Spiders"; if (!S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, S4d29fd735539d227da70d5ec1e1f619c.c_str())) 
{ FILE *S26c80efc0afe719b727e70139a7c5083 = S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, 
S4d29fd735539d227da70d5ec1e1f619c.c_str(), "w"); const char *S5c78038aacd5e89ab47e6264a74a3c8d = S95803ebf093303d8a61823e413a5533a(Scc2faae6b412ac43b64129b402c4b88e, 
Sd78b99dabb0d6fa85bc4336542f75a5b); fprintf(S26c80efc0afe719b727e70139a7c5083, "%s", S5c78038aacd5e89ab47e6264a74a3c8d); 
Sd33302a1daa8e684f02934fd9419ec83(Scc2faae6b412ac43b64129b402c4b88e, S26c80efc0afe719b727e70139a7c5083); 
}   Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S025863a2613718024b19af9f17c80f8c 
= new S53ed6907a30ee3eb77fae211c23825e2(S02608d12463a6154737b28beeb690c00*); S709f8a104a477b9e6883c170d8a6a334(Sfc0ea13b94e9dc7d7b3b9f9d2d8ce7ad(Scc2faae6b412ac43b64129b402c4b88e, 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Secf226258a569bb83d59d1f51f0ea57a, 
S4d29fd735539d227da70d5ec1e1f619c, Se2a68395b91e1c7469849288f0e1cced)); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sbeefb1163940cfc088f0d4ddf16405a5 
= true; 
#endif
 }   const char *Sdac7935164e5563cdcee21b9316f8f09(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Sab4316c0ce69e117120cdea8f74da4f9) {  S68f7bcbebe9a6192b736f378d5d9f0a4::iterator S62575e1994976d80c435e9f4c9583157 
= Scc2faae6b412ac43b64129b402c4b88e.S6fc8282c018df72ef25a462c23a6f4f6.find(Sab4316c0ce69e117120cdea8f74da4f9); 
 if (S62575e1994976d80c435e9f4c9583157 != Scc2faae6b412ac43b64129b402c4b88e.S6fc8282c018df72ef25a462c23a6f4f6.end()) 
{ if ((*S62575e1994976d80c435e9f4c9583157).second == "") { return NULL;  } else {  return (*S62575e1994976d80c435e9f4c9583157).second.c_str(); 
} }  S20eef3f593c81168fda7b744ac0e88e4(Scc2faae6b412ac43b64129b402c4b88e);  for (S53ed6907a30ee3eb77fae211c23825e2(S02608d12463a6154737b28beeb690c00)::iterator 
Sc0b4f37b772a706d984fd690ef7c2ced = Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S025863a2613718024b19af9f17c80f8c.begin(); 
Sc0b4f37b772a706d984fd690ef7c2ced != Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S025863a2613718024b19af9f17c80f8c.end(); 
Sc0b4f37b772a706d984fd690ef7c2ced++) {   register const char *See61a4478409ebe104351f43aff816ef = (*Sc0b4f37b772a706d984fd690ef7c2ced).See61a4478409ebe104351f43aff816ef.c_str(); 
if (S94b9f013d1697e8631ce1122b9e529b5(Sab4316c0ce69e117120cdea8f74da4f9, See61a4478409ebe104351f43aff816ef)) 
{ Scc2faae6b412ac43b64129b402c4b88e.S6fc8282c018df72ef25a462c23a6f4f6[Sab4316c0ce69e117120cdea8f74da4f9] 
= (*Sc0b4f37b772a706d984fd690ef7c2ced).Sc22377b5b326edb2bea57e372f1c01af;  return (*Sc0b4f37b772a706d984fd690ef7c2ced).Sc22377b5b326edb2bea57e372f1c01af.c_str(); 
} }   Scc2faae6b412ac43b64129b402c4b88e.S6fc8282c018df72ef25a462c23a6f4f6[Sab4316c0ce69e117120cdea8f74da4f9] 
= ""; return NULL; } 

