/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
import org.jdom.*;
import org.jdom.input.*;
import java.io.*;
import org.xml.sax.helpers.DefaultHandler;

/**
 * COMP4711 Lab 6 Solution.
 *
 * The approach here: make default handlers for each of the 3 scenarios.
 * Have each collect a list of elgible shows, that we can then display nicely.
 *
 * Disclaimer: this is not the only way to solve the problem, it is just
 * one way that appears elegant to me :)
 *
 * @author jim
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        who();
        when();
        where();
    }

    /**
     * Display the title & description of all Dr Who shows on BBC3.
     * How many shows of the total shown on BBC3 pertain to Dr Who?
     * Use the *title* element to test.
     */
    public static void who() {
        showTitle("W H O ... Dr Who shows on BBC3");        // Start the ball rolling
        SuperHandler handler = new WhoHandler();
        handler.parseXml("data/bbc3.xml");
        handler.condense();
        handler.showShows();
    }

    /**
     * Display the title, description & air time of all shows on between 8 & 11pm (local time) on TVDATA.
     * Order the display by air time, so it looks like a real schedule
     */
    public static void when() {
        showTitle("W H E N ... Shows between 8 & 11");        // Start the ball rolling
        SuperHandler handler = new WhenHandler();
        handler.parseXml("data/tvdata.xml");
        handler.condense();
        handler.showShows();
    }

    /**
     * Display the title, description & air time of all news shows on TVDATA.
     * Use the category element to determine these.
     */
    public static void where() {
        showTitle("W H E R E ... News shows");        // Start the ball rolling
        SuperHandler handler = new WhereHandler();
        handler.parseXml("data/tvdata.xml");
        handler.condense();
        handler.showShows();
    }

    /**
     * Fancy title display
     */
    public static void showTitle(String what) {
        System.out.println("-------------------------------------------");
        System.out.println(what);
        System.out.println("-------------------------------------------");
    }
}
