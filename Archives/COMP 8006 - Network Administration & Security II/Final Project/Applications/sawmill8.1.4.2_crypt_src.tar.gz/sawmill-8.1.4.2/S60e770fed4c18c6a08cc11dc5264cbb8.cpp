//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "S60e770fed4c18c6a08cc11dc5264cbb8.h"

#include "S93657e8be9d35683f99ca5613388c026.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "Se00f7d81e824b8a8baa31e30777a2666.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S69cbc6dcce78dce7d38d16ca78e553b8.h"
  Sb481dae06c4f4b9d3b1b9b18b896fa68::Sb481dae06c4f4b9d3b1b9b18b896fa68(Sc51497dedb5c0712f20ccaa9831c0365 
&S6ec129777c16ed8568398f5726365a75, const char *S63c954a64f22a1c1367029aa464d243d, bool Sd202583e3cbae0077742a0e579348338) 
: Sfe7618ef4b0786b73a2a9acfc49b94ce(S6ec129777c16ed8568398f5726365a75) { S1a97021946cc207f8a682d9f40e709c0 
= S63c954a64f22a1c1367029aa464d243d; Sf94baf9e56c2278f962c9fd6f06c8cc0 = NULL; S413393913814f6561d47906f248a3da7.Saf875b65294779100f83e2b651e92e55 
= Sd202583e3cbae0077742a0e579348338; }   
#include "sconfig.h"
 
#if HAVE_CSTDIO
 
#include <cstdio>

#endif
  void Sb481dae06c4f4b9d3b1b9b18b896fa68::S8a548fbbd62911c60c284937c41e0a0f() { Sf94baf9e56c2278f962c9fd6f06c8cc0 
= popen(S1a97021946cc207f8a682d9f40e709c0.c_str(), "r"); if (Sf94baf9e56c2278f962c9fd6f06c8cc0 == NULL) 
S9af25720509c69aa3c69a4c954caaab5(S1a97021946cc207f8a682d9f40e709c0, "$lang_messages.ERROR_EXECUTE_COMMAND"); 
 Sd848c24b85995c2ca815986ae39f0e92(0); Sd9d26ccad9c2196cb4fc77c84a3f7a3d = false; }   uint64 Sb481dae06c4f4b9d3b1b9b18b896fa68::S69229d6871c2cd0b77fe33f05144f0e9(S71b409bf2aa98ff69b95ba16e4cb2f05 
&Sf472b15dde2a4399a70a2e7fa0b6eb6f, char *S2985b4614d2618f174fd3c6fca49b42f, filelen_t Sd8d77b1ed00928dcc1bbf26f7598511d) 
{ if (!Sf94baf9e56c2278f962c9fd6f06c8cc0) { S4588c057cb67b6413763f6e1590b4f0c(); } size_t S86ef3c51f5d7dd462ed34fdc35e85b9c 
= fread(S2985b4614d2618f174fd3c6fca49b42f, 1, (size_t) Sd8d77b1ed00928dcc1bbf26f7598511d, Sf94baf9e56c2278f962c9fd6f06c8cc0); 
if (feof(Sf94baf9e56c2278f962c9fd6f06c8cc0) || (S86ef3c51f5d7dd462ed34fdc35e85b9c == 0)) eof = true; 
 return S86ef3c51f5d7dd462ed34fdc35e85b9c; }   void Sb481dae06c4f4b9d3b1b9b18b896fa68::S577943ab58039c24baeac25a70030170(void) 
{ if (Sd9d26ccad9c2196cb4fc77c84a3f7a3d) return; if (Sf94baf9e56c2278f962c9fd6f06c8cc0) {  pclose(Sf94baf9e56c2278f962c9fd6f06c8cc0); 
Sf94baf9e56c2278f962c9fd6f06c8cc0 = NULL; } Sd9d26ccad9c2196cb4fc77c84a3f7a3d = true; S16112b610b4e3339ec76d5a7b04d4c02(); 
}   S6d6cbe6673721b1104d6dcb8de7beb6a Sb481dae06c4f4b9d3b1b9b18b896fa68::Sdb807cbd507db99fefe8d0045ddb25dc(void) 
{ S0dd528a42552b31ec5d309edca503524("param1", S1a97021946cc207f8a682d9f40e709c0); return Scb7bd8b6a12d26f360aaf1301d91e15d(Scc2faae6b412ac43b64129b402c4b88e, 
"$lang_messages.MSG_READING_LOG_COMMAND"); }   S6d6cbe6673721b1104d6dcb8de7beb6a Sb481dae06c4f4b9d3b1b9b18b896fa68::Sbdeeade5060cfdaf59b062f643abfb67() 
{ S0dd528a42552b31ec5d309edca503524("param1", S1a97021946cc207f8a682d9f40e709c0); return Scb7bd8b6a12d26f360aaf1301d91e15d(Scc2faae6b412ac43b64129b402c4b88e, 
"$lang_stats.progress.reading_command"); }   const char *Sb481dae06c4f4b9d3b1b9b18b896fa68::S02e0bdbd0245ef077b2ca7c32dbe4cf0() 
{ return "command"; }   double Sb481dae06c4f4b9d3b1b9b18b896fa68::Sa645ef186899b7d89024160d78d7a66c(void) 
{  return -1; }   time_t Sb481dae06c4f4b9d3b1b9b18b896fa68::S26926d64837702f55b2920936df56399(void) 
{  return 0; }   void Sb481dae06c4f4b9d3b1b9b18b896fa68::S3f8a63896208e84c6eb5224d6b46ba6b(void) { Sf533dfa1f1a9d2f98470b69279857182.push_back("$lang_admin.log_source.data_from_command"); 
} 

