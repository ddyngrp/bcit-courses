
import java.util.ArrayList;
import java.util.Date;

/**
 * Flimsy POJO to hold a show object.
 *
 * @author A00696446
 */
public class Show implements Comparable {
    
    private String title, desc;
    
    private Date start, stop;

    private ArrayList<String> categories = new ArrayList<String>();

    public Show(String title, String desc, Date start, Date stop) {
        this.title = title;
        this.desc = desc;
        this.start = start;
        this.stop = stop;
    }

    public boolean addCategory(String category) {
        return categories.add(category);
    }

    public boolean removeCategory(String category) {
        return categories.remove(category);
    }

    public int compareTo(Object o) {
        Show other = (Show) o;
        return start.compareTo(other.getStart());
    }

    //Getters and Setters
    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getStop() {
        return stop;
    }

    public void setStop(Date stop) {
        this.stop = stop;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<String> getCategories() {
        return categories;
    }
    
    @Override
    public String toString() {
        return "\nShow: " + title +
                "\nDescription: " + desc +
                "\nTime: " + start + " to " + stop + " hrs";
    }

}
