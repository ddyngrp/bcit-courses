//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S01ffa7a1844b4bbecda6971fc288e3c1
 
#define S01ffa7a1844b4bbecda6971fc288e3c1
 
#include "S6c04980cbe475c3f0589b037cd017486.h"
 class S8438def6675d7357dd5d29588b69dca3 { public:   S6d6cbe6673721b1104d6dcb8de7beb6a Saad22bc7f9e994376e3a8030a8ea0548; 
 S6d6cbe6673721b1104d6dcb8de7beb6a S840ac6463824d1ef63962b0f22c9f1ac; int Sdc30ea99d45a8f475437cf62172bda66; 
int S314d00b3f556e86b2cbe9eac6055a139; S8438def6675d7357dd5d29588b69dca3(void) {  Saad22bc7f9e994376e3a8030a8ea0548 
= "nofilters"; Sdc30ea99d45a8f475437cf62172bda66 = 0; S314d00b3f556e86b2cbe9eac6055a139 = 0;  S840ac6463824d1ef63962b0f22c9f1ac 
= ""; } S8438def6675d7357dd5d29588b69dca3(const char *S1674632759b9d948016251e17cdbb704, int Sc7fdedf27af9040cfcdf42ba915d0b17, 
int S6165018435fddba05cd171e4f35827ce, const S6d6cbe6673721b1104d6dcb8de7beb6a &S696e8c231135f044b88994aad1fd49b4) 
{ Saad22bc7f9e994376e3a8030a8ea0548 = S1674632759b9d948016251e17cdbb704; S314d00b3f556e86b2cbe9eac6055a139 
= S6165018435fddba05cd171e4f35827ce; Sdc30ea99d45a8f475437cf62172bda66 = Sc7fdedf27af9040cfcdf42ba915d0b17; 
S840ac6463824d1ef63962b0f22c9f1ac = S696e8c231135f044b88994aad1fd49b4;  } S8438def6675d7357dd5d29588b69dca3(const 
S8438def6675d7357dd5d29588b69dca3 *S21ea7bd594352f0fd525c0db81824ba1) {  Saad22bc7f9e994376e3a8030a8ea0548 
= S21ea7bd594352f0fd525c0db81824ba1->Saad22bc7f9e994376e3a8030a8ea0548; S314d00b3f556e86b2cbe9eac6055a139 
= S21ea7bd594352f0fd525c0db81824ba1->S314d00b3f556e86b2cbe9eac6055a139; Sdc30ea99d45a8f475437cf62172bda66 
= S21ea7bd594352f0fd525c0db81824ba1->Sdc30ea99d45a8f475437cf62172bda66;  S840ac6463824d1ef63962b0f22c9f1ac 
= S21ea7bd594352f0fd525c0db81824ba1->S840ac6463824d1ef63962b0f22c9f1ac; } S8438def6675d7357dd5d29588b69dca3(const 
S8438def6675d7357dd5d29588b69dca3 &S21ea7bd594352f0fd525c0db81824ba1) {  Saad22bc7f9e994376e3a8030a8ea0548 
= S21ea7bd594352f0fd525c0db81824ba1.Saad22bc7f9e994376e3a8030a8ea0548; S314d00b3f556e86b2cbe9eac6055a139 
= S21ea7bd594352f0fd525c0db81824ba1.S314d00b3f556e86b2cbe9eac6055a139; Sdc30ea99d45a8f475437cf62172bda66 
= S21ea7bd594352f0fd525c0db81824ba1.Sdc30ea99d45a8f475437cf62172bda66;  S840ac6463824d1ef63962b0f22c9f1ac 
= S21ea7bd594352f0fd525c0db81824ba1.S840ac6463824d1ef63962b0f22c9f1ac; } ~S8438def6675d7357dd5d29588b69dca3() 
{  } }; typedef S8438def6675d7357dd5d29588b69dca3 *S60ccbf089518fa65094aca7ee1e6113d; 
#endif


