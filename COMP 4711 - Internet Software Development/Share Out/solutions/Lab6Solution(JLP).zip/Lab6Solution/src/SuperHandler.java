/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * This class contains common functionality for all the SAX handlers.
 * This includes setting up the SAX engine, as well as common field extraction.
 * @author jim
 */
public class SuperHandler extends DefaultHandler {

    protected Set<Show> data = null;           // all the extracted data
    protected Show[] condensed = null;          // shows after filtering
    protected Show one = null;                  // the current show object being built
    protected StringBuffer value = new StringBuffer();  // to hold text value of elements
    protected int candidates = 0;
    protected int selected = 0;

    /** Constructor */
    public SuperHandler() {
        super();
        data = new HashSet<Show>();

    }

    /** Down to work */
    public void parseXml(String filename) {
        System.out.println("Processing " + filename);
        try {
            // Create a builder factory
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xmlReader = saxParser.getXMLReader();

            xmlReader.setContentHandler(this);
            InputSource source = new InputSource(filename);
            xmlReader.parse(source);
        } catch (SAXException e) {
            // A parsing error occurred; the xml input is not valid
            System.out.println("Document parsing SAX error - " + e.getMessage());
        } catch (ParserConfigurationException e) {
            // A parsing error occurred; the xml input is not valid
            System.out.println("Document parsing parser error - " + e.getMessage());
        } catch (IOException e) {
            // A parsing error occurred; the xml input is not valid
            System.out.println("Document parsing I/O error - " + e.getMessage());
        }
    }

    /**
     * Handle the start of a new element.
     * We are only worried about the *programme" element; all else
     * will be picked off as we come to the end of each element,
     */
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals("programme")) {
            // start a new show
            one = new Show();
            // extract start & end times if we have those
            if (attributes != null) {
                one.startsAt = attributes.getValue("start");
                if (one.startsAt != null) {
                    one.startsAt = one.startsAt.substring(8, 10);
                }
                one.endsAt = attributes.getValue("stop");
                if (one.endsAt != null) {
                    one.endsAt = one.endsAt.substring(8, 10);
                }
            }
        }
        value = new StringBuffer();
    }

    /**
     * Handle values encountered.
     * Just add these to the text value being assembled.
     */
    public void characters(char[] ch, int start, int length) {
        value.append(new String(ch, start, length));
    }

    /**
     * Handle the end of an element.
     * Now it starts to get interesting.
     * If we have just completed an element of interest, then
     *
     */
    public void endElement(String uri, String localName, String qName) {
        if ((value == null) || (one == null)) {
            return; // nothing to see here
        }
        if (qName.equals("title")) {
            one.title = value.toString();
        }
        if (qName.equals("desc")) {
            one.description = value.toString();
        }
        if (qName.equals("start")) {
            one.startsAt = value.toString();
        }
        if (qName.equals("end")) {
            one.endsAt = value.toString();
        }

        if (qName.equals("category")) {
            one.categories.add(value.toString());
        }

        if (qName.equals("programme")) {
            data.add(one);
            candidates++;
        }
    }

    /**
     * Display our list
     *
     */
    public void showShows() {
        System.out.println("");
        for (Show show : data) {
            System.out.println(show.title + " : " + show.description + "[" + show.startsAt +
                    "-" + show.endsAt + "]");
        }
        System.out.println("\n" + selected + " of " + candidates + " shows selected.");
    }

    /**
     * Apply appropriate filtering to select only those elements that
     * we are interested in.
     * This will distinguish one handler from another..
     * Override the method if you want to condense the selection.
     */
    public void condense() {
    }
}
