/*
 * Model for an NHL conference, which contains divisions.
 *
 * @author Jim Parry
 */
package model;

import java.util.*;

public class Conference {

    /** Name of the conference */
    private String name;
    /** Map of the divisions in the conference */
    private SortedMap<String, Division> data = null;

    /** Convenience constructor */
    public Conference(String name) {
        this.name = name;
        data = new TreeMap<String, Division>();
    }

    /** Add a division to the conference */
    public void add(Division div) {
        data.put(div.getName(), div);
        div.setConference(this);
    }

    /** Accessor for the conference name */
    String getName() {
        return name;
    }

    /** Accessor for the conference's divisions */
    public SortedMap getDivisions() {
        return data;
    }
}
