using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace COMP2690.Bank
{
	public partial class SingleValueInputForm : Form
	{
		private bool emptyInputAllowed;
		private bool mustBeDecimalValue;
		private decimal amount;	// If the input is a decimal value then this value is set.

		public SingleValueInputForm()
		{
			InitializeComponent();
			emptyInputAllowed = false;
			mustBeDecimalValue = false;
			amount = 0m;
		}

		public string Prompt
		{
			get { return lblPrompt.Text; }
			set { lblPrompt.Text = value; }
		}

		public string Input
		{
			get { return txtInput.Text; }
			set { txtInput.Text = value; }
		}

		public bool EmptyInputAllowed
		{
			get { return emptyInputAllowed; }
			set { emptyInputAllowed = value; }
		}

		public bool MustBeDecimalValue
		{
			get { return mustBeDecimalValue; }
			set { mustBeDecimalValue = value; }
		}

		public decimal Amount { get { return amount; } }

		protected bool validateData(out decimal amount)
		{
			amount = 0m;

			if(mustBeDecimalValue)
			{
				if (!decimal.TryParse(txtInput.Text, out amount))
				{
					MessageBox.Show("Invalid amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					txtInput.Select();
					txtInput.SelectAll();
					return false;
				}
				else
				{
					return true;
				}
			}
			else if(emptyInputAllowed)
			{
				return true;
			}
			else if(txtInput.Text != "")
			{
				decimal.TryParse(txtInput.Text, out amount);
				return true;
			}
			else
			{
				return false;
			}
		}

		private void txtInput_Enter(object sender, EventArgs e)
		{
			txtInput.SelectAll();
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if (txtInput.Text == "" && !emptyInputAllowed)
			{
				MessageBox.Show("Must enter a value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				txtInput.Select();
			}
			else
			{
				if(validateData(out amount))
				{
					this.DialogResult = DialogResult.OK;
				}
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}


	}
}