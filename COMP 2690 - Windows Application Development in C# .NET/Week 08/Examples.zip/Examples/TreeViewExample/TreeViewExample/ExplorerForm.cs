/**************************************************************************
 * (C) Copyright 1992-2006 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/

// Ex. 14.6: ExplorerForm.cs
// Implementing a file browser similar to windows explorer.
// 
// (CS) Modified for COMP 2690.

using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

public partial class ExplorerForm : Form
{
	private string mDirectory;

	public ExplorerForm()
	{
	  InitializeComponent();
	}

	private void ExplorerForm_Load( object sender, EventArgs e )
	{
		tvwFolders.Nodes.Add("c:");
		PopulateTreeView("c:", tvwFolders.Nodes[0]);

		// Set the ImageList for both TreeView and ListView (look for an ImageList control 
		// called "images" in the component tray of the form design.)
		tvwFolders.ImageList = mainImageList;
		lvwFolderContents.SmallImageList = mainImageList;
	}

	private void tvwFolders_AfterExpand(object sender, TreeViewEventArgs e)
	{
		// Populate the selected nodes with its children.
		PopulateTreeView(e.Node.FullPath, e.Node);
	}

	private void tvwFolders_AfterSelect(object sender, TreeViewEventArgs e)
	{
		LoadFilesInDirectory(tvwFolders.SelectedNode.FullPath);
	}

	public void PopulateTreeView(string directoryValue, TreeNode rootNode)
	{
		// array stores all subdirectories in the directory
		string[] directoryArray = Directory.GetDirectories(directoryValue);

		// populate current node with subdirectories
		try
		{
			// check to see if any subdirectories are present
			if (directoryArray.Length != 0)
			{
				rootNode.Nodes.Clear();

				foreach (string directory in directoryArray)
				{
					// create TreeNode for current directory
					TreeNode childNode = new TreeNode(Path.GetFileName(directory));

					// (CS) I'd use the key values here but they aren't working very well
					//      for some reason.
					childNode.SelectedImageIndex = 1;
					childNode.ImageIndex = 0;

					// add current directory node to parent node
					rootNode.Nodes.Add(childNode);

					if (Directory.GetDirectories(childNode.FullPath).Length > 0)
					{
						// recursively populate every subdirectory
						//
						// (CS) I found this to be very slow because it potentially combs
						//      the entire drive if you select the root to start with.
						//      Instead, just indicate that there are subdirectories with 
						//      the plus symbol but don't load any.
						//
						//      In order to show the plus symbol, it seems you have to actually
						//      add a child node.  Let's do that but when the user opens this
						//      node to see its children, we'll remove this dummy child node and
						//      populate it with the correct items.

						//PopulateTreeView(directory, childNode);	// Recursive call.
						childNode.Nodes.Add("...");					// Dummy child node.
					}
				}
			}
		}
		catch (UnauthorizedAccessException)
		{
			rootNode.Nodes.Add("Access denied");
		}
	}

	public void LoadFilesInDirectory(string path)
	{
		DirectoryInfo DIcurrent;
		DirectoryInfo[] DIArray;
		FileInfo[] FIArray;
		ListViewItem newDirectoryItem;
		ListViewItem newFileItem;

		try
		{
			// clear ListView and set first item
			lvwFolderContents.Items.Clear();

			// update current directory
			mDirectory = path;
			DIcurrent = new DirectoryInfo(mDirectory);

			// put files and directories into arrays
			DIArray = DIcurrent.GetDirectories();
			FIArray = DIcurrent.GetFiles();

			// add file and directory names to ListView
			foreach (DirectoryInfo directoryInformation in DIArray)
			{
				// add directory to ListView
				newDirectoryItem = lvwFolderContents.Items.Add(directoryInformation.Name);
				newDirectoryItem.ImageKey = "FolderClosed";
			}

			foreach (FileInfo fileInformation in FIArray)
			{
				// add directory to ListView
				newFileItem = lvwFolderContents.Items.Add(fileInformation.Name);
				newFileItem.ImageKey = "File";
			}
		}
		catch (UnauthorizedAccessException)
		{
			MessageBox.Show("Warning: Some files may not be " +
					"visible due to permission settings", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
	} 

	private string removeTrailingBackslash(string path)
	{
		if (path != null && path.EndsWith("\\"))
		{
			return path.Substring(0, path.Length - 1);
		}
		else
		{
			return path;
		}
	}
} 

