//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Sea42d46c55a60398b1dcdaa31a873bb3.h"

#if HAVE_STDIO_H
 
#include <stdio.h>

#endif
 
#ifdef HAVE_FCNTL_H
 
#include <fcntl.h>

#endif
 
#include "Se00f7d81e824b8a8baa31e30777a2666.h"

#include "S69cbc6dcce78dce7d38d16ca78e553b8.h"

#include "S65b54cd362bca037dc0b5544f5095c09.h"

#include "S3e3af11e108aa6fefb5a12f010f7b40b.h"
  S8bc667a0d430f9dcea039427d0d0fb63::S8bc667a0d430f9dcea039427d0d0fb63(Sc51497dedb5c0712f20ccaa9831c0365 
&S6ec129777c16ed8568398f5726365a75, bool Sd202583e3cbae0077742a0e579348338) : Sfe7618ef4b0786b73a2a9acfc49b94ce(S6ec129777c16ed8568398f5726365a75) 
{ 
#if HAVE_FCNTL
  fcntl(fileno(stdin), S274aab04e2a1e9d070e1b34a3d24e00c, S5feb84a315bd3933fa680f6e0f6261ba); 
#endif
 S413393913814f6561d47906f248a3da7.Saf875b65294779100f83e2b651e92e55 = Sd202583e3cbae0077742a0e579348338; 
}   void S8bc667a0d430f9dcea039427d0d0fb63::S8a548fbbd62911c60c284937c41e0a0f(void) {   Sd848c24b85995c2ca815986ae39f0e92(0); 
Sd9d26ccad9c2196cb4fc77c84a3f7a3d = false; }   filelen_t S8bc667a0d430f9dcea039427d0d0fb63::S69229d6871c2cd0b77fe33f05144f0e9(S71b409bf2aa98ff69b95ba16e4cb2f05 
&Sf472b15dde2a4399a70a2e7fa0b6eb6f, char *S2985b4614d2618f174fd3c6fca49b42f, filelen_t Sd8d77b1ed00928dcc1bbf26f7598511d) 
{  bool S5207c97e0aeb0f5ff537f23d2b570c5c = false; filelen_t S86ef3c51f5d7dd462ed34fdc35e85b9c = 0; 
while (!S5207c97e0aeb0f5ff537f23d2b570c5c) {  S86ef3c51f5d7dd462ed34fdc35e85b9c = fread(S2985b4614d2618f174fd3c6fca49b42f, 
1, (size_t) Sd8d77b1ed00928dcc1bbf26f7598511d, stdin);  if (S86ef3c51f5d7dd462ed34fdc35e85b9c || feof(stdin)) 
S5207c97e0aeb0f5ff537f23d2b570c5c = true;  else {  if (!Scc2faae6b412ac43b64129b402c4b88e.Sd0a48d8cd7acc4d46c42c68ead89b986) 
{  S1972132661dc42f064d385e65c57a15b->Sefba724504821619b27729d3953e2a05(Scc2faae6b412ac43b64129b402c4b88e); 
} Sce0ba3706a1aa1892f87c7f61afb82b2(100); } }  return S86ef3c51f5d7dd462ed34fdc35e85b9c; }   void S8bc667a0d430f9dcea039427d0d0fb63::S577943ab58039c24baeac25a70030170(void) 
{ if (Sd9d26ccad9c2196cb4fc77c84a3f7a3d) return; Sd9d26ccad9c2196cb4fc77c84a3f7a3d = true; S16112b610b4e3339ec76d5a7b04d4c02(); 
}   S6d6cbe6673721b1104d6dcb8de7beb6a S8bc667a0d430f9dcea039427d0d0fb63::Sdb807cbd507db99fefe8d0045ddb25dc(void) 
{ return Scb7bd8b6a12d26f360aaf1301d91e15d(Scc2faae6b412ac43b64129b402c4b88e, "$lang_messages.MSG_READING_LOG_STDIN"); 
}   S6d6cbe6673721b1104d6dcb8de7beb6a S8bc667a0d430f9dcea039427d0d0fb63::Sbdeeade5060cfdaf59b062f643abfb67(void) 
{ return Scb7bd8b6a12d26f360aaf1301d91e15d(Scc2faae6b412ac43b64129b402c4b88e, "$lang_stats.progress.reading_stdin"); 
}   const char *S8bc667a0d430f9dcea039427d0d0fb63::S02e0bdbd0245ef077b2ca7c32dbe4cf0() { return "stdin"; 
}   double S8bc667a0d430f9dcea039427d0d0fb63::Sa645ef186899b7d89024160d78d7a66c(void) {  return -1; 
}   time_t S8bc667a0d430f9dcea039427d0d0fb63::S26926d64837702f55b2920936df56399(void) {  return 0; } 
  void S8bc667a0d430f9dcea039427d0d0fb63::S3f8a63896208e84c6eb5224d6b46ba6b(void) { Sf533dfa1f1a9d2f98470b69279857182.push_back("$lang_messages.MSG_STDIN_SCAN_FORM_MATCHES"); 
} 

