
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TreeSet;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.JDOMException;

/**
 * TV Listing thing.
 * 
 * @author jim
 */
public class Main {

    private static Document docBBC,  docTV;
    private static Element rootBBC,  rootTV;
    private static List<Element> programmesBBC,  programmesTV;
    private static TreeSet<Show> shows;
    

    static {
        try {
            SAXBuilder saxobj = new SAXBuilder();

            //Get BBC Data
            docBBC = saxobj.build("./data/bbc3.xml");
            rootBBC = docBBC.getRootElement();
            programmesBBC = rootBBC.getChildren("programme");

            //Get TV Data
            docTV = saxobj.build("./data/tvdata.xml");
            rootTV = docTV.detachRootElement();
            programmesTV = rootTV.getChildren("programme");

            shows = CreateShowsList(programmesTV);


        } catch (JDOMException e) {
            System.err.println(e);
        } catch (IOException e) {
            System.err.println(e);
        } catch (ParseException e) {
            System.err.println(e);
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        who();
        when();
        where();
    }

    /**
     * Display the title & description of all Dr Who shows on BBC3.
     * How many shows of the total shown on BBC3 pertain to Dr Who?
     * Use the *title* element to test.
     */
    public static void who() {
        System.out.println("List of Dr Who Shows:");
        int showCount = 0, whoCount = 0;
        for (Element programme : programmesBBC) {

            String title = programme.getChildText("title");
            showCount++;

            if (title.contains("Doctor Who")) {
                whoCount++;
                String desc = programme.getChildText("desc");
                String start = programme.getChildText("start");
                String end = programme.getChildText("end");
                System.out.println("\nShow: " + title);
                System.out.println("Description: " + desc);
                System.out.println("Time: " + start + " to " + end + " hrs");
            }
        }
        System.out.println("\n" + whoCount + " of " + showCount + " shows on BBC3 pertain to Dr Who");
    }

    /**
     * Display the title, description & air time of all shows on between 8 & 11pm (local time) on TVDATA.
     * Order the display by air time, so it looks like a real schedule
     */
    public static void when() {
        System.out.println("\nList of Shows that air between 8 & 11pm:");

        int showCount = 0;

        for (Show show : shows) {
            //If show starts between 8am and 11pm but not including
            //shows that start on 11pm
            if (show.getStart().getHours() >= 8 && show.getStart().getHours() < 23) {
                System.out.println(show);
                showCount++;

            }
        }
        if (showCount == 0) {
            System.out.println("No shows are playing during those times.");

        }

    }

    /**
     * Display the title, description & air time of all news shows on TVDATA.
     * Use the category element to determine these.
     */
    public static void where() {
        System.out.println("\nAll News Shows:");
        int showCount = 0;
        for (Show show : shows) {

            //Get categories
            ArrayList<String> categories = show.getCategories();
            for (String category : categories) {
                if (category != null && category.equals("News")) {
                    System.out.println(show);
                    showCount++;
                    break;
                }
            }

        }
        if (showCount == 0) {
            System.out.println("No shows are playing during those times.");

        }

    }

    public static TreeSet<Show> CreateShowsList(List<Element> programmesTV) throws ParseException {
        TreeSet<Show> newShows = new TreeSet<Show>();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss Z");
        //Store all shows in a happy little tree
        for (Element programme : programmesTV) {

            String title = programme.getChildText("title");
            String desc = programme.getChildText("desc");
            Date start = format.parse(programme.getAttributeValue("start"));
            Date end = format.parse(programme.getAttributeValue("stop"));

            Show newShow = new Show(title, desc, start, end);

            do {
                String category = programme.getChildText("category");
                newShow.addCategory(category);

            } while (programme.removeChild("category"));

            newShows.add(newShow);
        }
        return newShows;
    }
}
