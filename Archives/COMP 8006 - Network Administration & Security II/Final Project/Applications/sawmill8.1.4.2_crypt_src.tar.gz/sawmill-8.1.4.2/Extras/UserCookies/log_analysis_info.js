/*
	log analysis info
*/

function logAnalysisInfo() {
	
	var clientCookie = document.cookie.toString();
	var lavcString = clientCookie.indexOf("lavc=");
	var clientId = "";
	
	if (lavcString == -1) {
		
		// check whether we can set cookies
		document.cookie = "lavc=0";
		var tempClientCookie = document.cookie.toString();
		
		if (tempClientCookie.indexOf("lavc=0") != -1) {
		
			// set lavc cookie
			var nowDate = new Date();
			var t = nowDate.getTime();
			var n = Math.random() * 100000;
			n = Math.round(n);
			clientId = t + '' + n;
					
			nowDate.setFullYear(nowDate.getFullYear() + 20);
			var expiresDate = nowDate.toUTCString();
			
			document.cookie = "lavc=" + clientId + "; expires=" + expiresDate;
			
			// alert('cookie has been set to: ' + document.cookie.toString() + '\nclientId: ' + clientId);
		}
	}
	else {
		// read lavc cookie value
		var lavcStart = lavcString + 5;
		var lavcEnd = clientCookie.indexOf(";", lavcStart);
		if (lavcEnd == -1) {lavcEnd = clientCookie.length;}
		clientId = clientCookie.substring(lavcStart, lavcEnd);
			
		// alert('clientCookie String already exists: ' + clientCookie + '\nwe got clientId: ' + clientId);
	}
	
	// alert('screen width: ' + screen.width + '\nscreen height: ' + screen.height + '\ncolor depth: ' + screen.colorDepth + '\nclientId: ' + clientId);
	
	var img = '<img width="1" height="1" alt="" src="/picts/log_analysis_info.gif?';
	img += 'width=' + screen.width;
	img += '&height=' + screen.height;
	img += '&depth=' + screen.colorDepth;
	if (clientId != '') {img += '&lavc=' + clientId;}
	img += '">';
	
	// alert(img);
	
	document.write(img);
}

logAnalysisInfo();
