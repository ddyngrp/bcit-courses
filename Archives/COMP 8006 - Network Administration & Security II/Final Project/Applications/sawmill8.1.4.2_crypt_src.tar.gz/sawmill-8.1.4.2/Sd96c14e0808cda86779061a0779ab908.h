//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Sb525e61d737826a9724d3a17cfaed63a.h"
 
#if HAVE_STREAMBUF
 
#include <streambuf>

#else
 
# if HAVE_STREAMBUF_H
 
# include <streambuf.h>

# endif
 
#endif
 class Sc51497dedb5c0712f20ccaa9831c0365; class Sbb02c6e0fc20c8dab8bbaff365105510 : public S6ff816fca6bcd2d0b18e509d9aa55cc0 
{ S5b2556faa18cdaca5a6ad039f29d6254 &Scd4082426bdc6a9533556b5ca60add93; Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e; char *S2985b4614d2618f174fd3c6fca49b42f; muint S604eadefb057a699f7a9d51c10bd5998; 
muint S7e3f2beb73ed28408daa0d9ff0910f4f; bool S2d66b7b5021622c44906f8b841620651; public: Sbb02c6e0fc20c8dab8bbaff365105510(S5b2556faa18cdaca5a6ad039f29d6254 
&Sae94f4ecb3a506cf17470b3fdfe88b91, Sc51497dedb5c0712f20ccaa9831c0365 &S6ec129777c16ed8568398f5726365a75, 
bool S902da0eef5a1efa146c4bdeb7808266e); virtual ~Sbb02c6e0fc20c8dab8bbaff365105510(void); virtual int 
overflow(int S34410ea0d7783276aa8b5d4a06172810); 
#ifdef WINDOWS
 virtual int underflow(void) { return 0; } 
#endif
 };

