//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"
 
#include "Sb5a9bba78ccd5d7067282b6d680c50a0.h"

#include "Sb525e61d737826a9724d3a17cfaed63a.h"
 
#if HAVE_CTYPE_H
 
#include <ctype.h>

#endif
 
#if HAVE_SIGNAL_H
 
#include <signal.h>

#endif
 
#include "Sc854ae7450f698921771bd3b6762b4ac.h"

#include "Scc61ff7655a495d0c842fb268ce2e3c4.h"

#include "Se148d9e1c3b4085364a9ac2dbccf9964.h"

#include "S2b659cf002e8d20bd33ff44e6e3a8a70.h"

#include "S963dcac52f0380ef96a69e447a6fe65d.h"
 
#if HAVE_TIME_H
 
#include <time.h>

#endif
 
#include "Sc854ae7450f698921771bd3b6762b4ac.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S03b4aa5755dc381488543322f8a56e0a.h"

#include "S230eee6368f43217f41001b19455cd96.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "Secf36bf903121295607de79adb143b01.h"

#include "Scf163b9fe5fa9dd8c63f48cfe2ab82d9.h"

#include "Scae613df5f8d33d29ffa329e57180663.h"

#include "Sf13bd1612a9c372751cea798950065b7.h"

#include "S5dd234f440d08e4367741c6ac2ec7b35.h"

#include "Sbd58522302ebf2f051b304ca86c68ce3.h"

#include "Sd5d0864971a099befe0cde8fe198b302.h"

#include "S6c04980cbe475c3f0589b037cd017486.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Se24e5f8f12be3c8abcb9e4f17d005c29.h"

#include "char_checks.h"

#include "S963dcac52f0380ef96a69e447a6fe65d.h"
 
#define S02f6ad40b2ad1132a49dc09221638a6a(x) (((x) > 0) ? (x) : (-(x)))
 void Se558d687d64c05c9cbdb1343131a6d87(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{   if (Scc2faae6b412ac43b64129b402c4b88e.Sc9ac9bcbcb44894da4024ec7a15b8474) S0c0e20f1475d24dc8c30dcc27022a3c3(Scc2faae6b412ac43b64129b402c4b88e); 
S5151f99471c55d9270c9cf01bd02b97a; if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93727d2a1236bc83d1cafc7c191c1608) 
{ delete(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93727d2a1236bc83d1cafc7c191c1608); 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93727d2a1236bc83d1cafc7c191c1608 
= NULL; } S5151f99471c55d9270c9cf01bd02b97a; if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sa06951941922915f1fb91dd3e27a59dc) 
S52e8763e881c242e1c501df8ec23e915(Scc2faae6b412ac43b64129b402c4b88e); Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sbfcf0620c4be4153a0499ec46b1b3e71); 
Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S776cfc0cb3c07329211918858cd97b2a); 
delete(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Seba3d083d21ba0626ea975b2626efcf2); 
Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S1d0fdf18317a0ef6af7b9b16e9c72718); 
Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S959864a8e90a56837d7c672b64d83f19); 
if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sba26b770d0b41781ec70845c788a8700) 
{ delete ((Secf36bf903121295607de79adb143b01(muint) *) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sba26b770d0b41781ec70845c788a8700); 
delete ((Secf36bf903121295607de79adb143b01(muint) *) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93710861d8270b4ce7589f4740177667); 
} Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S16253203bd27dc8e6b7da1ec7088c71a); 
 if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.debug) { delete (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.debug); 
} }   void Sdabbc88403786f6343d20582c7688fa2(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
bool S38db5447d45d10d38fcd7373a171791e) {  Sc8915d498d2314d711d0597b98175b2c = time(NULL); if ((Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S99257421426175d1d1d49942e42ef67d 
== 0) || (Sc8915d498d2314d711d0597b98175b2c - Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S99257421426175d1d1d49942e42ef67d 
> 60*60)) { S709f8a104a477b9e6883c170d8a6a334(S0c0e20f1475d24dc8c30dcc27022a3c3(Scc2faae6b412ac43b64129b402c4b88e)); 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S99257421426175d1d1d49942e42ef67d 
= Sc8915d498d2314d711d0597b98175b2c; }  if (S38db5447d45d10d38fcd7373a171791e) {  if (Sc59f866c4bd8f523d23f039ea320fd35(Scc2faae6b412ac43b64129b402c4b88e, 
"Terminate")) { 
#ifndef WINDOWS
 Sb55a8771792315de88d494124781636c(S5b94e000a95897f43fa0090adb8b960a, "$lang_messages.MSG_TERMINATING_SERVER\n"); 

#endif
 S92325ae9c242bcbf562661b10820aed7(Scc2faae6b412ac43b64129b402c4b88e, "Terminate"); Sf41a6aede0fb5f80785aaee9e7519052(Scc2faae6b412ac43b64129b402c4b88e, 
"Killed", "Killed"); exit(0); }  S5710d404ee171ae86bc91f098296a32e(); }  }   void S5710d404ee171ae86bc91f098296a32e(void) 
{ if (S9e0246f15f76f59910865e27790cb6e5) return;  if (Sdcf14f47aad1c1162702056c56b0ab12 && !Sfab26a4f110f8008b90818cc57af2190) 
{   bool S72bd071f5576ec78696f11cc07c4d392 = true; 
#if HAVE_GETPGID
 pid_t S10f3d8081627b5e96ec5b14ade372000 = getpgid(Sdcf14f47aad1c1162702056c56b0ab12); if ((S10f3d8081627b5e96ec5b14ade372000 
== -1) && (errno == ESRCH)) { S72bd071f5576ec78696f11cc07c4d392 = false; } 
#else
 char S04f5e5e36a7c62132ef60104e2a9301e[100]; sprintf(S04f5e5e36a7c62132ef60104e2a9301e, "%ld", Sdcf14f47aad1c1162702056c56b0ab12); 
S6d6cbe6673721b1104d6dcb8de7beb6a Sa1c1f88c5586502d3862e1a1bae1f3be = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "IPC" + Sfae98e901cdbf1a268ec544cd9457415 + "MasterProcessLock." + S04f5e5e36a7c62132ef60104e2a9301e; 
  bool S2d7fedc9bf1bd2477ad7fbfc459c54eb = Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(NULL, 
Sa1c1f88c5586502d3862e1a1bae1f3be.c_str()); if (!S2d7fedc9bf1bd2477ad7fbfc459c54eb) { S72bd071f5576ec78696f11cc07c4d392 
= false; } else {  remove(Sa1c1f88c5586502d3862e1a1bae1f3be.c_str()); } 
#endif
 if (!S72bd071f5576ec78696f11cc07c4d392) {        if (getenv("SAWMILL_DEBUG") && (Sbea6e228a47bc141f76fa54e2c8ba1b9(getenv("SAWMILL_DEBUG"), 
"1"))) S1c060ee785e7ab9a9a45bb9573fc43bc << "Master process (" << Sdcf14f47aad1c1162702056c56b0ab12 
<< ") does not exist; exiting [WE ARE " << Sd526fda708dbbad24d7de62fea256c14() << "]\n"; exit(0); } 
} }   bool Sf310fb2fb49117cbd22868f779bb4d56(muint S5268410776decd83a0a26a51db5ce556) { char S04f5e5e36a7c62132ef60104e2a9301e[100]; 
sprintf(S04f5e5e36a7c62132ef60104e2a9301e, "%ld", S5268410776decd83a0a26a51db5ce556); S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa1c1f88c5586502d3862e1a1bae1f3be = S386ab9f82f83ce53d791996ba5e7db8e() + "IPC" + Sfae98e901cdbf1a268ec544cd9457415 
+ "MasterProcessLock." + S04f5e5e36a7c62132ef60104e2a9301e;  bool S2d7fedc9bf1bd2477ad7fbfc459c54eb 
= Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(NULL, Sa1c1f88c5586502d3862e1a1bae1f3be.c_str()); 
return S2d7fedc9bf1bd2477ad7fbfc459c54eb; }   void S0c0e20f1475d24dc8c30dcc27022a3c3(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) {  if (Scc2faae6b412ac43b64129b402c4b88e.S1ce0c25fdafc293cacd93beabe2cfe9c 
!= 0) return;   
#define S9b485c1dd1c98d7ba0467e4af3c32ead 60
 S6d6cbe6673721b1104d6dcb8de7beb6a Sd129040d9ca7fb292f4fe7d329693161 = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "IPC" + Sfae98e901cdbf1a268ec544cd9457415 + "LastCleanup"; if (S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, 
Sd129040d9ca7fb292f4fe7d329693161)) { time_t S1197ef8dd8b27dae14472ee29577f3b0 = S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
Sd129040d9ca7fb292f4fe7d329693161); if (S1197ef8dd8b27dae14472ee29577f3b0 < S9b485c1dd1c98d7ba0467e4af3c32ead) 
{ S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "Not cleaning IPC directory because last cleanup was only " 
<< S1197ef8dd8b27dae14472ee29577f3b0 << " seconds ago\n"); return; } S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Last IPC cleanup was " << S1197ef8dd8b27dae14472ee29577f3b0 << " seconds ago\n"); } else { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"No LastCleanup file found; cleaning temp files\n"); }  Sf41a6aede0fb5f80785aaee9e7519052(Scc2faae6b412ac43b64129b402c4b88e, 
"LastCleanup", "LastCleanup");    S709f8a104a477b9e6883c170d8a6a334(Sa74c308dbd5e3c883cb1e553cc8c918a(Scc2faae6b412ac43b64129b402c4b88e)); 
S709f8a104a477b9e6883c170d8a6a334(S3952330142ebcc94995e7b49af787624(Scc2faae6b412ac43b64129b402c4b88e, 
(Scc2faae6b412ac43b64129b402c4b88e.S01560544b2bb7101848668ad351b8922 + "TempImages").c_str()));  S709f8a104a477b9e6883c170d8a6a334(S3952330142ebcc94995e7b49af787624(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "TempLogs").c_str()));  S709f8a104a477b9e6883c170d8a6a334(S3952330142ebcc94995e7b49af787624(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "TemporaryFiles").c_str()));   Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "WebServerRoot" + Sfae98e901cdbf1a268ec544cd9457415 + "csv_export").c_str()); 
Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, (S386ab9f82f83ce53d791996ba5e7db8e() 
+ "WebServerRoot" + Sfae98e901cdbf1a268ec544cd9457415 + "graphs").c_str());  Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "auth_sessions").c_str()); Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "sessions_cache").c_str()); Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "session_files").c_str());  Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "TemporaryFiles" + Sfae98e901cdbf1a268ec544cd9457415 + "DeleteMe").c_str(), 
60);    S0d3555acb943332b0afc03f0de94064e(Scc2faae6b412ac43b64129b402c4b88e); }   bool Se6d610ba72b88bd9ef4e72f2bd462c6c(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S43f012de0c1d39bbffdace76cb72da3f) { mint Sb4841a255e082bd7cf3114c0a8244e3a 
= S6ebd86a1ffe5955f250729f70a634bf2(S43f012de0c1d39bbffdace76cb72da3f, Sfae98e901cdbf1a268ec544cd9457415); 
if (Sb4841a255e082bd7cf3114c0a8244e3a == -1) return false; const char *Sa0d162d0c7d63be1d940ba4a2367fc5b 
= S43f012de0c1d39bbffdace76cb72da3f + Sb4841a255e082bd7cf3114c0a8244e3a + 1; if (S4e8df42b9159db8d732c559a489ab192(Sa0d162d0c7d63be1d940ba4a2367fc5b, 
"Task")) { const char *Sa24a38545469b6d7207bd0c3e20abf4d = Sa0d162d0c7d63be1d940ba4a2367fc5b + 4; if 
(S9832bf8b8710e9b05679d0c81b71bea6(Sa24a38545469b6d7207bd0c3e20abf4d)) { mint Sccee1ed98c8c0a1f535e15c79d058a11 
= S34c9c535b6b63419a1b95b279a582962(Sa24a38545469b6d7207bd0c3e20abf4d); if (S0dc62b035ab4420b2e4b5f531132c139(Scc2faae6b412ac43b64129b402c4b88e, 
Sccee1ed98c8c0a1f535e15c79d058a11)) return true; } } return false; }   void S3952330142ebcc94995e7b49af787624(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S8f6d58719a8abe5ca435a10b3ceca358) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Cleaning up temporary files from directory " << S8f6d58719a8abe5ca435a10b3ceca358 << endl); if (Sa65ce13717451b94f10482e8ef0770a2(S8f6d58719a8abe5ca435a10b3ceca358) 
< 2) { S40bc864dbde9bdc106ff2121ba86ff7f("Returning because length < 2"); return; }  Saf2521015ace0146902a09f5ab8e70e5 
*Sc481127684e2512cb649811a3dcf750e = S37164dcdfc3397460947e5cd6299a691(S8f6d58719a8abe5ca435a10b3ceca358); 
if (!Sc481127684e2512cb649811a3dcf750e) { return; } const char *Sfb882b12a7c54e1b2edce48cb09a562c; S709f8a104a477b9e6883c170d8a6a334(Sfb882b12a7c54e1b2edce48cb09a562c 
= S9b0631ca19e9d2a13ac0e42922df1d1c(Scc2faae6b412ac43b64129b402c4b88e, Sc481127684e2512cb649811a3dcf750e, 
S8f6d58719a8abe5ca435a10b3ceca358, true)); if (Scc2faae6b412ac43b64129b402c4b88e.S3ed616017e5065680c56dcbc30310f2e) 
{ Sdba57c95b60da31796c0b9ab7a7cc4df(Sc481127684e2512cb649811a3dcf750e); } S35a4494f00627f79d6796f6234ba4071(); 
 Sc8915d498d2314d711d0597b98175b2c = time(NULL); S53ed6907a30ee3eb77fae211c23825e2(S6d6cbe6673721b1104d6dcb8de7beb6a) 
Sc6f7a33f30397184a5f2d5f809e26125; while (Sfb882b12a7c54e1b2edce48cb09a562c) {      S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Checking for active task directory: " << Sfb882b12a7c54e1b2edce48cb09a562c << endl); if (!Se6d610ba72b88bd9ef4e72f2bd462c6c(Scc2faae6b412ac43b64129b402c4b88e, 
Sfb882b12a7c54e1b2edce48cb09a562c)) { struct Sf1d191eb7ff462ff10706409614a3aa6 S7753be2cc6bcc32414647276ee2002da; 
mint Sa07d762b9b6c12a296f1eadc044f50f5 = S10f8390ee4fa970520481d00746b4d93(Sfb882b12a7c54e1b2edce48cb09a562c, 
&S7753be2cc6bcc32414647276ee2002da); if (Sa07d762b9b6c12a296f1eadc044f50f5 != -1) { if (Sc8915d498d2314d711d0597b98175b2c 
- S7753be2cc6bcc32414647276ee2002da.st_mtime > Sdeeef483298dad00627d0bebb682f0e7("miscellaneous.temporary_files_lifespan")) 
{ Sc6f7a33f30397184a5f2d5f809e26125.push_back(Sfb882b12a7c54e1b2edce48cb09a562c); }  }  } else { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Skipping cleanup of active task directory: " << Sfb882b12a7c54e1b2edce48cb09a562c << endl); }    Sfb882b12a7c54e1b2edce48cb09a562c 
= S9b0631ca19e9d2a13ac0e42922df1d1c(Scc2faae6b412ac43b64129b402c4b88e, Sc481127684e2512cb649811a3dcf750e, 
S8f6d58719a8abe5ca435a10b3ceca358, true); if (Scc2faae6b412ac43b64129b402c4b88e.S3ed616017e5065680c56dcbc30310f2e) 
Sdba57c95b60da31796c0b9ab7a7cc4df(Sc481127684e2512cb649811a3dcf750e); S35a4494f00627f79d6796f6234ba4071(); 
}   for (S53ed6907a30ee3eb77fae211c23825e2(S6d6cbe6673721b1104d6dcb8de7beb6a)::iterator S537237b4f1f67b8bacc87233f7404c23 
= Sc6f7a33f30397184a5f2d5f809e26125.begin(); S537237b4f1f67b8bacc87233f7404c23 != Sc6f7a33f30397184a5f2d5f809e26125.end(); 
S537237b4f1f67b8bacc87233f7404c23++) {  S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting recursively: " << (*S537237b4f1f67b8bacc87233f7404c23).c_str() << endl); Sb730f2206fd26ca7ce118d8c43e17c4a(Scc2faae6b412ac43b64129b402c4b88e, 
(*S537237b4f1f67b8bacc87233f7404c23).c_str(), true, false, false);    if (Scc2faae6b412ac43b64129b402c4b88e.S3ed616017e5065680c56dcbc30310f2e) 
{ Scc2faae6b412ac43b64129b402c4b88e.S3ed616017e5065680c56dcbc30310f2e = false; } }  Sdba57c95b60da31796c0b9ab7a7cc4df(Sc481127684e2512cb649811a3dcf750e); 
}   static void Sb12e63bcf840add39cb6f4d59b161d3d(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Sa0d162d0c7d63be1d940ba4a2367fc5b) {    S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"DeleteFileIfNotLocked(" << Sa0d162d0c7d63be1d940ba4a2367fc5b << ")\n"); off_t S80dc370e5eb68ca23e3d8af9b0b66219 
= Sc91e6762ee3d93d4be3fed12e5b4d86e(Sa0d162d0c7d63be1d940ba4a2367fc5b, "Task-");  if (S80dc370e5eb68ca23e3d8af9b0b66219 
== -1) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "Not deleting " << Sa0d162d0c7d63be1d940ba4a2367fc5b 
<< " because it is not a Task file\n"); return; }  if (Sc91e6762ee3d93d4be3fed12e5b4d86e(Sa0d162d0c7d63be1d940ba4a2367fc5b, 
"StartTime") != -1) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "Not deleting " 
<< Sa0d162d0c7d63be1d940ba4a2367fc5b << " because it is a StartTime file\n"); return; }    off_t Sdf437efc1f525f291dad5589eb5a0b75 
= Sc91e6762ee3d93d4be3fed12e5b4d86e(Sa0d162d0c7d63be1d940ba4a2367fc5b, "-", S80dc370e5eb68ca23e3d8af9b0b66219 
+ 5); char S44283c8350f5a4f5ee96b413cb9ea402[1000]; strcpy(S44283c8350f5a4f5ee96b413cb9ea402, Sa0d162d0c7d63be1d940ba4a2367fc5b); 
strcpy(S44283c8350f5a4f5ee96b413cb9ea402 + Sdf437efc1f525f291dad5589eb5a0b75 + 1, "Lock"); if (!Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(&Scc2faae6b412ac43b64129b402c4b88e, 
S44283c8350f5a4f5ee96b413cb9ea402)) { Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
Sa0d162d0c7d63be1d940ba4a2367fc5b, false); S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleted " << Sa0d162d0c7d63be1d940ba4a2367fc5b << "\n"); } else { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Not deleting " << Sa0d162d0c7d63be1d940ba4a2367fc5b << " because lock file is locked\n"); } } void 
S0d3555acb943332b0afc03f0de94064e(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{ S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "Cleaning IPC directory\n"); 

#define S9b485c1dd1c98d7ba0467e4af3c32ead 60
 muint S1197ef8dd8b27dae14472ee29577f3b0 = S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
(S386ab9f82f83ce53d791996ba5e7db8e() + "IPC" + Sfae98e901cdbf1a268ec544cd9457415 + "LastCleanup").c_str()); 
if (S1197ef8dd8b27dae14472ee29577f3b0 < S9b485c1dd1c98d7ba0467e4af3c32ead) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Not cleaning IPC directory because last cleanup was only " << S1197ef8dd8b27dae14472ee29577f3b0 << 
" seconds ago\n"); return; }  Sf41a6aede0fb5f80785aaee9e7519052(Scc2faae6b412ac43b64129b402c4b88e, "LastCleanup", 
"LastCleanup"); S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "Last IPC cleanup was " 
<< S1197ef8dd8b27dae14472ee29577f3b0 << " seconds ago\n");    S6d6cbe6673721b1104d6dcb8de7beb6a S566213669297090c5ad80332156c3392 
= S386ab9f82f83ce53d791996ba5e7db8e() + "IPC"; Saf2521015ace0146902a09f5ab8e70e5 *Sfa1d1734eec197a42d7099a3ca353fd6 
= S37164dcdfc3397460947e5cd6299a691(S566213669297090c5ad80332156c3392.c_str()); S53ed6907a30ee3eb77fae211c23825e2(S6d6cbe6673721b1104d6dcb8de7beb6a) 
Sc6f7a33f30397184a5f2d5f809e26125; time_t Sb5103f14da77bbb3404175689169f4f6 = time(NULL); set<S6d6cbe6673721b1104d6dcb8de7beb6a> 
S1ab335d25ce065be9ebe378c161c51fa; if (Sfa1d1734eec197a42d7099a3ca353fd6) { const char *Sfb882b12a7c54e1b2edce48cb09a562c 
= ""; while(Sfb882b12a7c54e1b2edce48cb09a562c) {  S709f8a104a477b9e6883c170d8a6a334(Sfb882b12a7c54e1b2edce48cb09a562c 
= S9b0631ca19e9d2a13ac0e42922df1d1c(Scc2faae6b412ac43b64129b402c4b88e, Sfa1d1734eec197a42d7099a3ca353fd6, 
S566213669297090c5ad80332156c3392.c_str(), false)); if (Sfb882b12a7c54e1b2edce48cb09a562c) { S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa8aa4ff36cd257c746a3ae870331cd16 = S566213669297090c5ad80332156c3392 + Sfae98e901cdbf1a268ec544cd9457415 
+ Sfb882b12a7c54e1b2edce48cb09a562c; S1ab335d25ce065be9ebe378c161c51fa.insert(Sa8aa4ff36cd257c746a3ae870331cd16); 
} } } Sdba57c95b60da31796c0b9ab7a7cc4df(Sfa1d1734eec197a42d7099a3ca353fd6);  
#define S0ac400d8c9aa358b13d06a6741b57cea 60
 
#define Sb5c04cdaf34ca54a0a1af951a3ed7cc1 10*60
 set<S6d6cbe6673721b1104d6dcb8de7beb6a> S4571bc6a86442c01a9ffeb0d0d56de40; for (set<S6d6cbe6673721b1104d6dcb8de7beb6a>::iterator 
S26c80efc0afe719b727e70139a7c5083 = S1ab335d25ce065be9ebe378c161c51fa.begin(); S26c80efc0afe719b727e70139a7c5083 
!= S1ab335d25ce065be9ebe378c161c51fa.end(); S26c80efc0afe719b727e70139a7c5083++) { bool S7accfccf41fff81f3187c8a977229818 
= false; if ((*S26c80efc0afe719b727e70139a7c5083).S50ecde1d8305c85a933dc85759419955("Task-")) { if ((*S26c80efc0afe719b727e70139a7c5083).Se543ff92285a848ed4d00f194cccf802("Lock")) 
{ if (!Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(&Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str())) { if (S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str()) > S0ac400d8c9aa358b13d06a6741b57cea) { Sb12e63bcf840add39cb6f4d59b161d3d(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str()); S6d6cbe6673721b1104d6dcb8de7beb6a S78a4cf7c887b728c0bf4bac93efa88b7 
= (*S26c80efc0afe719b727e70139a7c5083).substr(0, (*S26c80efc0afe719b727e70139a7c5083).length() - 4) 
+ "Request"; Sb12e63bcf840add39cb6f4d59b161d3d(Scc2faae6b412ac43b64129b402c4b88e, S78a4cf7c887b728c0bf4bac93efa88b7.c_str()); 
S6d6cbe6673721b1104d6dcb8de7beb6a S42c38a70addf02b796676eaca6574abe = (*S26c80efc0afe719b727e70139a7c5083).substr(0, 
(*S26c80efc0afe719b727e70139a7c5083).length() - 4) + "Result"; struct Sf1d191eb7ff462ff10706409614a3aa6 
S7753be2cc6bcc32414647276ee2002da; mint Sa07d762b9b6c12a296f1eadc044f50f5 = S10f8390ee4fa970520481d00746b4d93(S42c38a70addf02b796676eaca6574abe.c_str(), 
&S7753be2cc6bcc32414647276ee2002da); if (Sa07d762b9b6c12a296f1eadc044f50f5 != -1) { if (Sb5103f14da77bbb3404175689169f4f6 
- S7753be2cc6bcc32414647276ee2002da.st_mtime > Sb5c04cdaf34ca54a0a1af951a3ed7cc1) { Sb12e63bcf840add39cb6f4d59b161d3d(Scc2faae6b412ac43b64129b402c4b88e, 
S42c38a70addf02b796676eaca6574abe.c_str()); }  }  }  }  }  }  if (!S7accfccf41fff81f3187c8a977229818) 
{ S4571bc6a86442c01a9ffeb0d0d56de40.insert(*S26c80efc0afe719b727e70139a7c5083); S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Adding " << *S26c80efc0afe719b727e70139a7c5083 << " to next stage list\n"); }  }  
#define S446ebbd31b0f3db96816b3106a34c28c 10*60
 
#define S6436f662a027fa36daffc0a8b6ce93be 24*60*60
 
#define S3210023e5043f64a3bdfcdc5ae458899 30*24*60*60
 S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, "IPC cleanup stage 2\n"); for 
(set<S6d6cbe6673721b1104d6dcb8de7beb6a>::iterator S26c80efc0afe719b727e70139a7c5083 = S4571bc6a86442c01a9ffeb0d0d56de40.begin(); 
S26c80efc0afe719b727e70139a7c5083 != S4571bc6a86442c01a9ffeb0d0d56de40.end(); S26c80efc0afe719b727e70139a7c5083++) 
{ time_t S2641e136a5a533e9346c13d9c4dc7a26 = S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083)); S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Considering deleting " << *S26c80efc0afe719b727e70139a7c5083 << " (age=" << S2641e136a5a533e9346c13d9c4dc7a26 
<< ")\n"); if (S2641e136a5a533e9346c13d9c4dc7a26 > S3210023e5043f64a3bdfcdc5ae458899) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting old file (" << S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, (*S26c80efc0afe719b727e70139a7c5083).c_str()) 
<< ") unlocked HTTPRequest file " << *S26c80efc0afe719b727e70139a7c5083 << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); } if (S2641e136a5a533e9346c13d9c4dc7a26 > S446ebbd31b0f3db96816b3106a34c28c) 
{  if ((*S26c80efc0afe719b727e70139a7c5083).S50ecde1d8305c85a933dc85759419955("HTTPRequest-") && (S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str()) > S6436f662a027fa36daffc0a8b6ce93be)) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting very old old (" << S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, (*S26c80efc0afe719b727e70139a7c5083).c_str()) 
<< ") unlocked HTTPRequest file " << *S26c80efc0afe719b727e70139a7c5083 << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); }  else if ((*S26c80efc0afe719b727e70139a7c5083).S50ecde1d8305c85a933dc85759419955("MasterProcessLock.") 
&& !Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(&Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str())) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting old (" << S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, (*S26c80efc0afe719b727e70139a7c5083).c_str()) 
<< ") unlocked master process file " << *S26c80efc0afe719b727e70139a7c5083 << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); }  else Sb12e63bcf840add39cb6f4d59b161d3d(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str()); }   else if ((*S26c80efc0afe719b727e70139a7c5083).Se543ff92285a848ed4d00f194cccf802("-Lock") 
&& !Se2c73b544fed1ea7b7b2b0c2972c57b4::S5839d2761ddcd27091101ec6679aa751(&Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str())) { S6d6cbe6673721b1104d6dcb8de7beb6a Sc19519b2a1ce1235db5f943eaf59db5c 
= (*S26c80efc0afe719b727e70139a7c5083); Sc19519b2a1ce1235db5f943eaf59db5c.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
"-Lock", "-StartTime"); if (S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, Sc19519b2a1ce1235db5f943eaf59db5c.c_str())) 
{ if (S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, Sc19519b2a1ce1235db5f943eaf59db5c.c_str()) 
> S446ebbd31b0f3db96816b3106a34c28c) { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting old (" << S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, (*S26c80efc0afe719b727e70139a7c5083).c_str()) 
<< ") unlocked lockfile " << *S26c80efc0afe719b727e70139a7c5083 << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting associated StartTime file " << Sc19519b2a1ce1235db5f943eaf59db5c << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
Sc19519b2a1ce1235db5f943eaf59db5c.c_str(), false); } } else { S6bcf99fce07707f06693cebe6a409e38(S5658d59803aaff173e48653cc5df42b0, 
"Deleting unlocked lockfile of unknown age" << endl); Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); } } }  }   void Sea431cfe37a958b018ba33c9d4874de0(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S8f6d58719a8abe5ca435a10b3ceca358, muint S64e31edc0375e49839cf5c2b2276162b) 
{  if (Sa65ce13717451b94f10482e8ef0770a2(S8f6d58719a8abe5ca435a10b3ceca358) < 2) return;  Saf2521015ace0146902a09f5ab8e70e5 
*Sc481127684e2512cb649811a3dcf750e = S37164dcdfc3397460947e5cd6299a691(S8f6d58719a8abe5ca435a10b3ceca358); 
S53ed6907a30ee3eb77fae211c23825e2(S6d6cbe6673721b1104d6dcb8de7beb6a) Sc6f7a33f30397184a5f2d5f809e26125; 
set<S6d6cbe6673721b1104d6dcb8de7beb6a> S1ab335d25ce065be9ebe378c161c51fa; if (Sc481127684e2512cb649811a3dcf750e) 
{ const char *Sfb882b12a7c54e1b2edce48cb09a562c = ""; while(Sfb882b12a7c54e1b2edce48cb09a562c) {  S709f8a104a477b9e6883c170d8a6a334(Sfb882b12a7c54e1b2edce48cb09a562c 
= S9b0631ca19e9d2a13ac0e42922df1d1c(Scc2faae6b412ac43b64129b402c4b88e, Sc481127684e2512cb649811a3dcf750e, 
S8f6d58719a8abe5ca435a10b3ceca358, false)); if (Sfb882b12a7c54e1b2edce48cb09a562c) { S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa8aa4ff36cd257c746a3ae870331cd16 = S6d6cbe6673721b1104d6dcb8de7beb6a(S8f6d58719a8abe5ca435a10b3ceca358) 
+ Sfae98e901cdbf1a268ec544cd9457415 + Sfb882b12a7c54e1b2edce48cb09a562c; S1ab335d25ce065be9ebe378c161c51fa.insert(Sa8aa4ff36cd257c746a3ae870331cd16); 
} } } Sdba57c95b60da31796c0b9ab7a7cc4df(Sc481127684e2512cb649811a3dcf750e);   for (set<S6d6cbe6673721b1104d6dcb8de7beb6a>::iterator 
S26c80efc0afe719b727e70139a7c5083 = S1ab335d25ce065be9ebe378c161c51fa.begin(); S26c80efc0afe719b727e70139a7c5083 
!= S1ab335d25ce065be9ebe378c161c51fa.end(); S26c80efc0afe719b727e70139a7c5083++) {  if (S5790ab6bf05a9c559840b747f5a343b1(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str())) { Sea431cfe37a958b018ba33c9d4874de0(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), S64e31edc0375e49839cf5c2b2276162b);   Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); }  else { if ((muint) S864004971aec3065e93b508c22895158(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str()) > S64e31edc0375e49839cf5c2b2276162b) {   Sd8686ce9166f0b00d1c943dd2f6699dc(Scc2faae6b412ac43b64129b402c4b88e, 
(*S26c80efc0afe719b727e70139a7c5083).c_str(), false); }  }  }  } 

