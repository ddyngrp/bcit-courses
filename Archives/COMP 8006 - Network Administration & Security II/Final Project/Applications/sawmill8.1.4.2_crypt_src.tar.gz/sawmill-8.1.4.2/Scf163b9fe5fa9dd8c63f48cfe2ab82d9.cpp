//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































  
#include "sconfig.h"

#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Scf163b9fe5fa9dd8c63f48cfe2ab82d9.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"
 
#if HAVE_STRINGS_H
 
# include <strings.h>

#endif
 typedef struct { Sd8dc4e17d5d1560eaab0e15042065b71 *S1a716db23f47491edaab7f33f44a80d1; void *Sc8353b64d6ed55646496b7e7bb8ea712; 
} Sb2a24ce5eef39c69b9feb047623f9752; 
#if HAVE_PTHREAD
 
# ifdef WINDOWS
 
#  include <windows.h>

# else
 
#  ifdef macintosh
 
#   include <Threads.h>

#  else
 
#   include <sys/types.h>

#   if HAVE_PTHREAD_H
 
#    include <pthread.h>

#   endif
 
#   ifndef CYGWIN
 
#    include <sched.h>

#   endif
 
#  endif
 
# endif
 
# ifdef macintosh
 
# include <Threads.h>
 S22a1bd7d29a9226cf1c4c7e89ece6e11 void *S2a999eb2b4bfb62d92826d20088f156b(void *Sf0d79f57c44904e784307868ce267570); 
S22a1bd7d29a9226cf1c4c7e89ece6e11 void *S2a999eb2b4bfb62d92826d20088f156b(void *Sf0d79f57c44904e784307868ce267570) 
{ Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 = (Sb2a24ce5eef39c69b9feb047623f9752 
*) Sf0d79f57c44904e784307868ce267570; Sb2a24ce5eef39c69b9feb047623f9752 *S970a9b1a8c8325c7dc070ca73282c521 
= (Sb2a24ce5eef39c69b9feb047623f9752 *) Sf0d79f57c44904e784307868ce267570; (S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1)(S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712); 
return NULL; } 
# else
 
#  ifdef WINDOWS
 Sa20fea517e6c7aac5e1926a22b9ec656 Sc3e03fcd411502b2b363db014c4a957d( S2405afc2dba978b519765ccc17a5d768 
S41f8567f0a739ac0ae0f3bccf334547c ); Sa20fea517e6c7aac5e1926a22b9ec656 Sc3e03fcd411502b2b363db014c4a957d(S2405afc2dba978b519765ccc17a5d768 
S41f8567f0a739ac0ae0f3bccf334547c) { Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 
= (Sb2a24ce5eef39c69b9feb047623f9752 *) S41f8567f0a739ac0ae0f3bccf334547c; (S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1)(S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712); 
delete(S7f3f5c63b6fe99b1734383d7601f8140); return NULL; } Sbc8f1b4dba1955c2be83526803b08ea4 Se301fa5dd9377e5bbcf3d59833382f7d(S2405afc2dba978b519765ccc17a5d768 
S41f8567f0a739ac0ae0f3bccf334547c); Sbc8f1b4dba1955c2be83526803b08ea4 Se301fa5dd9377e5bbcf3d59833382f7d(S2405afc2dba978b519765ccc17a5d768 
S41f8567f0a739ac0ae0f3bccf334547c) { Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 
= (Sb2a24ce5eef39c69b9feb047623f9752 *) S41f8567f0a739ac0ae0f3bccf334547c; (S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1)(S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712); 
delete(S7f3f5c63b6fe99b1734383d7601f8140); return NULL; } 
#  else
 extern "C" void *S9718804936eab77729560f3444514dbc(void *S1f7262b9a902facac5858da6fb06ab5e); extern 
"C" void *S9718804936eab77729560f3444514dbc(void *S1f7262b9a902facac5858da6fb06ab5e) { Sb2a24ce5eef39c69b9feb047623f9752 
*S7f3f5c63b6fe99b1734383d7601f8140 = (Sb2a24ce5eef39c69b9feb047623f9752 *) S1f7262b9a902facac5858da6fb06ab5e; 
(S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1)(S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712); 
delete(S7f3f5c63b6fe99b1734383d7601f8140); return NULL; } 
#  endif
 
# endif
 
#endif
  S4673665870260a6a927871499a4441fa Se0179f6f891be04e60aa506e5f450b27(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sd8dc4e17d5d1560eaab0e15042065b71 *S1a716db23f47491edaab7f33f44a80d1, 
int Sa29e8a9db3602caf729ecee3fab209d6, void *Sc8353b64d6ed55646496b7e7bb8ea712) {  if (S3453986fad8ae18a4cddd52a6f55b49e) 
{ S4673665870260a6a927871499a4441fa S970a9b1a8c8325c7dc070ca73282c521; S3b2e35290544af6997c8f7489ad887b6(S970a9b1a8c8325c7dc070ca73282c521); 

#if HAVE_PTHREAD
 
#ifdef WINDOWS
 Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 = new Sb2a24ce5eef39c69b9feb047623f9752(); 
S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1 = S1a716db23f47491edaab7f33f44a80d1; 
S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712 = Sc8353b64d6ed55646496b7e7bb8ea712; 
Sbc8f1b4dba1955c2be83526803b08ea4 Sa6ce907452bb362acbc2ed81b188bcab; Se03aba064dfc3466b842ea3799d4e5a5(NULL, 
0, (S529b44b499a14a7adb349012e450597a) &Se301fa5dd9377e5bbcf3d59833382f7d, (void *) S7f3f5c63b6fe99b1734383d7601f8140, 
0, &Sa6ce907452bb362acbc2ed81b188bcab); S970a9b1a8c8325c7dc070ca73282c521 = (void *) (uint64) Sa6ce907452bb362acbc2ed81b188bcab; 

#else
 
# ifdef macintosh
  Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 = new Sb2a24ce5eef39c69b9feb047623f9752(); 
S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1 = S1a716db23f47491edaab7f33f44a80d1; 
S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712 = Sc8353b64d6ed55646496b7e7bb8ea712; 
 Sb2f13077e40982ac4a42132db78f3cfa S3ed616017e5065680c56dcbc30310f2e = S8504533b377932026ec3d79e53866495(S63d972461c44afca1d0082115bc1f7fb, 
Scda897f53c65e7e3eb048957fbfc921f(S2a999eb2b4bfb62d92826d20088f156b), (void *) S7f3f5c63b6fe99b1734383d7601f8140, 
0, S0eca2c17f3801c3511435ff33c73e31d, NULL, (Sa5e7526a4f6f3f0ef1e89c706925a5ff *) S970a9b1a8c8325c7dc070ca73282c521); 
if (S3ed616017e5065680c56dcbc30310f2e != S138190e09d368ed7ef61b7f5d7130f52) S29464bd8ff045846d164d4a2ecb441d6("$lang_messages.ERROR_CREATE_THREAD"); 

# else
  Sb2a24ce5eef39c69b9feb047623f9752 *S7f3f5c63b6fe99b1734383d7601f8140 = new Sb2a24ce5eef39c69b9feb047623f9752(); 
S7f3f5c63b6fe99b1734383d7601f8140->S1a716db23f47491edaab7f33f44a80d1 = S1a716db23f47491edaab7f33f44a80d1; 
S7f3f5c63b6fe99b1734383d7601f8140->Sc8353b64d6ed55646496b7e7bb8ea712 = Sc8353b64d6ed55646496b7e7bb8ea712; 

#  if HAVE_PTHREAD_ATTR_SETSCHEDPARAM
  pthread_attr_t S940794bc55a4fd5b8a81da1fbd263a36; bzero(&S940794bc55a4fd5b8a81da1fbd263a36, sizeof(pthread_attr_t)); 
pthread_attr_init(&S940794bc55a4fd5b8a81da1fbd263a36); pthread_attr_setscope(&S940794bc55a4fd5b8a81da1fbd263a36, 
PTHREAD_SCOPE_SYSTEM); struct sched_param Se4031f959a1a9da800e27e37b6d3084d; bzero(&Se4031f959a1a9da800e27e37b6d3084d, 
sizeof(sched_param));    pthread_attr_setschedparam(&S940794bc55a4fd5b8a81da1fbd263a36, &Se4031f959a1a9da800e27e37b6d3084d); 
int S1282400098429c5470611495b46d63d8 = pthread_create((pthread_t *) S970a9b1a8c8325c7dc070ca73282c521, 
&S940794bc55a4fd5b8a81da1fbd263a36, S9718804936eab77729560f3444514dbc, S7f3f5c63b6fe99b1734383d7601f8140); 

#  else
  int S1282400098429c5470611495b46d63d8 = pthread_create((pthread_t *) S970a9b1a8c8325c7dc070ca73282c521, 
NULL, S9718804936eab77729560f3444514dbc, S7f3f5c63b6fe99b1734383d7601f8140);  
#  endif
 if (S1282400098429c5470611495b46d63d8) S29464bd8ff045846d164d4a2ecb441d6("$lang_messages.ERROR_CREATE_THREAD"); 

# endif
 
#endif
 
#endif
 return S970a9b1a8c8325c7dc070ca73282c521; }  else return NULL; }  void S599b74f025e04cd0eaa04cdce33babc6(S4673665870260a6a927871499a4441fa 
S0ffdad806a67ca3d056fc98bc36136a5, int Sa29e8a9db3602caf729ecee3fab209d6) { 
#if HAVE_PTHREAD
 if (S3453986fad8ae18a4cddd52a6f55b49e) { 
#ifdef WINDOWS
 
#else
 
# ifdef macintosh
 
# else
  
#  if HAVE_PTHREAD_ATTR_SETSCHEDPARAM
 struct sched_param Se4031f959a1a9da800e27e37b6d3084d; Se4031f959a1a9da800e27e37b6d3084d.sched_priority 
= Sa29e8a9db3602caf729ecee3fab209d6; pthread_setschedparam(*((pthread_t *) S0ffdad806a67ca3d056fc98bc36136a5), 
SCHED_OTHER, &Se4031f959a1a9da800e27e37b6d3084d); 
#  endif
 
# endif
 
#endif
 }  
#endif
 }  void S4b7fab3e42860ee3e9bb8fc8faba5725(S4673665870260a6a927871499a4441fa S0ffdad806a67ca3d056fc98bc36136a5) 
{ 
#if HAVE_PTHREAD
 if (S3453986fad8ae18a4cddd52a6f55b49e) { 
#ifdef WINDOWS
 
#else
 
# ifdef macintosh
 
# else
   
# endif
 
#endif
 }  
#endif
 }  void S3b2e35290544af6997c8f7489ad887b6(S4673665870260a6a927871499a4441fa &S0ffdad806a67ca3d056fc98bc36136a5) 
{ 
#if HAVE_PTHREAD
 if (S3453986fad8ae18a4cddd52a6f55b49e) { 
#ifdef WINDOWS
 S0ffdad806a67ca3d056fc98bc36136a5 = new muint; 
#else
 
# ifdef macintosh
 S0ffdad806a67ca3d056fc98bc36136a5 = new Sa5e7526a4f6f3f0ef1e89c706925a5ff; 
# else
 S0ffdad806a67ca3d056fc98bc36136a5 = new pthread_t; 
# endif
 
#endif
 }  
#endif
 }  void Sd8c67ec4768107c629614b5cde8b0e89(S4673665870260a6a927871499a4441fa S0ffdad806a67ca3d056fc98bc36136a5) 
{ 
#if HAVE_PTHREAD
 if (S3453986fad8ae18a4cddd52a6f55b49e) { 
#ifdef WINDOWS
 delete((muint *) S0ffdad806a67ca3d056fc98bc36136a5); 
#else
 
# ifdef macintosh
 delete((Sa5e7526a4f6f3f0ef1e89c706925a5ff *) S0ffdad806a67ca3d056fc98bc36136a5); 
# else
 delete((pthread_t *) S0ffdad806a67ca3d056fc98bc36136a5); 
# endif
 
#endif
 }  
#endif
 }  S4673665870260a6a927871499a4441fa Se0179f6f891be04e60aa506e5f450b27(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Sd8dc4e17d5d1560eaab0e15042065b71 *S1a716db23f47491edaab7f33f44a80d1, 
int Sa29e8a9db3602caf729ecee3fab209d6, void *Sc8353b64d6ed55646496b7e7bb8ea712); void Sd8c67ec4768107c629614b5cde8b0e89(S4673665870260a6a927871499a4441fa 
S0ffdad806a67ca3d056fc98bc36136a5);

