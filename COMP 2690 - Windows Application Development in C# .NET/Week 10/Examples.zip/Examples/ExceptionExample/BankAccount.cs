using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace COMP2690.Bank
{
	public class BankAccount
	{
		private decimal balance;

		public BankAccount(decimal openingBalance)
		{
			this.balance = openingBalance;
		}

		public void Withdraw(decimal amount)
		{
			if (!hasSufficientFunds(amount))
			{
				throw new NoSufficientFundsException(this, amount);
			}
			else
			{
				balance -= amount;
			}
		}

		public void Deposit(decimal amount)
		{
			balance += amount;
		}

		private bool hasSufficientFunds(decimal amount)
		{
			return balance >= amount;
		}

		public decimal Balance { get { return balance; } }

		public override string ToString()
		{
			return "Balance: " + Balance.ToString("C");
		}
	}

	public class NoSufficientFundsException : ApplicationException
	{
		private BankAccount account;
		private decimal transactionAmt;

		public NoSufficientFundsException(BankAccount account, decimal transactionAmt)
			: base("There are not sufficient funds to perform this transaction.")
		{
			this.account = account;
			this.transactionAmt = transactionAmt;
		}

		public BankAccount Account { get { return account; } }

		public decimal TransactionAmount { get { return transactionAmt; } }
	}
}
