import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Deck class. This represents a single deck of DECK_SIZE cards. This class has
 * several "stub" methods with comments and signatures. Feel free to add other
 * methods as you see fit. Suggestion: private void swap(int fistCard, int secondCard)
 * The suggested swap() method would function as a helper to the shuffle() method.
 * 
 * @author Colleen Penrowley 
 * @version Fall 2005 modified Fall 2006
 */
public class Deck  
{
    /** The number of cards in a deck */
    public static final int DECK_SIZE = 52;  
    /** The number of times to shuffle */
    public static final int TIMES_TO_SHUFFLE = 1000;  

   private ArrayList<Card> deck;                   // a deck of cards

    /**
     * Constructor for objects of class Deck
     */
    public Deck()
    {
       deck = new ArrayList<Card>();
       newDeck();
    }

    /**
     * Load a new deck with all DECK_SIZE cards
     */
    public void newDeck()
    {
        // create DECK_SIZE card objects and put them into the deck
    }
    
    /**
     * Add a single card to the deck.
     * @param a Card object
     */
    public void addCard(Card newCard)
    {
       // add a card to the deck
    }
    
    /**
     * Shuffle the deck. This involves selecting random pairs of 
     * cards and swapping them, the number of times to swap determined
     * by the constant TIMES_TO_SHUFFLE. Java provides a shuffle method
     * as part of the Collections interface, however for this assignment
     * you must write your own.
     */
    public void shuffle()
    {
        // shuffle the deck
    }
    
    
    /**
     * Display the entire contents of the deck. Not used in the
     * game but useful for debugging.
     */
    public void showDeck()
    {
        // show deck contents
    }
    
    /**
     * Remove the top card (the first card) from the deck.
     * @return the Card object removed or null if there is nothing in the deck.
     */
    public Card takeCard()
    {
        // return card or 
        return null;
    }
    

}
