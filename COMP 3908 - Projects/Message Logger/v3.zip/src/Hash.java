/*
 * Hash.java
 *
 * MLogger, 2008
 * Confidential and proprietary.
 */
package src;
import net.rim.device.api.crypto.HMACKey;
import net.rim.device.api.crypto.HMAC;
import net.rim.device.api.crypto.CryptoException;
import net.rim.device.api.crypto.MACOutputStream;
import net.rim.device.api.crypto.SHA1Digest;
import java.io.IOException;

/**
 * SHA1 hashing library class.
 */
public class Hash {
        
        /**
         * Generates an SHA1 hash given an input (using a blank key).
         * @param plainText Input text to hash.
         */
        public static String hash(String plainText) {
                String key = "";
                return hash(plainText, key);
        }
        
        /**
         * Generates an SHA1 hash given input and a key.
         * @param plainText Input text to hash.
         * @param hashKey Key to use for hashing.
         * @return Hashed data.
         */
        public static String hash(String plainText, String hashKey) {
            // temporary output storage
            byte[] digestData = {};
            
            // generate hash
            try {
                HMACKey key = new HMACKey(hashKey.getBytes());
                HMAC hMac = new HMAC(key, new SHA1Digest());
                MACOutputStream macStream = new MACOutputStream(hMac, null);
                macStream.write(plainText.getBytes());
                hMac.getMAC(digestData, 0);
            } catch (CryptoException e) {
                System.out.println("Crypt Exception: " + e);
                return "BAD Crypto";
            } catch (IOException e) {
                System.out.println("IOException: " + e);
                return "BAD IO";
            }
            
            // return hash
            return new String(digestData);
        }
}
