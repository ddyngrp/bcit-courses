import lejos.nxt.*;

public class MotorTest
{
    public static void main(String [] args) 
	{

		TouchSensor touch;
		touch = new TouchSensor(SensorPort.S1);
		while(!touch.isPressed())
		{
			Motor.A.forward();
		}

	}
}