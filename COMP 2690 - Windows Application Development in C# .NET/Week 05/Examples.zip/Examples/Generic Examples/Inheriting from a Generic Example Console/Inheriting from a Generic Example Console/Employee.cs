using System;
using System.Collections.Generic;
using System.Text;

namespace Inheriting_from_a_Generic_Example_Console
{
	public class Employee
	{
		private string name;
		private DateTime birthDate;
		private decimal totalCompensationEver;
		private int annualSalary;

		public Employee(string name, DateTime birthDate, int annualSalary)
		{
			this.name = name;
			this.birthDate = birthDate;
			this.totalCompensationEver = 0m;
			this.annualSalary = annualSalary;
		}

		public string Name { get { return name; } }

		public DateTime BirthDate { get { return birthDate; } }

		public int Age
		{
			get
			{
				DateTime now = DateTime.Now;
				int years = now.Year - birthDate.Year;

				// Has the person had a birthday this year?
				if ((now.Month < birthDate.Month)
						|| (now.Month == birthDate.Month && now.Day < birthDate.Day))
				{
					--years;
				}

				return years;
			}
		}

		public decimal TotalCompensationEver { get { return totalCompensationEver; } }

		public int AnnualSalary { get { return annualSalary; } }

		public void GiveRaise(int raise)
		{
			annualSalary += raise;
		}

		public void GiveBonus(decimal bonus)
		{
			totalCompensationEver += bonus;
		}

		public override string ToString()
		{
			return string.Format("{0}\n\t{1,-10} : {2} years old (born {3})\n\t{4,-10} : {5:C}\n\t{6,-10} : {7:C}",
					name, 
					"Age", Age, BirthDate.ToLongDateString(),
					"Salary", AnnualSalary,
					"Total Paid", TotalCompensationEver);
		}

	}
}
