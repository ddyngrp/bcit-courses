//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S04556290e1879ccec24ea0ac090b654c
 
#define S04556290e1879ccec24ea0ac090b654c
 
#include "S6ba6d720b7aeea661f5fbdf8872359a7.h"

#include "S17670e2d33cef852a486512d32a4a009.h"
 class S7ca5d44c3992eca4f11ed4ee768968cd; 
#define Sdb5866da64ebf639a5188b7d1c5eea97(name) Scc2faae6b412ac43b64129b402c4b88e.S44fb699c016f82a63dafaaf91baa1ec7->name(Scc2faae6b412ac43b64129b402c4b88e)
 class S1c339ad9d38116c1ca972a03774587e2 : public Saee9fc179d3e60f8fab2ae94c4883a93 { private: typedef 
struct { Sc9febc6fc903e0d23cfa2c30d4e6e3ba(S0f463f61fc04661c79755a8d81985228); Sbdd741232d1001ae35892289d2679fee(Sb44aa1164d5b1837a4e5b90e03d0c6b6); 
} S32cfae6d58bed51e604d9b137b7a62ba; S32cfae6d58bed51e604d9b137b7a62ba Sb81599bdf713b73487af2165efb27855; 
virtual void S7a1b927b33f96167f2aeff3ffbba6bb3(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{ S4fe531feca96e91290995f279d25bfd7(S0f463f61fc04661c79755a8d81985228, "progress_page_interval"); S9777db80b90847ef41d492c4043ee44e(Sb44aa1164d5b1837a4e5b90e03d0c6b6, 
"use_base_ten_for_byte_display", false); } public: S1c339ad9d38116c1ca972a03774587e2(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S7ca5d44c3992eca4f11ed4ee768968cd *S4b19b4b29bb277e733b991ae57b96d19) 
: Saee9fc179d3e60f8fab2ae94c4883a93(Scc2faae6b412ac43b64129b402c4b88e, S4b19b4b29bb277e733b991ae57b96d19) 
{ S1270a605f0fce74deff33447ee922daf->Sb81599bdf713b73487af2165efb27855 = this; } S8dbdf3515e7651f3a587ee9b6db7ac5f(S0f463f61fc04661c79755a8d81985228); 
Sc32adba7c162faf62e203ab26e0c3ae3(Sb44aa1164d5b1837a4e5b90e03d0c6b6); }; 
#endif


