import lejos.nxt.*;
import lejos.subsumption.*;

public class HitWall1 implements Behavior {
	
   TouchSensor touch;
   
   public HitWall1()
   {
	   touch = new TouchSensor(SensorPort.S2);
   }
   
   public boolean takeControl() {
      return touch.isPressed();
   }

   public void suppress() {
      Motor.A.stop();
      Motor.B.stop();
   }

   public void action() {
      // Back up:
      Motor.A.backward();
      Motor.B.backward();
      try{Thread.sleep(1000);}catch(Exception e) {}
      // Rotate by causing only one wheel to stop:
      Motor.A.stop();
      try{Thread.sleep(300);}catch(Exception e) {}
	  Motor.A.forward();
	  Motor.B.forward();
	  try{Thread.sleep(500);}catch(Exception e) {}
	  Motor.A.stop();
      try{Thread.sleep(300);}catch(Exception e) {}
   }
}


