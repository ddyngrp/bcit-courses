using System;
using System.Collections.Generic;
using System.Text;

namespace ListExample
{
	class Program
	{
		static void Main(string[] args)
		{
			List<Student> students = new List<Student>();

			students.Add(new Student("A00234567", "Mary", "Sanders"));

			Student student = new Student("A00347272", "Joanne", "Lambert");
			students.Add(student);

			students.Add("Julia");

			Console.WriteLine(students[0].Name);
		}
	}

	class Student
	{
		private string id;
		private string firstName;
		private string lastName;

		public Student(string id, string firstName, string lastName)
		{
			this.id = id;
			this.firstName = firstName;
			this.lastName = lastName;
		}

		public string ID { get { return id; } }
		public string Name { get { return firstName + " " + lastName; } }
	}
}
