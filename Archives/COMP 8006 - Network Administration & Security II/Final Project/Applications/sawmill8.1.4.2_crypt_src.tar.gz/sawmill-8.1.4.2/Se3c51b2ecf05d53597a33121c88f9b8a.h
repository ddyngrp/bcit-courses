//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#ifndef S0cba8ebc3737e15407fec57d03f77009
 
#define S0cba8ebc3737e15407fec57d03f77009
 
#include "S9f97187eb46793414e2c223f64b64f2a.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"
  S09799fec94d4fc2cf5cc3b724f1b8538 muint Sc9108e33c10c2d0b84c7e81f13e2c6e9::S5730725bc3376b16e20806b41aeda41e(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, register const unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058, 
register unsigned char S921bd2f8661f964a119e73fe452bb8ab) { return *((muint *) (S6ae56faa6e8f98fc7a905516d7c5b058 
+ Sf3692b4d9c644ff1df5680b514340236[S921bd2f8661f964a119e73fe452bb8ab])); }   S09799fec94d4fc2cf5cc3b724f1b8538 
void Sc9108e33c10c2d0b84c7e81f13e2c6e9::Sd1a1672b0cd3a54597c929b5911f5cca(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, register unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058, register 
unsigned char S921bd2f8661f964a119e73fe452bb8ab, register muint Sb79d4a4ac05ebdb8cb70e6b5594e9473) { 
*((muint *) (S6ae56faa6e8f98fc7a905516d7c5b058 + Sf3692b4d9c644ff1df5680b514340236[S921bd2f8661f964a119e73fe452bb8ab])) 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473; }   S09799fec94d4fc2cf5cc3b724f1b8538 void Sc9108e33c10c2d0b84c7e81f13e2c6e9::Sdfd062c4d51903256b5befefc334d94d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, register unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058, register 
int S921bd2f8661f964a119e73fe452bb8ab, register double Sb79d4a4ac05ebdb8cb70e6b5594e9473) { *((double 
*) (S6ae56faa6e8f98fc7a905516d7c5b058 + Sf3692b4d9c644ff1df5680b514340236[S921bd2f8661f964a119e73fe452bb8ab])) 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473; }   S09799fec94d4fc2cf5cc3b724f1b8538 double Sc9108e33c10c2d0b84c7e81f13e2c6e9::S652a6dcd2b115adfe27c6d9faa9d478d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, register const unsigned char *S6ae56faa6e8f98fc7a905516d7c5b058, 
register int S921bd2f8661f964a119e73fe452bb8ab) { return *((double *) (S6ae56faa6e8f98fc7a905516d7c5b058 
+ Sf3692b4d9c644ff1df5680b514340236[S921bd2f8661f964a119e73fe452bb8ab])); }  S09799fec94d4fc2cf5cc3b724f1b8538 
void Sc9108e33c10c2d0b84c7e81f13e2c6e9::S02c93a0dc80c9d91d29be0b8ba5f771f(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, register unsigned char **Sd8ceb361dd14427966d2087d54dd19ff, register 
int Se3f65b43cbb0b1b0f5e428cd18cea52a, register double S1396a8a482620bfd0f2e6cdd97a5f9f9, register double 
S990f56787ede499c671282f7ba9921e2) { register double S4a52ee54159302a137dd2e714d21db36, Sb187abb9bc6fb863a353081b390dc455; 
S709f8a104a477b9e6883c170d8a6a334(S4a52ee54159302a137dd2e714d21db36 = S47944c73b8a7908706f3752a88a8f03e(Scc2faae6b412ac43b64129b402c4b88e, 
*Sd8ceb361dd14427966d2087d54dd19ff, Se3f65b43cbb0b1b0f5e428cd18cea52a));  Sb187abb9bc6fb863a353081b390dc455 
= S4a52ee54159302a137dd2e714d21db36 + S1396a8a482620bfd0f2e6cdd97a5f9f9;     S709f8a104a477b9e6883c170d8a6a334(Sb7366e33c7da5bc61f7f17a56d8caa55(Scc2faae6b412ac43b64129b402c4b88e, 
*Sd8ceb361dd14427966d2087d54dd19ff, Se3f65b43cbb0b1b0f5e428cd18cea52a, Sb187abb9bc6fb863a353081b390dc455)); 
} 
#endif
 
#endif


