//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sf448753e802906819c049042472288c1
 
#define Sf448753e802906819c049042472288c1
 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sc157c2f77b7c40e8e321884b9ff616a4.h"

#include "Se00f7d81e824b8a8baa31e30777a2666.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S65b54cd362bca037dc0b5544f5095c09.h"

#include "S78ad491ac8a005c50b041106551db851.h"

#include "Sa962fe56d31486f7085f178942f70f9b.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#if HAVE_LIMITS_H
 
#include <limits.h>

#endif
 
#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class S69ea874c0a8d775fbb8debfe711290ba; class Se95419184494485796fb04318437d0ef 
{ public: Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e; mint S413a37d4b34cc0215a41e782fed855df; 
char *S38b3ce476209b0f8d488f435348215a2; mint S3c407ef36deb015a1d32cf2311cc2baf;  const char **Scae613df5f8d33d29ffa329e57180663; 
mint *S4ca5215a5e7bbbfe52d1a0333381e334; mint S7b9cef2f74cb8fa6199f8baebdd440d5; mint S22efc6513eeda9829fedd841883a3297; 
bool S37a547029d0d78ca49d236c747ce7624; mint Scd25b4ef2f5df438ff40b3326672f3a1; const char *S57bf54222a6b000401eeb0d340da81a9; 
 bool S1293707b45fc4a3a87134ac33f1a903c; const char *Sc968afa79815fe2cf0d903caaff9c79a; mint Sc0f4d1963f4c9b74bee20fea9666430e; 
 virtual void Sbd48403dc68e63f93b65f43083cfa74d(void) = 0; void Sb933258fedc2fb60398b3adaf82fc00e(void); 
public: mint S06280ddaafea1149147cafcd52755f67; mint S5b78f18711ee5653a11af9015974b673; Se95419184494485796fb04318437d0ef(Sc51497dedb5c0712f20ccaa9831c0365 
&S8fed4bd55d0dde65809c290f6d813bac, mint S9803bb85cf26fa79e0ac7e0e2e3c6492, const char *S21b42b84730c9a64978bb6d2fe7ef91e, 
bool S28b6362a102d62bf05137e0eb93d6b62); virtual ~Se95419184494485796fb04318437d0ef(void); virtual void 
S6c52b36a5530b8c11dc0ab0e4eb17ee0(void) = 0; virtual void S65c3edcea92e9b61059d87efa1297a7b(const char 
*S21b42b84730c9a64978bb6d2fe7ef91e, bool S28b6362a102d62bf05137e0eb93d6b62); virtual void S5224d940a63f99e95f980c0c01ba8e8c(void) 
= 0; const char *Sc9874f3d37354bf24890787bc9ba7ff6(void); mint Sdb8d4949eb2d5d43f9cb89f54889da33(S69ea874c0a8d775fbb8debfe711290ba 
*Sde98bde6aca3d1974bc059249c4c2367); mint S39fa000b919513a80e6650f5910c2638(void); virtual void S58283a663d72cd35da7cfeeefada5d45(void) 
{} void S49edaff3fe63042500684ae6ad423010(void); };  
#include "Sb525e61d737826a9724d3a17cfaed63a.h"
S5b2556faa18cdaca5a6ad039f29d6254 &operator << (S5b2556faa18cdaca5a6ad039f29d6254 &Scd4082426bdc6a9533556b5ca60add93, 
const Se95419184494485796fb04318437d0ef &S9583b4b682f2db878c2e571ec4c7e94c); 
#endif


