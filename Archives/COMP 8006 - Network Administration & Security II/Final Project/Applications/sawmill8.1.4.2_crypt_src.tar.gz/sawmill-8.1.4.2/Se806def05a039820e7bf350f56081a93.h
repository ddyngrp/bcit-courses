//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S8b1430a0291e1ad8090ee9709263924d
 
#define S8b1430a0291e1ad8090ee9709263924d
 
#include "S6ba6d720b7aeea661f5fbdf8872359a7.h"

#include <vector>
    
#include <map>
 class Se95419184494485796fb04318437d0ef; class Sa14f2810aa7f7746ebe6af24ad45815a; class S7ca5d44c3992eca4f11ed4ee768968cd; 
class S75ccf9043716e1e65fb03e27bd56b316; class S2c40c34261004b483b5b1d71ce1b2574 : public Saee9fc179d3e60f8fab2ae94c4883a93 
{ private: vector<S75ccf9043716e1e65fb03e27bd56b316*> Se806def05a039820e7bf350f56081a93; map<mint, mint> 
S5f6be95e79c71c863d24a5fe3a42a4c0;  void S7a1b927b33f96167f2aeff3ffbba6bb3(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S5b8584b8b333b248ee8dbe86c8b39540(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void Sef888672fdcbbff1ae8b369ed6f90b9d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e);                             public: S2c40c34261004b483b5b1d71ce1b2574(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S7ca5d44c3992eca4f11ed4ee768968cd *S4b19b4b29bb277e733b991ae57b96d19); 
virtual ~S2c40c34261004b483b5b1d71ce1b2574(void) {} void Sb32e23a157a33f28a04344edc66b04df(void); size_t 
S8745a864c05450cdbcb26d461cdc311a(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
S75ccf9043716e1e65fb03e27bd56b316 *S165eee74517178d3462ca33432982738(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, mint Sc0f4d1963f4c9b74bee20fea9666430e) { return Se806def05a039820e7bf350f56081a93[Sc0f4d1963f4c9b74bee20fea9666430e]; 
} mint Sce50b58eb6b4ab4f6f55d3fb62aa3158(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S8c4ce22cb8fcad79d81f1499da387f4c); mint S52281ee8ee042d68ff16f0dba5fd5716(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, mint S413a37d4b34cc0215a41e782fed855df); void S8d988d6e0ad1355abb46ca170ead16a8(void) 
{ S5f6be95e79c71c863d24a5fe3a42a4c0.erase(S5f6be95e79c71c863d24a5fe3a42a4c0.begin(), S5f6be95e79c71c863d24a5fe3a42a4c0.end()); 
}; mint Sc4222d932bcf71de49a03f7e8425e1d7; mint Scc62bb6be72e09ba11039f29c27bb6ea; mint S60bf19b9e8141c7c493353d482877e11; 
mint Sfe0b9f9860b45df4187dd66db3297cc7; mint S0f0fd92953101902c48ce9b4ce3b3c40; mint S467ede3800e44915d74e5f45b464abd9; 
mint S28b0f807f713abb7f2f7cca57b82195f; mint S1223e23d7141e9b765a9b5d1c1af8383; mint Sb75fc8169e7ea3bcc9f7d2faf906912f; 
mint S0b9eee8798411c2e9ec880f1fec9625d; mint Sd3a85f6497b63c9f97eea68cd9d41a6c; mint Sd43c581eb3c128ee4120c897e3de9467; 
mint Sa90fcd013645b34ddeee498e6b1cefcd; mint S99a1a474fb000d5dee4845bdc3f966da; mint S6334edb8944b76be955c9d792ba14e86; 
mint S5ed921b3f5076f49bb4bbcbc1533c7d8; mint S63b0a0e99bb889da03f37f839bdb2e86; mint Sfdf23d138afb80e37645cef29d5dc7b4; 
mint S7734f3a3320f625bdfb0f74bdd2419e9; mint S17542c8a2d438fa2206a13489b81ef15; mint Sdffd1baace7fe3bbb66235071bddde18; 
mint S68e23afaff0f97ec462cfe41c2a9e55c; mint S820abfc709da0bc711b925fbb487781f; mint S0d9e19b7416c391adeaba5fb5758ae84; 
mint S606f8c8b3febde24ee6c4533098d5caf; mint Scc381d9ea7b02fdbdc3fa194138965d0; mint Sd2d72de267c32e302b55b74fc4013c20; 
mint S73c0a69ffd5abdc66fa7d6700b100f61; mint S2fa2e4f6a86b35ef2de571c675b025b0; mint Se0f202086c3fc225cfd126a8da6510ee; 
mint Sb21a615240d8b44c15c7caab41d65d21; mint S0fb6327be0b5394343c296c35d6a7927; mint Sba63390f801fe376453da062f40754ac; 
mint Scd98fdd66eb4275f2a11187d87616af8; mint Sbe882b6910285fa4e9b850cc0a3edf8b; mint S084e789181b16fb70aff99d8e759b097; 
mint Sc5d4dcb442eed1df9190fb0cd1e83bf2;  mint S40dadd88aab4a5f463b1db8313993842; mint Sd6bcce9af01a6bbfed2d7c8250576ac5; 
 mint S642fa58ba63da14b79925563460a2316;                              };   
#endif


