//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
   
#include "sconfig.h"

#include "S82ae862efe6a00861e0794a99d6d803a.h"

#include "S3e068ccadc2f2885bc7f19ebf2ffff5e.h"

#include "gd.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "S6d69e97c87112f6ae4eeffb9c717b5fc.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"
 S754fcfbb62501a1fc9d67493bc0ebf6d S2df2e431a55fac90664cd30c2701f617(const S754fcfbb62501a1fc9d67493bc0ebf6d 
&Saa067c679173735c5d68fa7880012de4, const S754fcfbb62501a1fc9d67493bc0ebf6d &Sd5bc2fe3f3a4ef4405245ceae06ea548, 
const S754fcfbb62501a1fc9d67493bc0ebf6d &S55faae134fd9c1fb402889360cb12344) { return (Saa067c679173735c5d68fa7880012de4 
- Sd5bc2fe3f3a4ef4405245ceae06ea548).Sbff9cd766121d61662d70bf59097222e(Sd5bc2fe3f3a4ef4405245ceae06ea548 
- S55faae134fd9c1fb402889360cb12344); }  int S7d4c8f8a75754029a8f21cedadeda817(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S754fcfbb62501a1fc9d67493bc0ebf6d &S833cf2d7b58abc513d6f289ee4963ca4, 
gdImagePtr Sc38957f913dee39d165b20011d1ec1de, const Sfa93259f631b1566813ef0fd26878676 &S7abc8b241a35c679e5f143e6ea136665) 
{ double S20aef69c7f26392285bf797b786d9fba; if (S6d9b0f0a8f5c6afe82a10301fb5a05b7("statistics.miscellaneous.use_3d_graphs")) 
{ S754fcfbb62501a1fc9d67493bc0ebf6d S5cb907a4d629cee88bd261613cabfa4f((double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.x"), 
(double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.y"), (double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.z")); 
S20aef69c7f26392285bf797b786d9fba = S833cf2d7b58abc513d6f289ee4963ca4.Sb7aef162de8b9c5330d06239f0c4b541(S5cb907a4d629cee88bd261613cabfa4f); 
if (S20aef69c7f26392285bf797b786d9fba < 0) S20aef69c7f26392285bf797b786d9fba = 0; if (S20aef69c7f26392285bf797b786d9fba 
< 0.9) S20aef69c7f26392285bf797b786d9fba += 0.1; }  else S20aef69c7f26392285bf797b786d9fba = 1; int 
red = (int) (S20aef69c7f26392285bf797b786d9fba * S7abc8b241a35c679e5f143e6ea136665.red); int green = 
(int) (S20aef69c7f26392285bf797b786d9fba * S7abc8b241a35c679e5f143e6ea136665.green); int blue = (int) 
(S20aef69c7f26392285bf797b786d9fba * S7abc8b241a35c679e5f143e6ea136665.blue); int S061f09ad503732dac6ec600c195676a7 
= gdImageColorAllocate(Sc38957f913dee39d165b20011d1ec1de, red, green, blue); return S061f09ad503732dac6ec600c195676a7; 
}  Sfa93259f631b1566813ef0fd26878676 S05989e2ea69e41301b1cdde87ccefa06(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S754fcfbb62501a1fc9d67493bc0ebf6d &S833cf2d7b58abc513d6f289ee4963ca4, 
const Sfa93259f631b1566813ef0fd26878676 &S7abc8b241a35c679e5f143e6ea136665) { double S20aef69c7f26392285bf797b786d9fba 
= 0; if (S6d9b0f0a8f5c6afe82a10301fb5a05b7("statistics.miscellaneous.use_3d_graphs")) { S754fcfbb62501a1fc9d67493bc0ebf6d 
S5cb907a4d629cee88bd261613cabfa4f((double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.x"), 
(double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.y"), (double) S195c9961aa1bdcfba2707a9818c5ef9e("light_direction_vector.z")); 
S20aef69c7f26392285bf797b786d9fba = S833cf2d7b58abc513d6f289ee4963ca4.Sb7aef162de8b9c5330d06239f0c4b541(S5cb907a4d629cee88bd261613cabfa4f); 
if (S20aef69c7f26392285bf797b786d9fba < 0) S20aef69c7f26392285bf797b786d9fba = 0; if (S20aef69c7f26392285bf797b786d9fba 
< 0.9) S20aef69c7f26392285bf797b786d9fba += 0.1; }  else S20aef69c7f26392285bf797b786d9fba = 1; Sfa93259f631b1566813ef0fd26878676 
S34410ea0d7783276aa8b5d4a06172810; S34410ea0d7783276aa8b5d4a06172810.red = (int) (S20aef69c7f26392285bf797b786d9fba 
* S7abc8b241a35c679e5f143e6ea136665.red); S34410ea0d7783276aa8b5d4a06172810.green = (int) (S20aef69c7f26392285bf797b786d9fba 
* S7abc8b241a35c679e5f143e6ea136665.green); S34410ea0d7783276aa8b5d4a06172810.blue = (int) (S20aef69c7f26392285bf797b786d9fba 
* S7abc8b241a35c679e5f143e6ea136665.blue); return S34410ea0d7783276aa8b5d4a06172810; }  ostream &operator 
<< (ostream &Scd4082426bdc6a9533556b5ca60add93, const Sfa93259f631b1566813ef0fd26878676 &S7abc8b241a35c679e5f143e6ea136665) 
{ Scd4082426bdc6a9533556b5ca60add93 << "color:[" << (int) S7abc8b241a35c679e5f143e6ea136665.red << ", " 
<< (int) S7abc8b241a35c679e5f143e6ea136665.green << ", " << (int) S7abc8b241a35c679e5f143e6ea136665.blue 
<< "]"; return Scd4082426bdc6a9533556b5ca60add93; } ostream &operator << (ostream &Scd4082426bdc6a9533556b5ca60add93, 
const S754fcfbb62501a1fc9d67493bc0ebf6d &S9ce866776db3a93c43fe102b8f1b359e) { Scd4082426bdc6a9533556b5ca60add93 
<< "color:[" << S9ce866776db3a93c43fe102b8f1b359e.x << ", " << S9ce866776db3a93c43fe102b8f1b359e.y << 
", " << S9ce866776db3a93c43fe102b8f1b359e.Sc44908580ec1b6991d4b56919a4981df << "]"; return Scd4082426bdc6a9533556b5ca60add93; 
} 
#endif


