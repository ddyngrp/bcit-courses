package android.demo.cryptography;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class CryptographyDemo extends Activity {
	
	/**
	 * Initialize UI Components
	 */
	EditText plain_txt;
	EditText key_txt;
	EditText cipher_txt;
	EditText final_txt;
	Button encrypt_btn;
	Button decrypt_btn;
	RadioButton aes_radio;
	RadioButton des_radio;
	
	Context context;
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        context = this;
        
        // setup ui
        setupUI();
        
        // disable encrypt button for now
        decrypt_btn.setEnabled(false);
        
        // enable AES by default
        aes_radio.setChecked(true);
        
        // encrypt button function
        encrypt_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// check for empty fields
				if (plain_txt.getText().toString().equals("") || key_txt.getText().toString().equals("")) {
					Toast.makeText(context, "Plain and Key text CANNOT be empty!", Toast.LENGTH_SHORT).show();
				} else {
					// do encryption here
					Cryptography c = new Cryptography(getMode(), key_txt.getText().toString(), plain_txt.getText().toString());
					try {
						cipher_txt.setText(c.encrypt());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					// disable encrypt button and enable decrypt button
					encrypt_btn.setEnabled(false);
					decrypt_btn.setEnabled(true);
				}
			}
		});
        
        decrypt_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// check for empty key and ciphered text
				if (cipher_txt.getText().toString().equals("") || key_txt.getText().toString().equals("")) {
					Toast.makeText(context, "Plain and Key text CANNOT be empty!", Toast.LENGTH_SHORT).show();
				} else {
					// do decryption here
					Cryptography c = new Cryptography(getMode(), key_txt.getText().toString(), cipher_txt.getText().toString());
					try {
						final_txt.setText(c.decrypt());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					// disable decrypt button and enable encrypt button 
					decrypt_btn.setEnabled(false);
					encrypt_btn.setEnabled(true);
				}
			}
		});
    }
    
    private void setupUI() {
    	plain_txt = (EditText) findViewById(R.id.plaintext_txt);
    	key_txt = (EditText) findViewById(R.id.key_txt);
    	cipher_txt = (EditText) findViewById(R.id.cipher_txt);
    	final_txt = (EditText) findViewById(R.id.final_txt);
    	encrypt_btn = (Button) findViewById(R.id.encrypt_btn);
    	decrypt_btn = (Button) findViewById(R.id.decrypt_btn);
    	aes_radio = (RadioButton) findViewById(R.id.aes_radio);
    	des_radio = (RadioButton) findViewById(R.id.des_radio);
    	
    	System.out.println("UI Components is setup!");
    }
    
    private String getMode() {
    	if (aes_radio.isChecked()) return "AES";
    	if (des_radio.isChecked()) return "DES";
    	return "EMPTY";
    }
}