//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S1e8343b4251aafaed4a603cefa048dbc
 
#define S1e8343b4251aafaed4a603cefa048dbc
 
#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class Saacb9dc4c09242bfd4043bbe6215dcf9; class S0bce76637347695d0236157510f849a2 
{ S6d6cbe6673721b1104d6dcb8de7beb6a S8f6d58719a8abe5ca435a10b3ceca358; Saacb9dc4c09242bfd4043bbe6215dcf9 
*Sde98bde6aca3d1974bc059249c4c2367; public: S0bce76637347695d0236157510f849a2(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, Saacb9dc4c09242bfd4043bbe6215dcf9 *Sde98bde6aca3d1974bc059249c4c2367, 
const char *S8f6d58719a8abe5ca435a10b3ceca358); void Saf03001b3dcd0947638d6aaf9560149f(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); };  
#endif


