using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplicationExample
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// Add your code here.
		}

		private void btnGreeting_Click(object sender, EventArgs e)
		{
			// Add your code here.
			MessageBox.Show("Hello world!");
		}
	}
}