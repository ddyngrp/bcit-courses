
import java.util.*;

/**
 * ADT kinda class for a Show.
 * This makes the tvdata processing easier, but doesn't necessarily help the BBC processing.
 */
public class Show implements Comparable {

    public String title;
    public String description;
    public String startsAt; // use strings for time - convenient
    public String endsAt;
    public List<String> categories = null;

    public Show() {
        categories = new ArrayList<String>();
    }

    /**
     * Determine if this show falls inside a specific viewing window
     */
    public boolean fallsInside(String windowStart, String windowEnd) {
        return (((startsAt.compareTo(windowStart) >= 0) && (startsAt.compareTo(windowEnd) < 0) ||
                ((endsAt.compareTo(windowStart) > 0) && (endsAt.compareTo(windowEnd) <= 0))));
    }

    public int compareTo(Object a) {
        Show aaa = (Show) a;
        return aaa.startsAt.compareTo(this.startsAt);
    }
}
