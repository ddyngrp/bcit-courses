using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace ListBoxExample
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// Allow user to either select from the list or type any text.
			cboOverallImpression.DropDownStyle = ComboBoxStyle.DropDown;
			populateOverallImpressionList();

			// Allow user to just select from the list.
			cboRecommend.DropDownStyle = ComboBoxStyle.DropDownList;
			populateRecommendList();
		}

		private void populateOverallImpressionList()
		{
			cboOverallImpression.Items.Clear();
			cboOverallImpression.Items.Add("Great");
			cboOverallImpression.Items.Add("Satisfactory");
			cboOverallImpression.Items.Add("Needs improvement");
		}

		private void populateRecommendList()
		{
			cboRecommend.Items.Add("Yes");
			cboRecommend.Items.Add("No");
			cboRecommend.Items.Add("Undecided");
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

	}

}