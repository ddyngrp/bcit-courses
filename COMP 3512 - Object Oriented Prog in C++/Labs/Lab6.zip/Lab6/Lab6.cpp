#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "header.h"

using namespace std;

int main()
{
	Clock c1 = Clock::Clock(13,5);
	Clock c2 = Clock::Clock("2:5");
	Clock c3 = Clock::Clock("13:5");
	c1.print();
	c2.print();
	c2++;
	c2.print();
	++c2;
	c2.print();
	if(c3==c1)
		cout<<"good"<<endl;
	if(c3!=c1)
		cout<<"good1"<<endl;
	if(c2!=c1)
		cout<<"good2"<<endl;
	cout<<c1;
	cout<<c2;
	cout<<c3;
	return 0;
}
