//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class S80faba96320f3c09d9ebd10e2786c7c1 { Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e; bool S249fa597f1e02685fae1b078fe8970cd; public:   vector<muint> 
S39ffda1fd79ba0da373326e74d3fd752;   mint S413a37d4b34cc0215a41e782fed855df;  muint Sac595b55b1219ca6b8cc643ce8c934ed; 
bool *Sbdd28b8f77b41d64273166ccaf47cde9; bool *S2044bb40e86437b286b545c620e17479; bool *S6815a6373b3a72dc1a469f3fe2a711ce; 
muint Safef96f988426d0fe4e47687227c76de; muint S9728453cf69d84551798b735a34db471; bool Sd63620a58a0e3842c00304c477dd8b5a; 
S6d6cbe6673721b1104d6dcb8de7beb6a Se29dab00b28fe2fbc1938f628b1c1a14; S6d6cbe6673721b1104d6dcb8de7beb6a 
S6c262c7ae907d25e3bea365cad83902e; S6d6cbe6673721b1104d6dcb8de7beb6a S2181bd139ded7650debd2f6529a9e902; 
S6d6cbe6673721b1104d6dcb8de7beb6a Se8179fd2f5cc7352fe85a5a5728f4d56; public: bool S7b376e29bea3d4ce988ca1fc16dc2639; 
S80faba96320f3c09d9ebd10e2786c7c1(Sc51497dedb5c0712f20ccaa9831c0365 &S6ec129777c16ed8568398f5726365a75, 
muint S9803bb85cf26fa79e0ac7e0e2e3c6492, muint S74d248a693f01afc41ed401c9d361a40); S80faba96320f3c09d9ebd10e2786c7c1(Sc51497dedb5c0712f20ccaa9831c0365 
&S6ec129777c16ed8568398f5726365a75, muint S9803bb85cf26fa79e0ac7e0e2e3c6492, const char *S4109e536880d5514286a4c4ce1ae7788, 
bool S74ad438477ecf9773a0f8d6340b814ac); S80faba96320f3c09d9ebd10e2786c7c1(const S80faba96320f3c09d9ebd10e2786c7c1 
&Sa138e8351a9148ca0ebcdcca525408d1); S80faba96320f3c09d9ebd10e2786c7c1(const S80faba96320f3c09d9ebd10e2786c7c1 
*Sa138e8351a9148ca0ebcdcca525408d1); ~S80faba96320f3c09d9ebd10e2786c7c1(void); void S2addd03639662ea0487ec793539d2653(muint 
S3a726456978463ecd85dd4ae31baa068); S6d6cbe6673721b1104d6dcb8de7beb6a Sb07a2a36d07348538df9082bf5f90df7(void); 
   bool S70c4c99d24dc1e7e643c2a199e64a50c(bool S9b35f2f94eef8e9924626a8172018f33) const; muint Sb673f0a7e486d400b5c2043d1cd5c3d4(void); 
void S46aad1a1fe8b9fd9e35f777a283d1d6d(muint S3a726456978463ecd85dd4ae31baa068);  const char *Sfa785bbb39d7ca5102010802e35f8ff9(void); 
bool Se1b75b15a4054a7dc467fd258ef4bff7(void); bool Sc3f1a74994adc195a79cec8f14da9e06(S80faba96320f3c09d9ebd10e2786c7c1 
&S3e182de132bd59da166bb68e2dcd0708); size_t Sca6f14587d51b4c560953932924374c9(void); muint Scfcc57f29dc14ee34048f1cf2c0930d4(void); 
muint S7198be61e70aaf6bb45af1e99b0ece3b(void);  muint S81bb33d8b53926b9af7721c8aa4744f5(muint S3c407ef36deb015a1d32cf2311cc2baf 
= 0); muint Sc6d7a8bbbf2003065927cffbf2b5b881(void);  muint S834f2ebfa4009dd7613d0d7a04200916(void); 
muint Sbaf145e178b62c0d3b11f837c01f676b(void);   bool operator ==(const S80faba96320f3c09d9ebd10e2786c7c1 
&Sa138e8351a9148ca0ebcdcca525408d1); bool operator !=(const S80faba96320f3c09d9ebd10e2786c7c1 &Sa138e8351a9148ca0ebcdcca525408d1); 
void S8fb02d8e56e0fe182d0dba0dcc0ef573(S5b2556faa18cdaca5a6ad039f29d6254 &Scd4082426bdc6a9533556b5ca60add93) 
const; };  typedef S80faba96320f3c09d9ebd10e2786c7c1 *S8ccf988eda1fcf3154d27032ab687e1e; S5b2556faa18cdaca5a6ad039f29d6254 
&operator << (S5b2556faa18cdaca5a6ad039f29d6254 &Scd4082426bdc6a9533556b5ca60add93, const S80faba96320f3c09d9ebd10e2786c7c1 
&Sa138e8351a9148ca0ebcdcca525408d1);

