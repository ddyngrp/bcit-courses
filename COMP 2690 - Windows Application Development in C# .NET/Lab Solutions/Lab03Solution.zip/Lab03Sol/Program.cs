using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;

namespace Lab03Sol
{
	class Program
	{
		const int MENUITEM_DO_DIVISION = 1;
		const int MENUITEM_READ_MIXED = 2;

		static void Main(string[] args)
		{
			displayMainMenu();

			int iUserSelection;
			bool selectionMade = getIntFromUser("Enter a selection (1-2, blank to quit): ", 
					1, 2, out iUserSelection);

			if (selectionMade)
			{
				switch (iUserSelection)
				{
					case MENUITEM_READ_MIXED:
						doMixedDataExercise();
						break;
					case MENUITEM_DO_DIVISION:
						doNumbersExercise();
						break;
				}
			}

			// Pause before quitting, in case the user is running the program
			// from Windows Explorer.
			Console.WriteLine("\n\nGood-bye (hit Enter)...\n");
			Console.ReadLine();
		}

		private static void displayMainMenu()
		{
			Console.Clear();
			Console.WriteLine("COMP 2690 Lab 3\n================================================\n");
			Console.WriteLine(MENUITEM_DO_DIVISION + ". Do some division");
			Console.WriteLine(MENUITEM_READ_MIXED + ". Read mixed data from file");
			Console.WriteLine();
		}

		private static void doNumbersExercise()
		{
			int iNum1;
            int iNum2;	

			Console.Clear();
			Console.WriteLine("Please enter two whole numbers: \n");
	        getIntFromUser(" First Number: ", out iNum1);
            getIntFromUser("Second Number: ", out iNum2);

            if (iNum2 > 0)
            {
                Console.WriteLine("\nInteger division         : " + (iNum1 / iNum2).ToString());
                Console.WriteLine("Floating point division  : " + ((float)iNum1 / iNum2).ToString());
                Console.WriteLine("Modulus (remainder)      : " + (iNum1 % iNum2).ToString() + "\n");
            }
            else
            {
                Console.WriteLine("\nSecond number MUST be greater than zero.\n");
            }
		}

		private static void doMixedDataExercise()
		{
			StreamReader reader;
			string lineFromFile;
			float sum = 0.0f;

			Console.Clear();
			Console.Write("Enter path of mixed data file (blank to quit): ");

			string path = Console.ReadLine();
			if (path != "")
			{
				try
				{
					reader = new StreamReader(path);
				}
				catch (Exception ex)
				{
					Console.WriteLine("\nTrouble opening file: \n" + ex.Message + "\n");
					return;
				}

				Console.WriteLine();
				while ((lineFromFile = reader.ReadLine()) != null)
				{
					Console.Write(lineFromFile);

					char charValue;
					int intValue;
					float floatValue;

					if (char.TryParse(lineFromFile, out charValue))
					{
						Console.WriteLine("\tCharacter (ASCII value " + (int)charValue + ")");
					}
					else if (int.TryParse(lineFromFile, out intValue))
					{
						Console.WriteLine("\tInteger");
						sum += intValue;
					}
					else if (float.TryParse(lineFromFile, out floatValue))
					{
						Console.WriteLine("\tDouble");
						sum += floatValue;
					}
					else
					{
						Console.WriteLine("\tAssumed to be string");
					}
				}

				reader.Close();
				Console.WriteLine("\nSum of all numeric values is approximately " + sum.ToString("0.000") + "\n");
			}
		}

		/// <summary>
		/// Gets an integer from the user.  Keeps prompting under the user either 
		/// enters a valid integer or blank. 
		/// </summary>
		/// <param name="prompt">Message with which to prompt the user.  Makes 
		/// this method reusable in any console application.</param>
		/// <param name="result">(OUT) The integer entered by the user.</param>
		/// <returns>true if the user entered an integer; false if the user 
		/// entered nothing (empty string)</returns>
		private static bool getIntFromUser(string prompt, out int result)
		{
			string sInput;
			int iInput = 0;	// Take care of warning "use of unassigned variable".

			do
			{
				Console.Write(prompt);
				sInput = Console.ReadLine();
			} while( sInput != "" && int.TryParse(sInput, out iInput)==false );

			if( sInput == "" )
			{
				result = 0;	// Must always assign an 'out' parameter a value so give it something.
				return false;
			}
			else
			{
				result = iInput;
				return true;
			}
		}

		/// <summary>
		/// Gets an integer from the user.  Keeps prompting under the user either enters
		/// a valid integer between minValue and maxValue (inclusive) or blank.  (Written by CS.)
		/// </summary>
		/// <param name="prompt">Message with which to prompt the user.  Makes this method
		/// reusable in any console application.</param>
		/// <param name="minValue">Minimum integer value that is acceptable input.</param>
		/// <param name="maxValue">Maximum integer value that is acceptable input.</param>
		/// <param name="result">(OUT) The integer entered by the user.</param>
		/// <returns>true if the user entered an integer; false if the user entered 
		/// nothing (empty string)</returns>
		/// <returns></returns>
		private static bool getIntFromUser(string prompt, int minValue, int maxValue, out int result)
		{
			bool gotNum;

			do
			{
				gotNum = getIntFromUser(prompt, out result);
			} while (gotNum && (result < minValue || result > maxValue));

			return gotNum;
		}

	}
}
