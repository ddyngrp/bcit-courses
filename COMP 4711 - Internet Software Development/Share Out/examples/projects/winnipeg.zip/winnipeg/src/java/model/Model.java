/*
 * Model for the "static" data in the CFL, namely the league divisions, which contain teams.
 * 
 * This data is made available so you have an opportunity to practice
 * JSPs without XML.
 *
 * @author Jim Parry
 */
package model;

import java.util.*;

public class Model {

    /** Singleton instance */
    private static Model instance = null;
    /** Map to hold the league conferences */
    private SortedMap<String, Division> league = null;

    /** 
     * No argument constructor .
     * The "database" is populated by hard-coded statements.
     */
    private Model() {
        league = new TreeMap<String, Division>();

        Division div = new Division("West");
        div.add(new Team("bc", "BC", "Lions"));
        div.add(new Team("edmonton", "Edmonton", "Eskimos"));
        div.add(new Team("calgary", "Calgary", "Stampeders"));
        div.add(new Team("saskatchewan", "Saskatchewan", "Roughriders"));
        league.put("west",div);

        div = new Division("East");
        div.add(new Team("hamilton", "Hamilton", "Tiger-cats"));
        div.add(new Team("montral", "Montréal", "Alouettes"));
        div.add(new Team("toronto", "Toronto", "Argonauts"));
        div.add(new Team("winnipeg", "Winnipeg", "Blue Bombers"));
        league.put("east",div);

    }

    /** Singleton factory method */
    public static Model getInstance() {
        if (instance == null) {
            instance = new Model();
        }
        return instance;
    }

    /** Accessor for the league "database" */
    public SortedMap getLeague() {
        return league;
    }
}
