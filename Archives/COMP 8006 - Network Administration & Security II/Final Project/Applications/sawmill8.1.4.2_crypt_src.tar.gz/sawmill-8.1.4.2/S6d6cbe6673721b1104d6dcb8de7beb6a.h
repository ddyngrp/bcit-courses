//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sd3f9b13937154612fee3917bfb3ac813
 
#define Sd3f9b13937154612fee3917bfb3ac813
 
#include "string.h"

#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#include "sconfig.h"

#if HAVE_STRING_H
 
#include <string.h>

#endif
 class Sc51497dedb5c0712f20ccaa9831c0365; class S6d6cbe6673721b1104d6dcb8de7beb6a { private: const char 
*S36995569da14f148a7e4ad761c50f15a; public: off_t Sd8d77b1ed00928dcc1bbf26f7598511d; S6d6cbe6673721b1104d6dcb8de7beb6a(void); 
S6d6cbe6673721b1104d6dcb8de7beb6a(const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140); 
S6d6cbe6673721b1104d6dcb8de7beb6a(const char *S7f3f5c63b6fe99b1734383d7601f8140); S6d6cbe6673721b1104d6dcb8de7beb6a(const 
char *S7f3f5c63b6fe99b1734383d7601f8140, off_t Sd8d77b1ed00928dcc1bbf26f7598511d); S6d6cbe6673721b1104d6dcb8de7beb6a(char 
S34410ea0d7783276aa8b5d4a06172810); ~S6d6cbe6673721b1104d6dcb8de7beb6a(void); off_t length(void) const 
{ return Sd8d77b1ed00928dcc1bbf26f7598511d; }; const char *c_str(void) const { return S36995569da14f148a7e4ad761c50f15a; 
} S6d6cbe6673721b1104d6dcb8de7beb6a substr(off_t S36619381eba85b63775782eab1a382ef) const; S6d6cbe6673721b1104d6dcb8de7beb6a 
substr(off_t S36619381eba85b63775782eab1a382ef, off_t length) const; off_t find(const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S7f3f5c63b6fe99b1734383d7601f8140) const; off_t find(const char *S7f3f5c63b6fe99b1734383d7601f8140) 
const; off_t find(const char *S7f3f5c63b6fe99b1734383d7601f8140, off_t S36619381eba85b63775782eab1a382ef) 
const; off_t find(char S34410ea0d7783276aa8b5d4a06172810, off_t S36619381eba85b63775782eab1a382ef) const; 
off_t find(char S34410ea0d7783276aa8b5d4a06172810) const; off_t Sfeb1863668b2fb3be9981bdf9715bb86(char 
S34410ea0d7783276aa8b5d4a06172810) const; off_t Sfeb1863668b2fb3be9981bdf9715bb86(const char *S7f3f5c63b6fe99b1734383d7601f8140) 
const; off_t Sfeb1863668b2fb3be9981bdf9715bb86(const char *S7f3f5c63b6fe99b1734383d7601f8140, off_t 
S36619381eba85b63775782eab1a382ef) const; bool S50ecde1d8305c85a933dc85759419955(const char *S7f3f5c63b6fe99b1734383d7601f8140) 
const; bool S50ecde1d8305c85a933dc85759419955(const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140) 
const; bool S50ecde1d8305c85a933dc85759419955(char S34410ea0d7783276aa8b5d4a06172810) const; bool Se543ff92285a848ed4d00f194cccf802(const 
char *S7f3f5c63b6fe99b1734383d7601f8140) const; bool Se543ff92285a848ed4d00f194cccf802(const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S7f3f5c63b6fe99b1734383d7601f8140) const; bool Se543ff92285a848ed4d00f194cccf802(char S34410ea0d7783276aa8b5d4a06172810) 
const; bool S7c4c23c4982435c76bfd2635c357f6b7(const char *S7f3f5c63b6fe99b1734383d7601f8140) const; 
bool S7c4c23c4982435c76bfd2635c357f6b7(const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140) 
const; bool S7c4c23c4982435c76bfd2635c357f6b7(char S34410ea0d7783276aa8b5d4a06172810) const; void Saeac0dfe4d4aef2d19880d8ce355a5aa(muint 
Seb9d419135e896279ecc7721147bbd03, char S34410ea0d7783276aa8b5d4a06172810); S6d6cbe6673721b1104d6dcb8de7beb6a 
&S79fbb575bb5ad89b9b1705dae2b1dfb6(void); S6d6cbe6673721b1104d6dcb8de7beb6a &S1cb4f6eb603b8e7617cd6eadf2ce3ee5(void); 
S6d6cbe6673721b1104d6dcb8de7beb6a &Sd6f49f559fe7d26504379215fcb979e9(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S094cd7b74a64a6b7baf7c06983746bb5(void); void S1cec9a3ad934a4d5f08a42cf76707050(void); 
void S299aef7cd5b9f144aa5291d14895f934(void); void S57c185a834b97e13c78baddb847e41b4(void); void S23f035a74a8aeec11cfc740e503ca2c8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sdb0ce0a5cdab221e10f7b7de46267100, const char *Scb730d307e4a0317ac1cac4dd0230557); 
S6d6cbe6673721b1104d6dcb8de7beb6a operator +=(const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140); 
S6d6cbe6673721b1104d6dcb8de7beb6a operator +=(const char *S7f3f5c63b6fe99b1734383d7601f8140); S6d6cbe6673721b1104d6dcb8de7beb6a 
operator +=(char S34410ea0d7783276aa8b5d4a06172810); char operator[] (off_t Seb9d419135e896279ecc7721147bbd03) 
const; S6d6cbe6673721b1104d6dcb8de7beb6a &operator =(const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140); 
S6d6cbe6673721b1104d6dcb8de7beb6a &operator =(const char *S7f3f5c63b6fe99b1734383d7601f8140); }; S6d6cbe6673721b1104d6dcb8de7beb6a 
operator +(const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S44beb2c35c6c1921b0c756510740f73d); S6d6cbe6673721b1104d6dcb8de7beb6a operator +(const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d); S6d6cbe6673721b1104d6dcb8de7beb6a 
operator +(const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, char S34410ea0d7783276aa8b5d4a06172810); 
bool operator ==(const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S44beb2c35c6c1921b0c756510740f73d); bool operator ==(const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, 
const char *S44beb2c35c6c1921b0c756510740f73d); bool operator !=(const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S5f0b0ed8c42a3f27f38d645003e57304, const S6d6cbe6673721b1104d6dcb8de7beb6a &S44beb2c35c6c1921b0c756510740f73d); 
bool operator !=(const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, const char 
*S44beb2c35c6c1921b0c756510740f73d); bool operator < (const S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, 
const S6d6cbe6673721b1104d6dcb8de7beb6a &S44beb2c35c6c1921b0c756510740f73d); bool operator > (const 
S6d6cbe6673721b1104d6dcb8de7beb6a &S5f0b0ed8c42a3f27f38d645003e57304, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S44beb2c35c6c1921b0c756510740f73d); S5b2556faa18cdaca5a6ad039f29d6254 &operator << (S5b2556faa18cdaca5a6ad039f29d6254 
&Scd4082426bdc6a9533556b5ca60add93, const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140); 

#ifdef macintosh
 
#if 0
 S3a18542fda81ee73a9800d737c44bb2a struct S6665c6fdefe8c711b6e2375e291919b5 < S6d6cbe6673721b1104d6dcb8de7beb6a* 
> { typedef S2ae7241f0fa69799c3a5f7141ee2f87a Sac78a8923892d2cc8aabd6c4b35fa218; typedef S6d6cbe6673721b1104d6dcb8de7beb6a 
S4daa6fb8fecd353a8580a353b4ecb1ff; typedef S98e9231dac20140012f04172c03fdc23 S5a4c57dd4f8a8b6e40031dba855099b2; 
}; S3a18542fda81ee73a9800d737c44bb2a struct S6665c6fdefe8c711b6e2375e291919b5 <const S6d6cbe6673721b1104d6dcb8de7beb6a* 
> { typedef S2ae7241f0fa69799c3a5f7141ee2f87a Sac78a8923892d2cc8aabd6c4b35fa218; typedef const S6d6cbe6673721b1104d6dcb8de7beb6a 
S4daa6fb8fecd353a8580a353b4ecb1ff; typedef S98e9231dac20140012f04172c03fdc23 S5a4c57dd4f8a8b6e40031dba855099b2; 
}; 
#endif
 
#endif
 
#endif


