//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S52c96696ef4afb7db8b97d21aa5b2881
 
#define S52c96696ef4afb7db8b97d21aa5b2881
 
#include "S6ba6d720b7aeea661f5fbdf8872359a7.h"

#include "S17670e2d33cef852a486512d32a4a009.h"
 class S7ca5d44c3992eca4f11ed4ee768968cd; 
#define S941d348611ab4e5c8633cace6cffb222(name) Scc2faae6b412ac43b64129b402c4b88e.S422f19838fa76edbf8a085ec2e8505b2->name(Scc2faae6b412ac43b64129b402c4b88e)
 class S25fdafb7ecd91482fb26b3dc481a7544 : public Saee9fc179d3e60f8fab2ae94c4883a93 { private: typedef 
struct { Sbdd741232d1001ae35892289d2679fee(Sa2fcb38b62913fa83deb6ca4257ef327); Sbdd741232d1001ae35892289d2679fee(S4f6eda9105fd37f7fe3a16efff24dbee); 
Sc9febc6fc903e0d23cfa2c30d4e6e3ba(S99c036e9075ff4b5f578f39068fede76); } S32cfae6d58bed51e604d9b137b7a62ba; 
S32cfae6d58bed51e604d9b137b7a62ba Sb81599bdf713b73487af2165efb27855; virtual void S7a1b927b33f96167f2aeff3ffbba6bb3(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) { Seac258921be85ecf21f9d44985dcd9b5(Sa2fcb38b62913fa83deb6ca4257ef327, 
"look_up_ip_numbers"); Seac258921be85ecf21f9d44985dcd9b5(S4f6eda9105fd37f7fe3a16efff24dbee, "look_up_ip_numbers_before_filtering"); 
S4fe531feca96e91290995f279d25bfd7(S99c036e9075ff4b5f578f39068fede76, "dns_timeout"); } public: S25fdafb7ecd91482fb26b3dc481a7544(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S7ca5d44c3992eca4f11ed4ee768968cd *S4b19b4b29bb277e733b991ae57b96d19) 
: Saee9fc179d3e60f8fab2ae94c4883a93(Scc2faae6b412ac43b64129b402c4b88e, S4b19b4b29bb277e733b991ae57b96d19) 
{ S1270a605f0fce74deff33447ee922daf->Sb81599bdf713b73487af2165efb27855 = this; } Sc32adba7c162faf62e203ab26e0c3ae3(Sa2fcb38b62913fa83deb6ca4257ef327); 
Sc32adba7c162faf62e203ab26e0c3ae3(S4f6eda9105fd37f7fe3a16efff24dbee); S8dbdf3515e7651f3a587ee9b6db7ac5f(S99c036e9075ff4b5f578f39068fede76); 
}; 
#endif


