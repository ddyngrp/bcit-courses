Steffen L. Norgren - A00683006
Set F

To rebuild the program, launch the COMP 3770 - Assignment 2.vcproj file and compile the program.