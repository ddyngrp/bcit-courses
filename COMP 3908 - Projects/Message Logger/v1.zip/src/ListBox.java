/*
 * ListBox.java
 *
 * � <your company here>, 2003-2008
 * Confidential and proprietary.
 */



package src;

/**
 * 
 */
class ListBox {
    ListBox() {    }
} 
