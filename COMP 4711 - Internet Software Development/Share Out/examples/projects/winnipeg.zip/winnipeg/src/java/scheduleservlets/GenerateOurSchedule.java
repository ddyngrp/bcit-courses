/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduleservlets;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import model.MySAXApp;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author SoulH
 */
public class GenerateOurSchedule extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = null;
        try {
            ServletContext context = getServletContext();
            String path = context.getRealPath("/");
            path += "/WEB-INF/data/";
            
            //SAX processing .xhtml file and updating the tschedule.xml
            //in the \winnipeg\build\web\WEB-INF\data\ folder
            //Note: we want to keep the original version in the 
            //\winnipeg\web\WEB-INF\data\ folder (for backup)
            XMLReader xr = XMLReaderFactory.createXMLReader();
            FileOutputStream fos = new FileOutputStream(path + "tschedule.xml");
            MySAXApp handler = new MySAXApp(fos);
            
            xr.setContentHandler(handler);
            xr.setErrorHandler(handler);
            
            FileReader r = new FileReader(path + "UpdatedSchedule.xhtml");
            xr.parse(new InputSource(r));
            fos.close();
            
            rd = getServletContext().getRequestDispatcher("/schedule.jsp");
            rd.forward(request, response);
        } catch (SAXException se) {
            System.out.println("Oops, a SAXException occured.");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
