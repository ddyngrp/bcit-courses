//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S2b659cf002e8d20bd33ff44e6e3a8a70.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "Se24e5f8f12be3c8abcb9e4f17d005c29.h"
 muint Sdcf14f47aad1c1162702056c56b0ab12 = 0; bool Sfab26a4f110f8008b90818cc57af2190 = false; muint 
S707ce287d5c0714dd33b66a7df1475b3 = 0; muint Se7241f501127077bfd2eaed21c12d1cc = 0; Se2c73b544fed1ea7b7b2b0c2972c57b4 
*S1d556f889f4bc2f0eeac43606f269edc = NULL;  bool S44d2879ef432e9b7ea9668f8bddd46a7 = true; S6d6cbe6673721b1104d6dcb8de7beb6a 
S3d7cced431ee4c9ebb2e3d383f9b153c; S6d6cbe6673721b1104d6dcb8de7beb6a Sccff816db690fc6092ef080aca07d8f2; 
const char *S5d79645ac85eab3e1872b87884951b89 = "GeoIPCity-532.dat"; const char *S9956ebaea5cc830c9ec77ac842b9ee27 
= "GeoIPCity.dat"; const char *Sfebd76768dbec1aa9c9ff701288b7868 = "GeoIPOrg-111.dat"; const char *Sabd4e979f86841b7753335682db3b0e0 
= "GeoIPOrg.dat"; const char *S4cef90213625f05cbc5a9294e3c89b73 = "GeoIPDomain-173.dat"; const char 
*Sfe764bdeaf80db4ee49f657c45031f12 = "GeoIPDomain.dat"; const char *S81ca739932b3caf38e3996342b309795 
= "GeoIPISP-121.dat"; const char *Sa755dc2a4292e8db45ce07915d6aa9cc = "GeoIPISP.dat";  S6d6cbe6673721b1104d6dcb8de7beb6a 
S7204a1a6dc814790d3cbe1ecf11fc333; void *S87f7aa029cab5ff8c6886317c4ae7c3a = NULL; bool Sd3ec1c83d3f43765decd1fd03ef93b89 
= false; bool S9be2736d0e1d8df3cdac39b3587b6d47 = false; bool S5063a2f9985204e0b89dbe25eacc48b7 = false; 
const char *Sbbfbcd26a39bb015438864d32df8be03 = "\0\0\0\0\0\0\0\0\0\0"; S6d6cbe6673721b1104d6dcb8de7beb6a 
S8767764926c0176e0bc9ace733369be8; S6f1aca99a9b51fa4524099cdd063162b S56fcc181c2fcb9052832a467d17082c4; 
S6f1aca99a9b51fa4524099cdd063162b regexpLock; S6f1aca99a9b51fa4524099cdd063162b S3103cece49218c4bdfb00d0061da9d8e; 
S6f1aca99a9b51fa4524099cdd063162b S37b66753a7f07f86822effc9c842b12c; S6f1aca99a9b51fa4524099cdd063162b 
S7487ca9ee5ae64fa2a09b088f44dc1e7; S6f1aca99a9b51fa4524099cdd063162b Sb47d7bc8cef701206a3de709ede4ebfd; 
S6f1aca99a9b51fa4524099cdd063162b Sd975ed92fd36e0f5b03547ecad44be5b; S6f1aca99a9b51fa4524099cdd063162b 
S8a42c2aec66d06516032340dc5516aad; bool Se66049b94e13312a206457dd7fce9062 = false; bool Se6539117b0faf95112cebde9bd0c2465 
= true; S6d6cbe6673721b1104d6dcb8de7beb6a S8a981d3999c26a3a43188addb62c4e52; S6d6cbe6673721b1104d6dcb8de7beb6a 
S530f1c5b655b590225e2cfdfe6e674e8; S6d6cbe6673721b1104d6dcb8de7beb6a S99b4d14d3a605f5c74792b3286874e4c; 
time_t Sc8915d498d2314d711d0597b98175b2c = 0; uint64 S9feb44985445b0ce4db01e066e648130 = 0; bool S717faf697c21d0fb4d9f0bd898cfa511 
= false; S6d6cbe6673721b1104d6dcb8de7beb6a Sb58a8fc1f38a6f9f58b6a1ab3e1631a9; S6d6cbe6673721b1104d6dcb8de7beb6a 
Sc25bf34dbfdb5f8f82eb2722cee0bd12; S9f4d4ea4917e0ea34880cb67e0e58e66 *Sd3315df279e2103548ce818b96e12af2 
= NULL; bool S9e0246f15f76f59910865e27790cb6e5 = false; bool S263b8566c867fa87f2e6f19a172ae430 = false; 
bool Sa7fa879d9b646e7732c9c01e6f0bba13 = false; 
#ifdef SAWMILL
 bool Sb43b56fff9bc1038da1785a37c090c66 = false; bool S97990d396e8be476aa15f81c699bb482 = true; 
#else
 
# ifdef BCREPORT
 bool Sb43b56fff9bc1038da1785a37c090c66 = true; bool S97990d396e8be476aa15f81c699bb482 = false; 
# else
 
#  error Unknown product

# endif
 
#endif
 bool Sbeb19fc723b0fce9316166946e628d41 = false; bool Sc3c9455c0a9e9168b90fa14ad83f14f1 = false; bool 
S8562ea9f2b282321bb4996d27ce347f0 = false; bool S7e5f01234602189cb0f4c9c338245b2d = false; char *S3c5cc25ee7372d87c7aee7deda02e51f 
= (char *) ""; bool Sa11caea824c192f484fa61b07456ad8c = false; const char *S805b5b37e03134a4b99602734d94a116 
= NULL; muint S1a0ff674b987936cc1bbc6ba33b7ad01 = 0; muint S4815b3f660fa59b1c6e484b65e74533c = 0; 
#if HAVE_PTHREAD
 bool S3453986fad8ae18a4cddd52a6f55b49e = true; 
#else
 bool S3453986fad8ae18a4cddd52a6f55b49e = false; 
#endif
 muint S92feee79243eb1a2e8ee84ed28614052; muint S05cc7cbb25d32ce3d7596642e676d102 = 0; S6f1aca99a9b51fa4524099cdd063162b 
Sef029c825d63baf7604556beefaa7205;  map<S6d6cbe6673721b1104d6dcb8de7beb6a, S6d6cbe6673721b1104d6dcb8de7beb6a> 
Se3cd2c8a809a46e38a957b99373f5e36; bool S8b4285c8abe88e4a2ba3673879c9b4e6 = false; bool S6717007b21199f732b603477b3f19b00 
= false; bool S01a18b0199ddb3ca4f307ef250d159df = false; mint S18aaacd668f843ba7b0c292b32a6d981; int 
Se4ceb89503814d7e97bb987ccb50d87b = false; char S107f160894ecad3ca0ae8efadac337c7[1000];  const char 
*S9f307d23a7e1cd72014b16cfebd055d7[] = { "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", 
"Sep", "Oct", "Nov", "Dec" }; S6d6cbe6673721b1104d6dcb8de7beb6a Sbde324d3382a884660a4f07b5de694ac; S6d6cbe6673721b1104d6dcb8de7beb6a 
S33025acba6a16b2fe6803822cccef85f; S6d6cbe6673721b1104d6dcb8de7beb6a S8c7b1ebf52fc83b11d1f3b0701652786; 
S6d6cbe6673721b1104d6dcb8de7beb6a Seaf00538d6eed1f098e511ec5ddbf0cc; S6d6cbe6673721b1104d6dcb8de7beb6a 
S21b713288dcfea7774d762707f30b2ed; S6d6cbe6673721b1104d6dcb8de7beb6a S59ce22cf753b61fd1f8d3cb835ab3c61; 
S6d6cbe6673721b1104d6dcb8de7beb6a S7b31bfceed6dbe685f734862b9997dba; S6d6cbe6673721b1104d6dcb8de7beb6a 
S86db3095015a286a855ee1d7ba9f623d; S6d6cbe6673721b1104d6dcb8de7beb6a S0e1c860ac74546d814d2ddf68f77fa33; 
S6d6cbe6673721b1104d6dcb8de7beb6a S8862d29896f06049abb5925472619bc9; S6d6cbe6673721b1104d6dcb8de7beb6a 
S4fc057481c5688057b5ecd578bbdfd68; S6d6cbe6673721b1104d6dcb8de7beb6a S74fb77c8810571afc132d8abe902b6b0; 
S6d6cbe6673721b1104d6dcb8de7beb6a S0a00477c047967958019757f088af919; const char *S944caa4b612be699dace75815e1e7cf0[S47474c9d1a06925001c00d66da005fc6]; 
const char *Sd4042235b1aace5b9ce00b65a46baa78[S551cd4e7753d4041812da03c1d143800]; const char *S88b803d4dc8da6f9a27b0ecb943c478f[S69db65c67279774a2ac2aa1a2f16ce37]; 
const char *Sb9363b2357c9d675213e96d47b7470d5[S34d895da04f693412822c142c81d1769];   const char *S66e3290c6749e9e6c9fe4fab000d5002 
= "reject"; const char *S1e97150f41aa897da7c96d76f41e68cc = "accept"; const char *Sa7c3229a1ab282c7a5238e8f8acc3d2c 
= "goto_next_filter"; bool Sf51310c83123817021120ee097df7c32; bool Sda00d4d1c1a32e771c653d26cc09cbae; 
unsigned char S1589b250b0cea2de9e80418a29e077d6[256] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 110, 46, 118, 119, 73, 67, 50, 
117, 111, 32, 33, 62, 104, 92, 100, 107, 34, 35, 36, 38, 45, 93, 70, 76, 113, 52, 79, 51, 90, 53, 37, 
40, 64, 108, 39, 106, 41, 42, 63, 94, 43, 44, 124, 80, 95, 65, 47, 68, 48, 49, 74, 54, 82, 112, 96, 
55, 56, 57, 58, 66, 59, 60, 72, 69, 120, 61, 71, 101, 75, 77, 78, 81, 83, 126, 84, 102, 85, 86, 87, 
88, 89, 91, 97, 98, 99, 121, 103, 105, 109, 114, 115, 116, 122, 123, 125, 127, 128, 129, 130, 131, 132, 
133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 
153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 
173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 
193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 
213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 
233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 
253, 254, 255 }; unsigned char S0101c090fe7b54e586e75dfb7d3c1bdd[256] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 
9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 41, 42, 48, 
49, 50, 62, 51, 66, 63, 68, 69, 72, 73, 52, 33, 78, 80, 81, 38, 59, 57, 61, 83, 87, 88, 89, 90, 92, 
93, 97, 43, 70, 64, 77, 91, 37, 79, 95, 54, 98, 94, 36, 82, 100, 55, 101, 102, 58, 75, 103, 84, 104, 
106, 108, 109, 110, 111, 112, 60, 113, 45, 53, 71, 76, 86, 114, 115, 116, 46, 99, 107, 118, 44, 119, 
67, 47, 65, 120, 32, 40, 85, 56, 121, 122, 123, 39, 34, 35, 96, 117, 124, 125, 74, 126, 105, 127, 128, 
129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 
149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 
169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 
189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 
209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 
229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 
249, 250, 251, 252, 253, 254, 255 }; const char *S81ab72832b67185674ac9eea535afa1f = "*wbePgfpidDslamnNvtTqQocuU"; 
const char *Sd66b1b878153dc72608d06e73a787601[] = { "AF01->Badakhshan\n", "AF02->Badghis\n", "AF03->Baghlan\n", 
"AF30->Balkh\n", "AF05->Bamian\n", "AF06->Farah\n", "AF07->Faryab\n", "AF08->Ghazni\n", "AF09->Ghowr\n", 
"AF10->Helmand\n", "AF11->Herat\n", "AF31->Jowzjan\n", "AF13->Kabol\n", "AF23->Kandahar\n", "AF14->Kapisa\n", 
"AF15->Konar\n", "AF24->Kondoz\n", "AF16->Laghman\n", "AF17->Lowgar\n", "AF18->Nangarhar\n", "AF19->Nimruz\n", 
"AF20->Oruzgan\n", "AF21->Paktia\n", "AF29->Paktika\n", "AF22->Parvan\n", "AF32->Samangan\n", "AF33->Sar-e Pol\n", 
"AF26->Takhar\n", "AF27->Vardak\n", "AF28->Zabol\n", "AL01->Berat\n", "AL02->Diber\n", "AL03->Durres\n", 
"AL04->Elbasan\n", "AL05->Fier\n", "AL06->Gjirokaster\n", "AL07->Gramsh\n", "AL08->Kolonje\n", "AL09->Korce\n", 
"AL10->Kruje\n", "AL11->Kukes\n", "AL12->Lezhe\n", "AL13->Librazhd\n", "AL14->Lushnje\n", "AL15->Mat\n", 
"AL16->Mirdite\n", "AL17->Permet\n", "AL18->Pogradec\n", "AL19->Puke\n", "AL20->Sarande\n", "AL21->Shkoder\n", 
"AL22->Skrapar\n", "AL23->Tepelene\n", "AL28->Tirane\n", "AL26->Tropoje\n", "AL27->Vlore\n", "AL35->Kurbin\n", 
"DZ34->Adrar\n", "DZ35->Ain Defla\n", "DZ36->Ain Temouchent\n", "DZ01->Alger\n", "DZ37->Annaba\n", "DZ03->Batna\n", 
"DZ38->Bechar\n", "DZ18->Bejaia\n", "DZ19->Biskra\n", "DZ20->Blida\n", "DZ39->Bordj Bou Arreridj\n", 
"DZ21->Bouira\n", "DZ40->Boumerdes\n", "DZ04->Constantine\n", "DZ22->Djelfa\n", "DZ41->Chlef\n", "DZ42->El Bayadh\n", 
"DZ43->El Oued\n", "DZ44->El Tarf\n", "DZ45->Ghardaia\n", "DZ23->Guelma\n", "DZ46->Illizi\n", "DZ24->Jijel\n", 
"DZ47->Khenchela\n", "DZ25->Laghouat\n", "DZ26->Mascara\n", "DZ06->Medea\n", "DZ48->Mila\n", "DZ07->Mostaganem\n", 
"DZ27->M'sila\n", "DZ49->Naama\n", "DZ09->Oran\n", "DZ50->Ouargla\n", "DZ29->Oum el Bouaghi\n", "DZ51->Relizane\n", 
"DZ10->Saida\n", "DZ12->Setif\n", "DZ30->Sidi Bel Abbes\n", "DZ31->Skikda\n", "DZ52->Souk Ahras\n", 
"DZ53->Tamanghasset\n", "DZ33->Tebessa\n", "DZ13->Tiaret\n", "DZ54->Tindouf\n", "DZ55->Tipaza\n", "DZ56->Tissemsilt\n", 
"DZ14->Tizi Ouzou\n", "DZ15->Tlemcen\n", "AD07->Andorra la Vella\n", "AD02->Canillo\n", "AD03->Encamp\n", 
"AD04->La Massana\n", "AD05->Ordino\n", "AD06->Sant Julia de Loria\n", "AO19->Bengo\n", "AO01->Benguela\n", 
"AO02->Bie\n", "AO03->Cabinda\n", "AO04->Cuando Cubango\n", "AO05->Cuanza Norte\n", "AO06->Cuanza Sul\n", 
"AO07->Cunene\n", "AO08->Huambo\n", "AO09->Huila\n", "AO20->Luanda\n", "AO17->Lunda Norte\n", "AO18->Lunda Sul\n", 
"AO12->Malanje\n", "AO14->Moxico\n", "AO15->Uige\n", "AO16->Zaire\n", "AG01->Barbuda\n", "AG03->Saint George\n", 
"AG04->Saint John\n", "AG05->Saint Mary\n", "AG06->Saint Paul\n", "AG07->Saint Peter\n", "AG08->Saint Philip\n", 
"AR01->Buenos Aires\n", "AR02->Catamarca\n", "AR03->Chaco\n", "AR04->Chubut\n", "AR05->Cordoba\n", "AR06->Corrientes\n", 
"AR07->Distrito Federal\n", "AR08->Entre Rios\n", "AR09->Formosa\n", "AR10->Jujuy\n", "AR11->La Pampa\n", 
"AR12->La Rioja\n", "AR13->Mendoza\n", "AR14->Misiones\n", "AR15->Neuquen\n", "AR16->Rio Negro\n", "AR17->Salta\n", 
"AR18->San Juan\n", "AR19->San Luis\n", "AR20->Santa Cruz\n", "AR21->Santa Fe\n", "AR22->Santiago del Estero\n", 
"AR23->Tierra del Fuego\n", "AR24->Tucuman\n", "AU01->Australian Capital Territory\n", "AU02->New South Wales\n", 
"AU03->Northern Territory\n", "AU04->Queensland\n", "AU05->South Australia\n", "AU06->Tasmania\n", "AU07->Victoria\n", 
"AU08->Western Australia\n", "AT01->Burgenland\n", "AT02->Karnten\n", "AT03->Niederosterreich\n", "AT04->Oberosterreich\n", 
"AT05->Salzburg\n", "AT06->Steiermark\n", "AT07->Tirol\n", "AT08->Vorarlberg\n", "AT09->Wien\n", "BS24->Acklins and Crooked Islands\n", 
"BS05->Bimini\n", "BS06->Cat Island\n", "BS10->Exuma\n", "BS25->Freeport\n", "BS26->Fresh Creek\n", 
"BS27->Governor's Harbour\n", "BS28->Green Turtle Cay\n", "BS22->Harbour Island\n", "BS29->High Rock\n", 
"BS13->Inagua\n", "BS30->Kemps Bay\n", "BS15->Mint Island\n", "BS31->Marsh Harbour\n", "BS16->Mayaguana\n", 
"BS23->New Providence\n", "BS32->Nichollstown and Berry Islands\n", "BS18->Ragged Island\n", "BS33->Rock Sound\n", 
"BS34->Sandy Point\n", "BS35->San Salvador and Rum Cay\n", "BH01->Al Hadd\n", "BH02->Al Manamah\n", 
"BH08->Al Mintaqah al Gharbiyah\n", "BH11->Al Mintaqah al Wusta\n", "BH10->Al Mintaqah ash Shamaliyah\n", 
"BH03->Al Muharraq\n", "BH13->Ar Rifa\n", "BH05->Jidd Hafs\n", "BH14->Madinat Hamad\n", "BH12->Madinat\n", 
"BH09->Mintaqat Juzur Hawar\n", "BH06->Sitrah\n", "BD22->Bagerhat\n", "BD04->Bandarban\n", "BD25->Barguna\n", 
"BD01->Barisal\n", "BD23->Bhola\n", "BD24->Bogra\n", "BD26->Brahmanbaria\n", "BD27->Chandpur\n", "BD28->Chapai Nawabganj\n", 
"BD29->Chattagram\n", "BD30->Chuadanga\n", "BD05->Comilla\n", "BD31->Cox's Bazar\n", "BD32->Dhaka\n", 
"BD33->Dinajpur\n", "BD34->Faridpur\n", "BD35->Feni\n", "BD36->Gaibandha\n", "BD37->Gazipur\n", "BD38->Gopalganj\n", 
"BD39->Habiganj\n", "BD40->Jaipurhat\n", "BD41->Jamalpur\n", "BD42->Jessore\n", "BD43->Jhalakati\n", 
"BD44->Jhenaidah\n", "BD45->Khagrachari\n", "BD46->Khulna\n", "BD47->Kishorganj\n", "BD48->Kurigram\n", 
"BD49->Kushtia\n", "BD50->Laksmipur\n", "BD51->Lalmonirhat\n", "BD52->Madaripur\n", "BD53->Magura\n", 
"BD54->Manikganj\n", "BD55->Meherpur\n", "BD56->Moulavibazar\n", "BD57->Munshiganj\n", "BD12->Mymensingh\n", 
"BD58->Naogaon\n", "BD59->Narail\n", "BD60->Narayanganj\n", "BD61->Narsingdi\n", "BD62->Nator\n", "BD63->Netrakona\n", 
"BD64->Nilphamari\n", "BD13->Noakhali\n", "BD65->Pabna\n", "BD66->Panchagar\n", "BD67->Parbattya Chattagram\n", 
"BD15->Patuakhali\n", "BD68->Pirojpur\n", "BD69->Rajbari\n", "BD70->Rajshahi\n", "BD71->Rangpur\n", 
"BD72->Satkhira\n", "BD73->Shariyatpur\n", "BD74->Sherpur\n", "BD75->Sirajganj\n", "BD76->Sunamganj\n", 
"BD77->Sylhet\n", "BD78->Tangail\n", "BD79->Thakurgaon\n", "BB01->Christ Church\n", "BB02->Saint Andrew\n", 
"BB03->Saint George\n", "BB04->Saint James\n", "BB05->Saint John\n", "BB06->Saint Joseph\n", "BB07->Saint Lucy\n", 
"BB08->Saint Michael\n", "BB09->Saint Peter\n", "BB10->Saint Philip\n", "BB11->Saint Thomas\n", "BE01->Antwerpen\n", 
"BE02->Brabant\n", "BE03->Hainaut\n", "BE04->Liege\n", "BE05->Limburg\n", "BE06->Luxembourg\n", "BE07->Namur\n", 
"BE08->Oost-Vlaanderen\n", "BE09->West-Vlaanderen\n", "BZ01->Belize\n", "BZ02->Cayo\n", "BZ03->Corozal\n", 
"BZ04->Orange Walk\n", "BZ05->Stann Creek\n", "BZ06->Toledo\n", "BJ01->Atakora\n", "BJ02->Atlantique\n", 
"BJ03->Borgou\n", "BJ04->Mono\n", "BJ05->Oueme\n", "BJ06->Zou\n", "BM01->Devonshire\n", "BM02->Hamilton\n", 
"BM03->Hamilton\n", "BM04->Paget\n", "BM05->Pembroke\n", "BM06->Saint George\n", "BM07->Saint George's\n", 
"BM08->Sandys\n", "BM09->Smiths\n", "BM10->Southampton\n", "BM11->Warwick\n", "BT05->Bumthang\n", "BT06->Chhukha\n", 
"BT07->Chirang\n", "BT08->Daga\n", "BT09->Geylegphug\n", "BT10->Ha\n", "BT11->Lhuntshi\n", "BT12->Mongar\n", 
"BT13->Paro\n", "BT14->Pemagatsel\n", "BT15->Punakha\n", "BT16->Samchi\n", "BT17->Samdrup\n", "BT18->Shemgang\n", 
"BT19->Tashigang\n", "BT20->Thimphu\n", "BT21->Tongsa\n", "BT22->Wangdi Phodrang\n", "BO01->Chuquisaca\n", 
"BO02->Cochabamba\n", "BO03->El Beni\n", "BO04->La Paz\n", "BO05->Oruro\n", "BO06->Pando\n", "BO07->Potosi\n", 
"BO08->Santa Cruz\n", "BO09->Tarija\n", "BW01->Central\n", "BW02->Chobe\n", "BW03->Ghanzi\n", "BW04->Kgalagadi\n", 
"BW05->Kgatleng\n", "BW06->Kweneng\n", "BW07->Ngamiland\n", "BW08->North-East\n", "BW09->South-East\n", 
"BW10->Southern\n", "BR01->Acre\n", "BR02->Alagoas\n", "BR03->Amapa\n", "BR04->Amazonas\n", "BR05->Bahia\n", 
"BR06->Ceara\n", "BR07->Distrito Federal\n", "BR08->Espirito Santo\n", "BR29->Goias\n", "BR13->Maranhao\n", 
"BR14->Mato Grosso\n", "BR11->Mato Grosso do Sul\n", "BR15->Minas Gerais\n", "BR16->Para\n", "BR17->Paraiba\n", 
"BR18->Parana\n", "BR30->Pernambuco\n", "BR20->Piaui\n", "BR21->Rio de Janeiro\n", "BR22->Rio Grande do Norte\n", 
"BR23->Rio Grande do Sul\n", "BR24->Rondonia\n", "BR25->Roraima\n", "BR26->Santa Catarina\n", "BR27->Sao Paulo\n", 
"BR28->Sergipe\n", "BR31->Tocantins\n", "BN01->Belait\n", "BN02->Brunei and Muara\n", "BN03->Temburong\n", 
"BN04->Tutong\n", "BG39->Burgas\n", "BG42->Grad Sofiya\n", "BG43->Khaskovo\n", "BG46->Lovech\n", "BG33->Mikhaylovgrad\n", 
"BG47->Montana\n", "BG51->Plovdiv\n", "BG52->Razgrad\n", "BG58->Sofiya\n", "BG61->Varna\n", "BF15->Bam\n", 
"BF16->Bazega\n", "BF17->Bougouriba\n", "BF18->Boulgou\n", "BF19->Boulkiemde\n", "BF20->Ganzourgou\n", 
"BF21->Gnagna\n", "BF22->Gourma\n", "BF23->Houet\n", "BF24->Kadiogo\n", "BF25->Kenedougou\n", "BF26->Komoe\n", 
"BF27->Kossi\n", "BF28->Kouritenga\n", "BF29->Mouhoun\n", "BF30->Namentenga\n", "BF31->Naouri\n", "BF32->Oubritenga\n", 
"BF33->Oudalan\n", "BF34->Passore\n", "BF35->Poni\n", "BF36->Sanguie\n", "BF37->Sanmatenga\n", "BF38->Seno\n", 
"BF39->Sissili\n", "BF40->Soum\n", "BF41->Sourou\n", "BF42->Tapoa\n", "BF43->Yatenga\n", "BF44->Zoundweogo\n", 
"MM02->Chin State\n", "MM03->Irrawaddy\n", "MM04->Kachin State\n", "MM05->Karan State\n", "MM06->Kayah State\n", 
"MM07->Magwe\n", "MM08->Mandalay\n", "MM13->Mon State\n", "MM09->Pegu\n", "MM01->Rakhine State\n", "MM14->Rangoon\n", 
"MM10->Sagaing\n", "MM11->Shan State\n", "MM12->Tenasserim\n", "BI09->Bubanza\n", "BI02->Bujumbura\n", 
"BI10->Bururi\n", "BI11->Cankuzo\n", "BI12->Cibitoke\n", "BI13->Gitega\n", "BI14->Karuzi\n", "BI15->Kayanza\n", 
"BI16->Kirundo\n", "BI17->Makamba\n", "BI22->Muramvya\n", "BI18->Muyinga\n", "BI19->Ngozi\n", "BI20->Rutana\n", 
"BI21->Ruyigi\n", "KH29->Batdambang\n", "KH02->Kampong Cham\n", "KH03->Kampong Chhnang\n", "KH04->Kampong Spoe\n", 
"KH05->Kampong Thum\n", "KH06->Kampot\n", "KH07->Kandal\n", "KH08->Kaoh Kong\n", "KH09->Kracheh\n", 
"KH10->Mondol Kiri\n", "KH11->Phnum Penh\n", "KH12->Pouthisat\n", "KH13->Preah Vihear\n", "KH14->Prey Veng\n", 
"KH15->Rotanokiri\n", "KH16->Siemreab-Otdar Meanchey\n", "KH17->Stoeng Treng\n", "KH18->Svay Rieng\n", 
"KH19->Takev\n", "CM10->Adamaoua\n", "CM11->Centre\n", "CM04->Est\n", "CM12->Extreme-Nord\n", "CM05->Littoral\n", 
"CM13->Nord\n", "CM07->Nord-Ouest\n", "CM08->Ouest\n", "CM14->Sud\n", "CM09->Sud-Ouest\n", "CA01->Alberta\n", 
"CA02->British Columbia\n", "CA03->Manitoba\n", "CA04->New Brunswick\n", "CA05->Newfoundland and Labrador\n", 
"CA13->Northwest Territories\n", "CA07->Nova Scotia\n", "CA08->Ontario\n", "CA09->Prince Edward Island\n", 
"CA10->Quebec\n", "CA11->Saskatchewan\n", "CA12->Yukon Territory\n", "CA14->Nunavut\n", "CV01->Boa Vista\n", 
"CV02->Brava\n", "CV03->Fogo\n", "CV04->Maio\n", "CV05->Paul\n", "CV06->Praia\n", "CV07->Ribeira Grande\n", 
"CV08->Sal\n", "CV09->Santa Catarina\n", "CV10->Sao Nicolau\n", "CV11->Sao Vicente\n", "CV12->Tarrafal\n", 
"KY01->Creek\n", "KY02->Eastern\n", "KY03->Midland\n", "KY04->South Town\n", "KY05->Spot Bay\n", "KY06->Stake Bay\n", 
"KY07->West End\n", "KY08->Western\n", "CF01->Bamingui-Bangoran\n", "CF18->Bangui\n", "CF02->Basse-Kotto\n", 
"CF15->Gribingui\n", "CF03->Haute-Kotto\n", "CF04->Haute-Sangha\n", "CF05->Haut-Mbomou\n", "CF06->Kemo-Gribingui\n", 
"CF07->Lobaye\n", "CF08->Mbomou\n", "CF09->Nana-Mambere\n", "CF17->Ombella-Mpoko\n", "CF11->Ouaka\n", 
"CF12->Ouham\n", "CF13->Ouham-Pende\n", "CF16->Sangha\n", "CF14->Vakaga\n", "TD01->Batha\n", "TD02->Biltine\n", 
"TD03->Borkou-Ennedi-Tibesti\n", "TD04->Chari-Baguirmi\n", "TD05->Guera\n", "TD06->Kanem\n", "TD07->Lac\n", 
"TD08->Logone Occidental\n", "TD09->Logone Oriental\n", "TD10->Mayo-Kebbi\n", "TD11->Moyen-Chari\n", 
"TD12->Ouaddai\n", "TD13->Salamat\n", "TD14->Tandjile\n", "CL02->Aisen del General Carlos Ibanez del Campo\n", 
"CL03->Antofagasta\n", "CL04->Araucania\n", "CL05->Atacama\n", "CL06->Bio-Bio\n", "CL07->Coquimbo\n", 
"CL08->Libertador General Bernardo O'Higgins\n", "CL09->Los Lagos\n", "CL10->Magallanes y de la Antartica Chilena\n", 
"CL11->Maule\n", "CL12->Region Metropolitana\n", "CL13->Tarapaca\n", "CL01->Valparaiso\n", "CN01->Anhui\n", 
"CN22->Beijing\n", "CN07->Fujian\n", "CN15->Gansu\n", "CN30->Guangdong\n", "CN16->Guangxi\n", "CN18->Guizhou\n", 
"CN31->Hainan\n", "CN10->Hebei\n", "CN08->Heimintjiang\n", "CN09->Henan\n", "CN12->Hubei\n", "CN11->Hunan\n", 
"CN04->Jiangsu\n", "CN03->Jiangxi\n", "CN05->Jilin\n", "CN19->Liaoning\n", "CN20->Nei Mongol\n", "CN21->Ningxia\n", 
"CN06->Qinghai\n", "CN26->Shaanxi\n", "CN25->Shandong\n", "CN23->Shanghai\n", "CN24->Shanxi\n", "CN27->Sichuan\n", 
"CN28->Tianjin\n", "CN13->Xinjiang\n", "CN14->Xizang\n", "CN29->Yunnan\n", "CN02->Zhejiang\n", "CO01->Amazonas\n", 
"CO02->Antioquia\n", "CO03->Arauca\n", "CO04->Atlantico\n", "CO35->Bolivar\n", "CO36->Boyaca\n", "CO37->Caldas\n", 
"CO08->Caqueta\n", "CO32->Casanare\n", "CO09->Cauca\n", "CO10->Cesar\n", "CO11->Choco\n", "CO12->Cordoba\n", 
"CO33->Cundinamarca\n", "CO34->Distrito Especial\n", "CO15->Guainia\n", "CO14->Guaviare\n", "CO16->Huila\n", 
"CO17->La Guajira\n", "CO38->Magdalena\n", "CO19->Meta\n", "CO20->Narino\n", "CO21->Norte de Santander\n", 
"CO22->Putumayo\n", "CO23->Quindio\n", "CO24->Risaralda\n", "CO25->San Andres y Providencia\n", "CO26->Santander\n", 
"CO27->Sucre\n", "CO28->Tolima\n", "CO29->Valle del Cauca\n", "CO30->Vaupes\n", "CO31->Vichada\n", "KM01->Anjouan\n", 
"KM02->Grande Comore\n", "KM03->Moheli\n", "CG01->Bouenza\n", "CG12->Brazzaville\n", "CG03->Cuvette\n", 
"CG04->Kouilou\n", "CG05->Lekoumou\n", "CG06->Likouala\n", "CG07->Niari\n", "CG08->Plateaux\n", "CG11->Pool\n", 
"CG10->Sangha\n", "CR01->Alajuela\n", "CR02->Cartago\n", "CR03->Guanacaste\n", "CR04->Heredia\n", "CR06->Limon\n", 
"CR07->Puntarenas\n", "CR08->San Jose\n", "CI01->Abengourou\n", "CI61->Abidjan\n", "CI62->Aboisso\n", 
"CI05->Adzope\n", "CI06->Agboville\n", "CI36->Bangolo\n", "CI37->Beoumi\n", "CI07->Biankouma\n", "CI38->Bondoukou\n", 
"CI27->Bongouanou\n", "CI39->Bouafle\n", "CI40->Bouake\n", "CI11->Bouna\n", "CI12->Boundiali\n", "CI03->Dabakala\n", 
"CI41->Daloa\n", "CI14->Danane\n", "CI42->Daoukro\n", "CI67->Dimbokro\n", "CI16->Divo\n", "CI44->Duekoue\n", 
"CI17->Ferkessedougou\n", "CI18->Gagnoa\n", "CI45->Grand-Lahou\n", "CI69->Guiglo\n", "CI28->Issia\n", 
"CI20->Katiola\n", "CI21->Korhogo\n", "CI29->Lakota\n", "CI47->Man\n", "CI30->Mankono\n", "CI48->Mbahiakro\n", 
"CI23->Odienne\n", "CI31->Oume\n", "CI49->Sakassou\n", "CI50->San Pedro\n", "CI51->Sassandra\n", "CI25->Seguela\n", 
"CI52->Sinfra\n", "CI32->Soubre\n", "CI53->Tabou\n", "CI54->Tanda\n", "CI55->Tiassale\n", "CI33->Tingrela\n", 
"CI26->Touba\n", "CI56->Toumodi\n", "CI57->Vavoua\n", "CI73->Yamoussoukro\n", "CI34->Zuenoula\n", "CU05->Camaguey\n", 
"CU07->Ciego de Avila\n", "CU08->Cienfuegos\n", "CU02->Ciudad de la Habana\n", "CU09->Granma\n", "CU10->Guantanamo\n", 
"CU12->Holguin\n", "CU04->Isla de la Juventud\n", "CU11->La Habana\n", "CU13->Las Tunas\n", "CU03->Matanzas\n", 
"CU01->Pinar del Rio\n", "CU14->Sancti Spiritus\n", "CU15->Santiago de Cuba\n", "CU16->Villa Clara\n", 
"CY01->Famagusta\n", "CY02->Kyrenia\n", "CY03->Larnaca\n", "CY05->Limassol\n", "CY04->Nicosia\n", "CY06->Paphos\n", 
"DK01->Arhus\n", "DK02->Bornholm\n", "DK03->Frederiksborg\n", "DK04->Fyn\n", "DK05->Kobenhavn\n", "DK07->Nordjylland\n", 
"DK08->Ribe\n", "DK09->Ringkobing\n", "DK10->Roskilde\n", "DK11->Sonderjylland\n", "DK06->Staden Kobenhavn\n", 
"DK12->Storstrom\n", "DK13->Vejle\n", "DK14->Vestsjalland\n", "DK15->Viborg\n", "DJ02->Dikhil\n", "DJ03->Djibouti\n", 
"DJ04->Obock\n", "DJ05->Tadjoura\n", "DM02->Saint Andrew\n", "DM03->Saint David\n", "DM04->Saint George\n", 
"DM05->Saint John\n", "DM06->Saint Joseph\n", "DM07->Saint Luke\n", "DM08->Saint Mark\n", "DM09->Saint Patrick\n", 
"DM10->Saint Paul\n", "DM11->Saint Peter\n", "DO01->Azua\n", "DO02->Baoruco\n", "DO03->Barahona\n", 
"DO04->Dajabon\n", "DO05->Distrito Nacional\n", "DO06->Duarte\n", "DO11->Elias Pina\n", "DO28->El Seibo\n", 
"DO08->Espaillat\n", "DO29->Hato Mayor\n", "DO09->Independencia\n", "DO10->La Altagracia\n", "DO12->La Romana\n", 
"DO30->La Vega\n", "DO14->Maria Trinidad Sanchez\n", "DO31->Monsenor Nouel\n", "DO15->Monte Cristi\n", 
"DO32->Monte Plata\n", "DO16->Pedernales\n", "DO17->Peravia\n", "DO18->Puerto Plata\n", "DO19->Salcedo\n", 
"DO20->Samana\n", "DO21->Sanchez Ramirez\n", "DO33->San Cristobal\n", "DO23->San Juan\n", "DO24->San Pedro De Macoris\n", 
"DO25->Santiago\n", "DO26->Santiago Rodriguez\n", "DO27->Valverde\n", "EC02->Azuay\n", "EC03->Bolivar\n", 
"EC04->Canar\n", "EC05->Carchi\n", "EC06->Chimborazo\n", "EC07->Cotopaxi\n", "EC08->El Oro\n", "EC09->Esmeraldas\n", 
"EC01->Galapagos\n", "EC10->Guayas\n", "EC11->Imbabura\n", "EC12->Loja\n", "EC13->Los Rios\n", "EC14->Manabi\n", 
"EC15->Morona-Santiago\n", "EC23->Napo\n", "EC17->Pastaza\n", "EC18->Pichincha\n", "EC22->Sucumbios\n", 
"EC19->Tungurahua\n", "EC20->Zamora-Chinchipe\n", "EG01->Ad Daqahliyah\n", "EG02->Al Bahr al Ahmar\n", 
"EG03->Al Buhayrah\n", "EG04->Al Fayyum\n", "EG05->Al Gharbiyah\n", "EG06->Al Iskandariyah\n", "EG07->Al Isma'iliyah\n", 
"EG08->Al Jizah\n", "EG09->Al Minufiyah\n", "EG10->Al Minya\n", "EG11->Al Qahirah\n", "EG12->Al Qalyubiyah\n", 
"EG13->Al Wadi al Jadid\n", "EG14->Ash Sharqiyah\n", "EG15->As Suways\n", "EG16->Aswan\n", "EG17->Asyut\n", 
"EG18->Bani Suwayf\n", "EG19->Bur Sa'id\n", "EG20->Dumyat\n", "EG26->Janub Sina'\n", "EG21->Kafr ash Shaykh\n", 
"EG22->Matruh\n", "EG23->Qina\n", "EG27->Shamal Sina'\n", "EG24->Suhaj\n", "SV01->Ahuachapan\n", "SV02->Cabanas\n", 
"SV03->Chalatenango\n", "SV04->Cuscatlan\n", "SV05->La Libertad\n", "SV06->La Paz\n", "SV07->La Union\n", 
"SV08->Morazan\n", "SV09->San Miguel\n", "SV10->San Salvador\n", "SV11->Santa Ana\n", "SV12->San Vicente\n", 
"SV13->Sonsonate\n", "SV14->Usulutan\n", "GQ03->Annobon\n", "GQ04->Bioko Norte\n", "GQ05->Bioko Sur\n", 
"GQ06->Centro Sur\n", "GQ07->Kie-Ntem\n", "GQ08->Litoral\n", "GQ09->Wele-Nzas\n", "EE01->Harjumaa\n", 
"EE02->Hiiumaa\n", "EE03->Ida-Virumaa\n", "EE04->Jarvamaa\n", "EE05->Jogevamaa\n", "EE06->Kohtla-Jarve\n", 
"EE07->Laanemaa\n", "EE08->Laane-Virumaa\n", "EE09->Narva\n", "EE10->Parnu\n", "EE11->Parnumaa\n", "EE12->Polvamaa\n", 
"EE13->Raplamaa\n", "EE14->Saaremaa\n", "EE15->Sillamae\n", "EE16->Tallinn\n", "EE17->Tartu\n", "EE18->Tartumaa\n", 
"EE19->Valgamaa\n", "EE20->Viljandimaa\n", "EE21->Vorumaa\n", "FM03->Chuuk\n", "FM01->Kosrae\n", "FM02->Pohnpei\n", 
"FM04->Yap\n", "FJ01->Central\n", "FJ02->Eastern\n", "FJ03->Northern\n", "FJ04->Rotuma\n", "FJ05->Western\n", 
"FI01->�Ã�‎�land\n", "FI14->Eastern Finland\n", "FI06->Lapland\n", "FI08->Oulu\n", "FI13->Southern Finland\n", 
"FI15->Western Finland\n", "FRC1->Alsace\n", "FR97->Aquitaine\n", "FR98->Auvergne\n", "FR99->Basse-Normandie\n", 
"FRA1->Bourgogne\n", "FRA2->Bretagne\n", "FRA3->Centre\n", "FRA4->Champagne-Ardenne\n", "FRA5->Corse\n", 
"FRA6->Franche-Comte\n", "FRA7->Haute-Normandie\n", "FRA8->Ile-de-France\n", "FRA9->Languedoc-Roussillon\n", 
"FRB1->Limousin\n", "FRB2->Lorraine\n", "FRB3->Midi-Pyrenees\n", "FRB4->Nord-Pas-de-Calais\n", "FRB5->Pays de la Loire\n", 
"FRB6->Picardie\n", "FRB7->Poitou-Charentes\n", "FRB8->Provence-Alpes-Cote d'Azur\n", "FRB9->Rhone-Alpes\n", 
"GA01->Estuaire\n", "GA02->Haut-Ogooue\n", "GA03->Moyen-Ogooue\n", "GA04->Ngounie\n", "GA05->Nyanga\n", 
"GA06->Ogooue-Ivindo\n", "GA07->Ogooue-Lolo\n", "GA08->Ogooue-Maritime\n", "GA09->Woleu-Ntem\n", "GM01->Banjul\n", 
"GM02->Lower River\n", "GM03->MacCarthy Island\n", "GM07->North Bank\n", "GM04->Upper River\n", "GM05->Western\n", 
"DE01->Baden-Wurttemberg\n", "DE02->Bayern\n", "DE16->Berlin\n", "DE11->Brandenburg\n", "DE03->Bremen\n", 
"DE04->Hamburg\n", "DE05->Hessen\n", "DE12->Mecklenburg-Vorpommern\n", "DE06->Niedersachsen\n", "DE07->Nordrhein-Westfalen\n", 
"DE08->Rheinland-Pfalz\n", "DE09->Saarland\n", "DE13->Sachsen\n", "DE14->Sachsen-Anhalt\n", "DE10->Schleswig-Holstein\n", 
"DE15->Thuringen\n", "GH02->Ashanti\n", "GH03->Brong-Ahafo\n", "GH04->Central\n", "GH05->Eastern\n", 
"GH01->Greater Accra\n", "GH06->Northern\n", "GH10->Upper East\n", "GH11->Upper West\n", "GH08->Volta\n", 
"GH09->Western\n", "GR31->Aitolia kai Akarnania\n", "GR38->Akhaia\n", "GR36->Argolis\n", "GR41->Arkadhia\n", 
"GR20->Arta\n", "GR35->Attiki\n", "GR47->Dhodhekanisos\n", "GR04->Drama\n", "GR30->Evritania\n", "GR01->Evros\n", 
"GR34->Evvoia\n", "GR08->Florina\n", "GR32->Fokis\n", "GR29->Fthiotis\n", "GR10->Grevena\n", "GR39->Ilia\n", 
"GR12->Imathia\n", "GR17->Ioannina\n", "GR45->Iraklion\n", "GR23->Kardhitsa\n", "GR09->Kastoria\n", 
"GR14->Kavala\n", "GR27->Kefallinia\n", "GR25->Kerkira\n", "GR15->Khalkidhiki\n", "GR43->Khania\n", 
"GR50->Khios\n", "GR49->Kikladhes\n", "GR06->Kilkis\n", "GR37->Korinthia\n", "GR11->Kozani\n", "GR42->Lakonia\n", 
"GR21->Larisa\n", "GR46->Lasithi\n", "GR51->Lesvos\n", "GR26->Levkas\n", "GR24->Magnisia\n", "GR40->Messinia\n", 
"GR07->Pella\n", "GR16->Pieria\n", "GR19->Preveza\n", "GR44->Rethimni\n", "GR02->Rodhopi\n", "GR48->Samos\n", 
"GR05->Serrai\n", "GR18->Thesprotia\n", "GR13->Thessaloniki\n", "GR22->Trikala\n", "GR33->Voiotia\n", 
"GR03->Xanthi\n", "GR28->Zakinthos\n", "GL01->Nordgronland\n", "GL02->Ostgronland\n", "GL03->Vestgronland\n", 
"GD01->Saint Andrew\n", "GD02->Saint David\n", "GD03->Saint George\n", "GD04->Saint John\n", "GD05->Saint Mark\n", 
"GD06->Saint Patrick\n", "GT01->Alta Verapaz\n", "GT02->Baja Verapaz\n", "GT03->Chimaltenango\n", "GT04->Chiquimula\n", 
"GT05->El Progreso\n", "GT06->Escuintla\n", "GT07->Guatemala\n", "GT08->Huehuetenango\n", "GT09->Izabal\n", 
"GT10->Jalapa\n", "GT11->Jutiapa\n", "GT12->Peten\n", "GT14->Quiche\n", "GT13->Quetzaltenango\n", "GT15->Retalhuleu\n", 
"GT16->Sacatepequez\n", "GT17->San Marcos\n", "GT18->Santa Rosa\n", "GT19->Solola\n", "GT20->Suchitepequez\n", 
"GT21->Totonicapan\n", "GT22->Zacapa\n", "GN01->Beyla\n", "GN02->Boffa\n", "GN03->Boke\n", "GN04->Conakry\n", 
"GN05->Dabola\n", "GN06->Dalaba\n", "GN07->Dinguiraye\n", "GN31->Dubreka\n", "GN09->Faranah\n", "GN10->Forecariah\n", 
"GN11->Fria\n", "GN12->Gaoual\n", "GN13->Gueckedou\n", "GN32->Kankan\n", "GN15->Kerouane\n", "GN16->Kindia\n", 
"GN17->Kissidougou\n", "GN18->Koundara\n", "GN19->Kouroussa\n", "GN34->Labe\n", "GN21->Macenta\n", "GN22->Mali\n", 
"GN23->Mamou\n", "GN38->Nzerekore\n", "GN25->Pita\n", "GN39->Siguiri\n", "GN27->Telimele\n", "GN28->Tougue\n", 
"GN29->Yomou\n", "GW01->Bafata\n", "GW12->Biombo\n", "GW11->Bissau\n", "GW05->Bolama\n", "GW06->Cacheu\n", 
"GW10->Gabu\n", "GW04->Oio\n", "GW02->Quinara\n", "GW07->Tombali\n", "GY10->Barima-Waini\n", "GY11->Cuyuni-Mazaruni\n", 
"GY12->Demerara-Mahaica\n", "GY13->East Berbice-Corentyne\n", "GY14->Essequibo Islands-West Demerara\n", 
"GY15->Mahaica-Berbice\n", "GY16->Pomeroon-Supenaam\n", "GY17->Potaro-Siparuni\n", "GY18->Upper Demerara-Berbice\n", 
"GY19->Upper Takutu-Upper Essequibo\n", "HT06->Artibonite\n", "HT07->Centre\n", "HT08->Grand' Anse\n", 
"HT09->Nord\n", "HT10->Nord-Est\n", "HT03->Nord-Ouest\n", "HT11->Ouest\n", "HT12->Sud\n", "HT13->Sud-Est\n", 
"HN01->Atlantida\n", "HN02->Choluteca\n", "HN03->Colon\n", "HN04->Comayagua\n", "HN05->Copan\n", "HN06->Cortes\n", 
"HN07->El Paraiso\n", "HN08->Francisco Morazan\n", "HN09->Gracias a Dios\n", "HN10->Intibuca\n", "HN11->Islas de la Bahia\n", 
"HN12->La Paz\n", "HN13->Lempira\n", "HN14->Ocotepeque\n", "HN15->Olancho\n", "HN16->Santa Barbara\n", 
"HN17->Valle\n", "HN18->Yoro\n", "HU01->Bacs-Kiskun\n", "HU02->Baranya\n", "HU03->Bekes\n", "HU26->Bekescsaba\n", 
"HU04->Borsod-Abauj-Zemplen\n", "HU05->Budapest\n", "HU06->Csongrad\n", "HU07->Debrecen\n", "HU27->Dunaujvaros\n", 
"HU28->Eger\n", "HU08->Fejer\n", "HU25->Gyor\n", "HU09->Gyor-Moson-Sopron\n", "HU10->Hajdu-Bihar\n", 
"HU11->Heves\n", "HU29->Hodmezovasarhely\n", "HU20->Jasz-Nagykun-Szolnok\n", "HU30->Kaposvar\n", "HU31->Kecskemet\n", 
"HU12->Komarom-Esztergom\n", "HU13->Miskolc\n", "HU32->Nagykanizsa\n", "HU14->Nograd\n", "HU33->Nyiregyhaza\n", 
"HU15->Pecs\n", "HU16->Pest\n", "HU17->Somogy\n", "HU34->Sopron\n", "HU18->Szabolcs-Szatmar-Bereg\n", 
"HU19->Szeged\n", "HU35->Szekesfehervar\n", "HU36->Szolnok\n", "HU37->Szombathely\n", "HU38->Tatabanya\n", 
"HU21->Tolna\n", "HU22->Vas\n", "HU23->Veszprem\n", "HU39->Veszprem\n", "HU24->Zala\n", "HU40->Zalaegerszeg\n", 
"IS01->Akranes\n", "IS02->Akureyri\n", "IS03->Arnessysla\n", "IS04->Austur-Bardastrandarsysla\n", "IS05->Austur-Hunavatnssysla\n", 
"IS06->Austur-Skaftafellssysla\n", "IS07->Borgarfjardarsysla\n", "IS08->Dalasysla\n", "IS09->Eyjafjardarsysla\n", 
"IS10->Gullbringusysla\n", "IS11->Hafnarfjordur\n", "IS12->Husavik\n", "IS13->Isafjordur\n", "IS14->Keflavik\n", 
"IS15->Kjosarsysla\n", "IS16->Kopavogur\n", "IS17->Myrasysla\n", "IS18->Neskaupstadur\n", "IS19->Nordur-Isafjardarsysla\n", 
"IS20->Nordur-Mulasysla\n", "IS21->Nordur-Tingeyjarsysla\n", "IS22->Olafsfjordur\n", "IS23->Rangarvallasysla\n", 
"IS24->Reykjavik\n", "IS25->Saudarkrokur\n", "IS26->Seydisfjordur\n", "IS27->Siglufjordur\n", "IS28->Skagafjardarsysla\n", 
"IS29->Snafellsnes- og Hnappadalssysla\n", "IS30->Strandasysla\n", "IS31->Sudur-Mulasysla\n", "IS32->Sudur-Tingeyjarsysla\n", 
"IS33->Vestmannaeyjar\n", "IS34->Vestur-Bardastrandarsysla\n", "IS35->Vestur-Hunavatnssysla\n", "IS36->Vestur-Isafjardarsysla\n", 
"IS37->Vestur-Skaftafellssysla\n", "IN01->Andaman and Nicobar Islands\n", "IN02->Andhra Pradesh\n", 
"IN30->Arunachal Pradesh\n", "IN03->Assam\n", "IN34->Bihar\n", "IN05->Chandigarh\n", "IN06->Dadra and Nagar Haveli\n", 
"IN32->Daman and Diu\n", "IN07->Delhi\n", "IN33->Goa\n", "IN09->Gujarat\n", "IN10->Haryana\n", "IN11->Himachal Pradesh\n", 
"IN12->Jammu and Kashmir\n", "IN19->Karnataka\n", "IN13->Kerala\n", "IN14->Lakshadweep\n", "IN35->Madhya Pradesh\n", 
"IN16->Maharashtra\n", "IN17->Manipur\n", "IN18->Meghalaya\n", "IN31->Mizoram\n", "IN20->Nagaland\n", 
"IN21->Orissa\n", "IN22->Pondicherry\n", "IN23->Punjab\n", "IN24->Rajasthan\n", "IN29->Sikkim\n", "IN25->Tamil Nadu\n", 
"IN26->Tripura\n", "IN36->Uttar Pradesh\n", "IN28->West Bengal\n", "ID01->Aceh\n", "ID02->Bali\n", "ID03->Bengkulu\n", 
"ID09->Papua\n", "ID04->Jakarta Raya\n", "ID05->Jambi\n", "ID30->Jawa Barat\n", "ID07->Jawa Tengah\n", 
"ID08->Jawa Timur\n", "ID11->Kalimantan Barat\n", "ID12->Kalimantan Selatan\n", "ID13->Kalimantan Tengah\n", 
"ID14->Kalimantan Timur\n", "ID15->Lampung\n", "ID28->Maluku\n", "ID17->Nusa Tenggara Barat\n", "ID18->Nusa Tenggara Timur\n", 
"ID19->Riau\n", "ID20->Sulawesi Selatan\n", "ID21->Sulawesi Tengah\n", "ID22->Sulawesi Tenggara\n", 
"ID31->Sulawesi Utara\n", "ID24->Sumatera Barat\n", "ID32->Sumatera Selatan\n", "ID26->Sumatera Utara\n", 
"ID27->Timor Timur\n", "ID10->Yogyakarta\n", "IR01->Azarbayjan-e Bakhtari\n", "IR02->Azarbayjan-e Khavari\n", 
"IR13->Bakhtaran\n", "IR22->Bushehr\n", "IR03->Chahar Mahall va Bakhtiari\n", "IR28->Esfahan\n", "IR07->Fars\n", 
"IR08->Gilan\n", "IR09->Hamadan\n", "IR11->Hormozgan\n", "IR10->Ilam\n", "IR29->Kerman\n", "IR30->Khorasan\n", 
"IR15->Khuzestan\n", "IR05->Kohkiluyeh va Buyer Ahmadi\n", "IR16->Kordestan\n", "IR23->Lorestan\n", 
"IR34->Markazi\n", "IR35->Mazandaran\n", "IR25->Semnan\n", "IR04->Sistan va Baluchestan\n", "IR26->Tehran\n", 
"IR31->Yazd\n", "IR36->Zanjan\n", "IQ01->Al Anbar\n", "IQ02->Al Basrah\n", "IQ03->Al Muthanna\n", "IQ04->Al Qadisiyah\n", 
"IQ17->An Najaf\n", "IQ11->Arbil\n", "IQ05->As Sulaymaniyah\n", "IQ13->At Ta'mim\n", "IQ06->Babil\n", 
"IQ07->Baghdad\n", "IQ08->Dahuk\n", "IQ09->Dhi Qar\n", "IQ10->Diyala\n", "IQ12->Karbala'\n", "IQ14->Maysan\n", 
"IQ15->Ninawa\n", "IQ18->Salah ad Din\n", "IQ16->Wasit\n", "IE01->Carlow\n", "IE02->Cavan\n", "IE03->Clare\n", 
"IE04->Cork\n", "IE06->Donegal\n", "IE07->Dublin\n", "IE10->Galway\n", "IE11->Kerry\n", "IE12->Kildare\n", 
"IE13->Kilkenny\n", "IE15->Laois\n", "IE14->Leitrim\n", "IE16->Limerick\n", "IE18->Mintford\n", "IE19->Louth\n", 
"IE20->Mayo\n", "IE21->Meath\n", "IE22->Monaghan\n", "IE23->Offaly\n", "IE24->Roscommon\n", "IE25->Sligo\n", 
"IE26->Tipperary\n", "IE27->Waterford\n", "IE29->Westmeath\n", "IE30->Wexford\n", "IE31->Wicklow\n", 
"IL01->HaDarom\n", "IL02->HaMerkaz\n", "IL03->HaZafon\n", "IL04->Hefa\n", "IL05->Tel Aviv\n", "IL06->Yerushalayim\n", 
"IT01->Abruzzi\n", "IT02->Basilicata\n", "IT03->Calabria\n", "IT04->Campania\n", "IT05->Emilia-Romagna\n", 
"IT06->Friuli-Venezia Giulia\n", "IT07->Lazio\n", "IT08->Liguria\n", "IT09->Lombardia\n", "IT10->Marche\n", 
"IT11->Molise\n", "IT12->Piemonte\n", "IT13->Puglia\n", "IT14->Sardegna\n", "IT15->Sicilia\n", "IT16->Toscana\n", 
"IT17->Trentino-Alto Adige\n", "IT18->Umbria\n", "IT19->Valle d'Aosta\n", "IT20->Veneto\n", "JM01->Clarendon\n", 
"JM02->Hanover\n", "JM17->Kingston\n", "JM04->Manchester\n", "JM07->Portland\n", "JM08->Saint Andrew\n", 
"JM09->Saint Ann\n", "JM10->Saint Catherine\n", "JM11->Saint Elizabeth\n", "JM12->Saint James\n", "JM13->Saint Mary\n", 
"JM14->Saint Thomas\n", "JM15->Trelawny\n", "JM16->Westmoreland\n", "JP01->Aichi\n", "JP02->Akita\n", 
"JP03->Aomori\n", "JP04->Chiba\n", "JP05->Ehime\n", "JP06->Fukui\n", "JP07->Fukuoka\n", "JP08->Fukushima\n", 
"JP09->Gifu\n", "JP10->Gumma\n", "JP11->Hiroshima\n", "JP12->Hokkaido\n", "JP13->Hyogo\n", "JP14->Ibaraki\n", 
"JP15->Ishikawa\n", "JP16->Iwate\n", "JP17->Kagawa\n", "JP18->Kagoshima\n", "JP19->Kanagawa\n", "JP20->Kochi\n", 
"JP21->Kumamoto\n", "JP22->Kyoto\n", "JP23->Mie\n", "JP24->Miyagi\n", "JP25->Miyazaki\n", "JP26->Nagano\n", 
"JP27->Nagasaki\n", "JP28->Nara\n", "JP29->Niigata\n", "JP30->Oita\n", "JP31->Okayama\n", "JP47->Okinawa\n", 
"JP32->Osaka\n", "JP33->Saga\n", "JP34->Saitama\n", "JP35->Shiga\n", "JP36->Shimane\n", "JP37->Shizuoka\n", 
"JP38->Tochigi\n", "JP39->Tokushima\n", "JP40->Tokyo\n", "JP41->Tottori\n", "JP42->Toyama\n", "JP43->Wakayama\n", 
"JP44->Yamagata\n", "JP45->Yamaguchi\n", "JP46->Yamanashi\n", "JO02->Al Balqa'\n", "JO09->Al Karak\n", 
"JO10->Al Mafraq\n", "JO12->At Tafilah\n", "JO13->Az Zarqa\n", "JO14->Irbid\n", "JO07->Ma\n", "KE01->Central\n", 
"KE02->Coast\n", "KE03->Eastern\n", "KE05->Nairobi Area\n", "KE06->North-Eastern\n", "KE07->Nyanza\n", 
"KE08->Rift Valley\n", "KE09->Western\n", "KI01->Gilbert Islands\n", "KI02->Line Islands\n", "KI03->Phoenix Islands\n", 
"KP01->Chagang-do\n", "KP17->Hamgyong-bukto\n", "KP03->Hamgyong-namdo\n", "KP07->Hwanghae-bukto\n", 
"KP06->Hwanghae-namdo\n", "KP08->Kaesong-si\n", "KP09->Kangwon-do\n", "KP14->Namp'o-si\n", "KP11->P'yongan-bukto\n", 
"KP15->P'yongan-namdo\n", "KP12->P'yongyang-si\n", "KP13->Yanggang-do\n", "KR01->Cheju-do\n", "KR03->Cholla-bukto\n", 
"KR16->Cholla-namdo\n", "KR05->Ch'ungch'ong-bukto\n", "KR17->Ch'ungch'ong-namdo\n", "KR12->Inch'on-jikhalsi\n", 
"KR06->Kangwon-do\n", "KR18->Kwangju-jikhalsi\n", "KR13->Kyonggi-do\n", "KR14->Kyongsang-bukto\n", "KR20->Kyongsang-namdo\n", 
"KR10->Pusan-jikhalsi\n", "KR11->Soul-t'ukpyolsi\n", "KR15->Taegu-jikhalsi\n", "KR19->Taejon-jikhalsi\n", 
"KW01->Al Ahmadi\n", "KW02->Al Kuwayt\n", "KW03->Hawalli\n", "LA01->Attapu\n", "LA02->Champasak\n", 
"LA03->Houaphan\n", "LA04->Khammouan\n", "LA05->Louang Namtha\n", "LA06->Louangphrabang\n", "LA07->Oudomxai\n", 
"LA08->Phongsali\n", "LA09->Saravan\n", "LA10->Savannakhet\n", "LA11->Vientiane\n", "LA13->Xaignabouri\n", 
"LA14->Xiangkhoang\n", "LB01->Beqaa\n", "LB06->Liban-Sud\n", "LB03->Liban-Nord\n", "LB04->Beyrouth\n", 
"LB05->Mont-Liban\n", "LS10->Berea\n", "LS11->Butha-Buthe\n", "LS12->Leribe\n", "LS13->Mafeteng\n", 
"LS14->Maseru\n", "LS15->Mohales Hoek\n", "LS16->Mokhotmint\n", "LS17->Qachas Nek\n", "LS18->Quthing\n", 
"LS19->Thaba-Tseka\n", "LR01->Bong\n", "LR03->Grand Bassa\n", "LR04->Grand Cape Mount\n", "LR02->Grand Jide\n", 
"LR05->Lofa\n", "LR06->Maryland\n", "LR07->Monrovia\n", "LR08->Montserrado\n", "LR09->Nimba\n", "LR10->Sino\n", 
"LY47->Ajdabiya\n", "LY03->Al\n", "LY48->Al Fatih\n", "LY49->Al Jabal al Akhdar\n", "LY05->Al Jufrah\n", 
"LY50->Al Khums\n", "LY08->Al Kufrah\n", "LY51->An Nuqat al Khams\n", "LY13->Ash Shati'\n", "LY52->Awbari\n", 
"LY53->Az Zawiyah\n", "LY54->Banghazi\n", "LY55->Darnah\n", "LY56->Ghadamis\n", "LY57->Gharyan\n", "LY58->Misratah\n", 
"LY30->Murzuq\n", "LY34->Sabha\n", "LY59->Sawfajjin\n", "LY60->Surt\n", "LY61->Tarabulus\n", "LY41->Tarhunah\n", 
"LY42->Tubruq\n", "LY62->Yafran\n", "LY45->Zlitan\n", "LI01->Balzers\n", "LI02->Eschen\n", "LI03->Gamprin\n", 
"LI04->Mauren\n", "LI05->Planken\n", "LI06->Ruggell\n", "LI07->Schaan\n", "LI08->Schellenberg\n", "LI09->Triesen\n", 
"LI10->Triesenberg\n", "LI11->Vaduz\n", "LU01->Diekirch\n", "LU02->Grevenmacher\n", "LU03->Luxembourg\n", 
"MO01->Ilhas\n", "MO02->Macau\n", "MG05->Antananarivo\n", "MG01->Antsiranana\n", "MG02->Fianarantsoa\n", 
"MG03->Mahajanga\n", "MG04->Toamasina\n", "MG06->Toliara\n", "MW24->Blantyre\n", "MW02->Chikwawa\n", 
"MW03->Chiradzulu\n", "MW04->Chitipa\n", "MW06->Dedza\n", "MW07->Dowa\n", "MW08->Karonga\n", "MW09->Kasungu\n", 
"MW11->Limintwe\n", "MW10->Machinga\n", "MW12->Mangochi\n", "MW13->Mchinji\n", "MW14->Mulanje\n", "MW25->Mwanza\n", 
"MW15->Mzimba\n", "MW17->Nkhata Bay\n", "MW18->Nkhotakota\n", "MW19->Nsanje\n", "MW16->Ntcheu\n", "MW20->Ntchisi\n", 
"MW21->Rumphi\n", "MW22->Salima\n", "MW05->Thyolo\n", "MW23->Zomba\n", "MY01->Johor\n", "MY02->Kedah\n", 
"MY03->Kelantan\n", "MY15->Labuan\n", "MY04->Melaka\n", "MY05->Negeri Sembilan\n", "MY06->Pahang\n", 
"MY07->Perak\n", "MY08->Perlis\n", "MY09->Pulau Pinang\n", "MY16->Sabah\n", "MY11->Sarawak\n", "MY12->Selangor\n", 
"MY13->Terengganu\n", "MY14->Wilayah Persekutuan\n", "MV02->Aliff\n", "MV20->Baa\n", "MV17->Daalu\n", 
"MV14->Faafu\n", "MV27->Gaafu Aliff\n", "MV28->Gaafu Daalu\n", "MV07->Haa Aliff\n", "MV23->Haa Daalu\n", 
"MV26->Kaafu\n", "MV05->Laamu\n", "MV03->Laviyani\n", "MV12->Meemu\n", "MV29->Naviyani\n", "MV25->Noonu\n", 
"MV13->Raa\n", "MV01->Seenu\n", "MV24->Shaviyani\n", "MV08->Thaa\n", "MV04->Waavu\n", "ML01->Bamako\n", 
"ML02->Gao\n", "ML03->Kayes\n", "ML07->Koulikoro\n", "ML04->Mopti\n", "ML05->Segou\n", "ML06->Sikasso\n", 
"ML08->Tombouctou\n", "MR07->Adrar\n", "MR03->Assaba\n", "MR05->Brakna\n", "MR08->Dakhlet Nouadhibou\n", 
"MR04->Gorgol\n", "MR10->Guidimaka\n", "MR01->Hodh Ech Chargui\n", "MR02->Hodh El Gharbi\n", "MR12->Inchiri\n", 
"MR09->Tagant\n", "MR11->Tiris Zemmour\n", "MR06->Trarza\n", "MU21->Agalega Islands\n", "MU12->Black River\n", 
"MU22->Cargados Carajos\n", "MU13->Flacq\n", "MU14->Grand Port\n", "MU15->Moka\n", "MU16->Pamplemousses\n", 
"MU17->Plaines Wilhems\n", "MU18->Port Louis\n", "MU19->Riviere du Rempart\n", "MU23->Rodrigues\n", 
"MU20->Savanne\n", "MX01->Aguascalientes\n", "MX02->Baja California\n", "MX03->Baja California Sur\n", 
"MX04->Campeche\n", "MX05->Chiapas\n", "MX06->Chihuahua\n", "MX07->Coahuila de Zaragoza\n", "MX08->Colima\n", 
"MX09->Distrito Federal\n", "MX10->Durango\n", "MX11->Guanajuato\n", "MX12->Guerrero\n", "MX13->Hidalgo\n", 
"MX14->Jalisco\n", "MX15->Mexico\n", "MX16->Michoacan de Ocampo\n", "MX17->Morelos\n", "MX18->Nayarit\n", 
"MX19->Nuevo Leon\n", "MX20->Oaxaca\n", "MX21->Puebla\n", "MX22->Queretaro de Arteaga\n", "MX23->Quintana Roo\n", 
"MX24->San Luis Potosi\n", "MX25->Sinaloa\n", "MX26->Sonora\n", "MX27->Tabasco\n", "MX28->Tamaulipas\n", 
"MX29->Tlaxcala\n", "MX30->Veracruz-Llave\n", "MX31->Yucatan\n", "MX32->Zacatecas\n", "MC01->La Condamine\n", 
"MC02->Monaco\n", "MC03->Monte-Carlo\n", "MN01->Arhangay\n", "MN02->Bayanhongor\n", "MN03->Bayan-Olgiy\n", 
"MN21->Bulgan\n", "MN05->Darhan\n", "MN06->Dornod\n", "MN07->Dornogovi\n", "MN08->Dundgovi\n", "MN09->Dzavhan\n", 
"MN22->Erdenet\n", "MN10->Govi-Altay\n", "MN11->Hentiy\n", "MN12->Hovd\n", "MN13->Hovsgol\n", "MN14->Omnogovi\n", 
"MN15->Ovorhangay\n", "MN16->Selenge\n", "MN17->Suhbaatar\n", "MN18->Tov\n", "MN20->Ulaanbaatar\n", 
"MN19->Uvs\n", "MS01->Saint Anthony\n", "MS02->Saint Georges\n", "MS03->Saint Peter\n", "MA01->Agadir\n", 
"MA02->Al Hoceima\n", "MA03->Azilal\n", "MA05->Beni Mellal\n", "MA04->Ben Slimane\n", "MA06->Boulemane\n", 
"MA07->Casablanca\n", "MA08->Chaouen\n", "MA09->El Jadida\n", "MA10->El Kelaa des Srarhna\n", "MA11->Er Rachidia\n", 
"MA12->Essaouira\n", "MA13->Fes\n", "MA14->Figuig\n", "MA33->Guelmim\n", "MA34->Ifrane\n", "MA15->Kenitra\n", 
"MA16->Khemisset\n", "MA17->Khenifra\n", "MA18->Khouribga\n", "MA35->Laayoune\n", "MA41->Larache\n", 
"MA19->Marrakech\n", "MA20->Meknes\n", "MA21->Nador\n", "MA22->Ouarzazate\n", "MA23->Oujda\n", "MA24->Rabat-Sale\n", 
"MA25->Safi\n", "MA26->Settat\n", "MA38->Sidi Kacem\n", "MA27->Tanger\n", "MA36->Tan-Tan\n", "MA37->Taounate\n", 
"MA39->Taroudannt\n", "MA29->Tata\n", "MA30->Taza\n", "MA40->Tetouan\n", "MA32->Tiznit\n", "MZ01->Cabo Delgado\n", 
"MZ02->Gaza\n", "MZ03->Inhambane\n", "MZ10->Manica\n", "MZ04->Maputo\n", "MZ06->Nampula\n", "MZ07->Niassa\n", 
"MZ05->Sofala\n", "MZ08->Tete\n", "MZ09->Zambezia\n", "NA01->Bethanien\n", "NA03->Boesmanland\n", "NA02->Caprivi Oos\n", 
"NA22->Damaraland\n", "NA04->Gobabis\n", "NA05->Grootfontein\n", "NA23->Hereroland Oos\n", "NA24->Hereroland Wes\n", 
"NA06->Kaokoland\n", "NA20->Karasburg\n", "NA07->Karibib\n", "NA25->Kavango\n", "NA08->Keetmanshoop\n", 
"NA09->Luderitz\n", "NA10->Maltahohe\n", "NA26->Mariental\n", "NA27->Namaland\n", "NA11->Okahandja\n", 
"NA12->Omaruru\n", "NA13->Otjiwarongo\n", "NA14->Outjo\n", "NA15->Owambo\n", "NA16->Rehoboth\n", "NA17->Swakopmund\n", 
"NA18->Tsumeb\n", "NA21->Windhoek\n", "NR01->Aiwo\n", "NR02->Anabar\n", "NR03->Anetan\n", "NR04->Anibare\n", 
"NR05->Baiti\n", "NR06->Boe\n", "NR07->Buada\n", "NR08->Denigomodu\n", "NR09->Ewa\n", "NR10->Ijuw\n", 
"NR11->Meneng\n", "NR12->Nibok\n", "NR13->Uaboe\n", "NR14->Yaren\n", "NP01->Bagmati\n", "NP02->Bheri\n", 
"NP03->Dhawalagiri\n", "NP04->Gandaki\n", "NP05->Janakpur\n", "NP06->Karnali\n", "NP07->Kosi\n", "NP08->Lumbini\n", 
"NP09->Mahakali\n", "NP10->Mechi\n", "NP11->Narayani\n", "NP12->Rapti\n", "NP13->Sagarmatha\n", "NP14->Seti\n", 
"NL01->Drenthe\n", "NL12->Dronten\n", "NL02->Friesland\n", "NL03->Gelderland\n", "NL04->Groningen\n", 
"NL14->Lelystad\n", "NL05->Limburg\n", "NL06->Noord-Brabant\n", "NL07->Noord-Holland\n", "NL08->Overijssel\n", 
"NL09->Utrecht\n", "NL10->Zeeland\n", "NL13->Zuidelijke IJsselmeerpolders\n", "NL11->Zuid-Holland\n", 
"NL15->Overijssel\n", "NL16->Flevoland\n", "NZ01->Akaroa\n", "NZ03->Amuri\n", "NZ04->Ashburton\n", "NZ07->Bay of Islands\n", 
"NZ08->Bruce\n", "NZ09->Buller\n", "NZ10->Chatham Islands\n", "NZ11->Cheviot\n", "NZ12->Clifton\n", 
"NZ13->Clutha\n", "NZ14->Cook\n", "NZ16->Dannevirke\n", "NZ17->Egmont\n", "NZ18->Eketahuna\n", "NZ19->Ellesmere\n", 
"NZ20->Eltham\n", "NZ21->Eyre\n", "NZ22->Featherston\n", "NZ24->Franklin\n", "NZ26->Golden Bay\n", "NZ27->Great Barrier Island\n", 
"NZ28->Grey\n", "NZ29->Hauraki Plains\n", "NZ30->Hawera\n", "NZ31->Hawke's Bay\n", "NZ32->Heathcote\n", 
"NZD9->Hikurangi\n", "NZ33->Hobson\n", "NZ34->Hokianga\n", "NZ35->Horowhenua\n", "NZD4->Hurunui\n", 
"NZ36->Hutt\n", "NZ37->Inangahua\n", "NZ38->Inglewood\n", "NZ39->Kaikoura\n", "NZ40->Kairanga\n", "NZ41->Kiwitea\n", 
"NZ43->Lake\n", "NZ45->Mackenzie\n", "NZ46->Malvern\n", "NZE1->Manaia\n", "NZ47->Manawatu\n", "NZ48->Mangonui\n", 
"NZ49->Maniototo\n", "NZ50->Marlborough\n", "NZ51->Masterton\n", "NZ52->Matamata\n", "NZ53->Mount Herbert\n", 
"NZ54->Ohinemuri\n", "NZ55->Opotiki\n", "NZ56->Oroua\n", "NZ57->Otamatea\n", "NZ58->Otorohanga\n", "NZ59->Oxford\n", 
"NZ60->Pahiatua\n", "NZ61->Paparua\n", "NZ63->Patea\n", "NZ65->Piako\n", "NZ66->Pohangina\n", "NZ67->Raglan\n", 
"NZ68->Rangiora\n", "NZ69->Rangitikei\n", "NZ70->Rodney\n", "NZ71->Rotorua\n", "NZE2->Runanga\n", "NZE3->Saint Kilda\n", 
"NZD5->Silverpeaks\n", "NZ72->Southland\n", "NZ73->Stewart Island\n", "NZ74->Stratford\n", "NZD6->Strathallan\n", 
"NZ76->Taranaki\n", "NZ77->Taumarunui\n", "NZ78->Taupo\n", "NZ79->Tauranga\n", "NZE4->Thames-Coromandel\n", 
"NZ81->Tuapeka\n", "NZ82->Vincent\n", "NZ83->Waiapu\n", "NZD8->Waiheke\n", "NZ84->Waihemo\n", "NZ85->Waikato\n", 
"NZ86->Waikohu\n", "NZ88->Waimairi\n", "NZ89->Waimarino\n", "NZ90->Waimate\n", "NZ91->Waimate West\n", 
"NZ92->Waimea\n", "NZ93->Waipa\n", "NZ95->Waipawa\n", "NZ96->Waipukurau\n", "NZ97->Wairarapa South\n", 
"NZ98->Wairewa\n", "NZ99->Wairoa\n", "NZA4->Waitaki\n", "NZA6->Waitomo\n", "NZA8->Waitotara\n", "NZE6->Wallace\n", 
"NZB2->Wanganui\n", "NZE5->Waverley\n", "NZB3->Westland\n", "NZB4->Whakatane\n", "NZA1->Whangarei\n", 
"NZA2->Whangaroa\n", "NZA3->Woodville\n", "NI01->Boaco\n", "NI02->Carazo\n", "NI03->Chinandega\n", "NI04->Chontales\n", 
"NI05->Esteli\n", "NI06->Granada\n", "NI07->Jinotega\n", "NI08->Leon\n", "NI09->Madriz\n", "NI10->Managua\n", 
"NI11->Masaya\n", "NI12->Matagalpa\n", "NI13->Nueva Segovia\n", "NI14->Rio San Juan\n", "NI15->Rivas\n", 
"NI16->Zelaya\n", "NE01->Agadez\n", "NE02->Diffa\n", "NE03->Dosso\n", "NE04->Maradi\n", "NE05->Niamey\n", 
"NE06->Tahoua\n", "NE07->Zinder\n", "NG45->Abia\n", "NG11->Abuja Capital Territory\n", "NG35->Adamawa\n", 
"NG21->Akwa Ibom\n", "NG25->Anambra\n", "NG46->Bauchi\n", "NG26->Benue\n", "NG27->Borno\n", "NG22->Cross River\n", 
"NG36->Delta\n", "NG37->Edo\n", "NG47->Enugu\n", "NG28->Imo\n", "NG39->Jigawa\n", "NG23->Kaduna\n", 
"NG29->Kano\n", "NG24->Katsina\n", "NG40->Kebbi\n", "NG41->Kogi\n", "NG30->Kwara\n", "NG05->Lagos\n", 
"NG31->Niger\n", "NG16->Ogun\n", "NG48->Ondo\n", "NG42->Osun\n", "NG32->Oyo\n", "NG49->Plateau\n", "NG50->Rivers\n", 
"NG51->Sokoto\n", "NG43->Taraba\n", "NG44->Yobe\n", "NO01->Akershus\n", "NO02->Aust-Agder\n", "NO04->Buskerud\n", 
"NO05->Finnmark\n", "NO06->Hedmark\n", "NO07->Hordaland\n", "NO08->More og Romsdal\n", "NO09->Nordland\n", 
"NO10->Nord-Trondelag\n", "NO11->Oppland\n", "NO12->Oslo\n", "NO13->Ostfold\n", "NO14->Rogaland\n", 
"NO15->Sogn og Fjordane\n", "NO16->Sor-Trondelag\n", "NO17->Telemark\n", "NO18->Troms\n", "NO19->Vest-Agder\n", 
"NO20->Vestfold\n", "PK06->Azad Kashmir\n", "PK02->Balochistan\n", "PK01->Federally Administered Tribal Areas\n", 
"PK08->Islamabad\n", "PK07->Northern Areas\n", "PK03->North-West Frontier\n", "PK04->Punjab\n", "PK05->Sindh\n", 
"PA01->Bocas del Toro\n", "PA02->Chiriqui\n", "PA03->Cocle\n", "PA04->Colon\n", "PA05->Darien\n", "PA06->Herrera\n", 
"PA07->Los Santos\n", "PA08->Panama\n", "PA09->San Blas\n", "PA10->Veraguas\n", "PG01->Central\n", "PG08->Chimbu\n", 
"PG09->Eastern Highlands\n", "PG10->East New Britain\n", "PG11->East Sepik\n", "PG19->Enga\n", "PG02->Gulf\n", 
"PG12->Madang\n", "PG13->Manus\n", "PG03->Milne Bay\n", "PG14->Morobe\n", "PG20->National Capital\n", 
"PG15->New Ireland\n", "PG04->Northern\n", "PG07->North Solomons\n", "PG18->Sandaun\n", "PG05->Southern Highlands\n", 
"PG06->Western\n", "PG16->Western Highlands\n", "PG17->West New Britain\n", "PY18->Alto Paraguay\n", 
"PY01->Alto Parana\n", "PY02->Amambay\n", "PY03->Boqueron\n", "PY04->Caaguazu\n", "PY05->Caazapa\n", 
"PY19->Canindeyu\n", "PY06->Central\n", "PY20->Chaco\n", "PY07->Concepcion\n", "PY08->Cordillera\n", 
"PY10->Guaira\n", "PY11->Itapua\n", "PY12->Misiones\n", "PY13->Neembucu\n", "PY21->Nueva Asuncion\n", 
"PY15->Paraguari\n", "PY16->Presidente Hayes\n", "PY17->San Pedro\n", "PE01->Amazonas\n", "PE02->Ancash\n", 
"PE03->Apurimac\n", "PE04->Arequipa\n", "PE05->Ayacucho\n", "PE06->Cajamarca\n", "PE07->Callao\n", "PE08->Cusco\n", 
"PE09->Huancavelica\n", "PE10->Huanuco\n", "PE11->Ica\n", "PE12->Junin\n", "PE13->La Libertad\n", "PE14->Lambayeque\n", 
"PE15->Lima\n", "PE16->Loreto\n", "PE17->Madre de Dios\n", "PE18->Moquegua\n", "PE19->Pasco\n", "PE20->Piura\n", 
"PE21->Puno\n", "PE22->San Martin\n", "PE23->Tacna\n", "PE24->Tumbes\n", "PE25->Ucayali\n", "PH01->Abra\n", 
"PH02->Agusan del Norte\n", "PH03->Agusan del Sur\n", "PH04->Aklan\n", "PH05->Albay\n", "PHA1->Angeles\n", 
"PH06->Antique\n", "PHG8->Aurora\n", "PHA2->Bacolod\n", "PHA3->Bago\n", "PHA4->Baguio\n", "PHA5->Bais\n", 
"PH22->Basilan\n", "PHA6->Basilan City\n", "PH07->Bataan\n", "PH08->Batanes\n", "PH09->Batangas\n", 
"PHA7->Batangas City\n", "PH10->Benguet\n", "PH11->Bohol\n", "PH12->Bukidnon\n", "PH13->Bulacan\n", 
"PHA8->Butuan\n", "PHA9->Cabanatuan\n", "PHB1->Cadiz\n", "PH14->Cagayan\n", "PHB2->Cagayan de Oro\n", 
"PHB3->Calbayog\n", "PHB4->Caloocan\n", "PH15->Camarines Norte\n", "PH16->Camarines Sur\n", "PH17->Camiguin\n", 
"PHB5->Canlaon\n", "PH18->Capiz\n", "PH19->Catanduanes\n", "PH20->Cavite\n", "PHB6->Cavite City\n", 
"PH21->Cebu\n", "PHB7->Cebu City\n", "PHB8->Cotabato\n", "PHB9->Dagupan\n", "PHC1->Danao\n", "PHC2->Dapitan\n", 
"PH24->Davao\n", "PHC3->Davao City\n", "PH25->Davao del Sur\n", "PH26->Davao Oriental\n", "PHC4->Dipolog\n", 
"PHC5->Dumaguete\n", "PH23->Eastern Samar\n", "PHC6->General Santos\n", "PHC7->Gingoog\n", "PH27->Ifugao\n", 
"PHC8->Iligan\n", "PH28->Ilocos Norte\n", "PH29->Ilocos Sur\n", "PH30->Iloilo\n", "PHC9->Iloilo City\n", 
"PHD1->Iriga\n", "PH31->Isabela\n", "PH32->Kalinga-Apayao\n", "PHD2->La Carlota\n", "PH33->Laguna\n", 
"PH34->Lanao del Norte\n", "PH35->Lanao del Sur\n", "PHD3->Laoag\n", "PHD4->Lapu-Lapu\n", "PH36->La Union\n", 
"PHD5->Legaspi\n", "PH37->Leyte\n", "PHD6->Lipa\n", "PHD7->Lucena\n", "PH56->Maguindanao\n", "PHD8->Mandaue\n", 
"PHD9->Manila\n", "PHE1->Marawi\n", "PH38->Marinduque\n", "PH39->Masbate\n", "PH40->Mindoro Occidental\n", 
"PH41->Mindoro Oriental\n", "PH42->Misamis Occidental\n", "PH43->Misamis Oriental\n", "PH44->Mountain\n", 
"PHE2->Naga\n", "PHH3->Negros Occidental\n", "PH46->Negros Oriental\n", "PH57->North Cotabato\n", "PH67->Northern Samar\n", 
"PH47->Nueva Ecija\n", "PH48->Nueva Vizcaya\n", "PHE3->Omintapo\n", "PHE4->Ormoc\n", "PHE5->Oroquieta\n", 
"PHE6->Ozamis\n", "PHE7->Pagadian\n", "PH49->Palawan\n", "PHE8->Palayan\n", "PH50->Pampanga\n", "PH51->Pangasinan\n", 
"PHE9->Pasay\n", "PHF1->Puerto Princesa\n", "PHH2->Quezon\n", "PHF2->Quezon City\n", "PH68->Quirino\n", 
"PH53->Rizal\n", "PH54->Romblon\n", "PHF3->Roxas\n", "PH55->Samar\n", "PHF4->San Carlos\n", "PHF5->San Carlos\n", 
"PHF6->San Jose\n", "PHF7->San Pablo\n", "PHF8->Silay\n", "PH69->Siquijor\n", "PH58->Sorsogon\n", "PH70->South Cotabato\n", 
"PH59->Southern Leyte\n", "PH71->Sultan Kudarat\n", "PH60->Sulu\n", "PHF9->Surigao\n", "PH61->Surigao del Norte\n", 
"PH62->Surigao del Sur\n", "PHG1->Tacloban\n", "PHG2->Tagaytay\n", "PHG3->Tagbilaran\n", "PHG4->Tangub\n", 
"PH63->Tarlac\n", "PH72->Tawitawi\n", "PHG5->Toledo\n", "PHG6->Trece Martires\n", "PH64->Zambales\n", 
"PHG7->Zamboanga\n", "PH65->Zamboanga del Norte\n", "PH66->Zamboanga del Sur\n", "PL23->Biala Podlaska\n", 
"PL24->Bialystok\n", "PL25->Bielsko\n", "PL26->Bydgoszcz\n", "PL27->Chelm\n", "PL28->Ciechanow\n", "PL29->Czestochowa\n", 
"PL30->Elblag\n", "PL31->Gdansk\n", "PL32->Gorzow\n", "PL33->Jelenia Gora\n", "PL34->Kalisz\n", "PL35->Katowice\n", 
"PL36->Kielce\n", "PL37->Konin\n", "PL38->Koszalin\n", "PL39->Krakow\n", "PL40->Krosno\n", "PL41->Legnica\n", 
"PL42->Leszno\n", "PL43->Lodz\n", "PL44->Lomza\n", "PL45->Lublin\n", "PL46->Nowy Sacz\n", "PL47->Olsztyn\n", 
"PL48->Opole\n", "PL49->Ostroleka\n", "PL50->Pila\n", "PL51->Piotrkow\n", "PL52->Plock\n", "PL53->Poznan\n", 
"PL54->Przemysl\n", "PL55->Radom\n", "PL56->Rzeszow\n", "PL57->Siedlce\n", "PL58->Sieradz\n", "PL59->Skierniewice\n", 
"PL60->Slupsk\n", "PL61->Suwalki\n", "PL62->Szczecin\n", "PL63->Tarnobrzeg\n", "PL64->Tarnow\n", "PL65->Torun\n", 
"PL66->Walbrzych\n", "PL67->Warszawa\n", "PL68->Wloclawek\n", "PL69->Wroclaw\n", "PL70->Zamosc\n", "PL71->Zielona Gora\n", 
"PT02->Aveiro\n", "PT23->Azores\n", "PT03->Beja\n", "PT04->Braga\n", "PT05->Braganca\n", "PT06->Castelo Branco\n", 
"PT07->Coimbra\n", "PT08->Evora\n", "PT09->Faro\n", "PT11->Guarda\n", "PT13->Leiria\n", "PT14->Lisboa\n", 
"PT10->Madeira\n", "PT16->Portalegre\n", "PT17->Porto\n", "PT18->Santarem\n", "PT19->Setubal\n", "PT20->Viana do Castelo\n", 
"PT21->Vila Real\n", "PT22->Viseu\n", "RO01->Alba\n", "RO02->Arad\n", "RO03->Arges\n", "RO04->Bacau\n", 
"RO05->Bihor\n", "RO06->Bistrita-Nasaud\n", "RO07->Botosani\n", "RO08->Braila\n", "RO09->Brasov\n", 
"RO10->Bucuresti\n", "RO11->Buzau\n", "RO41->Calarasi\n", "RO12->Caras-Severin\n", "RO13->Cluj\n", "RO14->Constanta\n", 
"RO15->Covasna\n", "RO16->Dambovita\n", "RO17->Dolj\n", "RO18->Galati\n", "RO19->Gorj\n", "RO42->Giurgiu\n", 
"RO20->Harghita\n", "RO21->Hunedoara\n", "RO22->Ialomita\n", "RO23->Iasi\n", "RO25->Maramures\n", "RO26->Mehedinti\n", 
"RO27->Mures\n", "RO28->Neamt\n", "RO29->Olt\n", "RO30->Prahova\n", "RO31->Salaj\n", "RO32->Satu Mare\n", 
"RO33->Sibiu\n", "RO34->Suceava\n", "RO35->Teleorman\n", "RO36->Timis\n", "RO37->Tulcea\n", "RO38->Vaslui\n", 
"RO39->Valcea\n", "RO40->Vrancea\n", "RW01->Butare\n", "RW02->Byumba\n", "RW03->Cyangugu\n", "RW04->Gikongoro\n", 
"RW05->Gisenyi\n", "RW06->Gitarama\n", "RW07->Kibungo\n", "RW08->Kibuye\n", "RW09->Kigali\n", "RW10->Ruhengeri\n", 
"KN01->Christ Church Nichola Town\n", "KN02->Saint Anne Sandy Point\n", "KN03->Saint George Basseterre\n", 
"KN04->Saint George Gingerland\n", "KN05->Saint James Windward\n", "KN06->Saint John Capisterre\n", 
"KN07->Saint John Figtree\n", "KN08->Saint Mary Cayon\n", "KN09->Saint Paul Capisterre\n", "KN10->Saint Paul Charlestown\n", 
"KN11->Saint Peter Basseterre\n", "KN12->Saint Thomas Lowland\n", "KN13->Saint Thomas Middle Island\n", 
"KN15->Trinity Palmetto Point\n", "SH01->Ascension\n", "SH02->Saint Helena\n", "SH03->Tristan da Cunha\n", 
"LC01->Anse-la-Raye\n", "LC03->Castries\n", "LC04->Choiseul\n", "LC02->Dauphin\n", "LC05->Dennery\n", 
"LC06->Gros-Islet\n", "LC07->Laborie\n", "LC08->Micoud\n", "LC11->Praslin\n", "LC09->Soufriere\n", "LC10->Vieux-Fort\n", 
"VC01->Charlotte\n", "VC06->Grenadines\n", "VC02->Saint Andrew\n", "VC03->Saint David\n", "VC04->Saint George\n", 
"VC05->Saint Patrick\n", "SM01->Acquaviva\n", "SM06->Borgo Maggiore\n", "SM02->Chiesanuova\n", "SM03->Domagnano\n", 
"SM04->Faetano\n", "SM05->Fiorentino\n", "SM08->Monte Giardino\n", "SM07->San Marino\n", "SM09->Serravalle\n", 
"ST01->Principe\n", "ST02->Sao Tome\n", "SA02->Al Bahah\n", "SA15->Al Hudud ash Shamaliyah\n", "SA03->Al Jawf\n", 
"SA05->Al Madinah\n", "SA08->Al Qasim\n", "SA09->Al Qurayyat\n", "SA10->Ar Riyad\n", "SA06->Ash Sharqiyah\n", 
"SA13->Ha'il\n", "SA17->Jizan\n", "SA14->Makkah\n", "SA16->Najran\n", "SA19->Tabuk\n", "SN01->Dakar\n", 
"SN03->Diourbel\n", "SN09->Fatick\n", "SN10->Kaolack\n", "SN11->Kolda\n", "SN08->Louga\n", "SN04->Saint-Louis\n", 
"SN05->Tambacounda\n", "SN07->Thies\n", "SN12->Ziguinchor\n", "SC01->Anse aux Pins\n", "SC02->Anse Boileau\n", 
"SC03->Anse Etoile\n", "SC04->Anse Louis\n", "SC05->Anse Royale\n", "SC06->Baie Lazare\n", "SC07->Baie Sainte Anne\n", 
"SC08->Beau Vallon\n", "SC09->Bel Air\n", "SC10->Bel Ombre\n", "SC11->Cascade\n", "SC12->Glacis\n", 
"SC13->Grand' Anse\n", "SC14->Grand' Anse\n", "SC15->La Digue\n", "SC16->La Riviere Anglaise\n", "SC17->Mont Buxton\n", 
"SC18->Mont Fleuri\n", "SC19->Plaisance\n", "SC20->Pointe La Rue\n", "SC21->Port Glaud\n", "SC22->Saint Louis\n", 
"SC23->Takamaka\n", "SL01->Eastern\n", "SL02->Northern\n", "SL03->Southern\n", "SL04->Western Area\n", 
"SB05->Central\n", "SB06->Guadalcanal\n", "SB07->Isabel\n", "SB08->Makira\n", "SB03->Malaita\n", "SB09->Temotu\n", 
"SB04->Western\n", "SO01->Bakool\n", "SO02->Banaadir\n", "SO03->Bari\n", "SO04->Bay\n", "SO05->Galguduud\n", 
"SO06->Gedo\n", "SO07->Hiiraan\n", "SO08->Jubbada Dhexe\n", "SO09->Jubbada Hoose\n", "SO10->Mudug\n", 
"SO11->Nugaal\n", "SO12->Sanaag\n", "SO13->Shabeellaha Dhexe\n", "SO14->Shabeellaha Hoose\n", "SO15->Togdheer\n", 
"SO16->Woqooyi Galbeed\n", "ZA01->Cape Province\n", "ZA02->Natal\n", "ZA03->Orange Free State\n", "ZA04->Transvaal\n", 
"ES51->Andalucia\n", "ES52->Aragon\n", "ES34->Asturias\n", "ES53->Canarias\n", "ES39->Cantabria\n", 
"ES54->Castilla-La Mancha\n", "ES55->Castilla y Leon\n", "ES56->Cataluna\n", "ES57->Extremadura\n", 
"ES58->Galicia\n", "ES07->Islas Baleares\n", "ES27->La Rioja\n", "ES29->Madrid\n", "ES31->Murcia\n", 
"ES32->Navarra\n", "ES59->Pais Vasco\n", "ES60->Valenciana\n", "LK01->Amparai\n", "LK02->Anuradhapura\n", 
"LK03->Badulla\n", "LK04->Batticaloa\n", "LK23->Colombo\n", "LK06->Galle\n", "LK24->Gampaha\n", "LK07->Hambantota\n", 
"LK25->Jaffna\n", "LK09->Kalutara\n", "LK10->Kandy\n", "LK11->Kegalla\n", "LK12->Kurunegala\n", "LK26->Mannar\n", 
"LK14->Matale\n", "LK15->Matara\n", "LK16->Moneragala\n", "LK27->Mullaittivu\n", "LK17->Nuwara Eliya\n", 
"LK18->Polonnaruwa\n", "LK19->Puttalam\n", "LK20->Ratnapura\n", "LK21->Trincomalee\n", "LK28->Vavuniya\n", 
"SD28->Al Istiwa'iyah\n", "SD29->Al Khartum\n", "SD27->Al Wusta\n", "SD30->Ash Shamaliyah\n", "SD31->Ash Sharqiyah\n", 
"SD32->Bahr al Ghazal\n", "SD33->Darfur\n", "SD34->Kurdufan\n", "SR10->Brokopondo\n", "SR11->Commewijne\n", 
"SR12->Coronie\n", "SR13->Marowijne\n", "SR14->Nickerie\n", "SR15->Para\n", "SR16->Paramaribo\n", "SR17->Saramacca\n", 
"SR18->Sipaliwini\n", "SR19->Wanica\n", "SZ01->Hhohho\n", "SZ02->Lubombo\n", "SZ03->Manzini\n", "SZ05->Praslin\n", 
"SZ04->Shiselweni\n", "SE01->Alvsborgs Lan\n", "SE02->Blekinge Lan\n", "SE03->Gavleborgs Lan\n", "SE04->Goteborgs och Bohus Lan\n", 
"SE05->Gotlands Lan\n", "SE06->Hallands Lan\n", "SE07->Jamtlands Lan\n", "SE08->Jonkopings Lan\n", "SE09->Kalmar Lan\n", 
"SE10->Kopparbergs Lan\n", "SE11->Kristianstads Lan\n", "SE12->Kronobergs Lan\n", "SE13->Malmohus Lan\n", 
"SE14->Norrbottens Lan\n", "SE15->Orebro Lan\n", "SE16->Ostergotlands Lan\n", "SE17->Skaraborgs Lan\n", 
"SE18->Sodermanlands Lan\n", "SE26->Stockholms Lan\n", "SE21->Uppsala Lan\n", "SE22->Varmlands Lan\n", 
"SE23->Vasterbottens Lan\n", "SE24->Vasternorrlands Lan\n", "SE25->Vastmanlands Lan\n", "SE27->Skane Lan\n", 
"SE28->Vastra Gotaland\n", "CH01->Aargau\n", "CH02->Ausser-Rhoden\n", "CH03->Basel-Landschaft\n", "CH04->Basel-Stadt\n", 
"CH05->Bern\n", "CH06->Fribourg\n", "CH07->Geneve\n", "CH08->Glarus\n", "CH09->Graubunden\n", "CH10->Inner-Rhoden\n", 
"CH26->Jura\n", "CH11->Luzern\n", "CH12->Neuchatel\n", "CH13->Nidwalden\n", "CH14->Obwalden\n", "CH15->Sankt Gallen\n", 
"CH16->Schaffhausen\n", "CH17->Schwyz\n", "CH18->Solothurn\n", "CH19->Thurgau\n", "CH20->Ticino\n", 
"CH21->Uri\n", "CH22->Valais\n", "CH23->Vaud\n", "CH24->Zug\n", "CH25->Zurich\n", "SY01->Al Hasakah\n", 
"SY02->Al Ladhiqiyah\n", "SY03->Al Qunaytirah\n", "SY04->Ar Raqqah\n", "SY05->As Suwayda'\n", "SY06->Dar\n", 
"SY07->Dayr az Zawr\n", "SY13->Dimashq\n", "SY09->Halab\n", "SY10->Hamah\n", "SY11->Hims\n", "SY12->Idlib\n", 
"SY08->Rif Dimashq\n", "SY14->Tartus\n", "TZ01->Arusha\n", "TZ23->Dar es Salaam\n", "TZ03->Dodoma\n", 
"TZ04->Iringa\n", "TZ05->Kigoma\n", "TZ06->Kilimanjaro\n", "TZ07->Lindi\n", "TZ08->Mara\n", "TZ09->Mbeya\n", 
"TZ10->Morogoro\n", "TZ11->Mtwara\n", "TZ12->Mwanza\n", "TZ13->Pemba North\n", "TZ20->Pemba South\n", 
"TZ02->Pwani\n", "TZ24->Rukwa\n", "TZ14->Ruvuma\n", "TZ15->Shinyanga\n", "TZ16->Singida\n", "TZ17->Tabora\n", 
"TZ18->Tanga\n", "TZ21->Zanzibar Central\n", "TZ22->Zanzibar North\n", "TZ25->Zanzibar Urban\n", "TZ19->Kagera\n", 
"TH35->Ang Thong\n", "TH28->Buriram\n", "TH44->Chachoengsao\n", "TH32->Chai Nat\n", "TH26->Chaiyaphum\n", 
"TH48->Chanthaburi\n", "TH02->Chiang Mai\n", "TH03->Chiang Rai\n", "TH46->Chon Buri\n", "TH58->Chumphon\n", 
"TH23->Kalasin\n", "TH11->Kamphaeng Phet\n", "TH50->Kanchanaburi\n", "TH22->Khon Kaen\n", "TH63->Krabi\n", 
"TH40->Krung Thep\n", "TH06->Lampang\n", "TH05->Lamphun\n", "TH18->Loei\n", "TH34->Lop Buri\n", "TH01->Mae Hong Son\n", 
"TH24->Maha Sarakham\n", "TH43->Nakhon Nayok\n", "TH53->Nakhon Pathom\n", "TH21->Nakhon Phanom\n", "TH27->Nakhon Ratchasima\n", 
"TH16->Nakhon Sawan\n", "TH64->Nakhon Si Thammarat\n", "TH04->Nan\n", "TH31->Narathiwat\n", "TH17->Nong Khai\n", 
"TH38->Nonthaburi\n", "TH39->Pathum Thani\n", "TH69->Pattani\n", "TH61->Phangnga\n", "TH66->Phatthalung\n", 
"TH41->Phayao\n", "TH14->Phetchabun\n", "TH56->Phetchaburi\n", "TH13->Phichit\n", "TH12->Phitsanulok\n", 
"TH36->Phra Nakhon Si Ayutthaya\n", "TH07->Phrae\n", "TH62->Phuket\n", "TH45->Prachin Buri\n", "TH57->Prachuap Khiri Khan\n", 
"TH59->Ranong\n", "TH52->Ratchaburi\n", "TH47->Rayong\n", "TH25->Roi Et\n", "TH20->Sakon Nakhon\n", 
"TH42->Samut Prakan\n", "TH55->Samut Sakhon\n", "TH54->Samut Songkhram\n", "TH37->Saraburi\n", "TH67->Satun\n", 
"TH33->Sing Buri\n", "TH30->Sisaket\n", "TH68->Songkhla\n", "TH09->Sukhothai\n", "TH51->Suphan Buri\n", 
"TH60->Surat Thani\n", "TH29->Surin\n", "TH08->Tak\n", "TH65->Trang\n", "TH49->Trat\n", "TH71->Ubon Ratchathani\n", 
"TH19->Udon Thani\n", "TH15->Uthai Thani\n", "TH10->Uttaradit\n", "TH70->Yala\n", "TH72->Yasothon\n", 
"TG01->Amlame\n", "TG02->Aneho\n", "TG03->Atakpame\n", "TG15->Badou\n", "TG04->Bafilo\n", "TG05->Bassar\n", 
"TG06->Dapaong\n", "TG07->Kante\n", "TG08->Klouto\n", "TG14->Kpagouda\n", "TG09->Lama-Kara\n", "TG10->Lome\n", 
"TG11->Mango\n", "TG12->Niamtougou\n", "TG13->Notse\n", "TG16->Sotouboua\n", "TG17->Tabligbo\n", "TG19->Tchamba\n", 
"TG20->Tchaoudjo\n", "TG18->Tsevie\n", "TG21->Vogan\n", "TO01->Ha\n", "TO02->Tongatapu\n", "TO03->Vava\n", 
"TT01->Arima\n", "TT02->Caroni\n", "TT03->Mayaro\n", "TT04->Nariva\n", "TT05->Port-of-Spain\n", "TT06->Saint Andrew\n", 
"TT07->Saint David\n", "TT08->Saint George\n", "TT09->Saint Patrick\n", "TT10->San Fernando\n", "TT11->Tobago\n", 
"TT12->Victoria\n", "TN14->Al Kaf\n", "TN15->Al Mahdiyah\n", "TN16->Al Munastir\n", "TN02->Al Qasrayn\n", 
"TN03->Al Qayrawan\n", "TN26->Aryanah\n", "TN17->Bajah\n", "TN18->Banzart\n", "TN27->Bin\n", "TN06->Jundubah\n", 
"TN28->Madanin\n", "TN19->Nabul\n", "TN29->Qabis\n", "TN10->Qafsah\n", "TN31->Qibili\n", "TN32->Safaqis\n", 
"TN33->Sidi Bu Zayd\n", "TN22->Silyanah\n", "TN23->Susah\n", "TN34->Tatawin\n", "TN35->Tawzar\n", "TN36->Tunis\n", 
"TN37->Zaghwan\n", "TR81->Adana\n", "TR02->Adiyaman\n", "TR03->Afyon\n", "TR04->Agri\n", "TR75->Aksaray\n", 
"TR05->Amasya\n", "TR68->Ankara\n", "TR07->Antalya\n", "TR08->Artvin\n", "TR09->Aydin\n", "TR10->Balikesir\n", 
"TR76->Batman\n", "TR77->Bayburt\n", "TR11->Bilecik\n", "TR12->Bingol\n", "TR13->Bitlis\n", "TR14->Bolu\n", 
"TR15->Burdur\n", "TR16->Bursa\n", "TR17->Canakkale\n", "TR82->Cankiri\n", "TR19->Corum\n", "TR20->Denizli\n", 
"TR21->Diyarbakir\n", "TR22->Edirne\n", "TR23->Elazig\n", "TR24->Erzincan\n", "TR25->Erzurum\n", "TR26->Eskisehir\n", 
"TR83->Gaziantep\n", "TR28->Giresun\n", "TR69->Gumushane\n", "TR70->Hakkari\n", "TR31->Hatay\n", "TR32->Icel\n", 
"TR33->Isparta\n", "TR34->Istanbul\n", "TR35->Izmir\n", "TR46->Kahramanmaras\n", "TR78->Karaman\n", 
"TR84->Kars\n", "TR37->Kastamonu\n", "TR38->Kayseri\n", "TR79->Kirikkale\n", "TR39->Kirklareli\n", "TR40->Kirsehir\n", 
"TR41->Kocaeli\n", "TR71->Konya\n", "TR43->Kutahya\n", "TR44->Malatya\n", "TR45->Manisa\n", "TR72->Mardin\n", 
"TR48->Mugla\n", "TR49->Mus\n", "TR50->Nevsehir\n", "TR73->Nigde\n", "TR52->Ordu\n", "TR53->Rize\n", 
"TR54->Sakarya\n", "TR55->Samsun\n", "TR74->Siirt\n", "TR57->Sinop\n", "TR80->Sirnak\n", "TR58->Sivas\n", 
"TR59->Tekirdag\n", "TR60->Tokat\n", "TR61->Trabzon\n", "TR62->Tunceli\n", "TR63->Sanliurfa\n", "TR64->Usak\n", 
"TR65->Van\n", "TR66->Yozgat\n", "TR85->Zonguldak\n", "UG05->Busoga\n", "UG18->Central\n", "UG20->Eastern\n", 
"UG08->Karamoja\n", "UG21->Nile\n", "UG22->North Buganda\n", "UG23->Northern\n", "UG12->South Buganda\n", 
"UG24->Southern\n", "UG25->Western\n", "UA01->Cherkas'ka Oblast'\n", "UA02->Chernihivs'ka Oblast'\n", 
"UA03->Chernivets'ka Oblast'\n", "UA04->Dnipropetrovs'ka Oblast'\n", "UA05->Donets'ka Oblast'\n", "UA06->Ivano-Frankivs'ka Oblast'\n", 
"UA07->Kharkivs'ka Oblast'\n", "UA08->Khersons'ka Oblast'\n", "UA09->Khmel'nyts'ka Oblast'\n", "UA10->Kirovohrads'ka Oblast'\n", 
"UA11->Krym\n", "UA12->Kyyiv\n", "UA13->Kyyivs'ka Oblast'\n", "UA14->Luhans'ka Oblast'\n", "UA15->L'vivs'ka Oblast'\n", 
"UA16->Mykolayivs'ka Oblast'\n", "UA17->Odes'ka Oblast'\n", "UA18->Poltavs'ka Oblast'\n", "UA19->Rivnens'ka Oblast'\n", 
"UA20->Sevastopol'\n", "UA21->Sums'ka Oblast'\n", "UA22->Ternopil's'ka Oblast'\n", "UA23->Vinnyts'ka Oblast'\n", 
"UA24->Volyns'ka Oblast'\n", "UA25->Zakarpats'ka Oblast'\n", "UA26->Zaporiz'ka Oblast'\n", "UA27->Zhytomyrs'ka Oblast'\n", 
"AE01->Abu Zaby\n", "AE04->Al Fujayrah\n", "AE06->Ash Shariqah\n", "AE03->Dubayy\n", "AE05->Ra's al Khaymah\n", 
"AE07->Umm al Qaywayn\n", "GB01->Avon\n", "GBA5->Bedfordshire\n", "GB03->Berkshire\n", "GBB9->Buckinghamshire\n", 
"GBC3->Cambridgeshire\n", "GBC5->Cheshire\n", "GB07->Cleveland\n", "GB08->Cornwall\n", "GB09->Cumbria\n", 
"GBD3->Derbyshire\n", "GBD4->Devon\n", "GBD6->Dorset\n", "GBD8->Durham\n", "GBE2->East Sussex\n", "GBE4->Essex\n", 
"GBE6->Gloucestershire\n", "GB17->Greater London\n", "GB18->Greater Manchester\n", "GBF2->Hampshire\n", 
"GB20->Hereford and Worcester\n", "GBF8->Hertford\n", "GB22->Humberside\n", "GBG2->Isle of Wight\n", 
"GBG5->Kent\n", "GBH2->Lancashire\n", "GBH5->Leicestershire\n", "GBH7->Lincolnshire\n", "GB28->Merseyside\n", 
"GBI9->Norfolk\n", "GBJ1->Northamptonshire\n", "GBJ6->Northumberland\n", "GBJ7->North Yorkshire\n", 
"GBJ9->Nottinghamshire\n", "GBK2->Oxfordshire\n", "GBL6->Shropshire\n", "GBM3->Somerset\n", "GB37->South Yorkshire\n", 
"GBM9->Staffordshire\n", "GBN5->Suffolk\n", "GBN7->Surrey\n", "GB41->Tyne and Wear\n", "GBP3->Warwickshire\n", 
"GB43->West Midlands\n", "GBP6->West Sussex\n", "GB45->West Yorkshire\n", "GBP8->Wiltshire\n", "GBQ6->Antrim\n", 
"GBQ7->Ards\n", "GBQ8->Armagh\n", "GBQ9->Ballymena\n", "GBR1->Ballymoney\n", "GBR2->Banbridge\n", "GBR3->Belfast\n", 
"GBR4->Carrickfergus\n", "GBR5->Castlereagh\n", "GBR6->Coleraine\n", "GBR7->Cookstown\n", "GBR8->Craigavon\n", 
"GBR9->Down\n", "GBS1->Dungannon\n", "GBS2->Fermanagh\n", "GBS3->Larne\n", "GBS4->Limavady\n", "GBS5->Lisburn\n", 
"GBS6->Derry\n", "GBS7->Magherafelt\n", "GBS8->Moyle\n", "GBS9->Newry and Mourne\n", "GBT1->Newtownabbey\n", 
"GBT2->North Down\n", "GBT3->Omagh\n", "GBT4->Strabane\n", "GBT9->Scottish Borders, The\n", "GB79->Central\n", 
"GBU2->Dumfries and Galloway\n", "GBV1->Fife\n", "GB82->Grampian\n", "GBV3->Highland\n", "GB84->Lothian\n", 
"GBV9->Orkney\n", "GBW3->Shetland Islands\n", "GB87->Strathclyde\n", "GB88->Tayside\n", "GBW8->Eilean Siar\n", 
"GB90->Clwyd\n", "GB91->Dyfed\n", "GB92->Gwent\n", "GBY2->Gwynedd\n", "GB94->Mid Glamorgan\n", "GBY8->Powys\n", 
"GB96->South Glamorgan\n", "GB97->West Glamorgan\n", "US01->Alabama\n", "US02->Alaska\n", "US04->Arizona\n", 
"US05->Arkansas\n", "US06->California\n", "US08->Colorado\n", "US09->Connecticut\n", "US10->Delaware\n", 
"US11->District of Columbia\n", "US12->Florida\n", "US13->Georgia\n", "US15->Hawaii\n", "US16->Idaho\n", 
"US17->Illinois\n", "US18->Indiana\n", "US19->Iowa\n", "US20->Kansas\n", "US21->Kentucky\n", "US22->Louisiana\n", 
"US23->Maine\n", "US24->Maryland\n", "US25->Massachusetts\n", "US26->Michigan\n", "US27->Minnesota\n", 
"US28->Mississippi\n", "US29->Missouri\n", "US30->Montana\n", "US31->Nebraska\n", "US32->Nevada\n", 
"US33->New Hampshire\n", "US34->New Jersey\n", "US35->New Mexico\n", "US36->New York\n", "US37->North Carolina\n", 
"US38->North Dakota\n", "US39->Ohio\n", "US40->Oklahoma\n", "US41->Oregon\n", "US42->Pennyslvania\n", 
"US44->Rhode Island\n", "US45->South Carolina\n", "US46->South Dakota\n", "US47->Tennessee\n", "US48->Texas\n", 
"US49->Utah\n", "US50->Vermont\n", "US51->Virginia\n", "US53->Washington\n", "US54->West Virginia\n", 
"US55->Wisconsin\n", "US56->Wyoming\n", "UY01->Artigas\n", "UY02->Canelones\n", "UY03->Cerro Largo\n", 
"UY04->Colonia\n", "UY05->Durazno\n", "UY06->Flores\n", "UY07->Florida\n", "UY08->Lavalleja\n", "UY09->Maldonado\n", 
"UY10->Montevideo\n", "UY11->Paysandu\n", "UY12->Rio Negro\n", "UY13->Rivera\n", "UY14->Rocha\n", "UY15->Salto\n", 
"UY16->San Jose\n", "UY17->Soriano\n", "UY18->Tacuarembo\n", "UY19->Treinta y Tres\n", "VU05->Ambrym\n", 
"VU06->Aoba\n", "VU07->Banks\n", "VU08->Efate\n", "VU09->Epi\n", "VU10->Malakula\n", "VU11->Paama\n", 
"VU12->Pentecote\n", "VU13->Santo\n", "VU14->Shepherd\n", "VU15->Tafea\n", "VE01->Amazonas\n", "VE02->Anzoategui\n", 
"VE03->Apure\n", "VE04->Aragua\n", "VE05->Barinas\n", "VE06->Bolivar\n", "VE07->Carabobo\n", "VE08->Cojedes\n", 
"VE09->Delta Amacuro\n", "VE24->Dependencias Federales\n", "VE25->Distrito Federal\n", "VE11->Falcon\n", 
"VE12->Guarico\n", "VE13->Lara\n", "VE14->Merida\n", "VE15->Miranda\n", "VE16->Monagas\n", "VE17->Nueva Esparta\n", 
"VE18->Portuguesa\n", "VE19->Sucre\n", "VE20->Tachira\n", "VE21->Trujillo\n", "VE22->Yaracuy\n", "VE23->Zulia\n", 
"VN43->An Giang\n", "VN53->Ba Ria-Vung Tau\n", "VN02->Bac Thai\n", "VN03->Ben Tre\n", "VN54->Binh Dinh\n", 
"VN55->Binh Thuan\n", "VN56->Can Tho\n", "VN05->Cao Bang\n", "VN44->Dac Lac\n", "VN45->Dong Nai\n", 
"VN46->Dong Thap\n", "VN57->Gia Lai\n", "VN11->Ha Bac\n", "VN58->Ha Giang\n", "VN51->Ha Noi\n", "VN59->Ha Tay\n", 
"VN60->Ha Tinh\n", "VN12->Hai Hung\n", "VN13->Hai Phong\n", "VN52->Ho Chi Minh\n", "VN61->Hoa Binh\n", 
"VN62->Khanh Hoa\n", "VN47->Kien Giang\n", "VN63->Kon Tum\n", "VN22->Lai Chau\n", "VN23->Lam Dong\n", 
"VN39->Lang Son\n", "VN64->Lao Cai\n", "VN24->Mint An\n", "VN48->Minh Hai\n", "VN65->Nam Ha\n", "VN66->Nghe An\n", 
"VN67->Ninh Binh\n", "VN68->Ninh Thuan\n", "VN69->Phu Yen\n", "VN70->Quang Binh\n", "VN29->Quang Nam-Da Nang\n", 
"VN71->Quang Ngai\n", "VN30->Quang Ninh\n", "VN72->Quang Tri\n", "VN73->Soc Trang\n", "VN49->Song Be\n", 
"VN32->Son La\n", "VN33->Tay Ninh\n", "VN35->Thai Binh\n", "VN34->Thanh Hoa\n", "VN74->Thua Thien\n", 
"VN37->Tien Giang\n", "VN75->Tra Vinh\n", "VN76->Tuyen Quang\n", "VN77->Vinh Mint\n", "VN50->Vinh Phu\n", 
"VN78->Yen Bai\n", "WS02->Aiga-i-le-Tai\n", "WS03->Atua\n", "WS04->Fa\n", "WS05->Gaga\n", "WS07->Gagaifomauga\n", 
"WS08->Palauli\n", "WS09->Satupa\n", "WS10->Tuamasaga\n", "WS06->Va\n", "WS11->Vaisigano\n", "YE01->Abyan\n", 
"YE07->Al Bayda'\n", "YE08->Al Hudaydah\n", "YE09->Al Jawf\n", "YE03->Al Mahrah\n", "YE10->Al Mahwit\n", 
"YE11->Dhamar\n", "YE04->Hadramawt\n", "YE12->Hajjah\n", "YE13->Ibb\n", "YE06->Lahij\n", "YE14->Ma'rib\n", 
"YE05->Shabwah\n", "YE15->Sa\n", "YE16->San\n", "YE17->Ta\n", "ZR01->Bandundu\n", "ZR08->Bas-Zaire\n", 
"ZR02->Equateur\n", "ZR09->Haut-Zaire\n", "ZR03->Kasai-Occidental\n", "ZR04->Kasai-Oriental\n", "ZR06->Kinshasa\n", 
"ZR07->Kivu\n", "ZR05->Shaba\n", "ZM02->Central\n", "ZM08->Copperbelt\n", "ZM03->Eastern\n", "ZM04->Luapula\n", 
"ZM09->Lusaka\n", "ZM05->Northern\n", "ZM06->North-Western\n", "ZM07->Southern\n", "ZM01->Western\n", 
"ZW01->Manicaland\n", "ZW03->Mashonaland Central\n", "ZW04->Mashonaland East\n", "ZW05->Mashonaland West\n", 
"ZW06->Matabeleland North\n", "ZW07->Matabeleland South\n", "ZW02->Midlands\n", "ZW08->Masvingo\n", 
"TW01->Fu-chien\n", "TW02->Kao-hsiung\n", "TW03->T'ai-pei\n", "TW04->T'ai-wan\n", "AM01->Aragatsotn\n", 
"AM02->Ararat\n", "AM03->Armavir\n", "AM04->Geghark'unik'\n", "AM05->Kotayk'\n", "AM06->Lorri\n", "AM07->Shirak\n", 
"AM08->Syunik'\n", "AM09->Tavush\n", "AM10->Vayots' Dzor\n", "AM11->Yerevan\n", "AL29->Bulqize\n", "AL30->Delvine\n", 
"AL31->Devoll\n", "AL32->Has\n", "AL33->Kavaje\n", "AL34->Kucove\n", "AL35->Kurbin\n", "AL36->Malesi e Madhe\n", 
"AL37->Mallakaster\n", "AL38->Peqin\n", "AL39->Tirane\n", "HR01->Bjelovarsko-Bilogorska\n", "HR02->Brodsko-Posavska\n", 
"HR03->Dubrovacko-Neretvanska\n", "HR04->Istarska\n", "HR05->Karlovacka\n", "HR06->Koprivnicko-Krizevacka\n", 
"HR07->Krapinsko-Zagorska\n", "HR08->Licko-Senjska\n", "HR09->Medimurska\n", "HR10->Osjecko-Baranjska\n", 
"HR11->Pozesko-Slavonska\n", "HR12->Primorsko-Goranska\n", "HR13->Sibensko-Kninska\n", "HR14->Sisacko-Moslavacka\n", 
"HR15->Splitsko-Dalmatinska\n", "HR16->Varazdinska\n", "HR17->Viroviticko-Podravska\n", "HR18->Vukovarsko-Srijemska\n", 
"HR19->Zadarska\n", "HR20->Zagrebacka\n", "HR21->Grad Zagreb\n", "MD46->Balti\n", "MD47->Cahul\n", "MD48->Chisinau\n", 
"MD49->Stinga Nistrului\n", "MD50->Edinet\n", "MD51->Gagauzia\n", "MD52->Lapusna\n", "MD53->Orhei\n", 
"MD54->Soroca\n", "MD55->Tighina\n", "MD56->Ungheni\n", "NG52->Bayelsa\n", "NG53->Ebonyi\n", "NG54->Ekiti\n", 
"NG55->Gombe\n", "NG56->Nassarawa\n", "NG57->Zamfara\n", "BG38->Blagoevgrad\n", "BG40->Dobrich\n", "BG41->Gabrovo\n", 
"BG44->Kurdzhali\n", "BG45->Kyustendil\n", "BG48->Pazardzhik\n", "BG49->Pernik\n", "BG50->Pleven\n", 
"BG53->Ruse\n", "BG54->Shumen\n", "BG55->Silistra\n", "BG56->Sliven\n", "BG57->Smolyan\n", "BG59->Stara Zagora\n", 
"BG60->Turgovishte\n", "BG62->Veliko Turnovo\n", "BG63->Vidin\n", "BG64->Vratsa\n", "BG65->Yambol\n", 
"TR86->Ardahan\n", "TR87->Bartin\n", "TR88->Igdir\n", "TR89->Karabuk\n", "TR90->Kilis\n", "TR91->Osmaniye\n", 
"TR92->Yalova\n", "IR37->Golestan\n", "IR38->Qazvin\n", "IR39->Qom\n", "AD08->Escaldes-Engordany\n", 
"VE26->Vargas\n", "ID29->Maluku Utara\n", "EC24->Orellana\n", "CZ78->Jihomoravsky Kraj\n", "CZ79->Jihocesky Kraj\n", 
"CZ52->Hlavni Mesto Praha\n", "CZ80->Vysocina\n", "CZ81->Karlovarsky Kraj\n", "CZ82->Kralovehradecky Kraj\n", 
"CZ83->Liberecky Kraj\n", "CZ84->Olomoucky Kraj\n", "CZ85->Moravskoslezsky Kraj\n", "CZ86->Pardubicky Kraj\n", 
"CZ87->Plzensky Kraj\n", "CZ88->Stredocesky Kraj\n", "CZ89->Ustecky Kraj\n", "CZ90->Zlinsky Kraj\n", 
"KH30->Pailin\n", "BE10->Brabant Wallon\n", "BE11->Brussels Hoofdstedelijk Gewest\n", "BE12->Vlaams-Brabant\n", 
"BI23->Mwaro\n", "CI63->Adiake\n", "CI64->Alepe\n", "CI65->Bocanda\n", "CI66->Dabou\n", "CI68->Grand-Bassam\n", 
"CI70->Jacqueville\n", "CI71->Tiebissou\n", "CI72->Toulepleu\n", "ET44->Adis Abeba\n", "ET45->Afar\n", 
"ET46->Amara\n", "ET47->Binshangul Gumuz\n", "ET48->Dire Dawa\n", "ET49->Gambela Hizboch\n", "ET50->Hareri Hizb\n", 
"ET51->Oromiya\n", "ET52->Sumale\n", "ET53->Tigray\n", "ET54->YeDebub Biheroch Bihereseboch na Hizboch\n", 
"GN30->Coyah\n", "GN33->Koubia\n", "GN35->Lelouma\n", "GN36->Lola\n", "GN37->Mandiana\n", "IN37->Chhattisgarh\n", 
"IN38->Jharkhand\n", "IN39->Uttaranchal\n", "ID33->Banten\n", "ID34->Gorontalo\n", "ID35->Kepulauan Bangka Belitung\n", 
"KR21->Ulsan-gwangyoksi\n", "KG09->Batken\n", "LB07->Nabatiye\n", "LT56->Alytaus Apskritis\n", "LT57->Kauno Apskritis\n", 
"LT58->Klaipedos Apskritis\n", "LT59->Marijampoles Apskritis\n", "LT60->Panevezio Apskritis\n", "LT61->Siauliu Apskritis\n", 
"LT62->Taurages Apskritis\n", "LT63->Telsiu Apskritis\n", "LT64->Utenos Apskritis\n", "LT65->Vilniaus Apskritis\n", 
"MK01->Aracinovo\n", "MK02->Bac\n", "MK03->Belcista\n", "MK04->Berovo\n", "MK05->Bistrica\n", "MK06->Bitola\n", 
"MK07->Blatec\n", "MK08->Bogdanci\n", "MK09->Bogomila\n", "MK10->Bogovinje\n", "MK11->Bosilovo\n", "MK12->Brvenica\n", 
"MK13->Cair\n", "MK14->Capari\n", "MK15->Caska\n", "MK16->Cegrane\n", "MK17->Centar\n", "MK18->Centar Zupa\n", 
"MK19->Cesinovo\n", "MK20->Cucer-Sandevo\n", "MK21->Debar\n", "MK22->Delcevo\n", "MK23->Delogozdi\n", 
"MK24->Demir Hisar\n", "MK25->Demir Kapija\n", "MK26->Dobrusevo\n", "MK27->Dolna Banjica\n", "MK28->Dolneni\n", 
"MK29->Dorce Petrov\n", "MK30->Drugovo\n", "MK31->Dzepciste\n", "MK32->Gazi Baba\n", "MK33->Gevgelija\n", 
"MK34->Gostivar\n", "MK35->Gradsko\n", "MK36->Ilinden\n", "MK37->Izvor\n", "MK38->Jegunovce\n", "MK39->Kamenjane\n", 
"MK40->Karbinci\n", "MK41->Karpos\n", "MK42->Kavadarci\n", "MK43->Kicevo\n", "MK44->Kisela Voda\n", 
"MK45->Klecevce\n", "MK46->Kocani\n", "MK47->Konce\n", "MK48->Kondovo\n", "MK49->Konopiste\n", "MK50->Kosel\n", 
"MK51->Kratovo\n", "MK52->Kriva Palanka\n", "MK53->Krivogastani\n", "MK54->Krusevo\n", "MK55->Kuklis\n", 
"MK56->Kukurecani\n", "MK57->Kumanovo\n", "MK58->Labunista\n", "MK59->Lipkovo\n", "MK60->Lozovo\n", 
"MK61->Lukovo\n", "MK62->Makedonska Kamenica\n", "MK63->Makedonski Brod\n", "MK64->Mavrovi Anovi\n", 
"MK65->Meseista\n", "MK66->Miravci\n", "MK67->Mogila\n", "MK68->Murtino\n", "MK69->Negotino\n", "MK70->Negotino-Polosko\n", 
"MK71->Novaci\n", "MK72->Novo Selo\n", "MK73->Oblesevo\n", "MK74->Ohrid\n", "MK75->Orasac\n", "MK76->Orizari\n", 
"MK77->Oslomej\n", "MK78->Pehcevo\n", "MK79->Petrovec\n", "MK80->Plasnica\n", "MK81->Podares\n", "MK82->Prilep\n", 
"MK83->Probistip\n", "MK84->Radovis\n", "MK85->Rankovce\n", "MK86->Resen\n", "MK87->Rosoman\n", "MK88->Rostusa\n", 
"MK89->Samokov\n", "MK90->Saraj\n", "MK91->Sipkovica\n", "MK92->Sopiste\n", "MK93->Sopotnica\n", "MK94->Srbinovo\n", 
"MK95->Staravina\n", "MK96->Star Dojran\n", "MK97->Staro Nagoricane\n", "MK98->Stip\n", "MK99->Struga\n", 
"MKA1->Strumica\n", "MKA2->Studenicani\n", "MKA3->Suto Orizari\n", "MKA4->Sveti Nikole\n", "MKA5->Tearce\n", 
"MKA6->Tetovo\n", "MKA7->Topolcani\n", "MKA8->Valandovo\n", "MKA9->Vasilevo\n", "MKB1->Veles\n", "MKB2->Velesta\n", 
"MKB3->Vevcani\n", "MKB4->Vinica\n", "MKB5->Vitoliste\n", "MKB6->Vranestica\n", "MKB7->Vrapciste\n", 
"MKB8->Vratnica\n", "MKB9->Vrutok\n", "MKC1->Zajas\n", "MKC2->Zelenikovo\n", "MKC3->Zelino\n", "MKC4->Zitose\n", 
"MKC5->Zletovo\n", "MKC6->Zrnovci\n", "UG65->Adjumani\n", "UG66->Bugiri\n", "UG67->Busia\n", "UG69->Katakwi\n", 
"UG73->Nakasongola\n", "UG74->Sembabule\n", "GBA1->Barking and Dagenham\n", "GBA2->Barnet\n", "GBA3->Barnsley\n", 
"GBA4->Bath and North East Somerset\n", "GBA6->Bexley\n", "GBA7->Birmingham\n", "GBA8->Blackburn with Darwen\n", 
"GBA9->Blackpool\n", "GBB1->Bolton\n", "GBB2->Bournemouth\n", "GBB3->Bracknell Forest\n", "GBB4->Bradford\n", 
"GBB5->Brent\n", "GBB6->Brighton and Hove\n", "GBB7->Bristol, City of\n", "GBB8->Bromley\n", "GBC1->Bury\n", 
"GBC2->Calderdale\n", "GBC4->Camden\n", "GBC7->Coventry\n", "GBC8->Croydon\n", "GBD1->Darlington\n", 
"GBD2->Derby\n", "GBD5->Doncaster\n", "GBD7->Dudley\n", "GBD9->Ealing\n", "GBE1->East Riding of Yorkshire\n", 
"GBE3->Enfield\n", "GBE5->Gateshead\n", "GBE7->Greenwich\n", "GBE8->Hackney\n", "GBE9->Halton\n", "GBF1->Hammersmith and Fulham\n", 
"GBF3->Haringey\n", "GBF4->Harrow\n", "GBF5->Hartlepool\n", "GBF6->Havering\n", "GBF7->Herefordshire\n", 
"GBF9->Hillingdon\n", "GBG1->Hounslow\n", "GBG3->Islington\n", "GBG4->Kensington and Chelsea\n", "GBG6->Kingston upon Hull, City of\n", 
"GBG7->Kingston upon Thames\n", "GBG8->Kirklees\n", "GBG9->Knowsley\n", "GBH1->Lambeth\n", "GBH3->Leeds\n", 
"GBH4->Leicester\n", "GBH6->Lewisham\n", "GBH8->Liverpool\n", "GBH9->London, City of\n", "GBI1->Luton\n", 
"GBI2->Manchester\n", "GBI3->Medway\n", "GBI4->Merton\n", "GBI5->Middlesbrough\n", "GBI6->Milton Keynes\n", 
"GBI7->Newcastle upon Tyne\n", "GBI8->Newham\n", "GBJ2->North East Lincolnshire\n", "GBJ3->North Lincolnshire\n", 
"GBJ4->North Somerset\n", "GBJ5->North Tyneside\n", "GBJ8->Nottingham\n", "GBK1->Oldham\n", "GBK3->Peterborough\n", 
"GBK4->Plymouth\n", "GBK5->Poole\n", "GBK6->Portsmouth\n", "GBK7->Reading\n", "GBK8->Redbridge\n", "GBK9->Redcar and Cleveland\n", 
"GBL1->Richmond upon Thames\n", "GBL2->Rochdale\n", "GBL3->Rotherham\n", "GBL4->Rutland\n", "GBL5->Salford\n", 
"GBL7->Sandwell\n", "GBL8->Sefton\n", "GBL9->Sheffield\n", "GBM1->Slough\n", "GBM2->Solihull\n", "GBM4->Southampton\n", 
"GBM5->Southend-on-Sea\n", "GBM6->South Gloucestershire\n", "GBM7->South Tyneside\n", "GBM8->Southwark\n", 
"GBN1->St. Helens\n", "GBN2->Stockport\n", "GBN3->Stockton-on-Tees\n", "GBN4->Stoke-on-Trent\n", "GBN6->Sunderland\n", 
"GBN8->Sutton\n", "GBN9->Swindon\n", "GBO1->Tameside\n", "GBO2->Telford and Wrekin\n", "GBO3->Thurrock\n", 
"GBO4->Torbay\n", "GBO5->Tower Hamlets\n", "GBO6->Trafford\n", "GBO7->Wakefield\n", "GBO8->Walsall\n", 
"GBO9->Waltham Forest\n", "GBP1->Wandsworth\n", "GBP2->Warrington\n", "GBP4->West Berkshire\n", "GBP5->Westminster\n", 
"GBP7->Wigan\n", "GBP9->Windsor and Maidenhead\n", "GBQ1->Wirral\n", "GBQ2->Wokingham\n", "GBQ3->Wolverhampton\n", 
"GBQ4->Worcestershire\n", "GBQ5->York\n", "GBT5->Aberdeen City\n", "GBT6->Aberdeenshire\n", "GBT7->Angus\n", 
"GBT8->Argyll and Bute\n", "GBU1->Clackmannanshire\n", "GBU3->Dundee City\n", "GBU4->East Ayrshire\n", 
"GBU5->East Dunbartonshire\n", "GBU6->East Lothian\n", "GBU7->East Renfrewshire\n", "GBU8->Edinburgh, City of\n", 
"GBU9->Falkirk\n", "GBV2->Glasgow City\n", "GBV4->Inverclyde\n", "GBV5->Midlothian\n", "GBV6->Moray\n", 
"GBV7->North Ayrshire\n", "GBV8->North Lanarkshire\n", "GBW1->Perth and Kinross\n", "GBW2->Renfrewshire\n", 
"GBW4->South Ayrshire\n", "GBW5->South Lanarkshire\n", "GBW6->Stirling\n", "GBW7->West Dunbartonshire\n", 
"GBW9->West Lothian\n", "GBX1->Isle of Anglesey\n", "GBX2->Blaenau Gwent\n", "GBX3->Bridgend\n", "GBX4->Caerphilly\n", 
"GBX5->Cardiff\n", "GBX6->Ceredigion\n", "GBX7->Carmarthenshire\n", "GBX8->Conwy\n", "GBX9->Denbighshire\n", 
"GBY1->Flintshire\n", "GBY3->Merthyr Tydfil\n", "GBY4->Monmouthshire\n", "GBY5->Neath Port Talbot\n", 
"GBY6->Newport\n", "GBY7->Pembrokeshire\n", "GBY9->Rhondda Cynon Taff\n", "GBZ1->Swansea\n", "GBZ2->Torfaen\n", 
"GBZ3->Vale of Glamorgan, The\n", "GBZ4->Wrexham\n", "BA01->Federation of Bosnia and Herzegovina\n", 
"BA02->Republika Srpska\n", "MN23->Darhan Uul\n", "MN24->Govi-Sumber\n", "MN25->Orhon\n", "KP18->Najin Sonbong-si\n", 
"TR87->Bartin Ili\n", "ZW09->Bulawayo\n", "ZW10->Harare\n", 0}; char Sbc13b922b70712c59681e8e9513cdd49 
= 0; 
#ifdef macintosh
 S042d13b10485cabf99cf90ff4d75c4a3 Sadf8207ce6560fedefd25246451f950e = S161da4c62b05bf184863f3f14716e9dd; 

#endif
  int Sa7d4a1730a67c1bb9562993d12ddecdc; muint Scb97af3c3dd77223d23c4a32b48387dd = 0; S6f1aca99a9b51fa4524099cdd063162b 
S16bf031f93db701299be71e056b04f62;  muint S7feafa7d32159fd14127e866e559c332 = 0; S6f1aca99a9b51fa4524099cdd063162b 
S2268e9d9f6ab65f4de4fa629aa4bebb7; S6d6cbe6673721b1104d6dcb8de7beb6a S960c4d79666fac3e42b4a5e4d9e863b8 
= ""; S6d6cbe6673721b1104d6dcb8de7beb6a S3e891651914f3a0c3dd52cf9d823d861; S6f1aca99a9b51fa4524099cdd063162b 
Sdc011b7eecdd4c9ebbeea61ef3206c37; bool S4f1915463414e3e474ddb0ac8e1d76ff = false; S6f1aca99a9b51fa4524099cdd063162b 
Sc57885d72bc62764095074865d4342e6; S6f1aca99a9b51fa4524099cdd063162b Sf584a041524197ca906da67668bef36b; 
FILE *Sbe99661f85ab38b59aba1bfa9577f41a = NULL; Se2c73b544fed1ea7b7b2b0c2972c57b4 *Scc623d512b3f914c49ab5433524e2487 
= NULL; ofstream *S6633ece0c4447a219496d1d9a9a0f4f5 = NULL; S6f1aca99a9b51fa4524099cdd063162b S37c27fda89d6583076b170b9c608c222; 
bool S11ca703b02ff552b3fda8206206489c6 = false; S4673665870260a6a927871499a4441fa *S38db5447d45d10d38fcd7373a171791e 
= NULL; S6f1aca99a9b51fa4524099cdd063162b S62c2fb294be1611fda99cf132ad0893a; bool S3063cadee62070516b0261232081d19f; 
 void *Sb00454a7f6a8ca52037d5afba6964314;  void *S1b09a93c18167de60e8270e6cd25b065;  void S103b615f50bbc4dca41a4fad1bdea11d(S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa8f40f9e6fb272143b50feb3f3d45c04) {   Sdc011b7eecdd4c9ebbeea61ef3206c37.Obtain();  S3e891651914f3a0c3dd52cf9d823d861 
= Sa8f40f9e6fb272143b50feb3f3d45c04; if (!S3e891651914f3a0c3dd52cf9d823d861.Se543ff92285a848ed4d00f194cccf802(Sfae98e901cdbf1a268ec544cd9457415)) 
S3e891651914f3a0c3dd52cf9d823d861 += Sfae98e901cdbf1a268ec544cd9457415;  Sdc011b7eecdd4c9ebbeea61ef3206c37.Release(); 
 
#if defined(Se2f7c1b07e77b83af42dd2888bffc2ef) && defined(Sadd4926431496cf7ab51a4d419e434d6)
 chmod((S3e891651914f3a0c3dd52cf9d823d861 + "IPC").c_str(), 0777); 
#endif
 }  S6d6cbe6673721b1104d6dcb8de7beb6a S386ab9f82f83ce53d791996ba5e7db8e(void) { return S46db4488fd72b41b6dc6a1e3106cc9b0(); 
} const char *S46db4488fd72b41b6dc6a1e3106cc9b0(void) {   Sdc011b7eecdd4c9ebbeea61ef3206c37.Obtain(); 
if (S3e891651914f3a0c3dd52cf9d823d861.length() == 0) {    S3e891651914f3a0c3dd52cf9d823d861 = S6d6cbe6673721b1104d6dcb8de7beb6a() 
+ S6dc541f470409efdfd227ca57e926d39 + "LogAnalysisInfo" + Sfae98e901cdbf1a268ec544cd9457415; }  Sdc011b7eecdd4c9ebbeea61ef3206c37.Release(); 
 return S3e891651914f3a0c3dd52cf9d823d861.c_str(); }  void S7608d5e0ba7cd0ce8aff4c744c4de7c7(S6d6cbe6673721b1104d6dcb8de7beb6a 
Sfda27b398251e72fb5f8705b70a71e1c) {   S56fcc181c2fcb9052832a467d17082c4.Obtain(); S8767764926c0176e0bc9ace733369be8 
= Sfda27b398251e72fb5f8705b70a71e1c; S56fcc181c2fcb9052832a467d17082c4.Release(); }  S6d6cbe6673721b1104d6dcb8de7beb6a 
S9bdcbbc756fba9d7adc9e108d27dec81(void) {   S56fcc181c2fcb9052832a467d17082c4.Obtain(); S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa0d162d0c7d63be1d940ba4a2367fc5b = S8767764926c0176e0bc9ace733369be8; S56fcc181c2fcb9052832a467d17082c4.Release(); 
return Sa0d162d0c7d63be1d940ba4a2367fc5b; }  void Scd4d6b13e553c60ece87b3e9fc178484(void) {   S16bf031f93db701299be71e056b04f62.Obtain(); 
Scb97af3c3dd77223d23c4a32b48387dd++; S16bf031f93db701299be71e056b04f62.Release(); }  void S6e0c94ae3b306de7e92be1fd03e59ef6(void) 
{   S16bf031f93db701299be71e056b04f62.Obtain(); Scb97af3c3dd77223d23c4a32b48387dd--; S16bf031f93db701299be71e056b04f62.Release(); 
}  mint Sc1bfc5dbe0a63153c73e4322b0e5da5f(void) {   S16bf031f93db701299be71e056b04f62.Obtain(); mint 
S54c8f3692b3237f91dca3b86a06969a5 = Scb97af3c3dd77223d23c4a32b48387dd; S16bf031f93db701299be71e056b04f62.Release(); 
return S54c8f3692b3237f91dca3b86a06969a5; }  void S5397b7fd7be24d0a9f3d8d2b514fe50c(void) {   S2268e9d9f6ab65f4de4fa629aa4bebb7.Obtain(); 
S7feafa7d32159fd14127e866e559c332++; S2268e9d9f6ab65f4de4fa629aa4bebb7.Release(); }  void Sfec16770e92600050ef6fc308f845afe(void) 
{   S2268e9d9f6ab65f4de4fa629aa4bebb7.Obtain(); S7feafa7d32159fd14127e866e559c332--; S2268e9d9f6ab65f4de4fa629aa4bebb7.Release(); 
}  mint Sa9f8063733a4d948799153a1a53fb442(void) {   S2268e9d9f6ab65f4de4fa629aa4bebb7.Obtain(); mint 
S54c8f3692b3237f91dca3b86a06969a5 = S7feafa7d32159fd14127e866e559c332; S2268e9d9f6ab65f4de4fa629aa4bebb7.Release(); 
return S54c8f3692b3237f91dca3b86a06969a5; }  void S10386e79214e497598ad8c7b44414857(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) { if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8f5a59444a6ad8e25cbdf31c8befb2a9) 
return; Sc57885d72bc62764095074865d4342e6.Obtain(); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8f5a59444a6ad8e25cbdf31c8befb2a9 
= true; }  void S2b84410d60e996916ce209bf26dd1f9e(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{ if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8f5a59444a6ad8e25cbdf31c8befb2a9) 
{ Sc57885d72bc62764095074865d4342e6.Release(); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8f5a59444a6ad8e25cbdf31c8befb2a9 
= false; } } 

