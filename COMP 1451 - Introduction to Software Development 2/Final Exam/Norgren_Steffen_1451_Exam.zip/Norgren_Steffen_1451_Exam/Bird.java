
/**
 * Write a description of interface Bird here.
 * 
 * @author Steffen L. Norgren
 * @version 2007.08.17
 */

public interface Bird
{
    public abstract String getEggColour();
    
    public abstract double getFlightSpeedKMH();
}
