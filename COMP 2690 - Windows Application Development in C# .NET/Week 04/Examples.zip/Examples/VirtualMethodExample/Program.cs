using System;
using System.Collections.Generic;
using System.Text;

class Program
{
	static void Main(string[] args)
	{
		InventoryItem item = new InventoryItem(101, 1024.93m, "Gary Sanders");
		item.PrintReport();
	}
}

/// <summary>
/// Represents a base class for the virtual/override example.
/// </summary>
public class Item
{
	private int id;

	#region "Constructors"

	public Item(int id)
	{
		this.id = id;
	}

	#endregion

	public virtual void PrintReport()
	{
		Console.WriteLine("ID: {0}", id);
	}
}

/// <summary>
/// Represents a derived class for the virtual/override example.
/// </summary>
public class InventoryItem : Item
{
	private decimal price;
	private string buyer;
	private bool sold;

	#region "Constructors"

	public InventoryItem(int id, decimal price)
		: base(id)
	{
		this.price = price;
	}

	public InventoryItem(int id, decimal price, string buyer)
		: this(id, price)
	{
		if( buyer != null && buyer.Length > 0 )
		{
			this.buyer = buyer;
			this.sold = true;
		}
	}

	#endregion

	public override void PrintReport()
	{
		base.PrintReport();

		Console.WriteLine("Price: {0:C}", price);
		Console.WriteLine("Status: {0}",
				sold ? "Sold to "+buyer : "No buyer");
	}
}
