//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#ifndef Sd49450cb35f9a22b661b9bb961f2449e
 
#define Sd49450cb35f9a22b661b9bb961f2449e
 
#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#include "S8fe7a715c0f4ee4e2fb09d44d3a1a0d5.h"
 class S5859b25427ab04f6097bc5fe0e5ccb6b { public: S5859b25427ab04f6097bc5fe0e5ccb6b() { S6bf31c7094e675f3d2c913d3f4105984 
= 99999; } S5859b25427ab04f6097bc5fe0e5ccb6b(muint S3c2e8ce4e871c25897d9844e3d71aa77) { S6bf31c7094e675f3d2c913d3f4105984 
= S3c2e8ce4e871c25897d9844e3d71aa77; S51d728478b89d8254ee25a97f1c78d7f = new muint[S6bf31c7094e675f3d2c913d3f4105984 
+ 1]; } S5859b25427ab04f6097bc5fe0e5ccb6b(const S5859b25427ab04f6097bc5fe0e5ccb6b &Sdaf12ec292f49594ba9323c1b2dbab6c); 
~S5859b25427ab04f6097bc5fe0e5ccb6b(void) { delete[](S51d728478b89d8254ee25a97f1c78d7f); } void Sb41ef6fa585bce55f20e1016b68e9df4(mint 
Seb9d419135e896279ecc7721147bbd03, muint Sb79d4a4ac05ebdb8cb70e6b5594e9473) { S51d728478b89d8254ee25a97f1c78d7f[Seb9d419135e896279ecc7721147bbd03] 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473; } muint S3454ba91ffdd6d5c24e6576c7de50677(mint Seb9d419135e896279ecc7721147bbd03) 
const { return S51d728478b89d8254ee25a97f1c78d7f[Seb9d419135e896279ecc7721147bbd03]; } S5859b25427ab04f6097bc5fe0e5ccb6b 
&operator = (const S5859b25427ab04f6097bc5fe0e5ccb6b &S5859b25427ab04f6097bc5fe0e5ccb6b); friend S5b2556faa18cdaca5a6ad039f29d6254 
&operator<< (S5b2556faa18cdaca5a6ad039f29d6254 &Scd4082426bdc6a9533556b5ca60add93, const S5859b25427ab04f6097bc5fe0e5ccb6b 
&S5859b25427ab04f6097bc5fe0e5ccb6b); muint *S51d728478b89d8254ee25a97f1c78d7f; muint S6bf31c7094e675f3d2c913d3f4105984; 
};  bool operator== (const S5859b25427ab04f6097bc5fe0e5ccb6b &Sddaf97e67c0ca84403b21d292912225d, const 
S5859b25427ab04f6097bc5fe0e5ccb6b &S265b5a9b6b55e0cb397929043d3d4a5b); 
#endif
 
#endif


