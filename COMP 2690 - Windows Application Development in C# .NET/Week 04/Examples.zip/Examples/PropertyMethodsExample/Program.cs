using System;
using System.Collections.Generic;
using System.Text;

class Program
{
	static void Main(string[] args)
	{
		InventoryItem item = new InventoryItem("Office desk", 524.93m, "Gary Sanders");

		// Change the price.
		item.Price = 494.93m;

		// Get the new price.
		Console.WriteLine("The item's new price is {0:C}", item.Price);
	}
}

public class InventoryItem
{
	private string description;
	private decimal price;
	private string buyer;

	#region "Constructors"

	public InventoryItem(string description, decimal price)
	{
		this.description = description;
		this.price = price;
	}

	public InventoryItem(string description, decimal price, string buyer)
		: this(description, price)
	{
		if (buyer != null && buyer.Length > 0)
		{
			this.buyer = buyer;
		}
	}

	#endregion

	#region "Property Methods"

	/// <summary>
	/// Gets this object's description (read-only).
	/// </summary>
	public string Description
	{
		get
		{
			return description;
		}
	}


	/// <summary>
	/// Gets or sets this object's price.
	/// </summary>
	public decimal Price
	{
		get
		{
			return price;
		}
		set
		{
			this.price = value;
		}
	}


	/// <summary>
	/// Gets the name of this object's buyer, or empty string if 
	/// this item has not yet been sold. (read-only).
	/// </summary>
	public string Buyer
	{
		get 
		{
			if (Sold)
			{
				return buyer;
			}
			else
			{
				return string.Empty;
			}
		}
	}

	/// <summary>
	/// Gets whether or not this object has been sold.  Notice that
	/// there is no 'sold' instance variable--this property is a 
	/// so-called "calculated value" (read-only).
	/// </summary>
	public bool Sold
	{
		get
		{
			return buyer != null && buyer.Length > 0;
		}
	}

	#endregion

	#region "Other Methods"

	public void PrintReport()
	{
		Console.WriteLine("Description    : {0}", Description);
		Console.WriteLine("Price          : {0:C}", price);
		Console.WriteLine("Status         : {0}",
				Sold ? "Sold to " + buyer : "No buyer");
	}

	public void Sell(string buyer)
	{
		if (Sold)
		{
			throw new ApplicationException("Already sold to " + Buyer);
		}
		else if (buyer == null || buyer.Length == 0)
		{
			throw new ApplicationException("No buyer name supplied for sale.");
		}
		else
		{
			// Sell the item.
			this.buyer = buyer;
		}
	}

	#endregion
}
