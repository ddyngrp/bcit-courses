using System;
using System.Collections.Generic;
using System.Text;

namespace TryParseExample
{
	class Program
	{
		static void Main(string[] args)
		{
			int age;
			string input;

			// This loop prompts the user for an integer again and again until
			// the input string can be converted to an integer value.  
			do
			{
				Console.Write("Enter your age: ");
				input = Console.ReadLine();

				if (input == "") break;	// Allow user to exit.

			} while (int.TryParse(input, out age) == false);

			// Note that the int.TryParse returns a boolean value to indicate 
			// whether the input can be converted.  If it returns true then
			// it also "passes back" the converted integer value through its
			// second parameter.  In this way, TryParse can serve two purposes:
			// 1) validate the input, using its return value and 2) convert
			// from a string to a numeric value, using its second parameter.

			// There is also:
			//
			// double.TryParse
			// bool.TryParse
			// DateTime.TryParse
			// float.TryParse
			// etc.
		}
	}
}
