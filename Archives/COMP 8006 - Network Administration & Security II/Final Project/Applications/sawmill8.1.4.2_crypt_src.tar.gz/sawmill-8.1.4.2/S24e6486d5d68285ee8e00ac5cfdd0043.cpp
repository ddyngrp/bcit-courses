//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include <math.h>

#if HAVE_FLOAT_H
 
#include <float.h>

#endif
  int S22287e81656164da30dc31e11cee5ec9(double S20aef69c7f26392285bf797b786d9fba) { 
#if defined(S360e739c2a7abb7ae12907be3354bc8c) || defined(WIN32)
  return Sbffb586850c39f52966ccac2d5248a7d(S20aef69c7f26392285bf797b786d9fba); 
#else
 return isnan(S20aef69c7f26392285bf797b786d9fba); 
#endif
 } 

