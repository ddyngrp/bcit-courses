/*
 * SAX Handler to parse the xhtml file and update the schedule xml data
 *
 * @author Steve Hu & David Margine
 */
package model;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import java.io.FileOutputStream;

import java.io.IOException;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;

public class MySAXApp extends DefaultHandler {

    private boolean startParsing = false;
    private boolean insideRow = false;
    private FileOutputStream fos;
    private ContentHandler hd;
    private static int rowcount = 0;
    // XERCES 1 or 2 additionnal classes.
    private OutputFormat of;
    private AttributesImpl atts;

    public MySAXApp(FileOutputStream fo) {
        super();
        try {
            fos = fo;
            // initialize the xml format
            of = new OutputFormat("XML", "ISO-8859-1", true);
            of.setIndent(1);
            of.setIndenting(true);

            XMLSerializer serializer = new XMLSerializer(fos, of);

            // SAX2.0 ContentHandler.
            hd = serializer.asContentHandler();
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    @Override
    public void startDocument() {
        try {
            hd.startDocument();
            atts = new AttributesImpl();
            hd.startElement("", "", "TeamSchedule", atts);
            atts.clear();
            atts.addAttribute("", "", "Year", "CDATA", "2008");
            hd.startElement("", "", "Season", atts);
        } catch (SAXException se) {
            System.err.println(se);
        }
    }

    @Override
    public void endDocument() {
        try {
            hd.endElement("", "", "Season");
            hd.endElement("", "", "TeamSchedule");
        } catch (SAXException se) {
            System.err.println(se);
        }
    }

    @Override
    public void startElement(String uri, String name,
            String qName, Attributes atts) {
        if (qName.equals("tr")) {
            insideRow = true;
        }
    }

    @Override
    public void endElement(String uri, String name, String qName) {

        if (startParsing && qName.equals("tr")) {
            insideRow = false;
        }
    }

    @Override
    public void characters(char ch[], int start, int length) {
        String current = new String(ch, start, length);
        if (startParsing && insideRow) {

            try {
                if (length > 1 || (length == 1 && Character.isDigit(ch[start]))) {

                    switch (rowcount) {
                        case 0:
                            atts.clear();
                            atts.addAttribute("", "", "Week", "CDATA", current);
                            break;
                        case 1:
                            atts.addAttribute("", "", "Date", "CDATA", current);
                            hd.startElement("", "", "Schedule", atts);
                            if (current.equals(" (BYE WEEK)")) {
                                atts.clear();
                                hd.startElement("", "", "Teams", atts);
                                hd.endElement("", "", "Teams");
                                hd.startElement("", "", "Time", atts);
                                hd.endElement("", "", "Time");
                                hd.startElement("", "", "Stats", atts);
                                hd.endElement("", "", "Stats");
                                hd.endElement("", "", "Schedule");
                                rowcount = -1;
                            }
                            break;
                        case 2:
                            atts.clear();
                            hd.startElement("", "", "Teams", atts);
                            hd.characters(ch, start, length);
                            hd.endElement("", "", "Teams");
                            break;
                        case 3:
                            atts.clear();
                            hd.startElement("", "", "Time", atts);
                            hd.characters(ch, start, length);
                            hd.endElement("", "", "Time");
                            break;
                        case 4:
                            atts.clear();
                            hd.startElement("", "", "Stats", atts);
                            hd.characters(ch, start, length);
                            hd.endElement("", "", "Stats");
                            hd.endElement("", "", "Schedule");
                            rowcount = -1;
                            break;
                    }
                    rowcount++;
                }
            } catch (SAXException se) {
                System.err.println(se);
            }

        }
        // This determine the starting point of parsing
        if (current.compareTo("REGULAR SEASON") == 0) {
            startParsing = true;
        }
        // This is the end point of parsing
        if (current.compareTo("44-30 W") == 0) {
            startParsing = false;
        }
    }
}
