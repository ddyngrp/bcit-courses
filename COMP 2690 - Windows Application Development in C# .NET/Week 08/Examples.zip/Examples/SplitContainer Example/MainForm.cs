using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace SplitContainer_Example
{
	public partial class MainForm : Form
	{
		private List<Picture> pictures;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// Size of image is increased descreased to match
			// the size of the PictureBox control, while still
			// keeping its aspect ratio.
			picMain.SizeMode = PictureBoxSizeMode.Zoom;

			loadSomePictures("..\\..\\pics");
			populatePictureList();

			if (lstPictures.Items.Count > 0)
			{
				lstPictures.SelectedIndex = 0;
			}
		}

		private void loadSomePictures(string path)
		{
			pictures = new List<Picture>();

			string [] files = Directory.GetFiles(path);

			foreach (string file in files)
			{
				pictures.Add(new Picture(
						Image.FromFile(file),
						Path.GetFileNameWithoutExtension(file)));
			}
		}

		private void populatePictureList()
		{
			lstPictures.Items.Clear();

			foreach (Picture picture in pictures)
			{
				lstPictures.Items.Add(picture);
			}

			lstPictures.DisplayMember = "Description";


		}

		private void lstPictures_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lstPictures.SelectedIndex != -1)
			{
				Picture picture = lstPictures.SelectedItem as Picture;
				Debug.Assert(picture != null, "Should only be Picture objects in the ListBox.");

				picMain.Image = picture.Image;
			}
		}
	}
}