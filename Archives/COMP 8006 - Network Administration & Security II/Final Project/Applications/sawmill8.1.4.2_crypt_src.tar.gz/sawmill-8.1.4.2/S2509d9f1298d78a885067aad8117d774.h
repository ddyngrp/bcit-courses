//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Se566a9c41728167296cafcd4963f039f
 
#define Se566a9c41728167296cafcd4963f039f
 
#include "sconfig.h"

#include "Sf9922ee12c0191f731481fd32578283b.h"

#include "S1a14215d7a9ed417e57c419037ad81b9.h"
 class S6ebd5941df466d9a1c9cc8263c03ef42; class Sc51497dedb5c0712f20ccaa9831c0365; class S6935ea702da310c8571074717f076ea7; 
class S44de2eb5cbf19d9e0c855598b3781f42 : public S4f4955a74b11dc1f8b279197db71427f { private: S6ebd5941df466d9a1c9cc8263c03ef42 
*S1a14215d7a9ed417e57c419037ad81b9; S6935ea702da310c8571074717f076ea7 *S3bced6387f6e5964905bbb72fc146b3e; 
muint S3d7bef5b94828f4c5b1e6804605daa54; public: S44de2eb5cbf19d9e0c855598b3781f42(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S6ebd5941df466d9a1c9cc8263c03ef42 *S60283a425cf987277e107f9b3baaaa7e, 
S6935ea702da310c8571074717f076ea7 *Sf7c07efbb5aaea497ea48b25f1d532e0);    virtual bool Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, uint64 S3d7bef5b94828f4c5b1e6804605daa54);  virtual rownum_t S1f2884441072ae4fe0ccdf040e11970b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) { return S1a14215d7a9ed417e57c419037ad81b9->S9b87ec188ee0d8b8517cc332082a0a9c(); 
} };  
#endif


