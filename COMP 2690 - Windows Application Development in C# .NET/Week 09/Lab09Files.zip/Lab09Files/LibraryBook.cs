using System;
using System.Collections.Generic;
using System.Text;

namespace Solution
{
	public class LibraryBook
	{
		private string title, author;
		private int copyrightYr;

		public LibraryBook() { }

		public LibraryBook(string title, string author, int copyrightYr)
		{
			this.title = title;
			this.author = author;
			this.copyrightYr = copyrightYr;
		}

		public string Title
		{
			get { return title; }
			set { this.title = value; }
		}

		public string Author
		{
			get { return author; }
			set { this.author = value; }
		}

		public int CopyrightYear
		{
			get { return copyrightYr; }
			set { copyrightYr = value; }
		}

		public override string ToString()
		{
			return Title;
		}
	}
}
