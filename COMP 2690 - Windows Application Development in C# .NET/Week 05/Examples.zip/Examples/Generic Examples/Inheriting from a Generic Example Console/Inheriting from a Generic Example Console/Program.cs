using System;
using System.Collections.Generic;
using System.Text;

namespace Inheriting_from_a_Generic_Example_Console
{
	class Program
	{
		static void Main(string[] args)
		{
			EmployeeCollection employees = new EmployeeCollection();

			employees.Add(new Employee("Toula", new DateTime(1975, 4, 18), 104000));
			employees.Add(new Employee("Frank", new DateTime(1948, 6, 12), 66000));
			employees.Add(new Employee("Kendra", new DateTime(1972, 2, 20), 45000));
			employees.Add(new Employee("Simon", new DateTime(1938, 10, 1), 82000));

			// Distribute $10,000 amongst all employees.
			employees.GiveBonuses(10000m);

			// Display all employees.
			foreach(Employee employee in employees)
			{
				Console.WriteLine(employee);
			}
			Console.WriteLine();

			// Use EmployeeCollection.GetByAtLeastAge method to show a count of 
			// how many employees have reached a certain age.
			int atLeastAge = 45;
			Console.WriteLine("There are {0} employees who are at least {1} years old\n",
					employees.GetByAtLeastAge(atLeastAge).Count, 
					atLeastAge);
		}
	}
}
