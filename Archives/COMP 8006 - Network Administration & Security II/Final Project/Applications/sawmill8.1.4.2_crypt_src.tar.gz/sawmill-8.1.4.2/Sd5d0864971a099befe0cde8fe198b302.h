//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S36b5cb864d3855d4365718a456bdb7fe
 
#define S36b5cb864d3855d4365718a456bdb7fe
 
#include "sconfig.h"
class Sa14f2810aa7f7746ebe6af24ad45815a; 
#include "Scf163b9fe5fa9dd8c63f48cfe2ab82d9.h"

#include "S4c26649b975b46bffeabbcdd943eda42.h"

#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"

#if HAVE_TIME_H
 
#include <time.h>

#endif
 
#include "S3a1a3e8e7f71e2f3f206a8e5a2424cc6.h"
 class Sa14f2810aa7f7746ebe6af24ad45815a; class Saacb9dc4c09242bfd4043bbe6215dcf9; class S0ba050d9579c6281350b9ce7250e7370; 
class Sdf4fb278460c79939cf16951f2dbf6e8; class S4219b44ff72461b5d1a084c9fc0c9530 {     public:    S6f1aca99a9b51fa4524099cdd063162b 
Scd3eebc331ef7258867572e57d056835; time_t S296aa4d34c522abcf009abbf2b481195; time_t S493f6831ed70f3f3cd288a0ffc72f58b; 
     muint S79794ac664703fe6d2610bd02d58df12; muint S6d7dfb503b113d3b7d1fdb7d2fb2f820; mint S30a553c7bcfb53d8fd79bec200a0785d; 
muint S5615f2e9bd64d2ebc8a227570ea685fb;  S6d6cbe6673721b1104d6dcb8de7beb6a S0d8174a0bb8ed40f5903682324ee6588; 
   bool Sd2b2918d73a05f7cbc05058ea9582b94; bool S8a7dd059b10622e8ad24b35d89889819;       bool S6eab4532d10c95280114e6cb2e590278; 
bool Sf644d3d7dcd15a28de14dff22f508143; bool S7c343bbedfe8e32eab1888f897e7d75e; S6f1aca99a9b51fa4524099cdd063162b 
S91db758b4d80c17321b7ac0135159504; S6f1aca99a9b51fa4524099cdd063162b S4e5088a1c2623515f90f59b2fab3a7a2; 
S6f1aca99a9b51fa4524099cdd063162b Sd17372bc8ea99021fe20aaebfe68b938; S6f1aca99a9b51fa4524099cdd063162b 
Sb64e9fd2a474886bc2cbd056edf04fa7; S6f1aca99a9b51fa4524099cdd063162b S0f48f8183eebfba8f5b721630a8cc2fd; 
muint S6b1c53ad5aa4fc4a6566bf6a0716fb6a; S6f1aca99a9b51fa4524099cdd063162b S1f7438b3c77e19a399eedb4549e96fa4; 
muint Sc30dac25ec72be22310e1b58e0835144; time_t S63fb574cb6721b1f64a0858a3bec2b48; muint S6d7c06c0261868e4fcff2c2076a58c5d; 
Saacb9dc4c09242bfd4043bbe6215dcf9 *Sa67b3dca6d1374d64f745787cb8181b7; S4219b44ff72461b5d1a084c9fc0c9530(Sa14f2810aa7f7746ebe6af24ad45815a 
*S8fed4bd55d0dde65809c290f6d813bac); ~S4219b44ff72461b5d1a084c9fc0c9530(void);   void Sbea85e44eb159a658da24fcffa3e8607(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S584d8f83216f96f2ce72de1aae4d1387(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S5abc9e65e3656600567132e18072b4ed(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void Scf222d35abc0158b5e2fa7de0abd50ce(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); S7ca5d44c3992eca4f11ed4ee768968cd *Sd41b0868367d21196a59984626a8bfcc(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S976f3f8b6cf591faaa098827e57cd6fb(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e);   mint S8d0a0cb2a60dc077d0837c656b8ec773(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S1b5080401a5be0829712dc8e02e079a7);          void Sd564f841a0260829a15835e10f393339(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e);  }; 
#endif


