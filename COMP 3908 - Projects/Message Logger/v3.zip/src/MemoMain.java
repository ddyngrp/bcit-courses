/*
 * MemoMain.java
 *
 * <Trusterra>, 2003-2008
 * Confidential and proprietary.
 *@author Zhang,Mang(Edison)
 */
package src;

import net.rim.device.api.ui.UiApplication;


/**
 * MemoMain class
 * This class inherits from UiApplication which is the enter class for MemoLogger.
 *
 */
class MemoMain extends UiApplication{
    /**
    *
    *Default Constructor
    */
    MemoMain() 
    {
        Menu mainMenu = new Menu();

        pushScreen(mainMenu);

    }
    /**
    *Program entry method
    *
    */
    public static void main(String[] args)
    {
        MemoMain memoLogger = new MemoMain();
        memoLogger.enterEventDispatcher();
        
    }
} 
