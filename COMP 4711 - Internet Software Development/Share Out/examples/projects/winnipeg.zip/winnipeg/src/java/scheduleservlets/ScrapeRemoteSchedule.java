/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduleservlets;

import org.ccil.cowan.tagsoup.*;

import org.ccil.cowan.tagsoup.Parser;
import org.xml.sax.*;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import org.xml.sax.ContentHandler;

/**
 *
 * @author SoulH
 */
public class ScrapeRemoteSchedule extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = null;
        rd = getServletContext().getRequestDispatcher("/GenerateOurSchedule");
        
        //Retrieve URL from the update text field
        String urlPath = request.getParameter("url").toString();
        //Download the contents of url and store it
        String contents = downloadURL(urlPath); 

        FileOutputStream htmlout; // declare a file output object

        PrintStream p; // declare a print stream object

        ServletContext context = getServletContext();
        String path = context.getRealPath("/");
        path += "/WEB-INF/data/";

        // Create a new file output stream to store original nasty html
        // in the \winnipeg\build\web\WEB-INF\data\ folder
        htmlout = new FileOutputStream(path + "UpdatedSchedule.html");
        p = new PrintStream(htmlout);
        p.println(contents);
        p.close();

        // Create a new file output stream to store beautiful xhtml
        // in the \winnipeg\build\web\WEB-INF\data\ folder
        FileOutputStream xhtmlout;
        PrintStream p2;
        xhtmlout = new FileOutputStream(path + "UpdatedSchedule.xhtml");
        p2 = new PrintStream(xhtmlout);
       
        try {
            process("file:///" + path + "UpdatedSchedule.html", xhtmlout);
        } catch (SAXException e) {
            System.out.println("Ouch - a SAXException happened.");
        }
        p2.close();
        
        // Send the result to GenerateOurSchedule to update the xml file
        rd.forward(request, response);
    }

    /**
     * This method to the job of parsing url raw content
     * and store it as a string.
     * 
     * @param theURL schedule website url for parsing
     * @return buffered html source as string
     */
    private String downloadURL(String theURL) {
        URL url;
        InputStream is = null;
        DataInputStream dis;
        String s;
        StringBuffer sb = new StringBuffer();

        try {
            url = new URL(theURL);
            is = url.openStream();
            dis = new DataInputStream(new BufferedInputStream(is));
            while ((s = dis.readLine()) != null) {
                sb.append(s + "\n");
            }
        } catch (MalformedURLException mue) {
            System.out.println("Ouch - a MalformedURLException happened.");
            mue.printStackTrace();
            System.exit(1);
        } catch (IOException ioe) {
            System.out.println("Oops- an IOException happened.");
            ioe.printStackTrace();
            System.exit(1);
        } finally {
            try {
                is.close();
            } catch (IOException ioe) {
                System.out.println("Oops- another IOException happened.");
            }
        }
        return sb.toString();
    }

    /**
     * This method use Tagsoup-1.2 package
     * to conver the nasty html file 
     * into beautiful well-formed xhtml stream
     * 
     * @param src Source of html file 
     * @param os resulted xhtml output stream
     * @throws java.io.IOException
     * @throws org.xml.sax.SAXException
     */
    private void process(String src, OutputStream os)
            throws IOException, SAXException {
        XMLReader reader;
        reader = new Parser();

        HTMLSchema theSchema = new HTMLSchema();
        reader.setProperty(Parser.schemaProperty, theSchema);

        Writer writer;
        writer = new OutputStreamWriter(os);
        // Pick a content handler to generate the desired format.
        XMLWriter xmlWriter;
        xmlWriter = new XMLWriter(writer);
        xmlWriter.setPrefix(theSchema.getURI(), "");
        ContentHandler h = xmlWriter;
        reader.setContentHandler(h);

        InputSource is = new InputSource();
        is.setSystemId(src);
        try {
            reader.parse(is);
        } catch (IOException ioe) {
            System.err.println("IOException(process): " + ioe);
        } catch (SAXException se) {
            System.err.println("SAXException (process): " + se);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
