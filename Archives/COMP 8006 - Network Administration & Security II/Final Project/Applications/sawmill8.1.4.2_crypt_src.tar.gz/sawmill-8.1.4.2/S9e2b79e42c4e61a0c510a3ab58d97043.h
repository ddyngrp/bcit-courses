//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sf4574a7d2654040bf70e8dac644ab5bc
 
#define Sf4574a7d2654040bf70e8dac644ab5bc
 typedef enum { Sc9bcc7560e3fddbff9a61fec2249eee2, S01c3ffe270ad799de43010ecd4baabb7, Sf70af334de5a8032544c59c7c2295421, 
Sb93faa8e529ef57d227a0e253814b5c7 } S6c43f7b20963646dd7166569cdf65b11; 
#endif


