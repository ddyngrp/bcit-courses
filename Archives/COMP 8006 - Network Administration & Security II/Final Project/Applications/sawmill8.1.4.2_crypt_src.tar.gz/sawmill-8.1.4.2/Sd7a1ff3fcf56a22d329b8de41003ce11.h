//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S441a5418ff2e897051c32b0c8e6178ef
 
#define S441a5418ff2e897051c32b0c8e6178ef
 
#include "sconfig.h"

#include "S9639d09a160dd8e9bc404403e1905bd5.h"

#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"

#include "Scf163b9fe5fa9dd8c63f48cfe2ab82d9.h"

#include "Scc24f14d898b52398886178ddbbc6e88.h"

#include "S78ad491ac8a005c50b041106551db851.h"

#include "S1e643706385d1b2279a15fd1988cafd7.h"

#include "Sca15561e0819e26d2da18c941d9b8931.h"

#include "Sf167d7d53b38f2ac29e47b226e4dd8e8.h"

#include "S1e74a770ef962b25b6435ad580c71e5a.h"

#include "S2f7bf975e04ac223e53a9a7d141407f4.h"

#include "S4251970c545ff7063c10e0ac5324e0d8.h"

#if HAVE_TIME_H
 
#include <time.h>

#endif
 
#include "S1d74a1b184e8222d3ded4849bbfb69b5.h"

#include <stdio.h>
 class Sc51497dedb5c0712f20ccaa9831c0365; class S9f4d4ea4917e0ea34880cb67e0e58e66; 
#ifdef macintosh
 
#include <OpenTransport.h>

#include <OpenTptInternet.h>

#endif
 void S10386e79214e497598ad8c7b44414857(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
void S2b84410d60e996916ce209bf26dd1f9e(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
extern S6d6cbe6673721b1104d6dcb8de7beb6a S7204a1a6dc814790d3cbe1ecf11fc333;   class Se2c73b544fed1ea7b7b2b0c2972c57b4; 
extern Se2c73b544fed1ea7b7b2b0c2972c57b4 *S1d556f889f4bc2f0eeac43606f269edc; extern muint S707ce287d5c0714dd33b66a7df1475b3; 
extern muint Se7241f501127077bfd2eaed21c12d1cc; extern bool S44d2879ef432e9b7ea9668f8bddd46a7; extern 
muint Sdcf14f47aad1c1162702056c56b0ab12; extern bool Sfab26a4f110f8008b90818cc57af2190; extern S6d6cbe6673721b1104d6dcb8de7beb6a 
S3d7cced431ee4c9ebb2e3d383f9b153c; extern S6d6cbe6673721b1104d6dcb8de7beb6a Sccff816db690fc6092ef080aca07d8f2; 
extern bool Se6539117b0faf95112cebde9bd0c2465; extern bool S9be2736d0e1d8df3cdac39b3587b6d47; extern 
bool S5063a2f9985204e0b89dbe25eacc48b7; extern const char *S5d79645ac85eab3e1872b87884951b89; extern 
const char *S9956ebaea5cc830c9ec77ac842b9ee27; extern const char *Sfebd76768dbec1aa9c9ff701288b7868; 
extern const char *Sabd4e979f86841b7753335682db3b0e0; extern const char *Se70811edfabb87b042caf620b68c1812; 
extern const char *Sc640833ec2fb39eddccce47182643ec4; extern const char *S4cef90213625f05cbc5a9294e3c89b73; 
extern const char *Sfe764bdeaf80db4ee49f657c45031f12; extern const char *S81ca739932b3caf38e3996342b309795; 
extern const char *Sa755dc2a4292e8db45ce07915d6aa9cc;  extern bool S9e0246f15f76f59910865e27790cb6e5; 
extern bool S263b8566c867fa87f2e6f19a172ae430; extern S9f4d4ea4917e0ea34880cb67e0e58e66 *Sd3315df279e2103548ce818b96e12af2; 
extern bool Sa7fa879d9b646e7732c9c01e6f0bba13; extern bool Sd3ec1c83d3f43765decd1fd03ef93b89; extern 
S6d6cbe6673721b1104d6dcb8de7beb6a S8a981d3999c26a3a43188addb62c4e52; extern S6d6cbe6673721b1104d6dcb8de7beb6a 
S530f1c5b655b590225e2cfdfe6e674e8; extern S6d6cbe6673721b1104d6dcb8de7beb6a S99b4d14d3a605f5c74792b3286874e4c; 
extern bool S717faf697c21d0fb4d9f0bd898cfa511; extern bool S3453986fad8ae18a4cddd52a6f55b49e; extern 
S6d6cbe6673721b1104d6dcb8de7beb6a Sb58a8fc1f38a6f9f58b6a1ab3e1631a9; extern S6d6cbe6673721b1104d6dcb8de7beb6a 
Sc25bf34dbfdb5f8f82eb2722cee0bd12; extern bool S97990d396e8be476aa15f81c699bb482; extern bool Sb43b56fff9bc1038da1785a37c090c66; 
extern bool Sbeb19fc723b0fce9316166946e628d41; extern bool Sc3c9455c0a9e9168b90fa14ad83f14f1; extern 
bool S8562ea9f2b282321bb4996d27ce347f0; extern bool S7e5f01234602189cb0f4c9c338245b2d; extern const 
char *S805b5b37e03134a4b99602734d94a116;  extern muint S92feee79243eb1a2e8ee84ed28614052; extern const 
char *S944caa4b612be699dace75815e1e7cf0[S47474c9d1a06925001c00d66da005fc6]; extern const char *S88b803d4dc8da6f9a27b0ecb943c478f[S69db65c67279774a2ac2aa1a2f16ce37]; 
extern const char *Sb9363b2357c9d675213e96d47b7470d5[S34d895da04f693412822c142c81d1769];    extern bool 
S8b4285c8abe88e4a2ba3673879c9b4e6; extern bool S6717007b21199f732b603477b3f19b00; extern const char 
*Sd66b1b878153dc72608d06e73a787601[];  extern map<S6d6cbe6673721b1104d6dcb8de7beb6a, S6d6cbe6673721b1104d6dcb8de7beb6a> 
Se3cd2c8a809a46e38a957b99373f5e36; extern muint S05cc7cbb25d32ce3d7596642e676d102; extern S6f1aca99a9b51fa4524099cdd063162b 
Sef029c825d63baf7604556beefaa7205; extern S6f1aca99a9b51fa4524099cdd063162b S3103cece49218c4bdfb00d0061da9d8e; 
extern S6f1aca99a9b51fa4524099cdd063162b S37b66753a7f07f86822effc9c842b12c; extern S6f1aca99a9b51fa4524099cdd063162b 
S7487ca9ee5ae64fa2a09b088f44dc1e7; extern S6f1aca99a9b51fa4524099cdd063162b Sb47d7bc8cef701206a3de709ede4ebfd; 
extern S6f1aca99a9b51fa4524099cdd063162b Sd975ed92fd36e0f5b03547ecad44be5b; extern S6f1aca99a9b51fa4524099cdd063162b 
S8a42c2aec66d06516032340dc5516aad; extern bool Se66049b94e13312a206457dd7fce9062; extern muint S1a0ff674b987936cc1bbc6ba33b7ad01; 
extern muint S4815b3f660fa59b1c6e484b65e74533c; extern mint S18aaacd668f843ba7b0c292b32a6d981; extern 
int Se4ceb89503814d7e97bb987ccb50d87b; extern char S107f160894ecad3ca0ae8efadac337c7[1000]; extern int 
S0dd0a887bf15ca37284b8fa48c29a485; extern const char *S9f307d23a7e1cd72014b16cfebd055d7[]; extern const 
muint S1b43bfc43636aeafa8942f1dfdaa4931[]; extern const char *S944caa4b612be699dace75815e1e7cf0[S47474c9d1a06925001c00d66da005fc6]; 
extern const char *Sd4042235b1aace5b9ce00b65a46baa78[S551cd4e7753d4041812da03c1d143800];            
  extern bool S01a18b0199ddb3ca4f307ef250d159df; extern time_t Sc8915d498d2314d711d0597b98175b2c; extern 
uint64 S9feb44985445b0ce4db01e066e648130; extern bool Sa11caea824c192f484fa61b07456ad8c; extern S6d6cbe6673721b1104d6dcb8de7beb6a 
*Se9838b86b4af8c13b2a6a9a74edf05e2;  extern unsigned char S1589b250b0cea2de9e80418a29e077d6[]; extern 
unsigned char S0101c090fe7b54e586e75dfb7d3c1bdd[]; extern int Sa7d4a1730a67c1bb9562993d12ddecdc; extern 
const char *S1e97150f41aa897da7c96d76f41e68cc; extern const char *S66e3290c6749e9e6c9fe4fab000d5002; 
extern const char *Sa7c3229a1ab282c7a5238e8f8acc3d2c; extern bool Sda00d4d1c1a32e771c653d26cc09cbae; 
extern char Sbc13b922b70712c59681e8e9513cdd49; 
#ifdef macintosh
 extern S042d13b10485cabf99cf90ff4d75c4a3 Sadf8207ce6560fedefd25246451f950e; 
#endif
  extern S6d6cbe6673721b1104d6dcb8de7beb6a S960c4d79666fac3e42b4a5e4d9e863b8; extern S6f1aca99a9b51fa4524099cdd063162b 
Sc57885d72bc62764095074865d4342e6; extern S6f1aca99a9b51fa4524099cdd063162b regexpLock; extern S6f1aca99a9b51fa4524099cdd063162b 
Sf584a041524197ca906da67668bef36b;   extern void *S87f7aa029cab5ff8c6886317c4ae7c3a; extern FILE *Sbe99661f85ab38b59aba1bfa9577f41a; 
extern Se2c73b544fed1ea7b7b2b0c2972c57b4 *Scc623d512b3f914c49ab5433524e2487; extern bool S11ca703b02ff552b3fda8206206489c6; 
extern S4673665870260a6a927871499a4441fa *S38db5447d45d10d38fcd7373a171791e; extern S6f1aca99a9b51fa4524099cdd063162b 
S62c2fb294be1611fda99cf132ad0893a; extern bool S4f1915463414e3e474ddb0ac8e1d76ff; extern ofstream *S6633ece0c4447a219496d1d9a9a0f4f5; 
extern S6f1aca99a9b51fa4524099cdd063162b S37c27fda89d6583076b170b9c608c222; void S103b615f50bbc4dca41a4fad1bdea11d(S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa8f40f9e6fb272143b50feb3f3d45c04); const char *S46db4488fd72b41b6dc6a1e3106cc9b0(void); S6d6cbe6673721b1104d6dcb8de7beb6a 
S386ab9f82f83ce53d791996ba5e7db8e(void); void S7608d5e0ba7cd0ce8aff4c744c4de7c7(S6d6cbe6673721b1104d6dcb8de7beb6a 
Sa8f40f9e6fb272143b50feb3f3d45c04); S6d6cbe6673721b1104d6dcb8de7beb6a S9bdcbbc756fba9d7adc9e108d27dec81(void); 
void Scd4d6b13e553c60ece87b3e9fc178484(void); void S6e0c94ae3b306de7e92be1fd03e59ef6(void); mint Sc1bfc5dbe0a63153c73e4322b0e5da5f(void); 
void S5397b7fd7be24d0a9f3d8d2b514fe50c(void); void Sfec16770e92600050ef6fc308f845afe(void); mint Sa9f8063733a4d948799153a1a53fb442(void); 

#endif


