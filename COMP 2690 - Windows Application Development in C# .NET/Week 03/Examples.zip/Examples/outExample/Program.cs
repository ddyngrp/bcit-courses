using System;
using System.Collections.Generic;
using System.Text;

namespace outExample
{
	class ChangeDispenser
	{
		public static void CalcChange(
				decimal amtOwed, 
				decimal amtGiven, 
				out int dollarsChange, 
				out int quartersChange, 
				out int dimesChange, 
				out int nickelsChange, 
				out int penniesChange)
		{
			// Get change due in pennies.  
			// Explicitly casting to int will remove any fractional amount.
			int totalChangeInPennies = (int)((amtGiven - amtOwed) * 100);

			dollarsChange = totalChangeInPennies / 100;
			totalChangeInPennies -= dollarsChange * 100;

			quartersChange = totalChangeInPennies / 25;
			totalChangeInPennies -= quartersChange * 25;

			dimesChange = totalChangeInPennies / 10;
			totalChangeInPennies -= dimesChange * 10;

			nickelsChange = totalChangeInPennies / 5;
			totalChangeInPennies -= nickelsChange * 5;

			penniesChange = totalChangeInPennies;
		}
	}

	class Program
	{
		static void Main(string[] args)
		{

			string stringInput;
			decimal amtOwed, amtGiven;
			int dollars, quarters, dimes, nickels, pennies;

			Console.Write("Enter amount owed: ");
			stringInput = Console.ReadLine();
			amtOwed = Convert.ToDecimal(stringInput);

			Console.Write("Enter amount given: ");
			stringInput = Console.ReadLine();
			amtGiven = Convert.ToDecimal(stringInput);

			if (amtGiven >= amtOwed)
			{
				ChangeDispenser.CalcChange(
						amtOwed, amtGiven,
						out dollars, out quarters, out dimes, out nickels, out pennies);

				Console.WriteLine("\nYour change is:"
						+ "\n dollars  : " + dollars.ToString()
						+ "\n quarters : " + quarters.ToString()
						+ "\n dimes    : " + dimes.ToString()
						+ "\n nickels  : " + nickels.ToString()
						+ "\n pennies  : " + pennies.ToString() + "\n");
			}
			else
			{
				Console.WriteLine("\nNot enough money given!\n");
			}
		}

	}
}


