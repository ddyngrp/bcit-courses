//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S77479ca9c26fe9b4a97078dc3f101c6c
 
#define S77479ca9c26fe9b4a97078dc3f101c6c
 
#include "Sd295dc2269861866e4d15626cf1d8abe.h"

#include "zlib.h"

#include "bzlib.h"

#include "unzip.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "cc_regexp.h"
 class Sda1f7454beaee688465f017db4d14ba6; class Sf1608eebcac82e15a36bbd5b338184c5 : public Sfe7618ef4b0786b73a2a9acfc49b94ce 
{ S6d6cbe6673721b1104d6dcb8de7beb6a Scb837112bd0e4416c77465077532f477; S6d6cbe6673721b1104d6dcb8de7beb6a 
S43f012de0c1d39bbffdace76cb72da3f; bool S6425e265aa9915d1ecdec06e2de2f8f2; bool S1139935503d568ab3f0c3b185282912e; 
Sda1f7454beaee688465f017db4d14ba6 *S5ccbc6cc1c668578474ed30aab467503; bool S79cc1245dfd711e2e7aca25a723253e3; 
bool S3e4dc4c21455d542159aaabc55c28532; 
#define S303d01b8dd1f053d5f7e30ece5376bf2 10000
 char *S410bbad9f2b26e25d87b87ba43c98cc0; S6d6cbe6673721b1104d6dcb8de7beb6a S19adf9d5b8a74193fafa481181cf2b86; 
gzFile Sc163e95a1c0f5398de54f76ece7b93bc; BZFILE *S2b3888f63e03ada754c29b7ee32b02ac; unzFile S564aecc44ee4b3f485fa750d6e32d9d6; 
public: Sf1608eebcac82e15a36bbd5b338184c5(Sc51497dedb5c0712f20ccaa9831c0365 &S6ec129777c16ed8568398f5726365a75, 
const char *Sdd6563c1ca6ca3a9ef9c82de6e4e7f24, const char *S692be1aae1c19119e3216cbc86c67000, bool Sd202583e3cbae0077742a0e579348338); 
virtual void S8a548fbbd62911c60c284937c41e0a0f(void); virtual void S3f8a63896208e84c6eb5224d6b46ba6b(void); 
virtual bool S906d79a2db224b30265ca1043cf8fe6b(void) { return true; } virtual filelen_t S69229d6871c2cd0b77fe33f05144f0e9(S71b409bf2aa98ff69b95ba16e4cb2f05 
&Sf472b15dde2a4399a70a2e7fa0b6eb6f, char *S2985b4614d2618f174fd3c6fca49b42f, filelen_t Sd8d77b1ed00928dcc1bbf26f7598511d); 
virtual void S577943ab58039c24baeac25a70030170(void); virtual S6d6cbe6673721b1104d6dcb8de7beb6a Sdb807cbd507db99fefe8d0045ddb25dc(void); 
virtual time_t S26926d64837702f55b2920936df56399(void); virtual double Sa645ef186899b7d89024160d78d7a66c(void); 
virtual S6d6cbe6673721b1104d6dcb8de7beb6a Sbdeeade5060cfdaf59b062f643abfb67(void); virtual const char 
*S02e0bdbd0245ef077b2ca7c32dbe4cf0(); }; 
#endif


