//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S8fe7a715c0f4ee4e2fb09d44d3a1a0d5.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S5c686a55e1be1e5c2d8a4c8424ee6932.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "Se31981d874cf90aae9b970e888bfb32b.h"

#include "Sb1873817612472c6a597e9c6920c7114.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"
 
#define S5698308d790f3539623073e518056afa "next-section"
  void S3b63c0b2f37689afc101688f578f2091(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{   const char *Sc83e24db2da0ff0b6c3640dc92aab970 = "text/html"; S3b63c0b2f37689afc101688f578f2091(Scc2faae6b412ac43b64129b402c4b88e, 
"200 OK", Sc83e24db2da0ff0b6c3640dc92aab970, -1, false, true, false); } void S3b63c0b2f37689afc101688f578f2091(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S4a6cb99edf5d80c7bbd96fda8d69fb13, const char *Sc83e24db2da0ff0b6c3640dc92aab970, 
mint Sf538f90c372dd2cb2031856b8b621eb6, bool S359f3b602fb388938436fcaabb20d12f, bool Sf6b449e4c1d06fd4baf78e1096593c02, 
bool S3df0af19cabcabcfdb83f8678eb9ad67) {   S359f3b602fb388938436fcaabb20d12f = false; if (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4 
&& Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->Se62ce7be994c95b6dbc3411db22553fe 
&& Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->Se048bb144468f3349cbb0f29886e6145) 
{ S359f3b602fb388938436fcaabb20d12f = true; } if (!Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8ff4c51957a1cabef8e3bc945b2de4b1) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Not sending header because it's not web server or CGI mode" 
<< endl); return; }   if (!Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S023e46dfb01b3a92b00c87bb68c6baab) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Not sending header because it's not a live page" 
<< endl); return; }  if (Sd3315df279e2103548ce818b96e12af2) { S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, 
"Not sending header because it's an httpHandlerProcessPageBuffer page" << endl); return; }   if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S01fd61c098499beaafa8dd1730e571b7) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Not sending header because there is at least one stacked progress" 
<< endl); return; } S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Header debugging at " 
<< __FILE__ << ": " << __LINE__ << endl);  bool S0d155a7731fe0384659d3e1a127543c1 = false; if (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4) 
{ Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->S1479619d9314f2065c16e79a7675513c 
= false; }         S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Header debugging at " 
<< __FILE__ << ": " << __LINE__ << endl);   if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S023e46dfb01b3a92b00c87bb68c6baab 
&& !Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S05dc4388663bc7e9272a396c24cf1f30) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Header debugging at " << __FILE__ 
<< ": " << __LINE__ << endl);    if (S11ca703b02ff552b3fda8206206489c6) { S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, 
"Header debugging at " << __FILE__ << ": " << __LINE__ << endl);  if (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4 
&& Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->Se62ce7be994c95b6dbc3411db22553fe) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Header debugging at " << __FILE__ 
<< ": " << __LINE__ << endl); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"HTTP/1.1 ")); } else { S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"HTTP/1.0 ")); } S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S4a6cb99edf5d80c7bbd96fda8d69fb13, S6e068fea41b32fae579c0fd109d12fb0));   char S97c11f16b41244bff46393801be83410[500]; 
time_t S3efe85651f7412622a4b7e6bc2f87af5 = time(NULL); 
#if HAVE_LOCALTIME_R
 struct tm S06a7c056fbf01ef7c56dcb2c3f508dec; struct tm *S6b72e270bf638d4b30bcdc9cbee748c2 = localtime_r(&S3efe85651f7412622a4b7e6bc2f87af5, 
&S06a7c056fbf01ef7c56dcb2c3f508dec); 
#else
 struct tm *S6b72e270bf638d4b30bcdc9cbee748c2 = localtime(&S3efe85651f7412622a4b7e6bc2f87af5); 
#endif
 size_t S7f3f5c63b6fe99b1734383d7601f8140 = strftime(S97c11f16b41244bff46393801be83410, 500, "%a, %d %b %Y %H:%M:%S GMT", 
S6b72e270bf638d4b30bcdc9cbee748c2); if (S7f3f5c63b6fe99b1734383d7601f8140) { S709f8a104a477b9e6883c170d8a6a334( 
Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "Date: ", S97c11f16b41244bff46393801be83410, 
S6e068fea41b32fae579c0fd109d12fb0)); }  S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, 
"staticFile: " << S3df0af19cabcabcfdb83f8678eb9ad67 << endl); if (S3df0af19cabcabcfdb83f8678eb9ad67) 
{ S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "contentType: " << Sc83e24db2da0ff0b6c3640dc92aab970 
<< endl);  muint S64e31edc0375e49839cf5c2b2276162b; if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, 
"application/x-javascript") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, 
"text/css") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, "image/gif") || 
Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, "image/jpeg") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, 
"image/png")) S64e31edc0375e49839cf5c2b2276162b = 14400; else S64e31edc0375e49839cf5c2b2276162b = 0; 
S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "maxAge: " << S64e31edc0375e49839cf5c2b2276162b 
<< endl);     time_t S54cd71f5af066cd31347aea22277edb5 = time(NULL) + S64e31edc0375e49839cf5c2b2276162b; 

#if HAVE_LOCALTIME_R
 S6b72e270bf638d4b30bcdc9cbee748c2 = localtime_r(&S54cd71f5af066cd31347aea22277edb5, &S06a7c056fbf01ef7c56dcb2c3f508dec); 

#else
 S6b72e270bf638d4b30bcdc9cbee748c2 = localtime(&S54cd71f5af066cd31347aea22277edb5); 
#endif
 S7f3f5c63b6fe99b1734383d7601f8140 = strftime(S97c11f16b41244bff46393801be83410, 500, "%a, %d %b %Y %H:%M:%S GMT", 
S6b72e270bf638d4b30bcdc9cbee748c2); if (S7f3f5c63b6fe99b1734383d7601f8140) { S709f8a104a477b9e6883c170d8a6a334( 
Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "Expires: ", S97c11f16b41244bff46393801be83410, 
S6e068fea41b32fae579c0fd109d12fb0)); }   Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Cache-Control: max-age=", Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, S64e31edc0375e49839cf5c2b2276162b), 
S6e068fea41b32fae579c0fd109d12fb0); S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, 
"Added Cache-Control header with max-age=" << S64e31edc0375e49839cf5c2b2276162b << endl); }   else { 
Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "Cache-Control: max-age=0", S6e068fea41b32fae579c0fd109d12fb0); 
S6bcf99fce07707f06693cebe6a409e38(S4da6ab5c9fa4ebc0d3a96a5c4bb83d5f, "Added Cache-Control header with zero max-age" 
<< endl); }  S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Server: Sawmill/", S264788b0ec3dd9d2eea09ffe91d6aeaa(Scc2faae6b412ac43b64129b402c4b88e).c_str(), S6e068fea41b32fae579c0fd109d12fb0)); 
if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, "gif/data")) { S709f8a104a477b9e6883c170d8a6a334(Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Accept-Ranges: image/gif", S6e068fea41b32fae579c0fd109d12fb0)); }   if (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->Se62ce7be994c95b6dbc3411db22553fe) 
{ if (S359f3b602fb388938436fcaabb20d12f) { S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Connection: close", S6e068fea41b32fae579c0fd109d12fb0)); } else {   S709f8a104a477b9e6883c170d8a6a334( 
Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "Keep-Alive: timeout=60, max=100", 
S6e068fea41b32fae579c0fd109d12fb0)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Connection: Keep-Alive", S6e068fea41b32fae579c0fd109d12fb0));   }   } }  else { 
#ifdef macintosh
 S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"HTTP/1.0 200 OK", S6e068fea41b32fae579c0fd109d12fb0)); 
#endif
 }     if (Sf538f90c372dd2cb2031856b8b621eb6 != -1) {  S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-length: ", Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, Sf538f90c372dd2cb2031856b8b621eb6), 
S6e068fea41b32fae579c0fd109d12fb0)); }  if (Se2966fbcaea5cb926b81dc6fff1fcbaf(Scc2faae6b412ac43b64129b402c4b88e, 
"cgionly_savepasswordcookie") == "true") {      }  if (Scc2faae6b412ac43b64129b402c4b88e.Se7a7d21cfafd6f4ea10c8e66722683cd.length()) 
{ S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
Scc2faae6b412ac43b64129b402c4b88e.Se7a7d21cfafd6f4ea10c8e66722683cd.c_str())); } 
#if 0
  if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S68ca9f99a54d5e749a638e38004de5ee 
&& Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S2ac946dfc3f4c106fa7906e277d33e4f) 
{ S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-type: Multipart/x-mixed-replace;boundary=", S5698308d790f3539623073e518056afa, S6e068fea41b32fae579c0fd109d12fb0, 
S6e068fea41b32fae579c0fd109d12fb0)); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S2ac946dfc3f4c106fa7906e277d33e4f 
= false; }   if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S68ca9f99a54d5e749a638e38004de5ee) 
{ S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S6e068fea41b32fae579c0fd109d12fb0, S6e068fea41b32fae579c0fd109d12fb0)); S709f8a104a477b9e6883c170d8a6a334( 
Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "--", S5698308d790f3539623073e518056afa, 
S6e068fea41b32fae579c0fd109d12fb0)); } 
#endif
                               if (Sc83e24db2da0ff0b6c3640dc92aab970[0]) {   if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, 
"text/csv")) { S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-type: ", Sc83e24db2da0ff0b6c3640dc92aab970, S6e068fea41b32fae579c0fd109d12fb0)); } else if 
(Sbea6e228a47bc141f76fa54e2c8ba1b9(Sc83e24db2da0ff0b6c3640dc92aab970, "application/vnd.ms-excel")) { 
S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-type: ", Sc83e24db2da0ff0b6c3640dc92aab970, S6e068fea41b32fae579c0fd109d12fb0)); } else {  
   S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-type: ", Sc83e24db2da0ff0b6c3640dc92aab970)); if (S5c6bf2bf93522d729e78b78410ff24e7("miscellaneous.charset")) 
{ Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "; charset="); Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S22bbd1db66323e9152a85ead057ada5c("miscellaneous.charset")); } else if (S3d2e1f30084426e6f24dc1801aa68aa6(Scc2faae6b412ac43b64129b402c4b88e, 
"charset")) { Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, "; charset="); Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S7ba42d71d11a2c3fcb456e9de6a53ca1("charset").c_str()); }     S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S6e068fea41b32fae579c0fd109d12fb0));  if (S3d2e1f30084426e6f24dc1801aa68aa6(Scc2faae6b412ac43b64129b402c4b88e, 
"CONTENT_LANGUAGE")) { S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-language: ", S7ba42d71d11a2c3fcb456e9de6a53ca1("CONTENT_LANGUAGE").c_str(), "\n")); } } }  
if (Sf6b449e4c1d06fd4baf78e1096593c02) { S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S6e068fea41b32fae579c0fd109d12fb0)); } }      if ((Sd3315df279e2103548ce818b96e12af2 == NULL) && Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4 
&& S0d155a7731fe0384659d3e1a127543c1) { Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->S1479619d9314f2065c16e79a7675513c 
= true; }  if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S4862d90484bfec6392feb3277442e067 
== "HEAD") Sf4ee370243771c454bd48735594e12a4("No error -- exit"); }  void Scabc7b4f45e16e52ca93d01651fec3d6(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) { if (!Se4ceb89503814d7e97bb987ccb50d87b) { for (int S9b94e2c9d966d38d56020d99329da11b 
= 0; S9b94e2c9d966d38d56020d99329da11b < 1000; S9b94e2c9d966d38d56020d99329da11b++) S107f160894ecad3ca0ae8efadac337c7[S9b94e2c9d966d38d56020d99329da11b] 
= ' '; S107f160894ecad3ca0ae8efadac337c7[999] = 0; Se4ceb89503814d7e97bb987ccb50d87b = true; }  if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8ff4c51957a1cabef8e3bc945b2de4b1) 
{ S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
S107f160894ecad3ca0ae8efadac337c7)); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"\n")); } }  void Sd1d5592d47602b0494d161bdbaf67fd6(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{  } 
#ifndef macintosh
  void Sd47e80cb47354cbfba29bbda872bdfef(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
bool Sfd2cfc252246314f5013ef182e86957a) { if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sf7c5acd8ae3207a6d45f9e10a8ce6a0e) 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sf7c5acd8ae3207a6d45f9e10a8ce6a0e->flush(); 
if (Sfd2cfc252246314f5013ef182e86957a) S709f8a104a477b9e6883c170d8a6a334( Scabc7b4f45e16e52ca93d01651fec3d6(Scc2faae6b412ac43b64129b402c4b88e) 
); S688c9ac189d42a63a6a6e94b45d8dd07(Scc2faae6b412ac43b64129b402c4b88e); }  
#endif
 void S688c9ac189d42a63a6a6e94b45d8dd07(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{  if (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S023e46dfb01b3a92b00c87bb68c6baab) 
Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S67f0ed61c6cbbb0311ca3bd501cf6aa3 
= true; Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Se44e16ce478744a17b99defd8c97767d++; 
 if (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4 && (Scc2faae6b412ac43b64129b402c4b88e.S8de59aaa8ddd52e0816889eb5af004a4->S1479619d9314f2065c16e79a7675513c) 
&& Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S023e46dfb01b3a92b00c87bb68c6baab) 
{ Sde7cdfd411b943b2396776e2d85e063e(Scc2faae6b412ac43b64129b402c4b88e, "0\r\n"); Sde7cdfd411b943b2396776e2d85e063e(Scc2faae6b412ac43b64129b402c4b88e, 
"\r\n"); } } 

