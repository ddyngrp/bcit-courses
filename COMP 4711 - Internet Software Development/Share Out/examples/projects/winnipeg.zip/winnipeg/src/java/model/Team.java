/*
 * Model for a CFL team
 * 
 * @author  Jim Parry
 */
package model;

public class Team {

    /** Team identifier (unique), a.k.a. its webapp context */
    private String id = null;
    /** City the team plays in */
    private String city = null;
    /** Name of the team */
    private String name = null;
    /** Division the team plays in */
    private Division division = null;

    /** Convenience constructor */
    public Team(String id, String city, String name) {
        this.id = id;
        this.city = city;
        this.name = name;
    }

    /** Accessor for the team's identifier */
    public String getId() {
        return id;
    }

    /** Accessor for the team's city */
    public String getCity() {
        return city;
    }

    /** Accessor for the team's name */
    public String getName() {
        return name;
    }

    /** Accessor for the team's division */
    public Division getDivision() {
        return division;
    }

    /** Mutator for the team's division */
    public void setDivision(Division division) {
        this.division = division;
    }

}
