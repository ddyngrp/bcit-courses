/*
 * CancelException.java
 *
 * � <your company here>, 2003-2008
 * Confidential and proprietary.
 */

package src;


import java.lang.Exception;

/**
 * 
 */
class CancelException extends Exception{

} 
