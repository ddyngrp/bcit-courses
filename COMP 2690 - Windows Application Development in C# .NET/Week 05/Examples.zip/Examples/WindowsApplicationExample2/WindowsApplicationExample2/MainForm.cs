using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplicationExample2
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void btnGo_Click(object sender, EventArgs e)
		{
			if(txtFirstName.Text == "")
			{
				MessageBox.Show("Please enter your first name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
				txtFirstName.Focus();
			}
			else if(txtLastName.Text == "")
			{
				MessageBox.Show("Please enter your last name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
				txtLastName.Focus();
			}
			else
			{
				// Output the result.
				lblOutput.Text = string.Format("Hello {0} {1}!", txtFirstName.Text, txtLastName.Text);

				// Clear the textboxes.
				txtFirstName.Text = txtLastName.Text = "";

				txtFirstName.Focus();
			}

		}

	}
}