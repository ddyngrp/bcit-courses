using System;
using System.Collections.Generic;
using System.Text;

namespace InheritingFromGenericExample
{
	public class EmployeeCollection : List<Employee>
	{
		public void GiveBonuses(decimal totalBonusFund)
		{
			// Divide the total funds evenly amongst all employees.
			decimal bonus = totalBonusFund / this.Count;

			// Give bonus to each employee.
			foreach (Employee employee in this)
			{
				employee.GiveBonus(bonus);
			}
		}

		/// <summary>
		/// Returns a new EmployeeCollection containing just those employees who
		/// have reaches the given age.  Note that this does NOT create new Employee
		/// objects.  It creates new Employee references to the same objects as 
		/// those in this collection.
		/// </summary>
		/// <param name="age">The age that an employee must have reached in order to
		/// be included in the returned collection.</param>
		/// <returns></returns>
		public EmployeeCollection GetByAtLeastAge(int age)
		{
			EmployeeCollection result = new EmployeeCollection();

			foreach (Employee employee in this)
			{
				if (employee.Age >= age)
				{
					result.Add(employee);
				}
			}

			return result;
		}
	}
}
