using System;
using System.Collections.Generic;
using System.Text;

namespace ConstructorInitializerExample
{
	public class Program
	{
		public static void Main()
		{



		}
	}

	/// <summary>
	/// Represents a base class for the example.
	/// </summary>
	public class Item
	{
		private int id;

		/// <summary>
		/// Default constructor.
		/// </summary>
		public Item() 
		{ 
		}

		/// <summary>
		/// Non-default constructor.
		/// </summary>
		/// <param name="id"></param>
		public Item(int id)
		{
			this.id = id;
		}
	}

	/// <summary>
	/// Represents a derived class for the example.
	/// </summary>
	public class InventoryItem : Item
	{
		private decimal price;
		private string buyer;
		private bool sold;

		/// <summary>
		/// Default constructor.  This will implicitly call the
		/// base class' default constructor first.
		/// </summary>
		public InventoryItem()
		{
		}

		/// <summary>
		/// Non-default constructor.  Uses an initializer to explicitly
		/// call the correct base class constructor first.
		/// </summary>
		/// <param name="id"></param>
		/// <param name="price"></param>
		public InventoryItem(int id, decimal price)
			: base(id)
		{
			this.price = price;
		}

		public InventoryItem(int id, decimal price, string buyer)
			: this(id, price)
		{
			sold = true;
			this.buyer = buyer;
		}

		public decimal GetPrice()
		{
			return price;
		}

		/// <summary>
		/// Sell this inventory item.  A given item can only be sold once so this 
		/// method returns ALREADY_SOLD if the method is called twice on the same
		/// object.
		/// </summary>
		/// <param name="buyer">Name of the buyer.</param>
		/// <param name="applyDiscount">If true then this item is sold at its price 
		/// minus the default discount.</param>
		/// <returns>Price of the sale, including discount if any, or ALREADY_SOLD 
		/// if this item is already sold.</returns>
		public decimal Sell(string buyer, bool applyDiscount)
		{
			if (!sold)
			{
				sold = true;
				this.buyer = buyer;

				// Return price with discount?
				//return applyDiscount ? price - (price * DEFAULT_DISCOUNT) : price;
				return calculateSalePrice(applyDiscount);
			}
			else
			{
				return ALREADY_SOLD;
			}
		}

		private decimal calculateSalePrice(bool applyDiscount)
		{
			if (applyDiscount)
			{
				return price - (price * DEFAULT_DISCOUNT);
			}
			else
			{
				return price;
			}
		}

		/// <summary>
		/// Optional discount when the item is sold.
		/// </summary>
		public const decimal DEFAULT_DISCOUNT = 0.1m;
		/// <summary>
		/// Return value from the Sell method that indicates that the Sell 
		/// failed because it is already sold.
		/// </summary>
		public const decimal ALREADY_SOLD = -1m;

	}
}
