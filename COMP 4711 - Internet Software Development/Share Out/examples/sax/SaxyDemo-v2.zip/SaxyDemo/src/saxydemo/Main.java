package saxydemo;

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.io.*;

/*
 * Demonstrate maintaining state while using SAX processing.
 * 
 * We have a database of medical article citations (medsamp2008.xml),
 * and want to produce a list of articles published in 1999 (or some arbitrary year).
 * The publication date is inside a Year element, but Year elements are nested
 * inside several other elements (DateCreated, DateCompleted, DateRevised and PubDate).
 * 
 * We will have to remember which element we are inside before examining the year field,
 * in order to do a proper job.
 */
/**
 *
 * @author jim
 */
public class Main extends DefaultHandler {

    int YEARSOUGHT = 2000;   
    
    // the fields we want to report
    String pubName = null;
    String articleTitle = null;
    String pubDate = null;
    int yearFound = 0;    
    
    // state control flags
    boolean inCitation = false;
    boolean inArticle = false;

    // trapping booleans
    boolean gotName = false;
    boolean gotTitle = false;
    boolean gotYear = false;
    boolean gotMonth = false;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Main us = new Main();

        XMLReader xmlReader = null;
        try {
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            SAXParser saxParser = spfactory.newSAXParser();
            xmlReader = saxParser.getXMLReader();

            xmlReader.setContentHandler(us);
            InputSource source = new InputSource("./medsamp2008.xml");
            xmlReader.parse(source);
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Handle the start of a new element
     */
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        if (inCitation) {
            // we are inside a MedlineCitation
            if (qName.equals("Article")) {
                inArticle = true;    // found an article :)
            }
        } else {
            if (qName.equals("MedlineCitation")) {
                // we found a citation
                inCitation = true;
                // reset article fields
                pubName = "";
                articleTitle = "";
                pubDate = "";
                yearFound = 0;
            }
        }
        // check for specific fields if inside an article
        if (inArticle) {
            if (qName.equals("Year")) gotYear = true;
            else if (qName.equals("Month")) gotMonth = true;
            else if (qName.equals("Title")) gotName = true;
            else if (qName.equals("ArticleTitle")) gotTitle = true;
        }
    }

    /**
     * Handle values encountered
     */
    public void characters(char[] ch, int start, int length) {
        // process if we have found an element we are looking for, otherwise ignore
        if (gotName) {
            pubName = new String(ch,start,length);
        } else if (gotTitle) {
            articleTitle = new String(ch,start,length);
        } else if (gotYear) {
            String theYear = new String(ch,start,length);
            pubDate += "" + theYear;
            yearFound = Integer.parseInt(theYear);
        } else if (gotMonth) {
            pubDate = new String(ch,start,length) + ",  " + pubDate;
        }
        
    }
    
    /**
     * Handle the end of an element
     */
    public void endElement(String uri, String localName, String qName) {
        if (qName.equals("Article")) {
            // was this an article we want to report?
            if (yearFound == YEARSOUGHT) {
                System.out.println(articleTitle + " (" + pubDate + " - " + pubName + ")");
            }
            inArticle = false;
        } else if (qName.equals("MedlineCitation")) {
            inCitation = false;
            inArticle = false;
        }
        
        gotTitle = false;
        gotName = false;
        gotYear = false;
        gotMonth = false;
    }
}




