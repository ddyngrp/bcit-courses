//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#if HAVE_STDLIB_H
 
#include <stdlib.h>

#endif
 
#include "S9639d09a160dd8e9bc404403e1905bd5.h"

#include "Sdaf12ec292f49594ba9323c1b2dbab6c.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S68f7bcbebe9a6192b736f378d5d9f0a4.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "S2b659cf002e8d20bd33ff44e6e3a8a70.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "Sa61fc4da3e223fa99af3c4225290d4a3.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "Se31981d874cf90aae9b970e888bfb32b.h"

#include "S5e8b429ed8e223d657763cf8925ee779.h"

#include "Sc157c2f77b7c40e8e321884b9ff616a4.h"

#include "S17be0f68f5d7d8233d466e33746ac31e.h"

#include "S1e74a770ef962b25b6435ad580c71e5a.h"
  void Sea03428aa4f031b9b96d58dab49364cc(void) {     S50b7e0dcd24b047fdcc1b3ce5cd66c29();           
 S944caa4b612be699dace75815e1e7cf0[S25d4c5e33134c287c67797f73064f2ad] = "hierarchical"; S944caa4b612be699dace75815e1e7cf0[S17947c22872285be4eb1a57819e1c2d6] 
= "page"; S944caa4b612be699dace75815e1e7cf0[S9e3adab8c6434201ac86538d87eb812c] = "url"; S944caa4b612be699dace75815e1e7cf0[Sc5ec971f35c5be8d6b11c62192139a47] 
= "date_time"; S944caa4b612be699dace75815e1e7cf0[Se12f3cb15f81c19e310f05bc5955f7bb] = "date"; S944caa4b612be699dace75815e1e7cf0[S4d4340cded825ac8decdc8141b1d156c] 
= "time"; S944caa4b612be699dace75815e1e7cf0[S4f14de1485f45178b9614f1f753773d7] = "host"; S944caa4b612be699dace75815e1e7cf0[S82e41596563cb8c33801be602ffe76ed] 
= "agent"; S944caa4b612be699dace75815e1e7cf0[S8ec63832f67d94f392c563ca45656b90] = "size"; S944caa4b612be699dace75815e1e7cf0[S319cacf963e8cb783dfe16c68dedf4fc] 
= "integer"; S944caa4b612be699dace75815e1e7cf0[S2d8557b731eaff2427c0dfbe99fb8023] = "visitorid"; S944caa4b612be699dace75815e1e7cf0[Sa64523d1205914ddcf6ca2bc09305402] 
= "response"; S944caa4b612be699dace75815e1e7cf0[S4181bbdcf19785a99faf2dd376bfd795] = "flat"; S944caa4b612be699dace75815e1e7cf0[S8849aa8745de7887d9e6c11f3f0fe5b1] 
= "duration_hms"; Sd4042235b1aace5b9ce00b65a46baa78[Scfacdd4a0654aeb4ffc70ad18b36fcef] = "string"; Sd4042235b1aace5b9ce00b65a46baa78[S569cdff913889425bdc1a3efe3a21442] 
= "int"; Sd4042235b1aace5b9ce00b65a46baa78[S1a5c8674d4ada3302517e931fc498dc6] = "int"; Sd4042235b1aace5b9ce00b65a46baa78[Se9bc80770030fb9b326994d8a222d48e] 
= "float"; Sd4042235b1aace5b9ce00b65a46baa78[See30bee453d3fa8f0f85d2fb9e39eb47] = "unique"; for (int 
Seb9d419135e896279ecc7721147bbd03 = Sb59bb68115ffa54a636ef7775f6819dd; Seb9d419135e896279ecc7721147bbd03 
< S34d895da04f693412822c142c81d1769; Seb9d419135e896279ecc7721147bbd03++) S88b803d4dc8da6f9a27b0ecb943c478f[Seb9d419135e896279ecc7721147bbd03] 
= NULL; S88b803d4dc8da6f9a27b0ecb943c478f[S73ef288f031afe578381b32889a98d32] = "dd/mmm/yyyy:hh:mm:ss"; 
S88b803d4dc8da6f9a27b0ecb943c478f[Sad2fa7bff65dce7c6e9e49a446b09718] = "www mmm dd hh:mm:ss GMT-hh:mm yyyy"; 
S88b803d4dc8da6f9a27b0ecb943c478f[Sa5aa15bf25c8554468f4391137f21b86] = "yyyy/mm/dd hh:mm:ss"; S88b803d4dc8da6f9a27b0ecb943c478f[S3eb79b1d3d588ec798c22bb8d06f5644] 
= "mm/dd/yyyy:hh:mm:ss"; S88b803d4dc8da6f9a27b0ecb943c478f[Se3026c321f0eb2d951d421003aee215c] = "mm/dd/yy"; 
S88b803d4dc8da6f9a27b0ecb943c478f[Sa0d5e5309cdd11677d51c94912ddf3e0] = "mm/dd/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S8a11244d85152ecf62245e96b5da7fdd] 
= "dd/mm/yy"; S88b803d4dc8da6f9a27b0ecb943c478f[S5111d1aebca0c1774721a96817d1d3d1] = "dd/mm/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S70014a87e58d9fafb8db1eb1fb1e7ad5] 
= "ddmmmyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S1ea63fdead88de2267a54deb2eb078fa] = "dd/mmm/yy"; S88b803d4dc8da6f9a27b0ecb943c478f[S784f1242754e79557e0308fbd3d22206] 
= "dmmmyyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[Se84dbb85ecf98cde1fe7580e43115737] = "d/mmm/yyyy";  
S88b803d4dc8da6f9a27b0ecb943c478f[S600f9a0ab781d50a686e59165940506b] = "mmm/dd/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S92c28715f58faaeef93ca70ea8544c41] 
= "mmm/dd/yy"; S88b803d4dc8da6f9a27b0ecb943c478f[S9d5ddd2ae37d62e5fa6b1b2dac7ac2a9] = "yyyymmdd"; S88b803d4dc8da6f9a27b0ecb943c478f[S12b338f57d5efe65ea074e177aba2dbe] 
= "yymmdd"; S88b803d4dc8da6f9a27b0ecb943c478f[Sf4039e3ecad8d5018b84595b63c825bc] = "yyyy/m/d"; S88b803d4dc8da6f9a27b0ecb943c478f[S8a3a6705b632d4d9524e33d0b42216e3] 
= "yyyy/mm/dd";  S88b803d4dc8da6f9a27b0ecb943c478f[S9b531c4b258056a51d40e265a42d19c6] = "mmddyyyy"; 
S88b803d4dc8da6f9a27b0ecb943c478f[Sfae179642b6a9c72635c62a3ea7c4594] = "yyyymmddhhmmss"; S88b803d4dc8da6f9a27b0ecb943c478f[Sa54f9744f99615afd9243efe42602cea] 
= "yymmdd-hhmmss"; S88b803d4dc8da6f9a27b0ecb943c478f[S57fecd9096f970b1c38b2a34cc5532ea] = "m/d/yy h:mm"; 
S88b803d4dc8da6f9a27b0ecb943c478f[S5f9221f67f2d1ddc8cf5a6c66218358d] = "m/d/yy"; S88b803d4dc8da6f9a27b0ecb943c478f[S1420554fa018dc7d35c01038c34d93d0] 
= "m/d/y"; S88b803d4dc8da6f9a27b0ecb943c478f[S9a80e15f6364c36060cb92118e75c19c] = "y/m/d"; S88b803d4dc8da6f9a27b0ecb943c478f[S72c8909c5d3d79fa94faae6569c9d566] 
= "m/d/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S820f630946304b5bfb9e17fcd74b8dd3] = "d/m/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S48ebfd976efdc3a9c5c790644fd918cc] 
= "d/m/yy"; S88b803d4dc8da6f9a27b0ecb943c478f[S7993398f612b68a9ea5dde97d8ebc3fe] = "d/m/y"; S88b803d4dc8da6f9a27b0ecb943c478f[Sd43a9a4aed6068f682906bb0103b616a] 
= "mmdd"; S88b803d4dc8da6f9a27b0ecb943c478f[S834d680305a3eb8318b7e4cd14cb7bde] = "mm/dd";  S88b803d4dc8da6f9a27b0ecb943c478f[Sc125f8d7f4dc814bad6c14fc398eb286] 
= "dd mmm"; S88b803d4dc8da6f9a27b0ecb943c478f[S224a505db1a16d87994b21dd33f3255d] = "mmm/dd"; S88b803d4dc8da6f9a27b0ecb943c478f[S694b1fe0b438bdca68361052b7b4ae32] 
= "mmm dd yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[Sb409072ba4061c75281ee9abd71a7b1e] = "yyyy/mmm/dd"; 
S88b803d4dc8da6f9a27b0ecb943c478f[S3083dbaecbccf30ee35247141d4f6692] = "mmmmm/dd/yyyy"; S88b803d4dc8da6f9a27b0ecb943c478f[S24bf758665888a0a70f6f2b9cf444f1f] 
= "seconds_since_jan1_1970"; S88b803d4dc8da6f9a27b0ecb943c478f[Sf4bc4475bba9db7f6b627e376a1d9ac5] = 
"TAI64N"; S88b803d4dc8da6f9a27b0ecb943c478f[S23d05b6a13dba5e1cb6317d864f521f8] = "auto"; S88b803d4dc8da6f9a27b0ecb943c478f[S97b842689c0b2c96cffc43ba557a3dfb] 
= "mmm dd hh:mm:ss yyyy"; for (int Seb9d419135e896279ecc7721147bbd03 = Sb59bb68115ffa54a636ef7775f6819dd; 
Seb9d419135e896279ecc7721147bbd03 < S34d895da04f693412822c142c81d1769; Seb9d419135e896279ecc7721147bbd03++) 
Sb9363b2357c9d675213e96d47b7470d5[Seb9d419135e896279ecc7721147bbd03] = NULL; Sb9363b2357c9d675213e96d47b7470d5[S157f5cf7290119ff5c2e08aeba036fd6] 
= "dd/mmm/yyyy:hh:mm:ss"; Sb9363b2357c9d675213e96d47b7470d5[Sd5c4b9edb13f58598c4d8bd7bccb0f53] = "www mmm dd hh:mm:ss GMT-hh:mm yyyy"; 
Sb9363b2357c9d675213e96d47b7470d5[S2ca217250c503ea89c99608bb474bc54] = "yyyy/mm/dd hh:mm:ss"; Sb9363b2357c9d675213e96d47b7470d5[S2dcbdd4b778df46d9f70a1a2cc07cb52] 
= "mm/dd/yyyy:hh:mm:ss"; Sb9363b2357c9d675213e96d47b7470d5[S08a7d8c43f6b6b257668802e221788fd] = "yyyymmddhhmmss"; 
Sb9363b2357c9d675213e96d47b7470d5[S3af95c68a7c71f4367bae4c37eada331] = "yymmdd-hhmmss"; Sb9363b2357c9d675213e96d47b7470d5[S815cd792ec215a8c0c200de198ddde81] 
= "m/d/yy h:mm"; Sb9363b2357c9d675213e96d47b7470d5[S9a56bed96709477711445efaec76553e] = "hh:mm:ss"; 
Sb9363b2357c9d675213e96d47b7470d5[Sd9a95bf0892b28bb09b7bf58ca93bed8] = "hhmmss"; Sb9363b2357c9d675213e96d47b7470d5[S63df83449b5ec40d08780b10f6850752] 
= "h:mm:ss"; Sb9363b2357c9d675213e96d47b7470d5[Sfb5560a15585c16776f1cc9d09818d48] = "h:m:s"; Sb9363b2357c9d675213e96d47b7470d5[S65a41c646bb20fd5701328ef2a3bfcb8] 
= "hhmm"; Sb9363b2357c9d675213e96d47b7470d5[S225dfba4a29a182087e03b36fabbe0f2] = "h:mm"; Sb9363b2357c9d675213e96d47b7470d5[S2db1e7eff6e7513b8fd169270c39b5ef] 
= "h:mm:ss AM/PM";  Sb9363b2357c9d675213e96d47b7470d5[Sdf4ed4d0c989996b29f4adbd1e8a3f43] = "h:mm AM/PM"; 
Sb9363b2357c9d675213e96d47b7470d5[Se0a5e2826f7c509ec2b958e276c9d59e] = "seconds_since_jan1_1970"; Sb9363b2357c9d675213e96d47b7470d5[Se5c740d230aa9a362245433b854e055c] 
= "TAI64N"; Sb9363b2357c9d675213e96d47b7470d5[S36cf222f0430c58e30062e773a755736] = "auto"; Sb9363b2357c9d675213e96d47b7470d5[S6d558342c8b0f8e741a467deae56bef1] 
= "mmm dd hh:mm:ss yyyy";   
#if 0
 
#ifdef macintosh
 S97990d396e8be476aa15f81c699bb482 = true; Sb43b56fff9bc1038da1785a37c090c66 = false; 
#else
  if (S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "bcreport") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, 
"BCReport") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "BCREPORT") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, 
"bluecoatreport") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "BlueCoatReport") 
|| S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "BLUECOATREPORT")) Sb43b56fff9bc1038da1785a37c090c66 
= true; else Sb43b56fff9bc1038da1785a37c090c66 = false;  if (!Sb43b56fff9bc1038da1785a37c090c66) { if 
(S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "sawmill") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, 
"Sawmill") || S94b9f013d1697e8631ce1122b9e529b5(Sb58a8fc1f38a6f9f58b6a1ab3e1631a9, "SAWMILL")) S97990d396e8be476aa15f81c699bb482 
= true; else S97990d396e8be476aa15f81c699bb482 = false; } 
#endif
 
#endif
 }   void S3f70e76c507f1490e2946057a5100dcb(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{ } 

