//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDR_ACCELERATOR                 101
#define IDR_MENU                        102
#define ID_FILE_CONNECT                 40002
#define ID_FILE_DISCONNECT              40003
#define ID_FILE_EXIT                    40004
#define ID_EDIT_FONT                    40006
#define ID_EDIT_                        40007
#define ID_EDIT_CLEARSCREEN             40008
#define ID_HELP_ABOUTTERMINAL           40009
#define ID_EDIT_40010                   40010
#define ID_EMULATE_FILL                 40011
#define ID_EMULATE_SLOWLYFILLBUFFER     40012
#define ID_VIEW_LOCALECHO               40013
#define ID_VIEW_CLEARSCREEN             40014
#define ID_HELP_ABOUT                   40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
