/* Allegro datafile object indexes, produced by grabber v4.2.0, MinGW32 */
/* Datafile: c:\Dev-Cpp\Projects\pongdatafile.dat */
/* Date: Thu Jul 13 11:29:58 2006 */
/* Do not hand edit! */

#define BALL                             0        /* BMP  */
#define BAR                              1        /* BMP  */
#define BOING                            2        /* SAMP */
#define PONGFONT                         3        /* FONT */

