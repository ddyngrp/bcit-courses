using System;
using System.Collections.Generic;
using System.Text;

namespace Solution
{
	class Contact
	{
		private string name, phone, email;

		public Contact(string name, string phone, string email)
		{
			this.name = name;
			this.phone = phone;
			this.email = email;
		}

		public string Name { get { return name; } }
		public string Phone { get { return phone; } }
		public string Email { get { return email; } }

		public override string ToString()
		{
			return Name; 
		}
	}
}
