
   partial class ExplorerForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
		  this.components = new System.ComponentModel.Container();
		  System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExplorerForm));
		  this.tvwFolders = new System.Windows.Forms.TreeView();
		  this.lvwFolderContents = new System.Windows.Forms.ListView();
		  this.splitContainer1 = new System.Windows.Forms.SplitContainer();
		  this.mainImageList = new System.Windows.Forms.ImageList(this.components);
		  this.splitContainer1.Panel1.SuspendLayout();
		  this.splitContainer1.Panel2.SuspendLayout();
		  this.splitContainer1.SuspendLayout();
		  this.SuspendLayout();
		  // 
		  // tvwFolders
		  // 
		  this.tvwFolders.Dock = System.Windows.Forms.DockStyle.Fill;
		  this.tvwFolders.Location = new System.Drawing.Point(0, 0);
		  this.tvwFolders.Name = "tvwFolders";
		  this.tvwFolders.Size = new System.Drawing.Size(135, 207);
		  this.tvwFolders.TabIndex = 0;
		  this.tvwFolders.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvwFolders_AfterSelect);
		  this.tvwFolders.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.tvwFolders_AfterExpand);
		  // 
		  // lvwFolderContents
		  // 
		  this.lvwFolderContents.Dock = System.Windows.Forms.DockStyle.Fill;
		  this.lvwFolderContents.Location = new System.Drawing.Point(0, 0);
		  this.lvwFolderContents.Name = "lvwFolderContents";
		  this.lvwFolderContents.Size = new System.Drawing.Size(270, 207);
		  this.lvwFolderContents.TabIndex = 1;
		  this.lvwFolderContents.UseCompatibleStateImageBehavior = false;
		  this.lvwFolderContents.View = System.Windows.Forms.View.List;
		  // 
		  // splitContainer1
		  // 
		  this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
		  this.splitContainer1.Location = new System.Drawing.Point(0, 0);
		  this.splitContainer1.Name = "splitContainer1";
		  // 
		  // splitContainer1.Panel1
		  // 
		  this.splitContainer1.Panel1.Controls.Add(this.tvwFolders);
		  // 
		  // splitContainer1.Panel2
		  // 
		  this.splitContainer1.Panel2.Controls.Add(this.lvwFolderContents);
		  this.splitContainer1.Size = new System.Drawing.Size(409, 207);
		  this.splitContainer1.SplitterDistance = 135;
		  this.splitContainer1.TabIndex = 2;
		  // 
		  // mainImageList
		  // 
		  this.mainImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("mainImageList.ImageStream")));
		  this.mainImageList.TransparentColor = System.Drawing.Color.Red;
		  this.mainImageList.Images.SetKeyName(0, "FolderClosed");
		  this.mainImageList.Images.SetKeyName(1, "FolderOpen");
		  this.mainImageList.Images.SetKeyName(2, "File");
		  // 
		  // ExplorerForm
		  // 
		  this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
		  this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		  this.ClientSize = new System.Drawing.Size(409, 207);
		  this.Controls.Add(this.splitContainer1);
		  this.Name = "ExplorerForm";
		  this.Text = "TreeView Example - Folder Explorer";
		  this.Load += new System.EventHandler(this.ExplorerForm_Load);
		  this.splitContainer1.Panel1.ResumeLayout(false);
		  this.splitContainer1.Panel2.ResumeLayout(false);
		  this.splitContainer1.ResumeLayout(false);
		  this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.TreeView tvwFolders;
	   private System.Windows.Forms.ListView lvwFolderContents;
	   private System.Windows.Forms.SplitContainer splitContainer1;
	   private System.Windows.Forms.ImageList mainImageList;
   }


