//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!




















































#if 0
  
#ifndef Se75c8e12a39a6ca4359aee08e13871c0
 
#define Se75c8e12a39a6ca4359aee08e13871c0
 
#include "S1a14215d7a9ed417e57c419037ad81b9.h"

#include "S8b5c116509568b6a184fe1f9c24d7bc5.h"
 class S69ea874c0a8d775fbb8debfe711290ba; class Sb15f6d62e62828fa8c2707766cfa61e8; class Sca83f2ba77404931369c15fc6db8dc03 
: public S6ebd5941df466d9a1c9cc8263c03ef42 { private: Sc51497dedb5c0712f20ccaa9831c0365 *S0850770ccc1d710b184b98f64fc06607; 
S69ea874c0a8d775fbb8debfe711290ba *Sde98bde6aca3d1974bc059249c4c2367; FILE *S9868cb1be8057ba4e855f7cfe406826b; 
S46befded556f051bb87f2e7e9275303f Sdd4a0cecc04301dcde1aabeef81876fa; muint Sc1ff708c3bf2ae7a9a53cb4e17f82299; 

#define S0973a79a8d06417efd08650d3b5d404f 2
 S46befded556f051bb87f2e7e9275303f S1048085e695303ce48801dec5000012c[S0973a79a8d06417efd08650d3b5d404f]; 
muint Sdc27b03abaddd77c9f37372f5c6d774f[S0973a79a8d06417efd08650d3b5d404f]; muint S00eef647dbe0d8ace508947072e65cb9[S0973a79a8d06417efd08650d3b5d404f]; 
muint S2e77d62f54f5345260eed258380c5e60; muint S27f70072e3629dc7386ef32e0adec247; Sb15f6d62e62828fa8c2707766cfa61e8 
*Sf61df9a34d3e7be4b45a312fb0de239e; unsigned char *S753adcc3059bb2a4935cd898d156d75d; muint Sb26c464d2391c8093d206e633c157810; 
muint Sfc0717eabeeea61514d4a32b0ce82f64; void Saff6ebce1c848809f8fd751968dfd7ab(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sf1bb612fb103904163f3361e636db355); public: Sca83f2ba77404931369c15fc6db8dc03(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); virtual ~Sca83f2ba77404931369c15fc6db8dc03(void); virtual void 
S370235c3e90e5c23da1818f88e0f7c10(unsigned long S0a8436e51d8c251e031c1a94c2317002); virtual void Sbfa089fba13d139b03b9b7305503e516(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); virtual void Sbb3816bd614474e27aec873aed072563(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
long Sb79d4a4ac05ebdb8cb70e6b5594e9473); virtual long Se6c2454c6dceabfb0190c4f07f3001d8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
bool S7f267dec6d167e17b050dd3ffb3632f3 = true); virtual void Se2cf07af861e42f6dec3d594d9b0883a(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, 
double Sb79d4a4ac05ebdb8cb70e6b5594e9473); virtual double S0d28f1f7e5f1d88f4cd82df506322020(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe); 
virtual void S615a269ca4651401d526ebd237a876b4(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, long 
Sb79d4a4ac05ebdb8cb70e6b5594e9473); virtual void Sae437b16a5ebd9e286529032c51ec7e6(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint S45ac028d65de68b656f6beed47bb05e0, muint S3d8ee3c332e6fb56e9e256ddfaf2c5fc, 
S6ebd5941df466d9a1c9cc8263c03ef42 *S912a86dae5c9ea4933c953a2e42a4975, muint S3bef84d37aac181254529ae3c4ebf131, 
muint S24cb89260942843611814af34d983181); virtual Sd52d2261900a32d63729ba78632c53b9 *Sa43e3b1574c5ad83319defc22277b4fa(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sb75b130e2cafe73a5d4d59707f8293fe); virtual muint S86cb4008f0393187e56e0a95e210c377(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, muint Sf1bb612fb103904163f3361e636db355, muint Sb75b130e2cafe73a5d4d59707f8293fe); 
virtual const char *Sa3432f70164f1da8313f905fc022afd7(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe); virtual 
void Se7998206b675d30b2506d58d2ac7ab48(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
unsigned long Sf1bb612fb103904163f3361e636db355, unsigned long Sb75b130e2cafe73a5d4d59707f8293fe, const 
char *Sb79d4a4ac05ebdb8cb70e6b5594e9473); virtual void Sdeee17eb25d8e8090c1658211db68411(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, vector<S84cb5f9994c76e5bc79552e3fd79e2cc> &Sddae8602054f3a89fe990e06e544f1b7); 
 static void Sce5116eda522bbb06414836b849d40ad(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
S7ca5d44c3992eca4f11ed4ee768968cd *S83b1913201260a0e8936f053b2521dd8); };  
#endif
 
#endif


