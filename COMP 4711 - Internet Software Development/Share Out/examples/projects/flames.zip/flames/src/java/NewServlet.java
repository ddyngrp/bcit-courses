/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.*;
import java.net.*;

import java.sql.DatabaseMetaData;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author HP_Administrator
 */
public class NewServlet extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String[] elements;
        boolean errors = true;
        PrintWriter out = response.getWriter();
        
        try {
            // Create file 
            String ls_path = getServletContext().getRealPath("/") + "update.xml";
            
            FileWriter fstream = new FileWriter(ls_path);
            BufferedWriter file = new BufferedWriter(fstream);            
            
            response.setContentType("text/html;charset=UTF-8");            
            
            // process the schedule file, something like
            URL url = new URL(request.getParameter("url"));
            BufferedReader source = new BufferedReader(new InputStreamReader(url.openStream()));
            String input = null;
            
            file.write(
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n" +
                    "<schedule \n" +
                    "\txmlns=\"http://www.w3schools.com\"\n" +
                    "\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                    "\txsi:schemaLocation=\"http://www.w3schools.com schedule.xsd\">\n");
            
            // skip initial line
            input = source.readLine();
            
            while ((input = source.readLine()) != null) {
                elements = input.split(",");
                file.write("\t<game>\n");
                file.write("\t\t<date>" + elements[1] + "</date>\n");
                if (elements[4].equals("Calgary")) {
                    elements[2] = elements[2].substring(4);
                    file.write("\t\t<visitor>" + elements[2] + "</visitor>\n");
                } else {
                    file.write("\t\t<visitor>Calgary</visitor>\n");
                }
                file.write("\t\t<home>" + elements[4] + "</home>\n");
                file.write("\t\t<score>0 - 0</score>\n");
                file.write("\t</game>\n");
                //file.write(elements[0]);
                out.println("" + input);
            }
            file.write("</schedule>\n");
            
            //  Close the output stream
            file.close();
            
            errors = false;
        } catch (Exception e){//  Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }        
        

        // NOTES ... parse the HTML, looking for the relevant schedule bits, using a tool like
        // the Swing HTML parser (http://java.sun.com/products/jfc/tsc/articles/bookmarks/)
        // or the sourceforge HTML parser project (http://htmlparser.sourceforge.net/)
        // in order to build your updated schedule XML document
        
        // HINT probably looking for a <div> with a specific ID or class, in order to
        // isolate your schedule data

        if (errors) {
            // this output should only ever happen if there is an error
            // processing the URL above            
            try {
                out.println("Link has errors");
                out.println("<br/>" + request.getParameter("url"));
            } finally {
                out.close();
            }
        } else {
            response.sendRedirect("update"); // this should be a link to your "database" updater
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
