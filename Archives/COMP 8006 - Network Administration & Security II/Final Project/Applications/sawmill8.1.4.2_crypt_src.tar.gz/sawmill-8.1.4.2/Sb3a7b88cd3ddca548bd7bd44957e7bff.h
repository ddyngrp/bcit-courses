//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S6778172f7056baed0cb03e3c63b3ceaf
 
#define S6778172f7056baed0cb03e3c63b3ceaf
 
#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"

#include "Secf36bf903121295607de79adb143b01.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class S52e35cc89e8db17017b9040fe7b17cad; class S92155ff9164b105ccd926b88ef89abf1 
{ Secf36bf903121295607de79adb143b01(S52e35cc89e8db17017b9040fe7b17cad *) S83758062e667388b0236560d7670060d; 
S7ca5d44c3992eca4f11ed4ee768968cd *S384437c2252f89b4c914a896fd6f1d55; public: S92155ff9164b105ccd926b88ef89abf1(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sa0d162d0c7d63be1d940ba4a2367fc5b); ~S92155ff9164b105ccd926b88ef89abf1(void); 
void S005dc3f3d16563707eb19db57bf5f25d(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
Secf36bf903121295607de79adb143b01(S6d6cbe6673721b1104d6dcb8de7beb6a) &Sac9907f8ede23d8f7c9ad8bd6d78bf60, 
Secf36bf903121295607de79adb143b01(S6d6cbe6673721b1104d6dcb8de7beb6a)::iterator &Se52be4daa6003b3b7cf8075f2b8296d5, 
const char *S0ee4cdc85418ce1bb177c828419a381f); const char *S8ce7e8ec13b64228e745e71d84acd4fd(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sb79d4a4ac05ebdb8cb70e6b5594e9473); }; 
#endif


