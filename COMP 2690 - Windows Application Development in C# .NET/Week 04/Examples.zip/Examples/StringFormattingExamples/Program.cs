using System;
using System.Collections.Generic;
using System.Text;

class Program
{
	static void Main(string[] args)
	{
		string name = "Gillian";
		int numMessages = 3;

		//
		// Console.WriteLine method allows composite formatting.
		//

		Console.WriteLine("Hello {0}, you have {1} messages.\n", name, numMessages);

		Console.WriteLine("Hello {0}, you have {1} {2}.\n",
				name,
				numMessages,
				(numMessages == 1) ? "message" : "messages");

		//
		// When you do not want to use Console.WriteLine, use string.Format.
		//

		string msg;
		msg = string.Format("Hello {0}, you have {1} messages.\n", name, numMessages);
		AppendToLogFile( msg );

		SetStatusMsg(string.Format("You have {0} messages.", numMessages));

		//
		// Demonstrating optional alignment component of a placeholder
		// to set preferred field widths.
		//

		SystemUser [] users = {
				new SystemUser("Geoff", "Administrator", 15.2f),
				new SystemUser("Bridgette", "Administrator", 3.09f),
				new SystemUser("Andrew", "PowerUser", 44.45f),
				new SystemUser("Brenda", "User", 1.0f),
				new SystemUser("Natalie", "User", 0.0f)};

		Console.WriteLine("Average Logins Per Week");
		Console.WriteLine("============================================");
		Console.WriteLine("{0,-10}  {1,10}  {2}", "Name", "Average", "User Type");
		Console.WriteLine("============================================");
		foreach (SystemUser user in users)
		{
			Console.WriteLine("{0,-10}  {1,10}  {2}", 
					user.Name, 
					user.AvgLoginsPerWk, 
					user.UserType);
		}

		Console.WriteLine("\n\n\n");

		//
		// Demonstrating optional format string component of a placeholder
		// to format the floating point values.
		//

		Console.WriteLine("Average Logins Per Week");
		Console.WriteLine("============================================");
		Console.WriteLine("{0,-10}  {1,10}  {2}", "Name", "Average", "User Type");
		Console.WriteLine("============================================");
		foreach (SystemUser user in users)
		{
			Console.WriteLine("{0,-10}  {1,10:F2}  {2}",
					user.Name,
					user.AvgLoginsPerWk,
					user.UserType);
		}

		Console.WriteLine("\n\n\n");
	}

	/// <summary>
	/// This is a method that doesn't actually do anything, it just
	/// helps with the string.Format example because it receives any
	/// string.
	/// </summary>
	/// <param name="msg"></param>
	private static void SetStatusMsg(string msg)
	{
		// This method doesn't actually do anything.
	}

	/// <summary>
	/// This is a method that doesn't actually do anything, it just
	/// helps with the string.Format example because it receives any
	/// string.
	/// </summary>
	/// <param name="msg"></param>
	private static void AppendToLogFile(string msg)
	{
		// This method doesn't actually do anything.
	}

}

class SystemUser
{
	private string name;
	private string userType;
	private float avgLoginsPerWk;

	public SystemUser(string name, string userType, float avgLoginsPerWk)
	{
		this.name = name;
		this.userType = userType;
		this.avgLoginsPerWk = avgLoginsPerWk;
	}

	public string Name { get { return name; } }

	public string UserType { get { return userType; } }

	public float AvgLoginsPerWk
	{
		get { return avgLoginsPerWk; }
		set { avgLoginsPerWk = value; }
	}
}
