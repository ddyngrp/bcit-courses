using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace ListBoxExample
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// Create some Person objects and add them to the ListBox.
			populateListBox();

			// Since we populated the ListBox with non-string objects, how does it
			// know what to display???  Answer: we can tell it how to display these
			// objects by telling it which public property to look for in the Person 
			// class.  You give it a string, which is the name of the property.
			//
			// Note: The DisplayMember is set to a non-empty string then it is used
			//       instead of the object's ToString method.
			lstNames.DisplayMember = "FirstName";

			// Programmatically select the first ListBox item.
			// Note: This will fire the SelectedIndexChanged event, which is actually
			//       a good thing in this case. 
			lstNames.SelectedIndex = 0;
		}

		private void populateListBox()
		{
			// Clear ListBox first so that this method can be called again later if
			// necessary.
			lstNames.Items.Clear();

			// Create some Person objects and add them to the ListBox.
			lstNames.Items.Add( new Person("Joan", "Heart", new DateTime(1960, 5, 25)) );
			lstNames.Items.Add( new Person("Greg", "Taylor", new DateTime(1965, 6, 24)) );
			lstNames.Items.Add( new Person("Amber", "Black", new DateTime(1972, 2, 2)) );
			lstNames.Items.Add( new Person("William", "Garcia", new DateTime(1991, 9, 1)) );
			lstNames.Items.Add( new Person("Cindy", "Gold", new DateTime(2000, 1, 14)) );
			lstNames.Items.Add( new Person("Chris", "Smith", new DateTime(1957, 8, 30)) );
			lstNames.Items.Add( new Person("Jennifer", "Lancing", new DateTime(1939, 1, 27)) );
			lstNames.Items.Add( new Person("Hardeep", "Singh", new DateTime(1969, 12, 11)) );
		}

		private void lstNames_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Make sure something is selected in the list before proceeding.  We
			// could also check SelectedIndex to make sure it's not -1.
			if (lstNames.SelectedItem == null)
			{
				return;
			}

			// Now that we know that something is selected, make sure it is the object
			// associated with it is the correct type.  If it is not then we made a mistake
			// somewhere in the code.
			Debug.Assert(lstNames.SelectedItem is Person);

			// Now it's okay to "downcast" the object associated with the selected list item
			// to a Person.
			Person selectedPerson = (Person)lstNames.SelectedItem;

			// Regardless, if we get this far then display the person's details.
			displayPersonDetails(selectedPerson);

			Debug.WriteLine(lstNames.Text);
		}

		private void displayPersonDetails(Person person)
		{
			Debug.Assert(person != null);

			txtFirstName.Text = person.FirstName;
			txtLastName.Text = person.LastName;
			txtAge.Text = person.Age.ToString();
			txtBirthDate.Text = person.BirthDate.ToLongDateString();
		}
	}

}