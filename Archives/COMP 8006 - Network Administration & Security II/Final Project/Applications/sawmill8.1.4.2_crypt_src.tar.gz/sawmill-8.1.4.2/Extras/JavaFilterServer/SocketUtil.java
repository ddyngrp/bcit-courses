/*
 * IO Utility class
 */


import java.net.*;
import java.io.*;


public class SocketUtil
{
  private Socket s;

  public SocketUtil(Socket s)
  {
	this.s = s;
  }

  public BufferedReader getBufferedReader() throws IOException
  {
	InputStreamReader isr = new InputStreamReader (s.getInputStream ());
	BufferedReader br = new BufferedReader(isr);
	return br;
  }

  public PrintStream getPrintStream() throws IOException
  {
	return (new PrintStream(s.getOutputStream()));
  }

}