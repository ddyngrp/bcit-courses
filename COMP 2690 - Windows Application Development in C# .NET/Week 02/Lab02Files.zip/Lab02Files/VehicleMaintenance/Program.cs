using System;
using System.Globalization;

namespace VehicleMaintenance
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			Menu menu = new MainMenu();
			menu.DoMenu(false);
		}
	}
}
