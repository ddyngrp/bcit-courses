//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"
 
#include "sconfig.h"
 
#if HAVE_STDIO_H
 
#include <stdio.h>

#endif
 
#if HAVE_STDLIB_H
 
#include <stdlib.h>

#endif
 
#include "S68f7bcbebe9a6192b736f378d5d9f0a4.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "Sdd9bc04b09fe41eac38317a995497f2b.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "S5c686a55e1be1e5c2d8a4c8424ee6932.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"
 
#define Sc63a12a290963592b186850929aabfb3 10000
 void S4c88703d7f5d8b2c57fae4400b8ff114(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{ register int x; int Sdd082c5df4d4130a141a913d15596a7a;  char *S3aa47fe36cb5bd910183406b1187fcce = 
getenv("CONTENT_LENGTH"); if (S3aa47fe36cb5bd910183406b1187fcce == 0) Sdd082c5df4d4130a141a913d15596a7a 
= 0; else Sdd082c5df4d4130a141a913d15596a7a = atoi(S3aa47fe36cb5bd910183406b1187fcce); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Se7f17ca48486f7df50f4095fb9fc650a 
= 0; for(x=0; Sdd082c5df4d4130a141a913d15596a7a && (!feof(stdin)); x++) { char *S74cb9e9d22a4b6b9e5060899a09adbf0 
= (char *) S73bf266c9f220cde75e8d320f9398b09(Scc2faae6b412ac43b64129b402c4b88e, stdin,'&',&Sdd082c5df4d4130a141a913d15596a7a); 
S35a4494f00627f79d6796f6234ba4071(); S1af04b42d2b181e54659516371fe58bb(S74cb9e9d22a4b6b9e5060899a09adbf0); 
Sf44c6c924e472a43a87cbd374e3c1daf(S74cb9e9d22a4b6b9e5060899a09adbf0); const char *S0d78aac5e03ed898192a9e8494f1ecad 
= Saee1ff9bc7d8d4d1288f04f76b8b4b25(Scc2faae6b412ac43b64129b402c4b88e, S74cb9e9d22a4b6b9e5060899a09adbf0,'='); 
S35a4494f00627f79d6796f6234ba4071(); (*((S68f7bcbebe9a6192b736f378d5d9f0a4 *) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8014d417de4c76119f4e005537a56266))[S6d6cbe6673721b1104d6dcb8de7beb6a(S0d78aac5e03ed898192a9e8494f1ecad)] 
= S6d6cbe6673721b1104d6dcb8de7beb6a(S74cb9e9d22a4b6b9e5060899a09adbf0); Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Se7f17ca48486f7df50f4095fb9fc650a++; 
Sbf77df85ecaba2fb69a3728a80f84b0b(S74cb9e9d22a4b6b9e5060899a09adbf0); Sbf77df85ecaba2fb69a3728a80f84b0b(S0d78aac5e03ed898192a9e8494f1ecad); 
} }  void S0d6d79649eb8ecd48b0e15c7bd284850(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
char *Sbfff1bda8975763a769e439634717076) { mint S71c2688bae567c8614fd6e477e142708 = 0; while (S71c2688bae567c8614fd6e477e142708 
!= -1) {  S71c2688bae567c8614fd6e477e142708 = Sc91e6762ee3d93d4be3fed12e5b4d86e(Sbfff1bda8975763a769e439634717076, 
"&"); if (S71c2688bae567c8614fd6e477e142708 != -1) Sbfff1bda8975763a769e439634717076[S71c2688bae567c8614fd6e477e142708] 
= 0;  mint Sb31cfeba5290c3b4b46cad9d98ca14df = Sc91e6762ee3d93d4be3fed12e5b4d86e(Sbfff1bda8975763a769e439634717076, 
'='); if (Sb31cfeba5290c3b4b46cad9d98ca14df == -1) Sf4ee370243771c454bd48735594e12a4("$lang_messages.ERROR_HTTP_POST_FORMAT"); 
Sbfff1bda8975763a769e439634717076[Sb31cfeba5290c3b4b46cad9d98ca14df] = 0; char *name = Sbfff1bda8975763a769e439634717076; 
char *Sb79d4a4ac05ebdb8cb70e6b5594e9473 = Sbfff1bda8975763a769e439634717076 + Sb31cfeba5290c3b4b46cad9d98ca14df 
+ 1;  if (name[0]) {   S1af04b42d2b181e54659516371fe58bb(Sb79d4a4ac05ebdb8cb70e6b5594e9473);  Sf44c6c924e472a43a87cbd374e3c1daf(Sb79d4a4ac05ebdb8cb70e6b5594e9473); 
 (*((S68f7bcbebe9a6192b736f378d5d9f0a4 *) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8014d417de4c76119f4e005537a56266))[name] 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473; }   Sbfff1bda8975763a769e439634717076 += S71c2688bae567c8614fd6e477e142708 
+ 1; }  } 

