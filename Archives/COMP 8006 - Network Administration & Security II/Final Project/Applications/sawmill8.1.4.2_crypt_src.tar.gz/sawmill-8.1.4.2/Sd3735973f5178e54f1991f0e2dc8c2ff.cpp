//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sd3735973f5178e54f1991f0e2dc8c2ff.h"

#include "S4768720fc7733e4db52eb3e75b4c1ab0.h"

#include "S171b4aa91e83740b6fc65baf1d751d1a.h"

#include "Sbec4350f3dfbf641a291f807361e51e2.h"

#include "Sb6f8c5b1df214f11587c377ecd86d430.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"
  S5a1ba0c000fac30d20934f585ddbceb4::S5a1ba0c000fac30d20934f585ddbceb4(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S11502692d5c8b57bd211f972305b99fc *S60283a425cf987277e107f9b3baaaa7e, 
S7b13c521578835f6a0c68d7d5119c149 *Sb18a5c39d4e9c730bb94642a96f0fc84, S6935ea702da310c8571074717f076ea7 
*Sf7c07efbb5aaea497ea48b25f1d532e0) { S6ec129777c16ed8568398f5726365a75 = &Scc2faae6b412ac43b64129b402c4b88e; 
S1a14215d7a9ed417e57c419037ad81b9 = S60283a425cf987277e107f9b3baaaa7e; S057e8d652f08fa6cc73b9dd3f3070c01 
= Sb18a5c39d4e9c730bb94642a96f0fc84; S3bced6387f6e5964905bbb72fc146b3e = Sf7c07efbb5aaea497ea48b25f1d532e0; 
 S11502692d5c8b57bd211f972305b99fc *S921a2e276fe5110b0dde80daa3162371 = S057e8d652f08fa6cc73b9dd3f3070c01->S0753f13c160bf1356db257bed981e014(); 
   S6d6cbe6673721b1104d6dcb8de7beb6a Sd9dc751831ae38fd8fff57a1fb787ec0 = "ris_"; Sd9dc751831ae38fd8fff57a1fb787ec0 
+= S60283a425cf987277e107f9b3baaaa7e->S50725c229541d49fe591346687d603e6(); Sd9dc751831ae38fd8fff57a1fb787ec0 
+= "_"; S6d6cbe6673721b1104d6dcb8de7beb6a S0f359465004715f514a06f872695f30b = S3bced6387f6e5964905bbb72fc146b3e->S3e4d43814c27885703f44315755694ae->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e); 
S0f359465004715f514a06f872695f30b.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
".", "_"); Sd9dc751831ae38fd8fff57a1fb787ec0 += S0f359465004715f514a06f872695f30b; Sd9dc751831ae38fd8fff57a1fb787ec0 
+= "_"; if (S3bced6387f6e5964905bbb72fc146b3e->Sf67e8dafb94dc766559634006a45dcee == Sab7c78dfc40fec30fd9911b438046c24) 
{ Sd9dc751831ae38fd8fff57a1fb787ec0 += "ge"; Sd9dc751831ae38fd8fff57a1fb787ec0 += "_"; Sd9dc751831ae38fd8fff57a1fb787ec0 
+= S3bced6387f6e5964905bbb72fc146b3e->S07ecc7045b575372cd847cb0119cee13->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e); 
} else if (S3bced6387f6e5964905bbb72fc146b3e->Sf67e8dafb94dc766559634006a45dcee == Sc9f145eac8c2a8a97a400cf1603eb3d7) 
{ Sd9dc751831ae38fd8fff57a1fb787ec0 += "le"; Sd9dc751831ae38fd8fff57a1fb787ec0 += "_"; Sd9dc751831ae38fd8fff57a1fb787ec0 
+= S3bced6387f6e5964905bbb72fc146b3e->S07ecc7045b575372cd847cb0119cee13->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e); 
} else { S4fa4ca5d73e74ca8109426dbef6c2220("Internal: unsupported condition in SSQLUniqueIndexConditionRowSelector::SSQLUniqueIndexConditionRowSelector(): " 
<< S3bced6387f6e5964905bbb72fc146b3e->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e)); 
}   S6d6cbe6673721b1104d6dcb8de7beb6a Sc9e0199bb8dc0ed5dbbb12cc2e92a108 = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "TemporaryFiles" + Sfae98e901cdbf1a268ec544cd9457415 + "Task" + Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, 
Sd526fda708dbbad24d7de62fea256c14()) + Sfae98e901cdbf1a268ec544cd9457415 + Sd9dc751831ae38fd8fff57a1fb787ec0; 
    if (S311fc4dffa3ce0758ebb8291e5685a69(Scc2faae6b412ac43b64129b402c4b88e, Sc9e0199bb8dc0ed5dbbb12cc2e92a108)) 
{ S6fc1422ce2696af6e55125976fb8eb60 = S777a171901c233a31d2c8d34592def2d(Scc2faae6b412ac43b64129b402c4b88e, 
NULL, Sd9dc751831ae38fd8fff57a1fb787ec0.c_str(), true, true, Sc9e0199bb8dc0ed5dbbb12cc2e92a108.c_str()); 
  } else {  S7ca5d44c3992eca4f11ed4ee768968cd *S83b1913201260a0e8936f053b2521dd8 = Sc3057ef3d8b0af864991d43b59105f43(Scc2faae6b412ac43b64129b402c4b88e, 
""); S83b1913201260a0e8936f053b2521dd8->S8c964e0b43d59121cd86751a2578054e(Scc2faae6b412ac43b64129b402c4b88e, 
"header"); S83b1913201260a0e8936f053b2521dd8->S339ec4ebc6f2f5e7fc68e895ded32ae7("row_in_set", ""); S7ca5d44c3992eca4f11ed4ee768968cd 
*S93ed6f9c475f3d81aed028811bc2bb23 = S83b1913201260a0e8936f053b2521dd8->S6c7d84bb91509e8c72e7dd25a6eed444("row_in_set"); 
S93ed6f9c475f3d81aed028811bc2bb23->S339ec4ebc6f2f5e7fc68e895ded32ae7("field_name", "row_in_set"); S93ed6f9c475f3d81aed028811bc2bb23->S339ec4ebc6f2f5e7fc68e895ded32ae7("table_field_type", 
"int8"); S6fc1422ce2696af6e55125976fb8eb60 = S777a171901c233a31d2c8d34592def2d(Scc2faae6b412ac43b64129b402c4b88e, 
S83b1913201260a0e8936f053b2521dd8, Sd9dc751831ae38fd8fff57a1fb787ec0.c_str(), S471970bbce25bc5469c9c36266c22dfa, 
false, Sc9e0199bb8dc0ed5dbbb12cc2e92a108.c_str());    S6bcf99fce07707f06693cebe6a409e38(Sd6d3ea77b27eec0d4f2cecd46184b12f, 
"Building table " << Sd9dc751831ae38fd8fff57a1fb787ec0 << " of rows matching condition " << Sf7c07efbb5aaea497ea48b25f1d532e0->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e) 
<< endl); rownum_t Sc2e84de451e770a258d44ae986661000 = S921a2e276fe5110b0dde80daa3162371->S9b87ec188ee0d8b8517cc332082a0a9c(); 
for (rownum_t S59f2af6db8dcf720f15981c54a3a8fc5 = 1; S59f2af6db8dcf720f15981c54a3a8fc5 < Sc2e84de451e770a258d44ae986661000; 
S59f2af6db8dcf720f15981c54a3a8fc5++) {  muint Sb79d4a4ac05ebdb8cb70e6b5594e9473 = S921a2e276fe5110b0dde80daa3162371->Se6c2454c6dceabfb0190c4f07f3001d8(Scc2faae6b412ac43b64129b402c4b88e, 
S59f2af6db8dcf720f15981c54a3a8fc5, 0);  bool Se29dab00b28fe2fbc1938f628b1c1a14 = false; switch(S3bced6387f6e5964905bbb72fc146b3e->Sf67e8dafb94dc766559634006a45dcee) 
{ case Sab7c78dfc40fec30fd9911b438046c24: { mint Sa226f776c090ba64e10cf52b6cb54f74 = S3bced6387f6e5964905bbb72fc146b3e->S07ecc7045b575372cd847cb0119cee13->Sb6e4900847652f8228025b068be4043b(Scc2faae6b412ac43b64129b402c4b88e, 
S1a14215d7a9ed417e57c419037ad81b9, S59f2af6db8dcf720f15981c54a3a8fc5);  Se29dab00b28fe2fbc1938f628b1c1a14 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473 >= Sa226f776c090ba64e10cf52b6cb54f74; } break; case Sc9f145eac8c2a8a97a400cf1603eb3d7: 
{ mint Sa226f776c090ba64e10cf52b6cb54f74 = S3bced6387f6e5964905bbb72fc146b3e->S07ecc7045b575372cd847cb0119cee13->Sb6e4900847652f8228025b068be4043b(Scc2faae6b412ac43b64129b402c4b88e, 
S1a14215d7a9ed417e57c419037ad81b9, S59f2af6db8dcf720f15981c54a3a8fc5);  Se29dab00b28fe2fbc1938f628b1c1a14 
= Sb79d4a4ac05ebdb8cb70e6b5594e9473 <= Sa226f776c090ba64e10cf52b6cb54f74; } break; default: { S4fa4ca5d73e74ca8109426dbef6c2220("Internal: unsupported condition in SSQLUniqueIndexConditionRowSelector::SSQLUniqueIndexConditionRowSelector(): " 
<< S3bced6387f6e5964905bbb72fc146b3e->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e)); 
} }     S6fc1422ce2696af6e55125976fb8eb60->Sbb3816bd614474e27aec873aed072563(Scc2faae6b412ac43b64129b402c4b88e, 
S59f2af6db8dcf720f15981c54a3a8fc5 - 1, 0, Se29dab00b28fe2fbc1938f628b1c1a14);    }  S6bcf99fce07707f06693cebe6a409e38(Sd6d3ea77b27eec0d4f2cecd46184b12f, 
"Done building rows table " << Sd9dc751831ae38fd8fff57a1fb787ec0 << endl); S6bcf99fce07707f06693cebe6a409e38(Sd6d3ea77b27eec0d4f2cecd46184b12f, 
"Number of rows in " << Sd9dc751831ae38fd8fff57a1fb787ec0 << ": " << S6fc1422ce2696af6e55125976fb8eb60->S9b87ec188ee0d8b8517cc332082a0a9c() 
<< endl);   }  }  S5a1ba0c000fac30d20934f585ddbceb4::~S5a1ba0c000fac30d20934f585ddbceb4() { Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e = *S6ec129777c16ed8568398f5726365a75;   Saeb14fdf6f2105b186751ec63c557c1f(Scc2faae6b412ac43b64129b402c4b88e, 
S6fc1422ce2696af6e55125976fb8eb60); }   bool S5a1ba0c000fac30d20934f585ddbceb4::Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, uint64 S3d7bef5b94828f4c5b1e6804605daa54) { bool Se29dab00b28fe2fbc1938f628b1c1a14 
= S6fc1422ce2696af6e55125976fb8eb60->Se6c2454c6dceabfb0190c4f07f3001d8(Scc2faae6b412ac43b64129b402c4b88e, 
S3d7bef5b94828f4c5b1e6804605daa54, 0);  return Se29dab00b28fe2fbc1938f628b1c1a14; } 

