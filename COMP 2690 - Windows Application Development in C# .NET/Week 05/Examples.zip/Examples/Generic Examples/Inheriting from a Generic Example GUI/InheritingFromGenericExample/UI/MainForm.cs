using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace InheritingFromGenericExample
{
	public partial class MainForm : Form
	{
		private EmployeeCollection employees;

		public MainForm()
		{
			InitializeComponent();

			employees = new EmployeeCollection();
			employees.Add(new Employee("Barney", new DateTime(1963, 2, 5),  55000));
			employees.Add(new Employee("Janet", new DateTime(1954, 12, 16), 90000));
			employees.Add(new Employee("Ina", new DateTime(1970, 5, 25), 60000));
			employees.Add(new Employee("Amber", new DateTime(1980, 8, 11), 95000));
			employees.Add(new Employee("Frank", new DateTime(1941, 9, 15), 35000));
			employees.Add(new Employee("Sandra", new DateTime(1937, 2, 20), 66000));
			employees.Add(new Employee("Hardeep", new DateTime(1949, 1, 5),  62000));
			employees.Add(new Employee("Mindy", new DateTime(1959, 10, 15), 79000));
			employees.Add(new Employee("Al", new DateTime(1962, 7, 10), 80000));
			employees.Add(new Employee("Louis", new DateTime(1962, 6, 5),  81000));
			employees.Add(new Employee("Frances", new DateTime(1968, 6, 15), 72000));
			employees.Add(new Employee("Mauri", new DateTime(1951, 6, 26), 55000));

			lstEmployees.Sorted = true;
			lstEmployees.DataSource = employees;
			lstEmployees.DisplayMember = "Name";
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			displayEmployeeDetails();
		}

		private void listByAgeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			GetAgeForm ageDlg = new GetAgeForm();
			ageDlg.Text = "Age Filter";
			ageDlg.Prompt = "Enter an minimum age";
			if(ageDlg.ShowDialog() == DialogResult.OK)
			{
				EmployeeCollection employeesOfMinimumAge = employees.GetByAtLeastAge(ageDlg.Age);
				
				EmployeeListForm empListDlg = new EmployeeListForm(employeesOfMinimumAge);
				empListDlg.Text = 
						string.Format("Employees who are at least {0} years old", ageDlg.Age);
				empListDlg.ShowDialog();
				empListDlg.Dispose();
			}
			ageDlg.Dispose();
		}

		private void lstEmployees_SelectedIndexChanged(object sender, EventArgs e)
		{
			displayEmployeeDetails();
		}

		private void displayEmployeeDetails()
		{
			if (lstEmployees.SelectedItem != null)
			{
				Employee selectedEmployee = lstEmployees.SelectedItem as Employee;
				Debug.Assert(selectedEmployee != null, "The ListBox should have Employee objects in it.");

				lblSalary.Text = selectedEmployee.AnnualSalary.ToString("C");
				lblEarnings.Text = selectedEmployee.TotalCompensationEver.ToString("C");
				lblAge.Text = selectedEmployee.Age.ToString();
			}
			else
			{
				lblSalary.Text = lblEarnings.Text = lblAge.Text = "";
			}
		}
	}
}