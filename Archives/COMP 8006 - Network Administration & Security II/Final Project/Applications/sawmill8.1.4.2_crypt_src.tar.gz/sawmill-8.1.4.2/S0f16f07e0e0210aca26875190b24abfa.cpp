//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sf8bf294df8e289e8dc44ab73a9dd1167.h"

#include "sconfig.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#if HAVE_TIME_H
 
#include <time.h>

#endif
 
#if HAVE_STDIO_H
 
#include <stdio.h>

#endif
 
#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "Se31981d874cf90aae9b970e888bfb32b.h"

#include "S508c8eba79cf8e3f0f3efec699333525.h"

#include "S5c686a55e1be1e5c2d8a4c8424ee6932.h"

#include "Sa388ec26652b2aee4f05f41c19852b30.h"

#include "S03b4aa5755dc381488543322f8a56e0a.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "S17be0f68f5d7d8233d466e33746ac31e.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#include "S64b7320e919729c8be37fe1c222318eb.h"

#include "S963dcac52f0380ef96a69e447a6fe65d.h"
  void S89c01458b233809a62fdbea6bbae33a5(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
bool S1b033a86f02f4b90ca935e59c3a2ccbe) {  char S97c11f16b41244bff46393801be83410[30]; time_t S3efe85651f7412622a4b7e6bc2f87af5 
= time(NULL); 
#if HAVE_LOCALTIME_R
 struct tm S06a7c056fbf01ef7c56dcb2c3f508dec; struct tm *S6b72e270bf638d4b30bcdc9cbee748c2 = localtime_r(&S3efe85651f7412622a4b7e6bc2f87af5, 
&S06a7c056fbf01ef7c56dcb2c3f508dec); 
#else
 struct tm *S6b72e270bf638d4b30bcdc9cbee748c2 = localtime(&S3efe85651f7412622a4b7e6bc2f87af5); 
#endif
 strftime(S97c11f16b41244bff46393801be83410, 30, "[%d/%b/%Y:%H:%M:%S -0000]", S6b72e270bf638d4b30bcdc9cbee748c2); 
 const char *S2cd618805481456d2bc2ca3e27f6ba0c = Scc2faae6b412ac43b64129b402c4b88e.S6e534e2de6f6ee00118685ea47c38452.c_str(); 
 if (Sa65ce13717451b94f10482e8ef0770a2(S2cd618805481456d2bc2ca3e27f6ba0c) == 0) S2cd618805481456d2bc2ca3e27f6ba0c 
= "-"; else if (S94b9f013d1697e8631ce1122b9e529b5(S2cd618805481456d2bc2ca3e27f6ba0c, ' ')) { S2cd618805481456d2bc2ca3e27f6ba0c 
= Sbdc70c498cd54d91c938377bbdbd2897(Scc2faae6b412ac43b64129b402c4b88e, "\"", S2cd618805481456d2bc2ca3e27f6ba0c, 
"\""); }  const char *S655215778b8a2d1850f1d59bb2cbc69d; if (S1b033a86f02f4b90ca935e59c3a2ccbe) S655215778b8a2d1850f1d59bb2cbc69d 
= Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.Sf904eda9c8bf79040f8d6f7f1305d69f.c_str(); 
else S655215778b8a2d1850f1d59bb2cbc69d = S303ebfc6eeaf1c153a3882a61471ac48("write_log_entry_for_page"); 
S6d6cbe6673721b1104d6dcb8de7beb6a Sd8ceb361dd14427966d2087d54dd19ff = Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S96a674e765f33aa64936a8a27d0db394 
+ " - " + S2cd618805481456d2bc2ca3e27f6ba0c + " " + S97c11f16b41244bff46393801be83410 + " \"GET " + 
S655215778b8a2d1850f1d59bb2cbc69d + " HTTP/1.0\" 200 1 " + (Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8a10b4a9fca910affc02a1e479196718.length() 
? Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S8a10b4a9fca910affc02a1e479196718.c_str() 
: "-") + " \"" + Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S0d2c98b40fbbdd266aecaabc74ea63e5 
+ "\"\n";   S49d5518cb68be5829037dbed2be45396(Sb58c26af62a2dca70604fc8563b509b8("security.default_permissions")); 
FILE *S0dc30a348d2bad2a700d9e95b856485d = NULL;  if (S1b033a86f02f4b90ca935e59c3a2ccbe) {  if (!Sbe99661f85ab38b59aba1bfa9577f41a) 
{ S6d6cbe6673721b1104d6dcb8de7beb6a S3b5fe948d60282bd2e9a47b34af40d09 = S386ab9f82f83ce53d791996ba5e7db8e() 
+ "WebServerAccessLog"; Sbe99661f85ab38b59aba1bfa9577f41a = S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, 
S3b5fe948d60282bd2e9a47b34af40d09.c_str(), "a"); S6d6cbe6673721b1104d6dcb8de7beb6a S69a52c4b49689c7264ebd089e667a03a 
= S386ab9f82f83ce53d791996ba5e7db8e() + "Locks" + Sfae98e901cdbf1a268ec544cd9457415 + "WebServerAccessLog.lock"; 
Scc623d512b3f914c49ab5433524e2487 = new Se2c73b544fed1ea7b7b2b0c2972c57b4(&Scc2faae6b412ac43b64129b402c4b88e, 
S69a52c4b49689c7264ebd089e667a03a, true, false, false); S49d5518cb68be5829037dbed2be45396(Sb58c26af62a2dca70604fc8563b509b8("security.default_permissions")); 
} S0dc30a348d2bad2a700d9e95b856485d = Sbe99661f85ab38b59aba1bfa9577f41a; }   else { S0dc30a348d2bad2a700d9e95b856485d 
= S0b0bc33697c43de365cfff19bccb9a88(Scc2faae6b412ac43b64129b402c4b88e, S303ebfc6eeaf1c153a3882a61471ac48("output.log_to_write_pathname"), 
"a"); S49d5518cb68be5829037dbed2be45396(Sb58c26af62a2dca70604fc8563b509b8("security.default_permissions")); 
} Scc623d512b3f914c49ab5433524e2487->S053ae7af34c7fda6288bd1dfa31e5849(&Scc2faae6b412ac43b64129b402c4b88e); 
 size_t S849f1be76d98c196634b07e300cb6a7c = fwrite(Sd8ceb361dd14427966d2087d54dd19ff.c_str(), 1, Sd8ceb361dd14427966d2087d54dd19ff.length(), 
S0dc30a348d2bad2a700d9e95b856485d); if (S849f1be76d98c196634b07e300cb6a7c != Sd8ceb361dd14427966d2087d54dd19ff.length()) 
S41718a43d7c0f9585220d093d423e1f3(S303ebfc6eeaf1c153a3882a61471ac48("miscellaneous.log_to_write_pathname"), 
Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, Sd8ceb361dd14427966d2087d54dd19ff.length()), 
Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, ferror(S0dc30a348d2bad2a700d9e95b856485d)), 
"$lang_messages.ERROR_WRITE_SHORT");  fflush(S0dc30a348d2bad2a700d9e95b856485d);  if (!S1b033a86f02f4b90ca935e59c3a2ccbe) 
Sd33302a1daa8e684f02934fd9419ec83(Scc2faae6b412ac43b64129b402c4b88e, S0dc30a348d2bad2a700d9e95b856485d); 
Scc623d512b3f914c49ab5433524e2487->Release(&Scc2faae6b412ac43b64129b402c4b88e); if (!S1b033a86f02f4b90ca935e59c3a2ccbe) 
{ S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Content-type: text/html\n\n")); S709f8a104a477b9e6883c170d8a6a334( Sd1009cdb18832e7e06da36cebf858d43(Scc2faae6b412ac43b64129b402c4b88e, 
"Logged")); } } 

