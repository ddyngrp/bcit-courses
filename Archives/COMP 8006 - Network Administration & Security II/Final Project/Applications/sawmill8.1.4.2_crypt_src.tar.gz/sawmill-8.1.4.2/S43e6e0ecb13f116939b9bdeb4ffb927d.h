//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S524a93b3475e4bcc7ba2fe110ae7943c
 
#define S524a93b3475e4bcc7ba2fe110ae7943c
 enum S2649cee0b4276a29ff5fec1556f8325e { S90b271367b2bd4a3fa3def7bf185101d,     S31a800f863eb6915eb712369b632414c, 
Sb4c068b4464996202f62e289dd6d9472, Sa7fc0a3b7d28b55dfb5c691baee1d94d, S6afa0191043e64f5e76ac1c8c02acd5e, 
S320dfa74998417ddb6b28392f1d7c1d2, S89f24d0cf4b2c66545720d2a3798b01a, S6f7f5f097f06d19ae9d53ee5259d4e2d 
}; 
#endif


