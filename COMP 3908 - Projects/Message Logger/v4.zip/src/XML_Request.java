/*
 * XML_Request.java
 *
 * MLogger, 2008
 * Confidential and proprietary.
 */
package src; 

/**
 * XML generator class interface for server communications.
 * Each implementation should be generate valid SOAP:XML for MLogger Server.
 * Note: Use XML_Response to decode XML returned from the server.
 */
 public interface XML_Request {

	/**
	 * Generates the XML to be sent to the server.
	 */
    public String toString();
}
