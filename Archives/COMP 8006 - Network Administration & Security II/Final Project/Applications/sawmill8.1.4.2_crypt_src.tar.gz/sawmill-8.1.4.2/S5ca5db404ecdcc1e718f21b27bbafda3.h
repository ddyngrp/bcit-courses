//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sbe0ca63d51177b6424f1e06fa81c4de4
 
#define Sbe0ca63d51177b6424f1e06fa81c4de4
 
#include "sconfig.h"

#include "S4251970c545ff7063c10e0ac5324e0d8.h"

#include "S6d6cbe6673721b1104d6dcb8de7beb6a.h"
 
#if HAVE_NAMESPACES
 typedef std::map<S6d6cbe6673721b1104d6dcb8de7beb6a, mint, std::less<S6d6cbe6673721b1104d6dcb8de7beb6a> 
> Sa3d945a809e1366cd3e51ec4dff9525b; 
#else
 typedef S4251970c545ff7063c10e0ac5324e0d8(S6d6cbe6673721b1104d6dcb8de7beb6a, mint, less<S6d6cbe6673721b1104d6dcb8de7beb6a>) 
Sa3d945a809e1366cd3e51ec4dff9525b; 
#endif
 
#endif


