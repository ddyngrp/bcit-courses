//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S077fa128367d2b16cf7ed5886c523cd7.h"

#include "S1a14215d7a9ed417e57c419037ad81b9.h"
  S6a35ff03098e93db8dc66a2a6824e1e8::S6a35ff03098e93db8dc66a2a6824e1e8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S6ebd5941df466d9a1c9cc8263c03ef42 *S60283a425cf987277e107f9b3baaaa7e) 
{ S1a14215d7a9ed417e57c419037ad81b9 = S60283a425cf987277e107f9b3baaaa7e; }                   bool S6a35ff03098e93db8dc66a2a6824e1e8::Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, uint64 S3d7bef5b94828f4c5b1e6804605daa54) {  return true; } 

