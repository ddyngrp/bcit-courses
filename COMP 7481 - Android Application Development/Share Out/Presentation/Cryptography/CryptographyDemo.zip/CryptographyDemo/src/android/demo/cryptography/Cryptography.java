package android.demo.cryptography;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Cryptography {
	
	String mode;
	String key;
	String text;
	final String HEX = "0123456789ABCDEF";
	
	public Cryptography(String m, String k, String t) {
		mode = m;
		key = k;
		text = t;
	}
	
	public String encrypt() throws Exception {
		byte[] rawKey = getRawKey(key.getBytes());
		byte[] result = doEncrypt(rawKey, text.getBytes());
		return toHex(result);
	}
	
	private byte[] doEncrypt(byte[] raw, byte[] clear) throws Exception {
		SecretKeySpec sKeySpec = new SecretKeySpec(raw, mode);
		Cipher c = Cipher.getInstance(mode);
		c.init(Cipher.ENCRYPT_MODE, sKeySpec);
		byte[] encrypted = c.doFinal(clear);
		return encrypted;
	}
	
	public String decrypt() throws Exception {
		byte[] rawKey = getRawKey(key.getBytes());
		byte[] encrypted = toByte(text);
		byte[] result = doDecrypt(rawKey, encrypted);
		return new String(result);
	}
	
	private byte[] doDecrypt(byte[] raw, byte[] encrypted) throws Exception {
		SecretKeySpec sKeySpec = new SecretKeySpec(raw, mode);
		Cipher c = Cipher.getInstance(mode);
		c.init(Cipher.DECRYPT_MODE, sKeySpec);
		byte[] decrypted = c.doFinal(encrypted);
		return decrypted;
	}
	
	private byte[] getRawKey(byte[] key) throws Exception {
		KeyGenerator kgen = KeyGenerator.getInstance(mode);
		SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
		sr.setSeed(key);
		if (mode.equals("DES")) {
			kgen.init(64, sr);
		} else {
			kgen.init(128, sr);
		}
		SecretKey skey = kgen.generateKey();
		byte[] rawKey = skey.getEncoded();
		return rawKey;
	}
	
	private String fromHex(String hex) {
		return new String(toByte(hex));
	}
	
	private byte[] toByte(String hexString) {
		int len = hexString.length()/2;
		byte[] result = new byte[len];
		for (int i = 0; i < len; i++)
			 result[i] = Integer.valueOf(hexString.substring(2*i, 2*i+2), 16).byteValue();
		return result;
	}
	
	private String toHex(String txt) {
		return toHex(txt.getBytes());
	}
	
	private String toHex(byte[] b) {
		if (b == null) return "";
		StringBuffer result = new StringBuffer(2*b.length);
		for (int i = 0; i < b.length; i++) {
			appendHex(result, b[i]);
		}
		return result.toString();
	}
	
	private void appendHex(StringBuffer sb, byte b) {
		sb.append(HEX.charAt((b>>4)&0x0f)).append(HEX.charAt(b&0x0f));
	}

}
