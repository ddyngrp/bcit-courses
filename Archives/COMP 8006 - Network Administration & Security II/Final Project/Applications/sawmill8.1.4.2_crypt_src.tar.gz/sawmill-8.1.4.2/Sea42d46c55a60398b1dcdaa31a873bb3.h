//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sd0412795701abc9a991deec90ca232c4
 
#define Sd0412795701abc9a991deec90ca232c4
 
#include "Sd295dc2269861866e4d15626cf1d8abe.h"
 class S8bc667a0d430f9dcea039427d0d0fb63 : public Sfe7618ef4b0786b73a2a9acfc49b94ce { public: S8bc667a0d430f9dcea039427d0d0fb63(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, bool Sd202583e3cbae0077742a0e579348338); virtual void S8a548fbbd62911c60c284937c41e0a0f(void); 
virtual filelen_t S69229d6871c2cd0b77fe33f05144f0e9(S71b409bf2aa98ff69b95ba16e4cb2f05 &Sf472b15dde2a4399a70a2e7fa0b6eb6f, 
char *S2985b4614d2618f174fd3c6fca49b42f, filelen_t Sd8d77b1ed00928dcc1bbf26f7598511d); virtual void 
S577943ab58039c24baeac25a70030170(void); virtual S6d6cbe6673721b1104d6dcb8de7beb6a Sdb807cbd507db99fefe8d0045ddb25dc(void); 
virtual void S3f8a63896208e84c6eb5224d6b46ba6b(void); virtual bool S906d79a2db224b30265ca1043cf8fe6b(void) 
{ return false; } virtual time_t S26926d64837702f55b2920936df56399(void); virtual double Sa645ef186899b7d89024160d78d7a66c(void); 
virtual S6d6cbe6673721b1104d6dcb8de7beb6a Sbdeeade5060cfdaf59b062f643abfb67(void); virtual const char 
*S02e0bdbd0245ef077b2ca7c32dbe4cf0(); }; 
#endif


