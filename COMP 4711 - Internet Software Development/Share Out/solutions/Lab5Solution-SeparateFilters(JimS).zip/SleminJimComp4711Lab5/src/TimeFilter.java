/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import org.jdom.filter.Filter;
import org.jdom.*;

/**
 *
 * @author A00702683
 */
public class TimeFilter implements Filter {

    public boolean matches(Object obj) {

        int startTime;
        
        if(!(obj instanceof Element))
            return false;
        
        Element elem = (Element)obj;
        
        if(!elem.getName().equals("programme"))
            return false;

        startTime = Integer.parseInt(elem.getAttributeValue("start").substring(8, 10));

        return (startTime >= 8 && startTime <11);
    }
    
}
