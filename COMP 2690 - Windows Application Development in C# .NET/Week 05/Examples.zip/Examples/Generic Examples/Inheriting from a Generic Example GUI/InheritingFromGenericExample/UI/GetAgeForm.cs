using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace InheritingFromGenericExample
{
	public partial class GetAgeForm : Form
	{
		private int age;

		public GetAgeForm()
		{
			InitializeComponent();

			// By default, there is no prompt.
			lblPrompt.Text = "";
		}

		public int Age { get { return age; } }

		public string Prompt
		{
			get { return lblPrompt.Text; }
			set 
			{ 
				// Should probably set a maximum length so that the text does
				// not wrap and conflict with the TextBox location.
				lblPrompt.Text = value; 
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if( !int.TryParse(txtInput.Text, out age) || age < 1 )
			{
				MessageBox.Show("Please enter a valid age of at least 1.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				txtInput.Select();
				txtInput.SelectAll();
			}
			else
			{
				DialogResult = DialogResult.OK;
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}