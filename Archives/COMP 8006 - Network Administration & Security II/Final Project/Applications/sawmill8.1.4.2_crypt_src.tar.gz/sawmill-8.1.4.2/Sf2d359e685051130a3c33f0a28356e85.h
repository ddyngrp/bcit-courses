//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S3e30a38945d55d9b5cfa765e635b068b
 
#define S3e30a38945d55d9b5cfa765e635b068b
 
#include "sconfig.h"

#include "Sf9922ee12c0191f731481fd32578283b.h"
 class S6ebd5941df466d9a1c9cc8263c03ef42; class Sc51497dedb5c0712f20ccaa9831c0365; class Seb5c99c31ec05c2a33b7adfe044b2407 
: public S4f4955a74b11dc1f8b279197db71427f { private: S4f4955a74b11dc1f8b279197db71427f *S7e68f03d82796cb25619fb86df299474; 
S4f4955a74b11dc1f8b279197db71427f *S64820d26353b97a91928175a4cb5ab44; muint Sb17fed55d22eaeb6c09a4501e72b72fd; 
muint S877a92819da84a42c21704f1e891c397; public: Seb5c99c31ec05c2a33b7adfe044b2407(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S4f4955a74b11dc1f8b279197db71427f *S7e68f03d82796cb25619fb86df299474, 
S4f4955a74b11dc1f8b279197db71427f *S64820d26353b97a91928175a4cb5ab44); virtual ~Seb5c99c31ec05c2a33b7adfe044b2407(); 
  virtual bool Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
uint64 S3d7bef5b94828f4c5b1e6804605daa54); virtual rownum_t S1f2884441072ae4fe0ccdf040e11970b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); };  
#endif


