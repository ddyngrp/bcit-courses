using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ListBoxExample
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			// First, some input validation.
			if (txtName.Text == "")
			{
				MessageBox.Show("Please enter a name first.", "Add Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
			{
				// Add name from the TextBox into the ListBox.  By default,
				// the new ListBox item will be added to the end of the list.
				lstNames.Items.Add(txtName.Text);
			}

			// Send the input focus to the TextBox control and select any text it has.
			txtName.Select();
			txtName.SelectAll();
		}

		private void btnRemove_Click(object sender, EventArgs e)
		{
			int selectedIndex = lstNames.SelectedIndex;

			// First, some input validation.  In this case, the input is the selected
			// list index.  An index of -1 indicates that nothing is selected.
			if (lstNames.Items.Count == 0)
			{
				MessageBox.Show("The list is empty.", "Remove Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else if (selectedIndex == -1)
			{
				MessageBox.Show("Please select a name to remove first.", "Remove Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
			{
				// Remove the selected item from the list.
				lstNames.Items.RemoveAt(selectedIndex);
			}
		}
	}

}