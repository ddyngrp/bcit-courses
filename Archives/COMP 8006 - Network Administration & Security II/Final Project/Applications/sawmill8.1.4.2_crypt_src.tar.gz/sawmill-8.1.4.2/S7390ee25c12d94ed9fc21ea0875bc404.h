//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































   
#define ACCEPT_THIRD_PARAM_INT 1
            
#define HAVE_ALLOCA 1
  
#define HAVE_ALLOCA_H 1
  
#define HAVE_BOOST_CAPABLE_COMPILER 1
  
#define HAVE_BZERO 1
  
#define HAVE_DIRENT_H 1
    
#define HAVE_FCNTL_H 1
  
#define HAVE_GETDOMAINNAME 1
  
#define HAVE_GETPAGESIZE 1
  
#define HAVE_INTTYPES_H 1
  
#define HAVE_LIBPTHREAD 1
  
#define HAVE_LIMITS_H 1
    
#define HAVE_MALLOC_H 1
  
#define HAVE_MEMORY_H 1
  
#define HAVE_MMAP 1
  
#define HAVE_NAMESPACES 1
  
#undef HAVE_NANOSLEEP
    
#define HAVE_PTHREAD 1
  
#undef HAVE_PTHREAD_ATTR_SETSCHEDPARAM
  
#define HAVE_REGCOMP 1
  
#define HAVE_RE_COMP 1
  
#define HAVE_SEMAPHORES 1
  
#define HAVE_SEMAPHORE_H 1
    
#define HAVE_STDINT_H 1
  
#define HAVE_STDLIB_H 1
  
#define HAVE_STRERROR 1
  
#define HAVE_STRINGS_H 1
  
#define HAVE_STRING_H 1
  
#define HAVE_STRSTR 1
      
#define HAVE_ST_BLKSIZE 1
  
#define HAVE_ST_BLOCKS 1
      
#define HAVE_SYS_STAT_H 1
  
#define HAVE_SYS_TYPES_H 1
  
#define HAVE_SYS_WAIT_H 1
  
#undef HAVE_UNISTD_H
  
#define HAVE_USLEEP 1
  
#define HAVE_VPRINTF 1
  
#define PACKAGE "sawmill"
  
#define PACKAGE_BUGREPORT ""
  
#define PACKAGE_NAME ""
  
#define PACKAGE_STRING ""
  
#define PACKAGE_TARNAME ""
  
#define PACKAGE_VERSION ""
    
#define STDC_HEADERS 1
    
#define VERSION "6.3.4"
      

