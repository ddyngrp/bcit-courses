/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jim
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        who();
        when();
        where();
    }
    
    /**
     * Display the title & description of all Dr Who shows on BBC3.
     * How many shows of the total shown on BBC3 pertain to Dr Who?
     * Use the *title* element to test.
     */
    public static void who() {
        System.out.println("? of ? shows on BBC3 pertain to Dr Who");
    }
    
    /**
     * Display the title, description & air time of all shows on between 8 & 11pm (local time) on TVDATA.
     * Order the display by air time, so it looks like a real schedule
     */
    public static void when() {
        System.out.println("...");
    }
    
    /**
     * Display the title, description & air time of all news shows on TVDATA.
     * Use the category element to determine these.
     */
    public static void where() {
        System.out.println("...");
    }



}
