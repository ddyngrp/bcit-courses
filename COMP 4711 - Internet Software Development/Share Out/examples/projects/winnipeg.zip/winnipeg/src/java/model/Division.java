/*
 * Model for an CFL division
 * 
 * @author  Jim Parry
 */
package model;

import java.util.*;

public class Division {

    /** Division name */
    private String name = null;
    /** Map of the teams in the division */
    private SortedMap<String, Team> teams = null;

    /** Convenience constructor */
    public Division(String name) {
        this.name = name;
        teams = new TreeMap<String, Team>();

    }

    /** Add a team to the division */
    public void add(Team team) {
        teams.put(team.getId(), team);
        team.setDivision(this);
    }

    /** Accessor for the division name */
    public String getName() {
        return name;
    }

    /** Accessor for the teams in the division */
    public SortedMap<String, Team> getTeams() {
        return teams;
    }

}
