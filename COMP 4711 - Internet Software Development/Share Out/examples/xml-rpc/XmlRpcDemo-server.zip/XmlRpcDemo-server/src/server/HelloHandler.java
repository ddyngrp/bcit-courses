public class HelloHandler {
	public String sayHello(String name) {
		return "Hello " + name;
	}
}
