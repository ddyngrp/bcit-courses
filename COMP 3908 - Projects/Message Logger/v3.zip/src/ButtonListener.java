/*
 * ButtonListenner.java
 *
 * <Trusterra>, 2003-2008
 * Confidential and proprietary.
 *@param Zhang,Mang(Edison)
 */

package src;
import java.lang.Exception;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.component.ActiveAutoTextEditField;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Status;
import net.rim.device.api.ui.UiApplication;


/**
 * ButtonListener class
 *This class inherits from the FieldChageListener class, which captures all the
 *button pressing and react according to which button is clicked.
 */
public final class ButtonListener implements FieldChangeListener {
    private MediaController               mc;
    private EditField                     title;
    private ActiveAutoTextEditField       description;
    /**
    *ButtonListener Constructor
    *@param mc - media controller for organizing all the media items.
    */
    ButtonListener(MediaController mc,EditField title,ActiveAutoTextEditField description) {
        this.mc = mc;
        this.title = title;
        this.description = description;
    }
    /**
    *fieldChanged
    *inherited method for capturing field changes. in this case, any button click
    *is captured and processed.
    *
    *@param field       field that has any change to it from user usage.
    *@param context     field context
    */
    public void fieldChanged(Field field, int context){
        String btnLabel;
        int button;
        //button acton handler
        ButtonField btn = (ButtonField)field;
        btnLabel = btn.getLabel();
        //when image button is clicked
        if (btnLabel.equals(Menu.IMAGE_BTNLABEL)){
            button = Menu.IMAGE;
            processButton(button,btn);
            }
        //when audio button is clicked
        if (btnLabel.equals(Menu.AUDIO_BTNLABEL)){
            button = Menu.AUDIO;
            processButton(button,btn);
            }
        //when video button is clicked
        if (btnLabel.equals(Menu.VIDEO_BTNLABEL)){
            button = Menu.VIDEO;
            processButton(button,btn);
            } 
        //when cancel button is clicked
        if (btnLabel.equals(Menu.CANCEL_BTNLABEL)){
            button = Menu.CANCEL;
            processButton(button,btn);
            }
        //when send button is clicked
        if (btnLabel.equals(Menu.SEND_BTNLABEL)){
            button = Menu.SEND;
            //this is where i update my title.
            this.mc.title(this.title.getText());
            this.mc.description(this.description.getText());
                
            processButton(button,btn);
            }
        
    }
    /***
    *processButton method
    *This method consists of all the steps taken for button clicked.
    *@param button      -button number.
    *@param btn         -buttonfield that is being pressed.
    *
    */
    void processButton(int button,ButtonField btn){
        switch (button){

            case Menu.SEND:
                if (this.mc.loggedIn()) {
                    // Post Memo
                    XML_Post_Request request = new XML_Post_Request(this.mc);
                    XML_Post_Response response = new XML_Post_Response(XMLPost.postXMLData(request.toString()));
		    System.out.println("Status: " + response.status());
                    // Check if sending succeeded
                    if (response.success()) {
                        Status.show("Message Sent.");
                    } else {
                        Status.show("Message Sending Failed.");
                    }
                } else {
                    // Log In
                    LoginScreen loginScreen = new LoginScreen(this.mc);
                    UiApplication.getUiApplication().pushScreen(loginScreen);
                }
                break;
            case Menu.VIDEO:
                Status.show("Video Field will be implemented.");
                break;
            case Menu.AUDIO:
                //Status.show("Button pressed: " + btn.getLabel());
                AudioScreen ss = new AudioScreen(this.mc);
                UiApplication.getUiApplication().pushScreen(ss);
                break;
            case Menu.CANCEL:
                Status.show("Button pressed: " + btn.getLabel());
                break;
            case Menu.IMAGE:
                CameraStream cs = new CameraStream(this.mc);
                UiApplication.getUiApplication().pushScreen(cs);
               ;//regenerate item_list
               break;

            default:
                break;
   
        }
    }
} 

