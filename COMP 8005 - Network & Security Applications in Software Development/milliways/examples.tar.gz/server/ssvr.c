/*---------------------------------------------------------------------------------------
--	SOURCE FILE:	ssvr.c -   A simple Secure Echo Server using TCP
--
--	PROGRAM:		ssvr.exe
--
--	FUNCTIONS:		Berkeley Socket API
--
--	DATE:			February 2, 2002
--
--	REVISIONS:		(Date and Description)
--
--
--
--	DESIGNERS:		Aman Abdulla & Eric Rescorla
--                  The "load_dh_params"  and the  "generate_eph_rsa_key" functions are taken
--                  from the book by Eric Rescorla.
--			
--					In addition, the Client/Server implementation uses some common functions
--                  provided in "common.c" also from the same book by the aforementioned author.
--
--	PROGRAMMERS:	Aman Abdulla & Eric Rescorla
--
--	NOTES:
--	The program will accept TCP connections from client machines. It will then create a secure socket and
--  read data from the secure client socket and simply echo it back over its own secure socket. The secure
--  socket uses the OpenSSL library.
------------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "common.h"
#include "server.h"

#define SERVER_TCP_PORT 7000	// Default port
#define BUFSIZE	               255	//Buffer length
#define TRUE	1

static int  s_server_session_id_context = 1;

int main (int argc, char **argv)
{
	int	n, bytes_to_read, len, err;
	int	sd, new_sd, client_len, port;
	struct	sockaddr_in server, client;
	char	*bp, buf[BUFSIZE];
    int val = 1;

    // OpenSSL specific variables
	SSL_CTX *ctx;
    SSL *ssl;
    BIO *sbio;

    switch(argc)
	{
		case 1:
			port = SERVER_TCP_PORT;	// Use the default port
		break;
		case 2:
			port = atoi(argv[1]);	// Get user specified port
		break;
		default:
			fprintf(stderr, "Usage: %s [port]\n", argv[0]);
			exit(1);
	}

    // Build the SSL context
    ctx = initialize_ctx (KEYFILE, PASSWORD);
    load_dh_params (ctx, DHFILE);
    generate_eph_rsa_key (ctx);

    SSL_CTX_set_session_id_context (
		ctx,
        (void*)&s_server_session_id_context,
         sizeof s_server_session_id_context
	);

    // Create a stream socket
	if ((sd = socket (AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror ("Can't create a socket");
		exit(1);
	}

	// Bind an address to the socket
	bzero((char *)&server, sizeof(struct sockaddr_in));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = htonl(INADDR_ANY); // Accept connections from any client

    setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val));

    if (bind(sd, (struct sockaddr *)&server, sizeof(server)) == -1)
	{
		perror("Can't bind name to socket");
		exit(1);
	}

	// Listen for connections
	// queue up to 5 connect requests
	listen(sd, 5);

	while (TRUE)
	{
		client_len= sizeof(client);
		if ((new_sd = accept (sd, (struct sockaddr *)&client, &client_len)) == -1)
		{
			fprintf(stderr, "Can't accept client\n");
			exit(1);
		}

		printf(" Remote Address:  %s\n", inet_ntoa(client.sin_addr));
		bp = buf;
		bytes_to_read = BUFSIZE;
        n = 0;

        sbio = BIO_new_socket (new_sd, BIO_NOCLOSE);
        ssl = SSL_new (ctx);
        SSL_set_bio (ssl, sbio, sbio);

        if (err = SSL_accept (ssl) <= 0)
			berr_exit ("SSL Accept Error");

        // Read the data
        n = SSL_read (ssl, buf, BUFSIZE);
        switch (SSL_get_error (ssl, n))
        {
			case SSL_ERROR_NONE:
				len = n;
            break;
            case SSL_ERROR_ZERO_RETURN:
				SSL_shutdown (ssl);
                SSL_free (ssl);
                close (new_sd);
                berr_exit ("SSL Zero Return");
            break;
            default:
				berr_exit("SSL read problem");
        }


        printf ("Sending...\n");
        SSL_write (ssl, buf, BUFSIZE);
	    close (new_sd);
	}
	close(sd);
    
	// Release the context
	destroy_ctx (ctx);
	return(0);
}

void load_dh_params (SSL_CTX *ctx, char *file)
{
        DH *ret=0;
        BIO *bio;

        if ((bio=BIO_new_file(file,"r")) == NULL)
                berr_exit("Couldn't open DH file");

        ret = PEM_read_bio_DHparams(bio,NULL,NULL,NULL);
        BIO_free (bio);
        if(SSL_CTX_set_tmp_dh(ctx,ret)<0)
                berr_exit ("Couldn't set DH parameters");
}

void generate_eph_rsa_key (SSL_CTX *ctx)
{
        RSA *rsa;

        rsa=RSA_generate_key(512,RSA_F4,NULL,NULL);
      if (!SSL_CTX_set_tmp_rsa(ctx,rsa))
                berr_exit("Couldn't set RSA key");

    RSA_free(rsa);
}
