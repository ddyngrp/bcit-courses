using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// All of the types in News.dll are in this namespace.
using COMP2690.News;

namespace SampleProject
{
	public partial class MainForm : Form
	{
		// Keep this around for the life of the form.
		private NewsgroupCollection groups;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// This makes the ListBox resize correctly when its *height* is resized.
			lstGroups.IntegralHeight = false;
		}

		private bool downloadGroups()
		{
			// Of course, you will get this from the form when you do it (see screenshot in handout).
			string server = "news.microsoft.com";

			// Let's include only the groups that have "dotnet" or "windows" in the group name.
			// TIP: When you get the space-separated list from a ComboBox, make use of String.Split.
			string [] includeList = {"dotnet", "windows"};

			try
			{
				// Temporary connection to the server.
				NewsConnection connection = new NewsConnection();
				connection.Connect(server);

				groups = connection.GetNewsgroups(includeList, null);

				connection.Disconnect();

				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Download Newsgroups", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		private void populateGroupsList()
		{
			lstGroups.DataSource = groups;
		}

		private void clearGroupsList()
		{
			lstGroups.DataSource = null;
            lstGroups.Refresh();
		}

		private void btnGetGroups_Click(object sender, EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			
			clearGroupsList();
			downloadGroups();
			populateGroupsList();

			this.Cursor = Cursors.Default;
		}
	}
}