#include <iostream>
#include <iomanip>
#include <limits>
#include <sstream>
using namespace std;
class Clock{
public:
	Clock(int hour = 0, int min = 0):hour_(hour),min_(min){
		if(hour>24 || min>59)
			throw"Clock::Clock(int,int): invalid arguments";
	}

	Clock(const std::string& s):hour_(0),min_(0){
		int hour,  min;
		char colon;
		istringstream iss(s);
		
		if(!(iss>>hour>>colon>>min))
		{
			throw "Clock::Clock(string): invalid arguments form(H:M)";
		}

		if(hour >24 || hour < 0 || min > 59|| min < 0)
		{
			throw "Clock::Clock(string): invalid arguments form(H:M)";
		}
		else
		{
			hour_ = hour;
			min_ = min;
		}
	}

	Clock& operator++(){
   	  if(++min_>59)
	  {
		  min_=0;
		  if(++hour_>23)
		  {
			  hour_ = 0;
		  }
	  }
	  return *this;
	}
	
	Clock operator++(int){
	  Clock copy(*this);
	  ++*this;
	  return copy;

	}

	void print() const
	{
		std::cout<<setfill('0');
		if(hour_>11)
			std::cout<<std::setw(2)<<hour_-12<<":"<<std::setw(2)<<min_<<"PM"<<std::endl;
		else 
		{
			std::cout<<std::setw(2)<<hour_<<":"<<std::setw(2)<<min_<<"AM"<<std::endl;
		}
		std::cout<<setfill(' ');
	}
	friend	bool operator ==(const Clock& c1,const Clock& c2);
	friend	bool operator !=(const Clock& c1,const Clock& c2);
	friend  std::ostream& operator<<(std::ostream& os, const Clock& c);
 private:
 int hour_;
 int min_;
 };

bool operator ==(const Clock& c1,const Clock& c2)
{
	if(c1.hour_ != c2.hour_ || c1.min_ != c2.min_)
	{
		return false;
	}
	return true;
}

bool operator !=(const Clock& c1,const Clock& c2)
{
	return !(c1==c2);
}

std::ostream& operator<<(std::ostream& os, const Clock& c){
	std::cout<<setfill('0');
	std::cout<<std::setw(2)<<c.hour_<<":"<<std::setw(2)<<c.min_<<std::endl;
	std::cout<<setfill(' ');
	return os;
}
