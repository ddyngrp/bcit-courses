using System;
using System.Collections.Generic;
using System.Text;

namespace refExample
{
	class Program
	{
		static void Main(string[] args)
		{
			string input;
			int x, y, translateVal;
			
			// Get two integers from the user.
			Console.WriteLine("Enter two integer values for coordinates:");
			input = Console.ReadLine();
			x = Convert.ToInt32(input);
			input = Console.ReadLine();
			y = Convert.ToInt32(input);

			Console.WriteLine("Translate the coordinates by how much: ");
			input = Console.ReadLine();
			translateVal = Convert.ToInt32(input);

			translateCoords(ref x, ref y, translateVal);

			Console.WriteLine("Your coordinates are now (" 
					+ x.ToString() + "," + y.ToString() + ")");
		}

		private static void translateCoords(ref int x, ref int y, int translateVal)
		{
			x += translateVal;
			y += translateVal;
		}

	}
}
