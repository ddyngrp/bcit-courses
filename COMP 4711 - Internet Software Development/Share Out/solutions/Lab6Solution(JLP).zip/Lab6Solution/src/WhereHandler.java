
import java.util.SortedSet;
import java.util.TreeSet;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Collect elements from regular TV data that are in a news catagory
 *
 * @author jim
 */
public class WhereHandler extends SuperHandler {

    public WhereHandler() {
        super();
    }

    /**
     * Apply appropriate filtering to select only those elements that
     * we are interested in.
     * This will distinguish one handler from another.
     * We only want news shows
     */
    public void condense() {
        SortedSet<Show> answer = new TreeSet<Show>();
        for (Show show : data) {
            for (String cat : show.categories) {
            if (cat.toLowerCase().contains("news")) {
                answer.add(show);
                selected++;
            }
            }
        }
        data = answer;
    }
}
