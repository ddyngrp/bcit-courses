//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S498e68da295cdd43027218b12e47c250.h"

#include "S1a14215d7a9ed417e57c419037ad81b9.h"
  Sf11dbd6494d927ad43d7839980aab9ae::Sf11dbd6494d927ad43d7839980aab9ae(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, S4f4955a74b11dc1f8b279197db71427f *S19fc03f6c804c759e47b0eaa5646c250, 
S4f4955a74b11dc1f8b279197db71427f *S960f220aecaeed010b05fb32c679839f, S6ebd5941df466d9a1c9cc8263c03ef42 
*S60283a425cf987277e107f9b3baaaa7e) { S7e68f03d82796cb25619fb86df299474 = S19fc03f6c804c759e47b0eaa5646c250; 
S64820d26353b97a91928175a4cb5ab44 = S960f220aecaeed010b05fb32c679839f; S1a14215d7a9ed417e57c419037ad81b9 
= S60283a425cf987277e107f9b3baaaa7e; }  Sf11dbd6494d927ad43d7839980aab9ae::~Sf11dbd6494d927ad43d7839980aab9ae() 
{ if (S7e68f03d82796cb25619fb86df299474) delete S7e68f03d82796cb25619fb86df299474; if (S64820d26353b97a91928175a4cb5ab44) 
delete S64820d26353b97a91928175a4cb5ab44; }                  bool Sf11dbd6494d927ad43d7839980aab9ae::Sc540984088e5fe36f5620d965d2ff954(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, uint64 S3d7bef5b94828f4c5b1e6804605daa54) {  bool S3a8b3b43d1e348fa47518382f2d2f944 
= S7e68f03d82796cb25619fb86df299474->Sc540984088e5fe36f5620d965d2ff954(Scc2faae6b412ac43b64129b402c4b88e, 
S3d7bef5b94828f4c5b1e6804605daa54) && S64820d26353b97a91928175a4cb5ab44->Sc540984088e5fe36f5620d965d2ff954(Scc2faae6b412ac43b64129b402c4b88e, 
S3d7bef5b94828f4c5b1e6804605daa54);  return S3a8b3b43d1e348fa47518382f2d2f944; }   rownum_t Sf11dbd6494d927ad43d7839980aab9ae::S1f2884441072ae4fe0ccdf040e11970b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e) {     double S19ece89ba159981c79486a33ce737af2 = 1.0; double S52ed512b20a49696e17b740a7a0f395f 
= 1.0; if (S1a14215d7a9ed417e57c419037ad81b9->S9b87ec188ee0d8b8517cc332082a0a9c()) { S19ece89ba159981c79486a33ce737af2 
= S7e68f03d82796cb25619fb86df299474->S1f2884441072ae4fe0ccdf040e11970b(Scc2faae6b412ac43b64129b402c4b88e) 
/ S1a14215d7a9ed417e57c419037ad81b9->S9b87ec188ee0d8b8517cc332082a0a9c(); S52ed512b20a49696e17b740a7a0f395f 
= S64820d26353b97a91928175a4cb5ab44->S1f2884441072ae4fe0ccdf040e11970b(Scc2faae6b412ac43b64129b402c4b88e) 
/ S1a14215d7a9ed417e57c419037ad81b9->S9b87ec188ee0d8b8517cc332082a0a9c(); } double Sfd30b7f32e9a27eeb3aa338235d3b6a4 
= S19ece89ba159981c79486a33ce737af2 * S52ed512b20a49696e17b740a7a0f395f; rownum_t S9e57b2e61d9bac60fdea46986b83b672 
= (rownum_t) (Sfd30b7f32e9a27eeb3aa338235d3b6a4 * S1a14215d7a9ed417e57c419037ad81b9->S9b87ec188ee0d8b8517cc332082a0a9c()); 
return S9e57b2e61d9bac60fdea46986b83b672; } 

