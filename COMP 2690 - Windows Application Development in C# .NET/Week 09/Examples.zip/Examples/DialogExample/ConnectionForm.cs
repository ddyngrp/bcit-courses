using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using COMP2690.News;

namespace DialogExample
{
	public partial class ConnectionForm : Form
	{
		private NewsConnection connection;

		public ConnectionForm()
		{
			InitializeComponent();
		}

		private void ConnectionForm_Load(object sender, EventArgs e)
		{
			// Default news server.
			txtNewsServer.Text = "news.microsoft.com";
			txtNewsServer.Select();
			txtNewsServer.SelectAll();

			refreshControls();
		}

		private void chkAuthRequired_CheckedChanged(object sender, EventArgs e)
		{
			refreshControls();
		}

		private void refreshControls()
		{
			txtUsername.Enabled = txtPassword.Enabled = chkAuthRequired.Checked;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if (validateData())
			{
				try
				{
					connection = new NewsConnection();
					connection.Connect(txtNewsServer.Text);

					// This will close the dialog.  It will also allow the caller to
					// learn that the user didn't cancel the dialog.
					this.DialogResult = DialogResult.OK;
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
		}

		private bool validateData()
		{
			// Any form of data is valid here except username cannot
			// be blank if "authentication" is checked.

			if (chkAuthRequired.Checked && txtUsername.Text == "")
			{
				// This is one time that I break my own rule that says 
				// a method should do what its name suggests and nothing
				// else.
				MessageBox.Show("Please enter a username.", "Error",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				txtUsername.Focus();
				return false;
			}

			return true;
		}

		public NewsConnection Connection { get { return connection; } }
	}
}