//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#if HAVE_STDIO_H
 
#include <stdio.h>

#endif
 class Sc51497dedb5c0712f20ccaa9831c0365; class S6d6cbe6673721b1104d6dcb8de7beb6a; class Sa14f2810aa7f7746ebe6af24ad45815a; 
void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
char S34410ea0d7783276aa8b5d4a06172810); void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S5f0b0ed8c42a3f27f38d645003e57304); void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d); 
void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d, const 
char *Sfc6a31f955de0bb46d80796076dc6ac0); void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d, 
const char *Sfc6a31f955de0bb46d80796076dc6ac0, const char *S502d0adbb46f5ed23e1db48dba42b210); void 
Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d, const 
char *Sfc6a31f955de0bb46d80796076dc6ac0, const char *S502d0adbb46f5ed23e1db48dba42b210, const char *S82fd115d258a8a567141f777559cd305); 
void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d, const 
char *Sfc6a31f955de0bb46d80796076dc6ac0, const char *S502d0adbb46f5ed23e1db48dba42b210, const char *S82fd115d258a8a567141f777559cd305, 
const char *Sb28f3f3de16c1d493ebff241d25da464); void Sd1009cdb18832e7e06da36cebf858d43(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S5f0b0ed8c42a3f27f38d645003e57304, const char *S44beb2c35c6c1921b0c756510740f73d, 
const char *Sfc6a31f955de0bb46d80796076dc6ac0, const char *S502d0adbb46f5ed23e1db48dba42b210, const 
char *S82fd115d258a8a567141f777559cd305, const char *Sb28f3f3de16c1d493ebff241d25da464, const char *Se23db567c29ed06d5a5a0d31a7c14127); 
void Sd47e80cb47354cbfba29bbda872bdfef(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
bool Sfd2cfc252246314f5013ef182e86957a); void Sd1d5592d47602b0494d161bdbaf67fd6(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); S6d6cbe6673721b1104d6dcb8de7beb6a Se2966fbcaea5cb926b81dc6fff1fcbaf(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &S4bdcc14fa314dabdd1ed4c45cc9f3921); 
void S837b9c040212985843c98968646934a8(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Sa86fc0bd7ee552a2f0dc4d8ebe19d14c); void S837b9c040212985843c98968646934a8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &Sa86fc0bd7ee552a2f0dc4d8ebe19d14c); 
void S3b63c0b2f37689afc101688f578f2091(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
void S3b63c0b2f37689afc101688f578f2091(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S4a6cb99edf5d80c7bbd96fda8d69fb13, const char *Sc83e24db2da0ff0b6c3640dc92aab970, mint Sf538f90c372dd2cb2031856b8b621eb6, 
bool S359f3b602fb388938436fcaabb20d12f, bool Sf6b449e4c1d06fd4baf78e1096593c02, bool S3df0af19cabcabcfdb83f8678eb9ad67); 
void Sade2fda020768252844f1ca76ccb055f(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
void S688c9ac189d42a63a6a6e94b45d8dd07(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
void Saeec85ea9b878eb04612d25a543b1006(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *S5c383bcfd30422c8c49fa51fd58b3f46, bool Sfd2cfc252246314f5013ef182e86957a); void S0d6d79649eb8ecd48b0e15c7bd284850(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, char *Sbfff1bda8975763a769e439634717076); void S6a9a499e81623e252a3d893ba2e0d674(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); const char *Saee1ff9bc7d8d4d1288f04f76b8b4b25(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, char *line, char Sa78ee220f71c0eddf8ff38fe37ed636b); const char 
*S73bf266c9f220cde75e8d320f9398b09(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
FILE *Scc58a9c5ce31916640df788043cf087e, char Sa78ee220f71c0eddf8ff38fe37ed636b, int *Sdd082c5df4d4130a141a913d15596a7a); 
char S516ee58edd6967190e96bdc543eb8f31(char *Sc214e5537a91b6c85ff92fe5ac1a0670); void Sf44c6c924e472a43a87cbd374e3c1daf(char 
*Sa86fc0bd7ee552a2f0dc4d8ebe19d14c); void S1af04b42d2b181e54659516371fe58bb(char *str); int Sbe97e419baf7e25bcb6ff3d9493e2589(const 
char *S7f3f5c63b6fe99b1734383d7601f8140, char S34410ea0d7783276aa8b5d4a06172810); void S4c88703d7f5d8b2c57fae4400b8ff114(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S634f5eb6cb324b7d7bc75ce01c989f9f(char *Sfd0c7a6cfc5d97b160d4d4f02dbc9459, 
char *line, char Sa78ee220f71c0eddf8ff38fe37ed636b); int Sbe97e419baf7e25bcb6ff3d9493e2589(char *S7f3f5c63b6fe99b1734383d7601f8140, 
char S34410ea0d7783276aa8b5d4a06172810); int getline(char *S7f3f5c63b6fe99b1734383d7601f8140, int Sa413b58e37dad5c1385ebcde113904a1, 
FILE *Scc58a9c5ce31916640df788043cf087e); void Sf5f501ce3661cedc3310b47d22b67a48(FILE *Scc58a9c5ce31916640df788043cf087e, 
FILE *S8af1ef7f282489b84428bb2bf05bcf75); int S7b0b7fdab5ae2f214c03fa8642ed4623(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, int Sd6828b562c47accbc013b981af9b0843, char **Sae5bcc17c549747b11ea373fc2893e62); 
void Sfbf1f713f36ba30a1aae5d3b2d5a5089(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
void S4832c670d51f080631f58ce177b08890(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e); 
S7ca5d44c3992eca4f11ed4ee768968cd *Saf90f948cf4d5519b764e74a6ecfc1ea(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sf305eed75402b7f17d8ae660deff1106, const char *S0e7ffad94aa7d58d4897516ef8681edb); 
void S4faa3f9b89bf0ebe2b896f73c8c78faa(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Se6b0e3466a08eec9e50f7e09563d821a); void S68e4d02e8ad72ed181ef4989ea12eb59(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &name, const S6d6cbe6673721b1104d6dcb8de7beb6a 
&Sb79d4a4ac05ebdb8cb70e6b5594e9473); void Scabc7b4f45e16e52ca93d01651fec3d6(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S1b65c853b201645130a2c5d52126ee31(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sf6cd3133c4c2e5b749d445523b57bb3c); void S543e0c1eea62780642e89822579c4d9f(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void Sf7260835cfc1fd6caf346ff7ec6f6dcb(Sc51497dedb5c0712f20ccaa9831c0365 
*Scc2faae6b412ac43b64129b402c4b88e); void Sbc95e9975338139530bef2dc269fecfd(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void Sd905b78df16dffa6936bf05876660b20(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S6a661e23fe4b00f1f48f30f6b713d606(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &Sb79d4a4ac05ebdb8cb70e6b5594e9473, 
const S6d6cbe6673721b1104d6dcb8de7beb6a &S9d1e4535a2fe3881b55a3972834dd5d2, const char *S8d11fc1843ef6ad4e5ad7b55862c00cc, 
bool &Sa95a3727a1c95ea4e92cddb57ee49e33, bool &S50dd31b83e9ee2255d91f8cfbbed073f); void Sf52b290487aa9a4815295c468d1b597f(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &Sb79d4a4ac05ebdb8cb70e6b5594e9473, 
const S6d6cbe6673721b1104d6dcb8de7beb6a &S9d1e4535a2fe3881b55a3972834dd5d2, const char *S8d11fc1843ef6ad4e5ad7b55862c00cc, 
mint &Sa95a3727a1c95ea4e92cddb57ee49e33, bool &S50dd31b83e9ee2255d91f8cfbbed073f); void S96ed063b04cde6f9d5421fc996f07700(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const S6d6cbe6673721b1104d6dcb8de7beb6a &S4ccc6b097803d2948d0aad1679d40638);

