//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "Se31981d874cf90aae9b970e888bfb32b.h"

#if HAVE_UNISTD_H
 
#include <unistd.h>

#endif
 
#if HAVE_SYS_TYPES_H
 
#include <sys/types.h>

#endif
 
#include "Sb525e61d737826a9724d3a17cfaed63a.h"

#if HAVE_PWD_H
 
#include <pwd.h>

#endif
  const char *Sbcd7098eaf49628fcf30eb619a7b0a52(void) { 
#if defined(macintosh) || defined(WINDOWS)
  return 0; 
#else
  uid_t Sb6d720fb631fba724ba3a93a52749118 = getuid();  passwd *Sb0c530ced9f4847f14bbcd88871a3ae8 = getpwuid(Sb6d720fb631fba724ba3a93a52749118); 
 if (Sb0c530ced9f4847f14bbcd88871a3ae8) return Sb0c530ced9f4847f14bbcd88871a3ae8->pw_name; else return 
0; 
#endif
 } 

