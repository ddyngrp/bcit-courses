//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef Sbae6fcd352256e7caf5d919142503e3b
 
#define Sbae6fcd352256e7caf5d919142503e3b
 
#if 0
 typedef enum { S87e39c558fd7f0b5cbf4507aeb7774f7, Sbec483235f0e942edd9480c310763e71, S5c5a8d7a26c7e930d5b4d94e6aa92288, 
S34afa0d289b150821e3baf92eaec8289, S904af51017806bc78806b240d2da23fd, S0685da598aa387bb16481a1f2d7f5218 
} Sca24ba9e9f4f0007ee6d9f9ba118b297; typedef enum { S8a1ab5a037f55c9aae2ee6bbb905795f, S214445eb40d20403d4ea699c67f8cf75, 
S2ddc8a5b32b628d1a4f7ca0bdca95a5c, S3af850676fd5ca44ae7a334feb32334e, Sb8cec733e3eb0e5f6ba61e05cda8b869, 
S4ecc2d9f65e5987315f0a7fad5966e45, Se9d592717753500182012ade27b66b45, S5f125c53c348e477f0bf38adf3dab8d8, 
S84fed450fe9807e8291c07c4c1b242fa, Sfa18d907afed6b4fc619262c7409601f, S631f7d6700311cee48aa4617dda20332, 
S5ce7a3e9e827421355533fca2d082abf, S9cf0d107914f01e8cbe17885b1146b4a, Sd2fe647e68188a405374bf75b7cb45d2, 
Seef4ad8783a22e9d5034e6c8f427cd3b, S23a1a2513a8a1dbb031819482943e20d, S7b40015ec603fc3f57bb6b0fc76e3bb2 
} Saa731ab934fa3cca79eadfc8637b36ea; typedef enum { S1d5ddf49dbfeb967c07e64a4e31dd74f = 100, Sdefb617be4ced0323a51643b17f3f2e8, 
S1e8d73997799ac9ee5cbd241d12234cd, S94806ee7a87facec08867315dc420ddb, S1bec2ab3a09b0123cf6b08fb407521a0, 
Sf17213a6d980fcf9a62b98ee00d034a3, Sa7e28bc55b44d283a3910344864dcf9a, S51cace7cfa1b979d420bf14b8b13dc0d, 
S4aa217c6505fdcb5818542a0b09ce63f, S94b49b6e8ffda08c822a44a2ff1763f2 } S0728de1ee05015e06bf102784e4d206b; 
typedef enum { S77da1e7023ed79d2bb07736a6b834cfe, S19f6aaebc3d9646ccb620a7ca95972cc, S25f3405ba7ae9f55d727c76a2d5e59e9, 
S76fb576dc7c110b22d9a83c41ab19310, S1cc37459318ea0e45f3c3356be58f95e, Sb24296aa47abe16f4b493c4ff9d11474, 
S4a33e87e1f09447f9ffa1a6801bc7a65, Sbf6a3588bb4df325fb7d901d41a6763d, Sd8dcd1f7f592b22f9de9b1cc96fb8d40, 
S818818a53972373403815f8dea6e1c31, S5412a1295911d1544e628e29342c7cb7, S49887cf1b8fa8daf36b89738a5062dc9, 
S1da14374c89fe8459dd8397ac59ffc0a, S3273644a350477e26794af42f5930fa1, S57505c6feec055eed71f20adbbb373f5, 
Sd07cb073a36618080a8fc4d2f422c1c5, S58504e311ff607f20f2807f8e84aacb7, S3273f8816cbd858733272c686455d814, 
S97aa21a261aa6095bda780fc0f6cce75, S0a73abe20dc4017c8dd7c0de03dca9c9, S2b099bd0c93cfa3d04f577262cfabf8c, 
S15a816db2cb6422ff965240e1722f9c3, S3f784056986fd1a0e1a0fa8568e8f7cb, Se2c53e5252ae1aa8af8e7bebfc65f883, 
Sf06eb3fa8f4c3e9acd4c2df031d48164, S8dccb1b9cb3ae6eb7314b1d40cea6bed, S444d0243d5b079eb1956b75b5b163fe2, 
S28443f66ee2d04e95ed5ff5f6949ab0b, S232bfc79e4760dbf44d65468b7e333a8, Sf2d9f1b55a4611fb5192c8df93650031, 
Sf7f52955014299d5675875684dc395dc, S9929fb472cc4c1180bcb2b9b58133851, S51ceb2ccee51b8c29efa70c7e79bdd36, 
S47f5d2700359593b0124fb659354f387, S8a4bb887daeee5f61eceaeb53f604b5a, S071d3beefd6d4e77ebb2d8d95abc30f3, 
Sbda235dca92512df0c97c7a61a300d32, S170a9b9e2e10820e648c1df6173396e3 } S82102553cf93ddf4bbc71ead72e34504; 
 typedef enum { S1df5ad09de5d010f96075487237c4b09, Sb51a92d39ecea894d6f1fd8caae6fe48, S951532c76da8568ec110b23a315b9f24, 
S9c89dc727320006def2e47d0817f9852 } S621b7aadf1176a473321f2182652f60b; typedef enum { S5b1b55b9c1c11fcea51e2b4147007a8b 
= -100,   S1e97150f41aa897da7c96d76f41e68cc = -99, S66e3290c6749e9e6c9fe4fab000d5002 = -98, Sa7c3229a1ab282c7a5238e8f8acc3d2c 
= -97, S7a4defc876c52f49fed61b244ab41e1c = -96 } S49c7c797d4aba4fad3ced940c9a1671f; 
#endif
 
#endif


