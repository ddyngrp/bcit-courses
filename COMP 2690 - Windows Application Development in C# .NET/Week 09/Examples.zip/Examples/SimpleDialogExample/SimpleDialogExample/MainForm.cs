using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SimpleDialogExample
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			lblDlgResult.Text = "";
		}

		private void btnDoDialog_Click(object sender, EventArgs e)
		{

			// Create and display the dialog *modally* (user must complete
			// the dialog before continuing with the app).
			SimpleDialog dlg = new SimpleDialog();
			dlg.ShowDialog();

			// Note that ShowDialog() is a blocking call, meaning that the code
			// below will not execute until after the dialog closes.

			if(dlg.DialogResult == DialogResult.OK)
			{
				lblDlgResult.ForeColor = Color.Green;
				lblDlgResult.Text = "Dialog complete (OK pressed).";
			}
			else if(dlg.DialogResult == DialogResult.Cancel)
			{
				lblDlgResult.ForeColor = Color.Red;
				lblDlgResult.Text = "Dialog cancelled.";
			}
			else
			{
				lblDlgResult.ForeColor = Color.Red;
				lblDlgResult.Text = "Unexpected dialog result!";
			}
		}

	}
}