//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#ifndef S6ba1e6cf139403e1307e7691e0f65c7c
 
#define S6ba1e6cf139403e1307e7691e0f65c7c
 
#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"
 class Sc51497dedb5c0712f20ccaa9831c0365; class S9f4d4ea4917e0ea34880cb67e0e58e66 { Sc51497dedb5c0712f20ccaa9831c0365 
*S6ec129777c16ed8568398f5726365a75; char *S2985b4614d2618f174fd3c6fca49b42f; size_t Sa377fd1ff03c2bed7f3b34a55753ded9; 
size_t S19564b408bfbcfc06be2c8a3a5f1078b; private:  S9f4d4ea4917e0ea34880cb67e0e58e66(void); void S365f5c9a4f619388bcc8a84cec72e76b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S7f3f5c63b6fe99b1734383d7601f8140);  ~S9f4d4ea4917e0ea34880cb67e0e58e66(void); 
public:      size_t length(void) { return S19564b408bfbcfc06be2c8a3a5f1078b; } void S31323566cd702a614f9f40d529ea1231(size_t 
Se21bc886dbace4cded3f59e0bf7f2bc9);  char *c_str(void) const { *(S2985b4614d2618f174fd3c6fca49b42f + 
S19564b408bfbcfc06be2c8a3a5f1078b) = 0; return S2985b4614d2618f174fd3c6fca49b42f; } void set(const char 
*S7f3f5c63b6fe99b1734383d7601f8140); void S20b09b177f39f0ac741e72c879732acd(const char *S7f3f5c63b6fe99b1734383d7601f8140, 
size_t S36619381eba85b63775782eab1a382ef, size_t length); void S20b09b177f39f0ac741e72c879732acd(const 
char *S7f3f5c63b6fe99b1734383d7601f8140, size_t S36619381eba85b63775782eab1a382ef); void Sbb776973600322ab316306ef2d275ccf(const 
char *S7f3f5c63b6fe99b1734383d7601f8140); void Sbb776973600322ab316306ef2d275ccf(const S6d6cbe6673721b1104d6dcb8de7beb6a 
&S7f3f5c63b6fe99b1734383d7601f8140); void Sbb776973600322ab316306ef2d275ccf(char S34410ea0d7783276aa8b5d4a06172810); 
void Sbb776973600322ab316306ef2d275ccf(S9f4d4ea4917e0ea34880cb67e0e58e66 *S7f3f5c63b6fe99b1734383d7601f8140); 
void Sba326078fe9f8ee0e7839d86f9dbaf92(const char *S7f3f5c63b6fe99b1734383d7601f8140); void Sc16c24fa3fbec1a42b7f946323ef1179(const 
char *S7f3f5c63b6fe99b1734383d7601f8140, size_t S36619381eba85b63775782eab1a382ef, size_t length); void 
Sc16c24fa3fbec1a42b7f946323ef1179(const char *S7f3f5c63b6fe99b1734383d7601f8140, size_t S36619381eba85b63775782eab1a382ef); 
bool S50ecde1d8305c85a933dc85759419955(const char *S7f3f5c63b6fe99b1734383d7601f8140) { return S94b9f013d1697e8631ce1122b9e529b5(c_str(), 
S7f3f5c63b6fe99b1734383d7601f8140); } bool S50ecde1d8305c85a933dc85759419955(char S34410ea0d7783276aa8b5d4a06172810) 
{ return S94b9f013d1697e8631ce1122b9e529b5(c_str(), S34410ea0d7783276aa8b5d4a06172810); } void S23f035a74a8aeec11cfc740e503ca2c8(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *S9127733269dbf38964c7e32cb594f7e6, const char *Scb730d307e4a0317ac1cac4dd0230557); 
 friend S9f4d4ea4917e0ea34880cb67e0e58e66 *Scbc391abb6d4fdeed1aa169c4ae8906b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); friend S9f4d4ea4917e0ea34880cb67e0e58e66 *Scbc391abb6d4fdeed1aa169c4ae8906b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sea50747fc484e2e5860c54da0b0c5bdb); friend void Sc52c352c30ddf37c65e1901facda820f(S9f4d4ea4917e0ea34880cb67e0e58e66 
*Sde2e5ea52463b2e9e0ddd32998204c41); friend void S280d1f67c073a95e6111723c11b41092(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); };  typedef S9f4d4ea4917e0ea34880cb67e0e58e66 *Sf59d52504f6359b364605705e38c9754; 
bool operator < (const S9f4d4ea4917e0ea34880cb67e0e58e66 &Scc58a9c5ce31916640df788043cf087e, const char 
*S7f3f5c63b6fe99b1734383d7601f8140); bool operator < (const S9f4d4ea4917e0ea34880cb67e0e58e66 &Scc58a9c5ce31916640df788043cf087e, 
const S6d6cbe6673721b1104d6dcb8de7beb6a &S7f3f5c63b6fe99b1734383d7601f8140); 
#define S98da7eaad6724ebb56d3dd95335485aa(Scc58a9c5ce31916640df788043cf087e, S5f0b0ed8c42a3f27f38d645003e57304, S44beb2c35c6c1921b0c756510740f73d) Scc58a9c5ce31916640df788043cf087e->Sbb776973600322ab316306ef2d275ccf(S5f0b0ed8c42a3f27f38d645003e57304); Scc58a9c5ce31916640df788043cf087e->Sbb776973600322ab316306ef2d275ccf(S44beb2c35c6c1921b0c756510740f73d);
 
#define S9d10c58d35ac1945c08e322b5ed52633(Scc58a9c5ce31916640df788043cf087e, S5f0b0ed8c42a3f27f38d645003e57304, S44beb2c35c6c1921b0c756510740f73d, Sfc6a31f955de0bb46d80796076dc6ac0) Scc58a9c5ce31916640df788043cf087e->Sbb776973600322ab316306ef2d275ccf(S5f0b0ed8c42a3f27f38d645003e57304); Scc58a9c5ce31916640df788043cf087e->Sbb776973600322ab316306ef2d275ccf(S44beb2c35c6c1921b0c756510740f73d); Scc58a9c5ce31916640df788043cf087e->Sbb776973600322ab316306ef2d275ccf(Sfc6a31f955de0bb46d80796076dc6ac0)
 S9f4d4ea4917e0ea34880cb67e0e58e66 *Scbc391abb6d4fdeed1aa169c4ae8906b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); S9f4d4ea4917e0ea34880cb67e0e58e66 *Scbc391abb6d4fdeed1aa169c4ae8906b(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sea50747fc484e2e5860c54da0b0c5bdb); void Sc52c352c30ddf37c65e1901facda820f(S9f4d4ea4917e0ea34880cb67e0e58e66 
*Sde2e5ea52463b2e9e0ddd32998204c41); void S280d1f67c073a95e6111723c11b41092(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); void S2d90c99cc12a525846a44a07ea4ca23d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e); 
#endif


