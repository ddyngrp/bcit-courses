/*
 * MediaList.java
 *
 * MLogger, 2008
 * Confidential and proprietary.
 */
package src; 
class MediaList {
    /**
     * First media item in the list (null if empty).
     */
    private MediaNode first = null;
    
    
    /**
     * Last media item in the list (null if empty).
     */
    private MediaNode last = null;
    
    
    /**
     * Number of items in the list.
     */
    private int size = 0;
    
    /**
     * Adds a media item to the list.
     * @param item The item to add.
     */
    public void add(MediaItem item) {
        MediaNode node = new MediaNode(this.last, item, null);
        if (first == null)
            first = node;
        if (this.last != null)
            this.last.next(node);
        this.last = node;
        this.size++;
    }
    
    /**
     * Deletes a media item from the list.
     * @param item The item to delete.
     */
    public void delete(int index) {
        if (this.size > 0) {
            MediaNode node = this.first;
            for (int i =0; i <= index && node != null; ++i) {
                node = node.next();
            }
            if (node != null) {
                node.delete();
                this.size--;
            }
        }
    }
    
    /**
     * Returns a specified MediaItem.
     * @param index Index value of the media item to return.
     * @return The specified MediaItem (or null if bad index).
     */
    public MediaItem get(int index) {
        MediaNode node = this.first;
        for (int i=0; i <= index && node != null; ++i) {
            node = node.next();
        }
        return (node == null) ? null : node.item();
    }
    
    /**
     * Returns an Iterator.
     * @return The iterator (actually the first MediaNode of the list).
     */
    public MediaNode iterator() {
        return this.first;
    }
    
    /**
     * Gets the number of MediaItems in the list.
     * @return The number of MediaItems in the list.
     */
    public int size() {
        return this.size;
    }
    
    /**
     * Clears all items out of the list.
     */
    public void clear() {
        for (; this.size > 0; this.size--)
            this.first.delete();
        this.first = null;
        this.last = null;
    }
} 
