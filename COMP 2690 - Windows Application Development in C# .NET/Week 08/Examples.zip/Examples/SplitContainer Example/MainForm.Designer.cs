namespace SplitContainer_Example
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.lstPictures = new System.Windows.Forms.ListBox();
			this.picMain = new System.Windows.Forms.PictureBox();
			this.mainSplitContainer.Panel1.SuspendLayout();
			this.mainSplitContainer.Panel2.SuspendLayout();
			this.mainSplitContainer.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.picMain)).BeginInit();
			this.SuspendLayout();
			// 
			// mainSplitContainer
			// 
			this.mainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mainSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.mainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.mainSplitContainer.Name = "mainSplitContainer";
			// 
			// mainSplitContainer.Panel1
			// 
			this.mainSplitContainer.Panel1.Controls.Add(this.lstPictures);
			// 
			// mainSplitContainer.Panel2
			// 
			this.mainSplitContainer.Panel2.Controls.Add(this.picMain);
			this.mainSplitContainer.Size = new System.Drawing.Size(299, 157);
			this.mainSplitContainer.SplitterDistance = 112;
			this.mainSplitContainer.TabIndex = 0;
			// 
			// lstPictures
			// 
			this.lstPictures.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstPictures.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstPictures.FormattingEnabled = true;
			this.lstPictures.IntegralHeight = false;
			this.lstPictures.ItemHeight = 16;
			this.lstPictures.Location = new System.Drawing.Point(0, 0);
			this.lstPictures.Name = "lstPictures";
			this.lstPictures.Size = new System.Drawing.Size(112, 157);
			this.lstPictures.TabIndex = 1;
			this.lstPictures.SelectedIndexChanged += new System.EventHandler(this.lstPictures_SelectedIndexChanged);
			// 
			// picMain
			// 
			this.picMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.picMain.Location = new System.Drawing.Point(0, 0);
			this.picMain.Name = "picMain";
			this.picMain.Size = new System.Drawing.Size(183, 157);
			this.picMain.TabIndex = 0;
			this.picMain.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(299, 157);
			this.Controls.Add(this.mainSplitContainer);
			this.Name = "MainForm";
			this.Text = "SplitContainer Example";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.mainSplitContainer.Panel1.ResumeLayout(false);
			this.mainSplitContainer.Panel2.ResumeLayout(false);
			this.mainSplitContainer.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.picMain)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer mainSplitContainer;
		private System.Windows.Forms.ListBox lstPictures;
		private System.Windows.Forms.PictureBox picMain;
	}
}

