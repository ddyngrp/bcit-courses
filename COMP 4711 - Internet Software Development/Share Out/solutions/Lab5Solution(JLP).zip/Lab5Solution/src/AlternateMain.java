/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
import org.jdom.*;
import org.jdom.input.*;
import java.io.*;

/**
 * COMP4711 Lab 5 Solution.
 *
 * Disclaimer: this is not the only way to solve the problem, it is just
 * one way that appears elegant to me :)
 *
 * I trust you notice the exception handling, as opposed to having all
 * the methods pass the buck :-/
 *
 * NOTE: This solution has been refactored, including the use of an inner class,
 * to simplify the main method logic. There is lots more refactoring that could be done to make it cleaner,
 * but there are only so many hours in a day!
 *
 * @author jim
 */
public class AlternateMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        who();
        when();
        where();
    }

    /**
     * Display the title & description of all Dr Who shows on BBC3.
     * How many shows of the total shown on BBC3 pertain to Dr Who?
     * Use the *title* element to test.
     */
    public static void who() {
        // Start the ball rolling
        System.out.println("-------------------------------------------");
        System.out.println("W H O ... Dr Who shows on BBC3");
        System.out.println("-------------------------------------------");
        int pgmCount = 0;       // # programs
        int foundCount = 0;     // # of Dr Who
        String DOCTOR_WHO = "Doctor Who".toLowerCase();

        // build the DOM for bbc3.xml
        Document doc = null;
        SAXBuilder builder = new SAXBuilder();
        try {
            doc = builder.build("data/bbc3.xml");
        } catch (JDOMException se) {
            System.out.println("*** Error parsing bbc3.xml - " + se.getMessage());
            return;
        } catch (IOException ioe) {
            System.out.println("*** I/O error reading bbc3.xml - " + ioe.getMessage());
            return;
        }

        // Let's traverse the document
        Element root = doc.getRootElement();
        List shows = root.getChildren();

        // We only want those that involve Dr Who
        for (Object obj : shows) {
            pgmCount++; // another program
            Element show = (Element) obj;
            String showTitle = show.getChildText("title").toLowerCase();
            if (showTitle.contains(DOCTOR_WHO)) {
                foundCount++; // this one is relevant
                System.out.println(show.getChildText("title") + " : " + show.getChildText("desc"));
            }
        }

        // wrap it up
        System.out.println("" + foundCount + " of " + pgmCount + " shows on BBC3 pertain to Dr Who");
        System.out.println("");
    }

    /**
     * Display the title, description & air time of all shows on between 8 & 11pm (local time) on TVDATA.
     * Order the display by air time, so it looks like a real schedule.
     *
     * NOTE: the test data happend to be ordered by time, but the DTD does not say anything
     * about this, and it would be improper to assume this to be the case always.
     * We shall use a SortedMap<String,String> to manage this ... use the start & end times,
     * concatenated, as the key, and the display string for that show as the value.
     *
     * NOTE 2: I am basing this solution only on the "hour", and ignoring the minute value
     * of start & end times, so it doesn't get too unwieldy.
     */
    public static void when() {
        // Start the ball rolling
        System.out.println("-------------------------------------------");
        System.out.println("W H E N ... Shows between 8 & 11");
        System.out.println("-------------------------------------------");
        SortedMap<String, String> winners = new TreeMap<String, String>();
        int WINDOW_START = 8;   // beginning of the schedule window
        int WINDOW_END = 11;    // end of the schedule window

        // build the DOM for tvdata.xml
        Document doc = null;
        SAXBuilder builder = new SAXBuilder();
        try {
            doc = builder.build("data/tvdata.xml");
        } catch (JDOMException se) {
            System.out.println("*** Error parsing tvdata.xml - " + se.getMessage());
            return;
        } catch (IOException ioe) {
            System.out.println("*** I/O error reading tvdata.xml - " + ioe.getMessage());
            return;
        }

        // Let's traverse the document
        Element root = doc.getRootElement();
        List shows = root.getChildren("programme");

        // We only want those that are aired between 8 & 11
        for (Object obj : shows) {
            Show show = new Show(obj);
            if (show.fallsInside(WINDOW_START, WINDOW_END)) {
                winners.put(show.key, show.value);
            }
        }

        // Let's display the results nicely
        for (String key : winners.keySet()) {
            System.out.println(key + "  " + winners.get(key));
        }

        System.out.println(""); // wrap it up
    }

    /**
     * Display the title, description & air time of all news shows on TVDATA.
     * Use the category element to determine these.
     */
    public static void where() {
        // Start the ball rolling
        System.out.println("-------------------------------------------");
        System.out.println("W H E R E ... News shows in TVdata");
        System.out.println("-------------------------------------------");

        // build the DOM for tvdata.xml
        Document doc = null;
        SAXBuilder builder = new SAXBuilder();
        try {
            doc = builder.build("data/tvdata.xml");
        } catch (JDOMException se) {
            System.out.println("*** Error parsing tvdata.xml - " + se.getMessage());
            return;
        } catch (IOException ioe) {
            System.out.println("*** I/O error reading tvdata.xml - " + ioe.getMessage());
            return;
        }

        // Let's traverse the document
        Element root = doc.getRootElement();
        List shows = root.getChildren("programme");

        // We only want those that are news shows.
        // We shall determine this by checking the categories of a show.
        // NOTE: we set a boolean when we find a relevant show, rather than printing the
        // show every time it has a category with the word "news" in it.
        for (Object obj : shows) {
            Show show = new Show(obj);
            boolean relevant = false;
            // check this show's categories
            List categories = show.source.getChildren("category");
            for (Object c : categories) {
                Element category = (Element) c;
                // note - we are looking for "news" anywhere in the category - arbitrary choice
                if (category.getValue().toLowerCase().contains("news")) {
                    relevant = true;
                }
            }
            // if this is a keeper, print it
            if (relevant) {
                 System.out.println(show.key + "  " + show.value);
            }
        }

        // wrap it up
        System.out.println("");
    }

};
