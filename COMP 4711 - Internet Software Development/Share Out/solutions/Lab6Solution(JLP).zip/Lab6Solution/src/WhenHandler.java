
import java.util.SortedSet;
import java.util.TreeSet;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Collect elements from regular TV data that are on between 8 & 11
 *
 * @author jim
 */
public class WhenHandler extends SuperHandler {

    public WhenHandler() {
        super();
    }

    /**
     * Apply appropriate filtering to select only those elements that
     * we are interested in.
     * This will distinguish one handler from another.
     * We only want prime-time shows
     */
    public void condense() {
        SortedSet<Show> answer = new TreeSet<Show>();
        for (Show show : data) {
            if (show.fallsInside("0800", "1100")) {
                answer.add(show);
                selected++;
            }
        }
        data = answer;
    }
}
