/*---------------------------------------------------------------------------------------
--	SOURCE FILE:	sclnt.c - A simple Secure TCP client program.
--
--	PROGRAM:		sclnt.exe
--
--	FUNCTIONS:		Berkeley Socket API
--
--	DATE:			February 2, 2002
--
--	REVISIONS:		(Date and Description)
--
--	DESIGNERS:		Aman Abdulla & Eric Rescorla
--                  The "check_cert_chain function is taken from the book by Eric Rescorla.
--
--                  In addition, the Client/Server implementation uses some common functions
--                  provided in "common.c" also from the same book by the aforementioned author.
--
--	PROGRAMMERS:	Aman Abdulla & Eric Rescorla
--
--	NOTES:
--	The program will establish a TCP connection to a user specifed server. The server can be specified 
--	using a fully qualified domain name or and IP address. After the connection has been established 
--	the progarm creates a secure that will be used to send data to teh server. The user-entered string 
--	is sent to the server and the response (echo) back from the server is displayed.
----------------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include "common.h"

#define SERVER_TCP_PORT		7000	  // Default port
#define BUFLEN			255            // Buffer length

int main (int argc, char **argv)
{
	int n, bytes_to_read;
	int sd, port, err;
	struct hostent	*hp;
	struct sockaddr_in server;
	char  *host, *bp, rbuf[BUFLEN], sbuf[BUFLEN], **pptr;
	char str[16];
    
	// OpenSSL specific variables
	SSL_CTX *ctx;
    SSL *ssl;
    BIO *sbio;

	switch(argc)
	{
		case 2:
			host =	argv[1];	// Host name
			port =	SERVER_TCP_PORT;
		break;
		case 3:
			host =	argv[1];
			port =	atoi(argv[2]);	// User specified port
		break;
		default:
			fprintf(stderr, "Usage: %s host [port]\n", argv[0]);
			exit(1);
	}


	// Build the SSL context
    ctx = initialize_ctx (KEYFILE, PASSWORD);

	// Create the socket
	if ((sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
	{
		perror("Cannot create socket");
		exit(1);
	}
	bzero((char *)&server, sizeof(struct sockaddr_in));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	if ((hp = gethostbyname(host)) == NULL)
	{
		fprintf(stderr, "Unknown server address\n");
		exit(1);
	}
	bcopy(hp->h_addr, (char *)&server.sin_addr, hp->h_length);

	// Connecting to the server
	if (connect (sd, (struct sockaddr *)&server, sizeof(server)) == -1)
	{
		fprintf(stderr, "Can't connect to server\n");
		perror("connect");
		exit(1);
	}
	printf("Connected:    Server Name: %s\n", hp->h_name);
	pptr = hp->h_addr_list;
	printf("\t\tIP Address: %s\n", inet_ntop(hp->h_addrtype, *pptr, str, sizeof(str)));

    // Connect the SSL socket
    ssl = SSL_new (ctx);
    sbio = BIO_new_socket (sd, BIO_NOCLOSE);
    SSL_set_bio (ssl, sbio, sbio);
    if (SSL_connect (ssl) < 0)
    berr_exit ("SSL Connect Error!");
    check_cert_chain (ssl, host);

    printf("Enter Text to Transmit:\n");
	gets(sbuf); // get user's text

	// Transmit data through the socket
	err = SSL_write (ssl, sbuf, BUFLEN);

	printf("Receive:\n");
	bp = rbuf;
	bytes_to_read = BUFLEN;

    // Read the data echoed back
    SSL_read (ssl, bp, BUFLEN);
	printf ("%s\n", rbuf);
    fflush (stdout);
	close (sd);
    
	// Release the context
	destroy_ctx (ctx);
	return (0);
}


// Verify that the common name matches the host name
void check_cert_chain (SSL *ssl, char *host)
{
        X509 *peer;
        char peer_CN[256];

        if(SSL_get_verify_result(ssl)!=X509_V_OK)
                berr_exit("Certificate doesn't verify");

        /*Check the cert chain. The chain length
        is automatically checked by OpenSSL when we
        set the verify depth in the ctx */

        /*Check the common name*/
        peer=SSL_get_peer_certificate(ssl);
        X509_NAME_get_text_by_NID (
                X509_get_subject_name(peer),
                NID_commonName,
                peer_CN, 256
        );

        if(strcasecmp(peer_CN,host))
                err_exit("Common name doesn't match host name");
}