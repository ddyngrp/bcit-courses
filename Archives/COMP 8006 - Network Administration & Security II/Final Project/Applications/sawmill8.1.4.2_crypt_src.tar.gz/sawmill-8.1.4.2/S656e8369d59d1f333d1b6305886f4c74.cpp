//
// Sawmill Source Code
// 
// This source code is the intellectual property of Flowerfire,
// and is protected by federal trade secret laws.  Do not
// redistribute, modify, or use this source code, except to compile
// it, without the express written consent of Flowerfire.
//
// For more information, see http://www.sawmill.net/trade_secret.html
//
// The trial and full commercial licenses for Sawmill allow you
// to use the program, and to compile it from this source code,
// but you are not permitted to look at this source code.  Please
// do not attempt to use this source code for any purpose other 
// than compilation!



















































 
#include "sconfig.h"

#include "S03bd42fa450e1f34accdab3519aa18f4.h"

#include "Sd7a1ff3fcf56a22d329b8de41003ce11.h"

#include "Sa4bc89fb797fffe3989f435653081e8d.h"

#include "S53ed6907a30ee3eb77fae211c23825e2.h"

#include "Secf36bf903121295607de79adb143b01.h"

#include "Sa95266e9d13052fad657d08a38e5729b.h"

#include "Sd2b310343811110093f34d4db360546e.h"

#include "S78ad491ac8a005c50b041106551db851.h"

#include "Sd5d0864971a099befe0cde8fe198b302.h"

#include "S73732de38ae890ab3740ef4f8a5b7996.h"

#include "S96ba125ebc01b3b2746a65df0dca97d2.h"

#include "S5c686a55e1be1e5c2d8a4c8424ee6932.h"

#include "S508c8eba79cf8e3f0f3efec699333525.h"

#include "S3a79f7695a894248bc866236cc10d55b.h"

#include "S76b38d72dd03a1510b6a40de8b03fc78.h"

#include "Se00f7d81e824b8a8baa31e30777a2666.h"

#include "S50a433794a35f2de7397aa02a05782ba.h"

#include "S65b54cd362bca037dc0b5544f5095c09.h"

#include "S03b4aa5755dc381488543322f8a56e0a.h"

#include "S34c309ed637a8e6a888e4573b3b7f904.h"

#include "Sa962fe56d31486f7085f178942f70f9b.h"

#include "Se9b814b8282a366c5c9ccbf7fdecfe74.h"

#include "S2b659cf002e8d20bd33ff44e6e3a8a70.h"

#include "cc_regexp.h"

#include "S517484715e4abbdf430fe8a3286dce78.h"

#include "Sc9ae9176cbf879523674b42b80a1de8d.h"

#include "Scae613df5f8d33d29ffa329e57180663.h"

#include "S730d7dc4b5b7610dadd60b8f9db23bf2.h"

#include "S3e3af11e108aa6fefb5a12f010f7b40b.h"

#include "S8c35dc3541dc5a9aa957381ceea6ca02.h"

#include "Se806def05a039820e7bf350f56081a93.h"

#include "char_checks.h"
     class Sb562f4d3e35c4ff450d6e433e695f1e7 { public: Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e; 
Sb562f4d3e35c4ff450d6e433e695f1e7(Sc51497dedb5c0712f20ccaa9831c0365 &S6ec129777c16ed8568398f5726365a75) 
: Scc2faae6b412ac43b64129b402c4b88e(S6ec129777c16ed8568398f5726365a75) { } bool operator() (S9d9b1213b8e8dee3e5202e15cdc0afab 
*x, S9d9b1213b8e8dee3e5202e15cdc0afab *y) const { S6d6cbe6673721b1104d6dcb8de7beb6a S8543f52c41ea0545859c1fb572462119 
= x->name; S8543f52c41ea0545859c1fb572462119.S1cb4f6eb603b8e7617cd6eadf2ce3ee5(); S6d6cbe6673721b1104d6dcb8de7beb6a 
S73724dd3b7e659550ce2a526768adbef = y->name; S73724dd3b7e659550ce2a526768adbef.S1cb4f6eb603b8e7617cd6eadf2ce3ee5(); 
if (Sb43b56fff9bc1038da1785a37c090c66) { if (S8543f52c41ea0545859c1fb572462119.S50ecde1d8305c85a933dc85759419955("bluecoat")) 
{ S8543f52c41ea0545859c1fb572462119 = " " + S8543f52c41ea0545859c1fb572462119; } if (S73724dd3b7e659550ce2a526768adbef.S50ecde1d8305c85a933dc85759419955("bluecoat")) 
{ S73724dd3b7e659550ce2a526768adbef = " " + S73724dd3b7e659550ce2a526768adbef; } } return S8543f52c41ea0545859c1fb572462119 
< S73724dd3b7e659550ce2a526768adbef; } }; void Sf74fac256fd59cb57ebd90510fdc538d(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Sd677b423ceeac0bd8e856dfd6cb1db94) {  S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
S48638ac2d3acfedd891ef9de6d9ca56c;   if (!Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S0bd9ebbd28c33138f260f38afcd567b6) 
{ Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S0bd9ebbd28c33138f260f38afcd567b6 
= new S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*); Scc2faae6b412ac43b64129b402c4b88e.S334333264de3a5e6e897683e841976b8 
= 0;  S7ca5d44c3992eca4f11ed4ee768968cd *Sab0347b4a92a12d037d087b472d505e8 = Sb96e04ee47495193c47f7004f4f555a1("log_formats"); 
for (S7ca5d44c3992eca4f11ed4ee768968cd *S6b64ef280d80d7249305b248333f3b87 = Sab0347b4a92a12d037d087b472d505e8->Scf9a08b96fbb10815617bd2a33d4e51b(Scc2faae6b412ac43b64129b402c4b88e); 
S6b64ef280d80d7249305b248333f3b87; S6b64ef280d80d7249305b248333f3b87 = Sab0347b4a92a12d037d087b472d505e8->S8959a4733efe0c4c3118fe29974fb7a2(Scc2faae6b412ac43b64129b402c4b88e)) 
{  S9d9b1213b8e8dee3e5202e15cdc0afab *Sf17bd2683ca5196f1525a5f62776c7c7 = new S9d9b1213b8e8dee3e5202e15cdc0afab; 
Sf17bd2683ca5196f1525a5f62776c7c7->name = S6b64ef280d80d7249305b248333f3b87->S50725c229541d49fe591346687d603e6(); 
Sf17bd2683ca5196f1525a5f62776c7c7->Sc22377b5b326edb2bea57e372f1c01af = S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.format.format_label"); 
if (!S6b64ef280d80d7249305b248333f3b87->S84b49969ced69fcd76f788e837449ba5("log.format.autodetect_regular_expression") 
&& !S6b64ef280d80d7249305b248333f3b87->S84b49969ced69fcd76f788e837449ba5("log.format.autodetect_expression")) 
{ Sb3c15d52751fa37e8e783ffdac507fd5(Sf17bd2683ca5196f1525a5f62776c7c7->Sc22377b5b326edb2bea57e372f1c01af, 
"$lang_messages.ERROR_NO_AUTODETECT_FORMAT_FOUND"); }  Sf17bd2683ca5196f1525a5f62776c7c7->S97000a517bd100e0160dfeac6313f1b6 
= S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.miscellaneous.log_data_type"); 
 if (S6b64ef280d80d7249305b248333f3b87->S84b49969ced69fcd76f788e837449ba5("log.format.autodetect_lines")) 
Sf17bd2683ca5196f1525a5f62776c7c7->Sc6855ef4923f112299fbfdb0dd6b8368 = S6b64ef280d80d7249305b248333f3b87->S9347150fb63fbc65aa049ea5438d93b6("log.format.autodetect_lines"); 
else Sf17bd2683ca5196f1525a5f62776c7c7->Sc6855ef4923f112299fbfdb0dd6b8368 = 10;  if (Sf17bd2683ca5196f1525a5f62776c7c7->Sc6855ef4923f112299fbfdb0dd6b8368 
> Scc2faae6b412ac43b64129b402c4b88e.S334333264de3a5e6e897683e841976b8) Scc2faae6b412ac43b64129b402c4b88e.S334333264de3a5e6e897683e841976b8 
= Sf17bd2683ca5196f1525a5f62776c7c7->Sc6855ef4923f112299fbfdb0dd6b8368; if (S6b64ef280d80d7249305b248333f3b87->S84b49969ced69fcd76f788e837449ba5("log.format.autodetect_regular_expression")) 
{ S6d6cbe6673721b1104d6dcb8de7beb6a S4f6d1f7cecae2273768503639d032f11 = S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.format.autodetect_regular_expression"); 
Sf17bd2683ca5196f1525a5f62776c7c7->S6c262c7ae907d25e3bea365cad83902e = true;   int Sef365f984a347cadd898f77883ad12b5 
= regcomp(&Sf17bd2683ca5196f1525a5f62776c7c7->S4f6d1f7cecae2273768503639d032f11, S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.format.autodetect_regular_expression"), 
REG_EXTENDED); if (Sef365f984a347cadd898f77883ad12b5) { char S11a3f47f1efa92aad7d97270d8d32739[1000]; 
regerror(Sef365f984a347cadd898f77883ad12b5, &Sf17bd2683ca5196f1525a5f62776c7c7->S4f6d1f7cecae2273768503639d032f11, 
&(S11a3f47f1efa92aad7d97270d8d32739[0]), 1000); Sb3c15d52751fa37e8e783ffdac507fd5(S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.format.autodetect_regular_expression"), 
"$lang_messages.ERROR_COMPILING_REGEXP"); } }   else if (S6b64ef280d80d7249305b248333f3b87->S84b49969ced69fcd76f788e837449ba5("log.format.autodetect_expression")) 
{ Sf17bd2683ca5196f1525a5f62776c7c7->S6c262c7ae907d25e3bea365cad83902e = false; const char *S224b6774c60f4ad23653b2af904c3f6b 
= S6b64ef280d80d7249305b248333f3b87->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log.format.autodetect_expression"); 
Sf17bd2683ca5196f1525a5f62776c7c7->S7ebcc1e102c76cd750483117bb08c6ea = Sc3057ef3d8b0af864991d43b59105f43(Scc2faae6b412ac43b64129b402c4b88e, 
S224b6774c60f4ad23653b2af904c3f6b); S7ca5d44c3992eca4f11ed4ee768968cd *Sc013e0deefdd44bc33b77988f84ffbda 
= Sf17bd2683ca5196f1525a5f62776c7c7->S7ebcc1e102c76cd750483117bb08c6ea;  if (Sc013e0deefdd44bc33b77988f84ffbda->Sb81599bdf713b73487af2165efb27855 
== NULL) Sc013e0deefdd44bc33b77988f84ffbda->Sb81599bdf713b73487af2165efb27855 = new S05f455e54e79c3e428e073565af2cd53(Scc2faae6b412ac43b64129b402c4b88e, 
Sc013e0deefdd44bc33b77988f84ffbda); S05f455e54e79c3e428e073565af2cd53 *Sc23ca62cb586cfb7632bbc0648f3d3e6 
= (S05f455e54e79c3e428e073565af2cd53*) Sc013e0deefdd44bc33b77988f84ffbda->Sb81599bdf713b73487af2165efb27855; 
Sc23ca62cb586cfb7632bbc0648f3d3e6->S612821d5224a99da8040657bb834373d(Scc2faae6b412ac43b64129b402c4b88e); 
 S113a7f9a390c8e9266b8bfced44d845d S319c863a204ce77139ac1b8a27cc7595; S319c863a204ce77139ac1b8a27cc7595.Saec2f6eb44506ba469d3190ab26c46b4 
= Sc013e0deefdd44bc33b77988f84ffbda->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e); 
S319c863a204ce77139ac1b8a27cc7595.S1cd9c4966d6732250f09fd148fbf20d4 = Sc013e0deefdd44bc33b77988f84ffbda->Sed16ababedb8fbdb39eb62b320312bfe(Scc2faae6b412ac43b64129b402c4b88e); 
S319c863a204ce77139ac1b8a27cc7595.Se656ddb12a6b2fd37cd7d32b493acb19 = Sc013e0deefdd44bc33b77988f84ffbda; 
Sc23ca62cb586cfb7632bbc0648f3d3e6->S3a1b33761049b1644ae35315d18ccc90 = Sc013e0deefdd44bc33b77988f84ffbda->S2fcb08276be80cc1ff7abdabde1ca000(Scc2faae6b412ac43b64129b402c4b88e, 
S319c863a204ce77139ac1b8a27cc7595); }   ((S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
*) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S0bd9ebbd28c33138f260f38afcd567b6)->push_back(Sf17bd2683ca5196f1525a5f62776c7c7); 
}  }   S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) &S0bd9ebbd28c33138f260f38afcd567b6 
= *((S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) *) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S0bd9ebbd28c33138f260f38afcd567b6); 
for (S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*)::iterator S139a2eec095a5e717265dab0006c1900 
= S0bd9ebbd28c33138f260f38afcd567b6.begin(); S139a2eec095a5e717265dab0006c1900 != S0bd9ebbd28c33138f260f38afcd567b6.end(); 
S139a2eec095a5e717265dab0006c1900++) {  if (Scc2faae6b412ac43b64129b402c4b88e.Sf53e01426e9b5d8edd6ff6999eebb3c2 
> (*S139a2eec095a5e717265dab0006c1900)->Sc6855ef4923f112299fbfdb0dd6b8368) { }  else {  bool S2a4ac007f77626e82a795f1995433a6e; 
if ((*S139a2eec095a5e717265dab0006c1900)->S6c262c7ae907d25e3bea365cad83902e) {  REGEXP_LOCK_OBTAIN; 
S2a4ac007f77626e82a795f1995433a6e = !regexec(&((*S139a2eec095a5e717265dab0006c1900)->S4f6d1f7cecae2273768503639d032f11), 
Sd677b423ceeac0bd8e856dfd6cb1db94, 0, NULL, 0); REGEXP_LOCK_RELEASE; }  else { S0dd528a42552b31ec5d309edca503524("log_data_line", 
Sd677b423ceeac0bd8e856dfd6cb1db94);  S7ca5d44c3992eca4f11ed4ee768968cd *Sc013e0deefdd44bc33b77988f84ffbda 
= (*S139a2eec095a5e717265dab0006c1900)->S7ebcc1e102c76cd750483117bb08c6ea; Scc2faae6b412ac43b64129b402c4b88e.S0a0ba0324a834d53a8d0f4827daf4171 
= Sc013e0deefdd44bc33b77988f84ffbda->S125fa438ab7d0e5a305281fe931b4d4a(); S78ae68dfe2c19a960801c347739282fd 
S53eb4d136deee7a24f1368147743b989; Scc2faae6b412ac43b64129b402c4b88e.Sba3bb89649a93275b5867c244f7fd3f7 
= false; Scc2faae6b412ac43b64129b402c4b88e.Sf47536b6d4414c7e3350c04f4bcc49f6 = false; Scc2faae6b412ac43b64129b402c4b88e.S1ad8734f40fa79d715246203ef2b94fe 
= false; S53eb4d136deee7a24f1368147743b989.Sa4710926073618a997f869325774c040 = ""; S53eb4d136deee7a24f1368147743b989.Sb4d13b0409aae7ba9b8dea831bcb458d 
= false; S53eb4d136deee7a24f1368147743b989.S3630565caf449d8eb1932b8cf9139f07 = false; S05f455e54e79c3e428e073565af2cd53 
*Sc23ca62cb586cfb7632bbc0648f3d3e6 = (S05f455e54e79c3e428e073565af2cd53*) Sc013e0deefdd44bc33b77988f84ffbda->Sb81599bdf713b73487af2165efb27855; 
S7ca5d44c3992eca4f11ed4ee768968cd *Sce87cba75e442ed5396fef2240b1b107 = Sc23ca62cb586cfb7632bbc0648f3d3e6->S3a1b33761049b1644ae35315d18ccc90->S159474053113b22919eea8439fea6ae5(Scc2faae6b412ac43b64129b402c4b88e, 
S53eb4d136deee7a24f1368147743b989, "", false, S53eb4d136deee7a24f1368147743b989.S3630565caf449d8eb1932b8cf9139f07); 
Scc2faae6b412ac43b64129b402c4b88e.S0a0ba0324a834d53a8d0f4827daf4171 = NULL; S2a4ac007f77626e82a795f1995433a6e 
= Sce87cba75e442ed5396fef2240b1b107->S442f26558d8f1d709268bd684488e36b(Scc2faae6b412ac43b64129b402c4b88e); 
}  if (S2a4ac007f77626e82a795f1995433a6e) {  bool S5f03ce9b6ae144a2c0b7750dee34c320 = false; S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
&S33dd3b4f56d265d78412151da40670f9 = *((S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
*) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S33dd3b4f56d265d78412151da40670f9); 
for (S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*)::iterator Seb9d419135e896279ecc7721147bbd03 
= S33dd3b4f56d265d78412151da40670f9.begin(); Seb9d419135e896279ecc7721147bbd03 != S33dd3b4f56d265d78412151da40670f9.end(); 
Seb9d419135e896279ecc7721147bbd03++) if ((*Seb9d419135e896279ecc7721147bbd03)->name == (*S139a2eec095a5e717265dab0006c1900)->name) 
S5f03ce9b6ae144a2c0b7750dee34c320 = true; if (!S5f03ce9b6ae144a2c0b7750dee34c320) { S9d9b1213b8e8dee3e5202e15cdc0afab 
*Sf17bd2683ca5196f1525a5f62776c7c7 = new S9d9b1213b8e8dee3e5202e15cdc0afab(); *Sf17bd2683ca5196f1525a5f62776c7c7 
= *(*S139a2eec095a5e717265dab0006c1900); S33dd3b4f56d265d78412151da40670f9.push_back(Sf17bd2683ca5196f1525a5f62776c7c7); 
} }  }  }   if (Sd677b423ceeac0bd8e856dfd6cb1db94) { }  else { S878a3d3a963b22c05662063eca936ad0("Unknown log file format: \"" 
<< S303ebfc6eeaf1c153a3882a61471ac48("log.format.log_file_format") << "\""); }  S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
&S33dd3b4f56d265d78412151da40670f9 = *((S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*) 
*) Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S33dd3b4f56d265d78412151da40670f9); 
if (Sd677b423ceeac0bd8e856dfd6cb1db94 && (S33dd3b4f56d265d78412151da40670f9.size() > 1)) { for (S53ed6907a30ee3eb77fae211c23825e2(S9d9b1213b8e8dee3e5202e15cdc0afab*)::iterator 
S6b64ef280d80d7249305b248333f3b87 = S33dd3b4f56d265d78412151da40670f9.begin(); S6b64ef280d80d7249305b248333f3b87 
!= S33dd3b4f56d265d78412151da40670f9.end(); ) { if ((*S6b64ef280d80d7249305b248333f3b87)->name.S50ecde1d8305c85a933dc85759419955("(Generic)")) 
{ S33dd3b4f56d265d78412151da40670f9.erase(S6b64ef280d80d7249305b248333f3b87); S6b64ef280d80d7249305b248333f3b87 
= S33dd3b4f56d265d78412151da40670f9.begin(); } else S6b64ef280d80d7249305b248333f3b87++; } } }   const 
char *Sca2602b1725af315ad7495eddca9d0bf(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Secd20ac08c5debc250b360fe31b64f76) { char *name = Sba2c7eb5a7f9703c170fed61ef960a93(Scc2faae6b412ac43b64129b402c4b88e, 
Secd20ac08c5debc250b360fe31b64f76); char *Saec2f6eb44506ba469d3190ab26c46b4 = name; while (*Saec2f6eb44506ba469d3190ab26c46b4) 
{ if (!ISALNUM(*Saec2f6eb44506ba469d3190ab26c46b4)) *Saec2f6eb44506ba469d3190ab26c46b4 = '_';  *Saec2f6eb44506ba469d3190ab26c46b4 
= tolower(*Saec2f6eb44506ba469d3190ab26c46b4); Saec2f6eb44506ba469d3190ab26c46b4++; } while (name[0] 
== '_') name++; while (name[Sa65ce13717451b94f10482e8ef0770a2(name)-1] == '_') name[Sa65ce13717451b94f10482e8ef0770a2(name)-1] 
= 0; if (name[0] == 0) name = "empty_field"; return name; } const char *Sdc94255f95e145fefa09cb08e6446c58(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *name) { const char *Sc22377b5b326edb2bea57e372f1c01af 
= NULL; if (Sc941708ac716c7d0748240bb3fb43cce("lang_stats.field_labels")->S84b49969ced69fcd76f788e837449ba5(name)) 
{  Sc22377b5b326edb2bea57e372f1c01af = Sbdc70c498cd54d91c938377bbdbd2897(Scc2faae6b412ac43b64129b402c4b88e, 
"$lang_stats.field_labels.", name); } else { Sc22377b5b326edb2bea57e372f1c01af = Sba2c7eb5a7f9703c170fed61ef960a93(Scc2faae6b412ac43b64129b402c4b88e, 
name); static bool Sa8dbccf54461066f55bf9ea39625315c = false;   Sa8dbccf54461066f55bf9ea39625315c = 
true; S6d6cbe6673721b1104d6dcb8de7beb6a Sd0e69234a84e2e678cb6501bd9406dc4 = Sc22377b5b326edb2bea57e372f1c01af; 
Sd0e69234a84e2e678cb6501bd9406dc4.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
"_", " ");  } return Sc22377b5b326edb2bea57e372f1c01af; }   void Sd5d0b11267d13e242aa775ef7a48dead(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Secd20ac08c5debc250b360fe31b64f76, const char *Sd3d1d74a212645311e2b035f0e443351, 
mint S057e8d652f08fa6cc73b9dd3f3070c01, mint S1a8d428c67a98311a8ecc7711a7ba067, const char *S6edbac462707965c2970ef8fbdb2e58d, 
bool Sea8dddb7a974e451235c4a748007c785, bool Sfd0444b2e65433cf76e84f10bf0912af, bool S2773a55230058d737371f7476f6c7dd6) 
{   const char *name = Sca2602b1725af315ad7495eddca9d0bf(Scc2faae6b412ac43b64129b402c4b88e, Secd20ac08c5debc250b360fe31b64f76); 
const char *Sc22377b5b326edb2bea57e372f1c01af = Sdc94255f95e145fefa09cb08e6446c58(Scc2faae6b412ac43b64129b402c4b88e, 
name); Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, name, Sc22377b5b326edb2bea57e372f1c01af, 
Sd3d1d74a212645311e2b035f0e443351, S057e8d652f08fa6cc73b9dd3f3070c01, S1a8d428c67a98311a8ecc7711a7ba067, 
S6edbac462707965c2970ef8fbdb2e58d, Sea8dddb7a974e451235c4a748007c785, Sfd0444b2e65433cf76e84f10bf0912af, 
S2773a55230058d737371f7476f6c7dd6); } void Sd5d0b11267d13e242aa775ef7a48dead(Sc51497dedb5c0712f20ccaa9831c0365 
&Scc2faae6b412ac43b64129b402c4b88e, const char *Secd20ac08c5debc250b360fe31b64f76, const char *Sc22377b5b326edb2bea57e372f1c01af, 
const char *Sd3d1d74a212645311e2b035f0e443351, mint S057e8d652f08fa6cc73b9dd3f3070c01, mint S1a8d428c67a98311a8ecc7711a7ba067, 
const char *S6edbac462707965c2970ef8fbdb2e58d, bool Sea8dddb7a974e451235c4a748007c785, bool Sfd0444b2e65433cf76e84f10bf0912af, 
bool S2773a55230058d737371f7476f6c7dd6) { S6d6cbe6673721b1104d6dcb8de7beb6a name = Secd20ac08c5debc250b360fe31b64f76; 
S6d6cbe6673721b1104d6dcb8de7beb6a S082d71ad3355073b28ec02412353d9ab = name; name.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, 
"%", "_"); name.S23f035a74a8aeec11cfc740e503ca2c8(Scc2faae6b412ac43b64129b402c4b88e, ".", "_"); S709f8a104a477b9e6883c170d8a6a334(name 
= S648420c355f12f72930f7fc38ed3d2ba(Scc2faae6b412ac43b64129b402c4b88e, name.c_str()));   bool Sd7c7bc9a6899b0c16ac0dd9ef4231a67 
= false; for (mint Sc0f4d1963f4c9b74bee20fea9666430e = 0; Sc0f4d1963f4c9b74bee20fea9666430e < S081a3bc3c07b697703dc7a201ee41aa4(); 
Sc0f4d1963f4c9b74bee20fea9666430e++) { if ((S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S16afae31727c426449f830eeb14d81f3(Scc2faae6b412ac43b64129b402c4b88e) 
== S057e8d652f08fa6cc73b9dd3f3070c01) && (S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S80a5063ceddf459bce6f4836e22c5480(Scc2faae6b412ac43b64129b402c4b88e) 
== S1a8d428c67a98311a8ecc7711a7ba067)) { S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S5b0e82868aa537533b57d81256af2cfa()->Se27e37418da71e8d1108561dad91573b("index", 
0); S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S5b0e82868aa537533b57d81256af2cfa()->Se27e37418da71e8d1108561dad91573b("subindex", 
0); S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S5b0e82868aa537533b57d81256af2cfa()->Sc4cb013e45bec7d5f123878c171575b8(Scc2faae6b412ac43b64129b402c4b88e, 
true, false); }   if ((Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, "host") 
|| Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, "page")) && S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S5b0e82868aa537533b57d81256af2cfa()->S84b49969ced69fcd76f788e837449ba5("type") 
&& Sbea6e228a47bc141f76fa54e2c8ba1b9(S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S5b0e82868aa537533b57d81256af2cfa()->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
Sd3d1d74a212645311e2b035f0e443351) && (name != S110c0348fa767c7b6f222a32146471df(Sc0f4d1963f4c9b74bee20fea9666430e)->S50725c229541d49fe591346687d603e6(Scc2faae6b412ac43b64129b402c4b88e))) 
{ Sd7c7bc9a6899b0c16ac0dd9ef4231a67 = true; } }   if (Sd7c7bc9a6899b0c16ac0dd9ef4231a67) {  Sd3d1d74a212645311e2b035f0e443351 
= "flat"; }  bool S2a1b54d3941c11cd324a02c31ef75a57 = false; if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, 
"referrer") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, "URL") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, 
"url")) { Sd3d1d74a212645311e2b035f0e443351 = "url"; S2a1b54d3941c11cd324a02c31ef75a57 = true; } S450f949b3e7bb078cb242696e2df04a5(Sfc39285cd3249cf5279f58d15471472a, 
name.c_str(), Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, S057e8d652f08fa6cc73b9dd3f3070c01), 
Sa25c71346b9fa47998a5d0cd981a607d(Scc2faae6b412ac43b64129b402c4b88e, S1a8d428c67a98311a8ecc7711a7ba067), 
"$lang_messages.MSG_SET_FIELD\n");   S7ca5d44c3992eca4f11ed4ee768968cd *S2f2189448ce4f90cccfb90bf28e08572; 
if (Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(name.c_str())) 
S2f2189448ce4f90cccfb90bf28e08572 = Sd88999e2476dbfd316b0d0689530380b("log.fields")->S6c7d84bb91509e8c72e7dd25a6eed444(name.c_str()); 
else { S2f2189448ce4f90cccfb90bf28e08572 = Sc3057ef3d8b0af864991d43b59105f43(Scc2faae6b412ac43b64129b402c4b88e, 
Sd88999e2476dbfd316b0d0689530380b("log.fields"), name.c_str(), true, true); } S2f2189448ce4f90cccfb90bf28e08572->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
Sd3d1d74a212645311e2b035f0e443351); S2f2189448ce4f90cccfb90bf28e08572->S339ec4ebc6f2f5e7fc68e895ded32ae7("label", 
Sc22377b5b326edb2bea57e372f1c01af); S2f2189448ce4f90cccfb90bf28e08572->Se27e37418da71e8d1108561dad91573b("index", 
S057e8d652f08fa6cc73b9dd3f3070c01); S2f2189448ce4f90cccfb90bf28e08572->Se27e37418da71e8d1108561dad91573b("subindex", 
S1a8d428c67a98311a8ecc7711a7ba067); S2f2189448ce4f90cccfb90bf28e08572->S339ec4ebc6f2f5e7fc68e895ded32ae7("hierarchy_dividers", 
S6edbac462707965c2970ef8fbdb2e58d); S2f2189448ce4f90cccfb90bf28e08572->Sbd5bb2da8370e42b52d874c38ec0e60d("left_to_right", 
Sea8dddb7a974e451235c4a748007c785); S2f2189448ce4f90cccfb90bf28e08572->Sbd5bb2da8370e42b52d874c38ec0e60d("leading_divider", 
Sfd0444b2e65433cf76e84f10bf0912af); S2f2189448ce4f90cccfb90bf28e08572->Sbd5bb2da8370e42b52d874c38ec0e60d("case_sensitive", 
S2773a55230058d737371f7476f6c7dd6);   S2f2189448ce4f90cccfb90bf28e08572->Sc4cb013e45bec7d5f123878c171575b8(Scc2faae6b412ac43b64129b402c4b88e, 
true, false);  S6d6cbe6673721b1104d6dcb8de7beb6a Sb993daf4b8499b13a909c689d0a8d301 = S999e848df86282b2352ca41cfe6347e7("auto_setup.omit_database_fields") 
? S303ebfc6eeaf1c153a3882a61471ac48("auto_setup.omit_database_fields") : "";  if (S999e848df86282b2352ca41cfe6347e7("database.numerical_fields") 
&& Sd88999e2476dbfd316b0d0689530380b("database.numerical_fields")->S84b49969ced69fcd76f788e837449ba5(name.c_str())) 
{  }  else if (Sb993daf4b8499b13a909c689d0a8d301.S50ecde1d8305c85a933dc85759419955("," + name + ",") 
|| Sb993daf4b8499b13a909c689d0a8d301.Se543ff92285a848ed4d00f194cccf802("," + name) || Sb993daf4b8499b13a909c689d0a8d301.S7c4c23c4982435c76bfd2635c357f6b7(name 
+ ",") || (Sb993daf4b8499b13a909c689d0a8d301 == name)) {  }  else {    if (Scc2faae6b412ac43b64129b402c4b88e.Sac6d1e0e09992bdc7f7d82e327447bd7) 
{ bool S66dfb475fb4a13545972b832bb259f29 = S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Secd20ac08c5debc250b360fe31b64f76, 
"time") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351,"time"); bool Sc14112db0fb595e5ac634236aacb8d49 
= S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Secd20ac08c5debc250b360fe31b64f76, "date") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, 
"date"); bool S97d49821fab41eb568698d8516331874 = S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Secd20ac08c5debc250b360fe31b64f76, 
"date_time") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, "date_time");  
 if (S66dfb475fb4a13545972b832bb259f29 || Sc14112db0fb595e5ac634236aacb8d49 || S97d49821fab41eb568698d8516331874) 
{ if (!Scc2faae6b412ac43b64129b402c4b88e.S041e34f9c46652198ab499ba19723664) {  S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "$lang_stats.field_labels.date_time", "date_time", "string", "date_time", 0, 3, false)); 
S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"day_of_week", "$lang_stats.field_labels.day_of_week", "day_of_week", "string", "day_of_week", 0, 2, 
false)); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"hour_of_day", "$lang_stats.field_labels.hour_of_day", "hour_of_day", "string", "hour_of_day", 0, 2, 
false)); Scc2faae6b412ac43b64129b402c4b88e.S041e34f9c46652198ab499ba19723664 = true; }  }   else if 
(Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, "host") && !Scc2faae6b412ac43b64129b402c4b88e.S588359a0dbc87af4716dd943469ece59) 
{  S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, 
name.c_str(), "string", NULL, 99, 99, true); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"domain_description", "$lang_stats.field_labels.domain_description", "domain_description", "string", 
NULL, 0, 2, false)); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"location", "$lang_stats.field_labels.location", "location", "string", NULL, 0, 3, false)); S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"organization", "$lang_stats.field_labels.organization", "organization", "string", NULL, 0, 2, false); 
S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, "domain", "$lang_stats.field_labels.domain", 
"domain", "string", NULL, 0, 2, false); S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"isp", "$lang_stats.field_labels.isp", "isp", "string", NULL, 0, 2, false); Scc2faae6b412ac43b64129b402c4b88e.S588359a0dbc87af4716dd943469ece59 
= true; }   else {  if (false) {}  else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, 
"agent")) { S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"web_browser", "$lang_stats.field_labels.web_browser", "web_browser", "string", NULL, 0, 2, false)); 
S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"operating_system", "$lang_stats.field_labels.operating_system", "operating_system", "string", NULL, 
0, 2, false)); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"spider", "$lang_stats.field_labels.spider", "spider", "string", NULL, 0, 2, false)); }  else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Sd3d1d74a212645311e2b035f0e443351, 
"URL") && !S2a1b54d3941c11cd324a02c31ef75a57 && !Scc2faae6b412ac43b64129b402c4b88e.S1dc307cd01dee6294d214b8e368d2df5) 
{ if (S999e848df86282b2352ca41cfe6347e7("log.format.server_type") && Sbea6e228a47bc141f76fa54e2c8ba1b9(S303ebfc6eeaf1c153a3882a61471ac48("log.format.server_type"), 
"firewall")) { S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 1, 2, false)); } else 
{ S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 1, 3, false)); } Scc2faae6b412ac43b64129b402c4b88e.S1dc307cd01dee6294d214b8e368d2df5 
= true; }   else if (S2a1b54d3941c11cd324a02c31ef75a57) { S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 1, 3, false)); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"search_engine", "$lang_stats.field_labels.search_engine", "search_engine", "string", NULL, 0, 2, false)); 
S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"search_phrase", "$lang_stats.field_labels.search_phrase", "search_phrase", "string", NULL, 0, 2, false)); 
S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"referrer_description", "$lang_stats.field_labels.referrer_description", "referrer_description", "string", 
NULL, 0, 2, false)); }  else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sd3d1d74a212645311e2b035f0e443351, 
"page") && !Scc2faae6b412ac43b64129b402c4b88e.S1dc307cd01dee6294d214b8e368d2df5) { if (S999e848df86282b2352ca41cfe6347e7("log.format.server_type") 
&& Sbea6e228a47bc141f76fa54e2c8ba1b9(S303ebfc6eeaf1c153a3882a61471ac48("log.format.server_type"), "firewall")) 
{  S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 1, 2, false)); } else 
{ S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 0, 9, false)); } S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"file_type", "$lang_stats.field_labels.file_type", "file_type", "string", NULL, 0, 2, false));  S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"screen_dimensions", "$lang_stats.field_labels.screen_dimensions", "screen_dimensions", "string", NULL, 
0, 2, false)); S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"screen_depth", "$lang_stats.field_labels.screen_depth", "screen_depth", "string", NULL, 0, 2, false)); 
S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
"worm", "$lang_stats.field_labels.worm", "worm", "string", NULL, 0, 2, false));  Scc2faae6b412ac43b64129b402c4b88e.S1dc307cd01dee6294d214b8e368d2df5 
= true; }  else { S709f8a104a477b9e6883c170d8a6a334(S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), Sc22377b5b326edb2bea57e372f1c01af, name.c_str(), "string", NULL, 0, 2, false)); } }  } 
 }  }   void S7157e6ca201d1ff834bc586a8d9a0a75(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *Secd20ac08c5debc250b360fe31b64f76, const char *Sc22377b5b326edb2bea57e372f1c01af, const 
char *S8c4ce22cb8fcad79d81f1499da387f4c, const char *Sf67e8dafb94dc766559634006a45dcee, const char *S51471d9424ff182dfb7d3b2c10619a40, 
mint S06280ddaafea1149147cafcd52755f67, mint S5b78f18711ee5653a11af9015974b673, bool S79938e5d1e74ddfdd94de180cd1957d1) 
{ S6d6cbe6673721b1104d6dcb8de7beb6a name = Secd20ac08c5debc250b360fe31b64f76; S7ca5d44c3992eca4f11ed4ee768968cd 
*S13a9a9211d36eb6a1ce453de49ae0d6a = Sd88999e2476dbfd316b0d0689530380b("database.fields"); muint S45018a4a0eda59dcf6f63860c84d577b 
= S13a9a9211d36eb6a1ce453de49ae0d6a->S2fb1ff14b23267e3fb5cc97e8c3078dd(Scc2faae6b412ac43b64129b402c4b88e); 
S7ca5d44c3992eca4f11ed4ee768968cd *Sdc85423c5f83c44212e691dc467b56af = S13a9a9211d36eb6a1ce453de49ae0d6a->S21bee3707f6917fae8e6ec90766a0769(Scc2faae6b412ac43b64129b402c4b88e, 
name.c_str(), false, false, true); muint Sbfc66a5d4885a23cf061eaf0eef62cf4 = S13a9a9211d36eb6a1ce453de49ae0d6a->S2fb1ff14b23267e3fb5cc97e8c3078dd(Scc2faae6b412ac43b64129b402c4b88e); 
 Sdc85423c5f83c44212e691dc467b56af->S339ec4ebc6f2f5e7fc68e895ded32ae7("label", Sc22377b5b326edb2bea57e372f1c01af); 
Sdc85423c5f83c44212e691dc467b56af->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", Sf67e8dafb94dc766559634006a45dcee); 
Sdc85423c5f83c44212e691dc467b56af->S339ec4ebc6f2f5e7fc68e895ded32ae7("log_field", S8c4ce22cb8fcad79d81f1499da387f4c); 
if (S51471d9424ff182dfb7d3b2c10619a40) Sdc85423c5f83c44212e691dc467b56af->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
S51471d9424ff182dfb7d3b2c10619a40); if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Sf67e8dafb94dc766559634006a45dcee, 
"string")) { Sdc85423c5f83c44212e691dc467b56af->Se27e37418da71e8d1108561dad91573b("suppress_top", S06280ddaafea1149147cafcd52755f67); 
Sdc85423c5f83c44212e691dc467b56af->Se27e37418da71e8d1108561dad91573b("suppress_bottom", S5b78f18711ee5653a11af9015974b673); 
Sdc85423c5f83c44212e691dc467b56af->Sbd5bb2da8370e42b52d874c38ec0e60d("always_include_leaves", S79938e5d1e74ddfdd94de180cd1957d1); 
} Sdc85423c5f83c44212e691dc467b56af->Sc4cb013e45bec7d5f123878c171575b8(Scc2faae6b412ac43b64129b402c4b88e, 
true, false);   if (!Scc2faae6b412ac43b64129b402c4b88e.Sd0a48d8cd7acc4d46c42c68ead89b986 && Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93727d2a1236bc83d1cafc7c191c1608 
&& (S45018a4a0eda59dcf6f63860c84d577b != Sbfc66a5d4885a23cf061eaf0eef62cf4)) { mint S0626b4be018884c5f253c2c5561eed1a 
= S70c74863207715a92af6a3127b3d04d6(name.c_str());  ((S69ea874c0a8d775fbb8debfe711290ba *) S1ecb2f2f4a04cf5861918291022bd266)->S9ebc5f4498b169a920c2a92f1255fc93 
= (Sd52d2261900a32d63729ba78632c53b9 **) S73264a722380ca67a2ba2bb30548bf64(((S69ea874c0a8d775fbb8debfe711290ba 
*) S1ecb2f2f4a04cf5861918291022bd266)->S9ebc5f4498b169a920c2a92f1255fc93, S85459fb9b577cfc38dabb71affe9fc7a() 
* sizeof(Sd52d2261900a32d63729ba78632c53b9 *), "initializing subitems");  ((S69ea874c0a8d775fbb8debfe711290ba 
*) S1ecb2f2f4a04cf5861918291022bd266)->S35d3da3bc274239d30f7ba624bcf150b(Scc2faae6b412ac43b64129b402c4b88e, 
S0626b4be018884c5f253c2c5561eed1a); S1972132661dc42f064d385e65c57a15b->S032add4616f7d7844a4654d4bed19713 
= (S601921eb7b4e2dc6cfc9af3904a74bc9 **) S73264a722380ca67a2ba2bb30548bf64(S1972132661dc42f064d385e65c57a15b->S032add4616f7d7844a4654d4bed19713, 
(S85459fb9b577cfc38dabb71affe9fc7a() + 1) * sizeof(S601921eb7b4e2dc6cfc9af3904a74bc9 *), "reallocating itemnums array"); 
S1972132661dc42f064d385e65c57a15b->S032add4616f7d7844a4654d4bed19713[S0626b4be018884c5f253c2c5561eed1a] 
= NULL;    }  }       void Se7d1a4939df3ca12ee807263e68ccaff(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
const char *line, const S6d6cbe6673721b1104d6dcb8de7beb6a &S6b64ef280d80d7249305b248333f3b87) {   if 
(Scc2faae6b412ac43b64129b402c4b88e.S0304c5d37d661bed37f5122e41fae468) return;   if (S6b64ef280d80d7249305b248333f3b87 
== "W3C") { if (S4e8df42b9159db8d732c559a489ab192(line, "#Fields:") || S4e8df42b9159db8d732c559a489ab192(line, 
"# Date\tTime")) { if (Scc2faae6b412ac43b64129b402c4b88e.S9bf8f41a8ec6e092668f61fb0541d09a == line) 
{  return; } Scc2faae6b412ac43b64129b402c4b88e.S9bf8f41a8ec6e092668f61fb0541d09a = line; } else {  return; 
} }   if (S651b5472e8358ea02f90e1a716664d31 && Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S93727d2a1236bc83d1cafc7c191c1608) 
{ S6d6cbe6673721b1104d6dcb8de7beb6a Sa6b2c16f24c9b19c63e1b560fb7b409e = S1ecb2f2f4a04cf5861918291022bd266->S2cc373f4dc5b1908c24f873fc07f0178(Scc2faae6b412ac43b64129b402c4b88e) 
+ "last_format_line.txt"; S4e5ad2e3038f5c0eb0973a77357e2b72(Scc2faae6b412ac43b64129b402c4b88e, Sa6b2c16f24c9b19c63e1b560fb7b409e.c_str(), 
Sb58c26af62a2dca70604fc8563b509b8("security.database_directory_permissions")); Sf7da212b23d3aa173472001e8927ab61(Scc2faae6b412ac43b64129b402c4b88e, 
line, Sa6b2c16f24c9b19c63e1b560fb7b409e.c_str()); }  off_t S3982b63c43c3ed107bcac2232130694e = 0; S6d6cbe6673721b1104d6dcb8de7beb6a 
S618b9f9c747d1536dcae44fbd0c51f78 = ""; if (S6b64ef280d80d7249305b248333f3b87 == "WebSTAR") { Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, 
"$lang_messages.MSG_PARSING_LOG_FORMAT_LINE\n"); S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, 
line << "\n"); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "m/d/y"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", 
"hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", "\t"); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", 
false); S3982b63c43c3ed107bcac2232130694e = 13; } else if (S6b64ef280d80d7249305b248333f3b87 == "Netscape") 
{ Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, "$lang_messages.MSG_PARSING_FORMAT_LINE\n"); 
S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, line << "\n"); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", 
"dd/mmm/yyyy:hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "dd/mmm/yyyy:hh:mm:ss"); 
S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", true); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.common_log_format", 
true); S3982b63c43c3ed107bcac2232130694e = 7; } else if (S6b64ef280d80d7249305b248333f3b87 == "FW1NG") 
{ Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, "$lang_messages.MSG_PARSING_FORMAT_LINE\n"); 
S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, line << "\n"); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", 
"dmmmyyyy"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "h:m:s"); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", 
false); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.common_log_format", false); S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
"\" \""); S3982b63c43c3ed107bcac2232130694e = 0; } else if (S6b64ef280d80d7249305b248333f3b87 == "W3C") 
{ Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, "$lang_messages.MSG_PARSING_FIELDS_LINE\n"); 
S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, line << "\n");    if (Scc2faae6b412ac43b64129b402c4b88e.S2c520a15664bb16a34c44d8b13cfa4b8 
== "Vicomsoft Log Generator") S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "dd/mm/yy"); 
else S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "auto");  if (S4e8df42b9159db8d732c559a489ab192(line, 
"#Fields: ") || (S4e8df42b9159db8d732c559a489ab192(line, "#Fields:\t"))) { S3982b63c43c3ed107bcac2232130694e 
= 9; S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "hh:mm:ss"); }  else { S3982b63c43c3ed107bcac2232130694e 
= 2;   S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "h:m:s"); }  mint Sf2d58f59147d1bbfc1c36d6eecb97a40 
= 0; mint S473dafbc0bb0de221f51cecd5a6e04b4 = 0; for (off_t Seb9d419135e896279ecc7721147bbd03 = 0; Seb9d419135e896279ecc7721147bbd03 
< Sa65ce13717451b94f10482e8ef0770a2(line); Seb9d419135e896279ecc7721147bbd03++) { if (line[Seb9d419135e896279ecc7721147bbd03] 
== '\t') S473dafbc0bb0de221f51cecd5a6e04b4++; else if (line[Seb9d419135e896279ecc7721147bbd03] == ' ') 
Sf2d58f59147d1bbfc1c36d6eecb97a40++; }   if (!S38c6c22ce1bfdd2adc7f1ecb9c4ed070("log.format.field_separator", 
"\t") && (S6b64ef280d80d7249305b248333f3b87 != "WebSTAR")) { if (Sf2d58f59147d1bbfc1c36d6eecb97a40 == 
0) S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", "\t");   else if ((S473dafbc0bb0de221f51cecd5a6e04b4 
== 0) && (S6b64ef280d80d7249305b248333f3b87 != "WebSTAR")) S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
""); else if ((S473dafbc0bb0de221f51cecd5a6e04b4 == 0) && (S6b64ef280d80d7249305b248333f3b87 == "WebSTAR")) 
S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", " ");     else if (Sf2d58f59147d1bbfc1c36d6eecb97a40 
> S473dafbc0bb0de221f51cecd5a6e04b4) S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
" "); else S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", "\t"); }      if ((S473dafbc0bb0de221f51cecd5a6e04b4 
== 1) && (Sf2d58f59147d1bbfc1c36d6eecb97a40 > 2)) { S618b9f9c747d1536dcae44fbd0c51f78 = " "; S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
"\t"); }      }   else if (S6b64ef280d80d7249305b248333f3b87 == "FW1") { Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, 
"$lang_messages.MSG_PARSING_FW1_FORMAT_LINE"); S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, 
line << "\n"); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "dmmmyyyy"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", 
"auto"); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", false); S3982b63c43c3ed107bcac2232130694e 
= 0; char S7f3f5c63b6fe99b1734383d7601f8140[2]; S7f3f5c63b6fe99b1734383d7601f8140[0] = line[3]; S7f3f5c63b6fe99b1734383d7601f8140[1] 
= 0; S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", S7f3f5c63b6fe99b1734383d7601f8140); 
}  else if ((S6b64ef280d80d7249305b248333f3b87 == "CSV") || (S6b64ef280d80d7249305b248333f3b87 == "CSV GENERIC")) 
{ Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, "$lang_messages.MSG_PARSING_CSV_FORMAT_LINE"); 
S6bcf99fce07707f06693cebe6a409e38(Sfc39285cd3249cf5279f58d15471472a, line << "\n");    S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", 
false); S3982b63c43c3ed107bcac2232130694e = 0;  S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
","); } else S00d6a0a2d331762dfcf4df377a29d38a();  int S294fca4acb13f83abe989523fdb674fb = 1;    if 
(Scc2faae6b412ac43b64129b402c4b88e.Scc73d63489f56a210fafa9fde50c9e82.S263b3ac1b39ac41593340d2545114c67.length()) 
{ S450f949b3e7bb078cb242696e2df04a5(Sfc39285cd3249cf5279f58d15471472a, "date", "#Date", "#Date", "$lang_messages.MSG_SET_FIELD\n"); 
S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date", "date", 0, 0, "/", true, false, false)); }  while (line[S3982b63c43c3ed107bcac2232130694e] == 
' ') S3982b63c43c3ed107bcac2232130694e++;   if (S618b9f9c747d1536dcae44fbd0c51f78 == "") S618b9f9c747d1536dcae44fbd0c51f78 
= S303ebfc6eeaf1c153a3882a61471ac48("log.format.field_separator"); if (S6b64ef280d80d7249305b248333f3b87 
== "WebSTAR") S618b9f9c747d1536dcae44fbd0c51f78 = " ";  off_t Sf262ff38710f4fd986183d656e416ed5 = 0; 
  while (Sf262ff38710f4fd986183d656e416ed5 != -1) {  if (S618b9f9c747d1536dcae44fbd0c51f78.length()) 
{ Sf262ff38710f4fd986183d656e416ed5 = Sc91e6762ee3d93d4be3fed12e5b4d86e(line + S3982b63c43c3ed107bcac2232130694e, 
S618b9f9c747d1536dcae44fbd0c51f78.c_str()); } else { Sf262ff38710f4fd986183d656e416ed5 = Sc91e6762ee3d93d4be3fed12e5b4d86e(line 
+ S3982b63c43c3ed107bcac2232130694e, ' '); if (Sf262ff38710f4fd986183d656e416ed5 == -1) {  Sf262ff38710f4fd986183d656e416ed5 
= Sc91e6762ee3d93d4be3fed12e5b4d86e(line + S3982b63c43c3ed107bcac2232130694e, '\t');  if (Sf262ff38710f4fd986183d656e416ed5 
!= -1) ; else {   Sf262ff38710f4fd986183d656e416ed5 = Sc91e6762ee3d93d4be3fed12e5b4d86e(line + S3982b63c43c3ed107bcac2232130694e, 
' '); } }  }   const char *Se52be4daa6003b3b7cf8075f2b8296d5; if (Sf262ff38710f4fd986183d656e416ed5 
== -1) { S709f8a104a477b9e6883c170d8a6a334( Se52be4daa6003b3b7cf8075f2b8296d5 = S2febbb7cd862018638bd89d0521ba8a1(Scc2faae6b412ac43b64129b402c4b88e, 
line, S3982b63c43c3ed107bcac2232130694e)); } else { S709f8a104a477b9e6883c170d8a6a334( Se52be4daa6003b3b7cf8075f2b8296d5 
= S2febbb7cd862018638bd89d0521ba8a1(Scc2faae6b412ac43b64129b402c4b88e, line, S3982b63c43c3ed107bcac2232130694e, 
Sf262ff38710f4fd986183d656e416ed5)); } if (Se52be4daa6003b3b7cf8075f2b8296d5[0] == '"') { S709f8a104a477b9e6883c170d8a6a334(Se52be4daa6003b3b7cf8075f2b8296d5 
= Sba2c7eb5a7f9703c170fed61ef960a93(Scc2faae6b412ac43b64129b402c4b88e, Se52be4daa6003b3b7cf8075f2b8296d5 
+ 1)); } if (Se52be4daa6003b3b7cf8075f2b8296d5[0] && (Se52be4daa6003b3b7cf8075f2b8296d5[Sa65ce13717451b94f10482e8ef0770a2(Se52be4daa6003b3b7cf8075f2b8296d5) 
- 1] == '"')) { S709f8a104a477b9e6883c170d8a6a334(Se52be4daa6003b3b7cf8075f2b8296d5 = S2febbb7cd862018638bd89d0521ba8a1(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, 0, Sa65ce13717451b94f10482e8ef0770a2(Se52be4daa6003b3b7cf8075f2b8296d5) 
- 1)); }  
#if defined(macintosh) && TARGET_CPU_68K
 
#undef S450f949b3e7bb078cb242696e2df04a5
 
#define S450f949b3e7bb078cb242696e2df04a5(S9ce866776db3a93c43fe102b8f1b359e, Sa9fed0c8d58c22ff8d64c6fa74237b11, S88a21ab88797a5438e7cf4b45e23ee0e, S8ac3182220f6faef92c2910c476a759f, Scd4082426bdc6a9533556b5ca60add93)
 
#endif
   if (false) {}  else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(Se52be4daa6003b3b7cf8075f2b8296d5, "-")) 
{ }  if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "[%SYSDATE%]")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", S294fca4acb13f83abe989523fdb674fb, 1, "", true, true, false)); }  else if 
(S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->srvhdrs.clf-status%")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "response", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, 
true)); }   else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->reqpb.clf-request%")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"operation", "flat", S294fca4acb13f83abe989523fdb674fb, 1, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"page", "page", S294fca4acb13f83abe989523fdb674fb, 2, "/?", true, true, true)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"protocol", "flat", S294fca4acb13f83abe989523fdb674fb, 3, "", false, false, false)); } else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"x-request-line")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"cs_method", "flat", S294fca4acb13f83abe989523fdb674fb, 1, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"cs_uri", "page", S294fca4acb13f83abe989523fdb674fb, 2, "/?", true, true, true)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"cs_version", "flat", S294fca4acb13f83abe989523fdb674fb, 3, "", false, false, false)); }     else if 
(S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->reqpb.proxy-request%")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"operation", "flat", S294fca4acb13f83abe989523fdb674fb, 1, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"page", "page", S294fca4acb13f83abe989523fdb674fb, 2, "/", true, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"protocol", "flat", S294fca4acb13f83abe989523fdb674fb, 3, "", false, false, false)); }  else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"COMMON_LOG_FORMAT") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "CLF")) 
{ Sb55a8771792315de88d494124781636c(Sfc39285cd3249cf5279f58d15471472a, "$lang_messages.MSG_DETECTED_COMMON_LOG_FORMAT"); 
S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "dd/mmm/yyyy:hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", 
"dd/mmm/yyyy:hh:mm:ss"); S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.treat_brackets_as_quotes", true); 
S7fca4c2e23ed3898c42bb60e79f6e67d("log.format.common_log_format", true); S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
"");  S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"hostname", "host", 1, 0, ".", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"server domain", "flat", 2, 0, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"authenticated user", "flat", 3, 0, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", 4, 1, "", true, true, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"operation", "flat", 5, 1, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"page", "page", 5, 2, "/?", true, true, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"protocol", "flat", 5, 3, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"server response", "response", 6, 0, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"size", "size", 7, 0, "", false, false, true)); }   else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"[DATE")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date", "date", S294fca4acb13f83abe989523fdb674fb, 1, "/", true, false, false)); S294fca4acb13f83abe989523fdb674fb--; 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "TIME]")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"time", "time", S294fca4acb13f83abe989523fdb674fb, 2, ":", true, false, false)); } else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"x-timestamp") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "timestamp") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "date-time")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", 
"seconds_since_jan1_1970"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "seconds_since_jan1_1970"); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "x-event-datetime")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date/time", "date/time", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", 
"yyyy/mm/dd hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "yyyy/mm/dd hh:mm:ss"); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "localtime") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"x-localtime")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"timezone", "flat", S294fca4acb13f83abe989523fdb674fb+1, 0, "", false, false, false)); S294fca4acb13f83abe989523fdb674fb++; 
 S1438a87766a9cade8f1f312277c84f51("log.format.date_format", "dd/mmm/yyyy:hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", 
"dd/mmm/yyyy:hh:mm:ss");  } else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"endtime")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", S294fca4acb13f83abe989523fdb674fb, 1, "", false, false, false)); S1438a87766a9cade8f1f312277c84f51("log.format.date_format", 
"mm/dd/yyyy:hh:mm:ss"); S1438a87766a9cade8f1f312277c84f51("log.format.time_format", "mm/dd/yyyy:hh:mm:ss"); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "URL") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"CS-URI") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-uri") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"cs-uri-path") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "target") || 
  S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-uri-stem")) {     S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "page", S294fca4acb13f83abe989523fdb674fb, 0, "/?", true, false, 
false)); }   else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "c-ip") || 
S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "c-dns") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"%Ses->client.ip%") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "hostname")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "host", S294fca4acb13f83abe989523fdb674fb, 0, ".", false, false, 
false)); }  else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "date")) { 
S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "date", S294fca4acb13f83abe989523fdb674fb, 0, "/", true, false, false)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "time")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "time", S294fca4acb13f83abe989523fdb674fb, 0, ":", true, false, true)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-username")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "flat", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-status") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"sc-status") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "c-status")) { 
S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "response", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, 
false)); } else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-method") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "s-operation")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "flat", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-version") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"cs-protocol")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "flat", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, false)); 
}  else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "sc-bytes") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"x-bytes-received") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "BYTES_SENT") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "BYTES") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Se52be4daa6003b3b7cf8075f2b8296d5, 
"len") || Sbea6e228a47bc141f76fa54e2c8ba1b9(Se52be4daa6003b3b7cf8075f2b8296d5, "Acct-Output-Octets") 
|| Sbea6e228a47bc141f76fa54e2c8ba1b9(Se52be4daa6003b3b7cf8075f2b8296d5, "total-bytes") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"%Req->vars.p2c-cl%") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->srvhdrs.content-length%")) 
{ S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "size", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, true)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "filesize")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "size", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, true)); 
} else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs(User-Agent)") || 
S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "c-agent") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"agent") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->headers.user-agent%") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "%Req->headers.user-agent%") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "browser")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "agent", S294fca4acb13f83abe989523fdb674fb, 0, "", false, false, 
false)); }  else if (S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs(Referer)") 
|| S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "cs-referred") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"cs-referer") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "referrer") || 
S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, "referer") || S4c971a6ce0be3ec20bf2de8a9f8d2ceb(Se52be4daa6003b3b7cf8075f2b8296d5, 
"%Req->headers.referer%")) { S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"referrer", "referrer", S294fca4acb13f83abe989523fdb674fb, 0, "/", true, false, false)); }   else { 
 const char *Saec2f6eb44506ba469d3190ab26c46b4 = Se52be4daa6003b3b7cf8075f2b8296d5; char *S7f3f5c63b6fe99b1734383d7601f8140 
= (char *) Se52be4daa6003b3b7cf8075f2b8296d5; while (*Saec2f6eb44506ba469d3190ab26c46b4) { if ((*Saec2f6eb44506ba469d3190ab26c46b4 
!= '\"') && (*Saec2f6eb44506ba469d3190ab26c46b4 != '\'') && (*Saec2f6eb44506ba469d3190ab26c46b4 != '%')) 
{ *S7f3f5c63b6fe99b1734383d7601f8140 = *Saec2f6eb44506ba469d3190ab26c46b4; S7f3f5c63b6fe99b1734383d7601f8140++; 
}; Saec2f6eb44506ba469d3190ab26c46b4++; } *S7f3f5c63b6fe99b1734383d7601f8140 = 0; if (Se52be4daa6003b3b7cf8075f2b8296d5[0]) 
{  S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
Se52be4daa6003b3b7cf8075f2b8296d5, "flat", S294fca4acb13f83abe989523fdb674fb, 0, "", true, false, false)); 
}  }  S294fca4acb13f83abe989523fdb674fb++;  S3982b63c43c3ed107bcac2232130694e += Sf262ff38710f4fd986183d656e416ed5 
+ (S618b9f9c747d1536dcae44fbd0c51f78.length() ? S618b9f9c747d1536dcae44fbd0c51f78.length() : 1); }  
   if (S38c6c22ce1bfdd2adc7f1ecb9c4ed070("log.format.field_separator", "\" \"")) { S1438a87766a9cade8f1f312277c84f51("log.format.field_separator", 
" "); }     
#if 0
 for (mint Sc0f4d1963f4c9b74bee20fea9666430e = 0; Sc0f4d1963f4c9b74bee20fea9666430e < (mint) S081a3bc3c07b697703dc7a201ee41aa4(); 
Sc0f4d1963f4c9b74bee20fea9666430e++) {  S7ca5d44c3992eca4f11ed4ee768968cd *S5160557c626187d293ab950f1a7cf5fe 
= Sd88999e2476dbfd316b0d0689530380b("log.fields")->S24c995b03cbba3d8ba76b423f4b0a7b2(Scc2faae6b412ac43b64129b402c4b88e, 
Sc0f4d1963f4c9b74bee20fea9666430e, true);  if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S5160557c626187d293ab950f1a7cf5fe->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
"date_time")) { if (S1411e5cdf69ee5c7bae55eda056360bd->Sfe0b9f9860b45df4187dd66db3297cc7 != -1) { S5160557c626187d293ab950f1a7cf5fe->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"flat"); } }  if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S5160557c626187d293ab950f1a7cf5fe->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
"date")) { if (S1411e5cdf69ee5c7bae55eda056360bd->S0f0fd92953101902c48ce9b4ce3b3c40 != -1) { S5160557c626187d293ab950f1a7cf5fe->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"flat"); } }  if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S5160557c626187d293ab950f1a7cf5fe->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
"time")) { if (S1411e5cdf69ee5c7bae55eda056360bd->S467ede3800e44915d74e5f45b464abd9 != -1) { S5160557c626187d293ab950f1a7cf5fe->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"flat"); } }  if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S5160557c626187d293ab950f1a7cf5fe->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
"host")) { if (S1411e5cdf69ee5c7bae55eda056360bd->S17542c8a2d438fa2206a13489b81ef15 != -1) { S5160557c626187d293ab950f1a7cf5fe->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"flat"); } }  if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S5160557c626187d293ab950f1a7cf5fe->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"), 
"page")) { if (S1411e5cdf69ee5c7bae55eda056360bd->Sc4222d932bcf71de49a03f7e8425e1d7 != -1) { S5160557c626187d293ab950f1a7cf5fe->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", 
"flat"); } } } 
#endif
  S709f8a104a477b9e6883c170d8a6a334(S06715a7f208e9a643d80eb64a583b213(Scc2faae6b412ac43b64129b402c4b88e)); 
  }   void S51fb0e272a2a73f48294c9c53993c97b(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e, 
S7ca5d44c3992eca4f11ed4ee768968cd *Sebff2b8a1db37bc3d06c5e6f5d316682) {  if (S999e848df86282b2352ca41cfe6347e7("database.numerical_fields")) 
{ S7ca5d44c3992eca4f11ed4ee768968cd *S7c31fff989baa54512c7556e096a5ece = Sd88999e2476dbfd316b0d0689530380b("database.numerical_fields"); 
 set<S6d6cbe6673721b1104d6dcb8de7beb6a> S248801904e5b5d0ad7107a910f51cfac; for (S7ca5d44c3992eca4f11ed4ee768968cd 
*S70b2735b04ec5685acee01caaa5b19d0 = S7c31fff989baa54512c7556e096a5ece->Scf9a08b96fbb10815617bd2a33d4e51b(Scc2faae6b412ac43b64129b402c4b88e); 
S70b2735b04ec5685acee01caaa5b19d0; S70b2735b04ec5685acee01caaa5b19d0 = S7c31fff989baa54512c7556e096a5ece->S8959a4733efe0c4c3118fe29974fb7a2(Scc2faae6b412ac43b64129b402c4b88e)) 
{ const char *name = S70b2735b04ec5685acee01caaa5b19d0->S50725c229541d49fe591346687d603e6(); if (Sebff2b8a1db37bc3d06c5e6f5d316682->S84b49969ced69fcd76f788e837449ba5("numerical_fields") 
&& Sebff2b8a1db37bc3d06c5e6f5d316682->S6c7d84bb91509e8c72e7dd25a6eed444("numerical_fields")->S84b49969ced69fcd76f788e837449ba5(name) 
&& Sebff2b8a1db37bc3d06c5e6f5d316682->S6c7d84bb91509e8c72e7dd25a6eed444("numerical_fields")->S83ee3acc3a0531260fecbeac7973e9cc(name)) 
{ if (S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("aggregation_method") && 
Sbea6e228a47bc141f76fa54e2c8ba1b9(S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("aggregation_method"), 
"average")) {  S248801904e5b5d0ad7107a910f51cfac.insert(S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("average_denominator_field")); 
}  }  }   for (S7ca5d44c3992eca4f11ed4ee768968cd *S70b2735b04ec5685acee01caaa5b19d0 = S7c31fff989baa54512c7556e096a5ece->Scf9a08b96fbb10815617bd2a33d4e51b(Scc2faae6b412ac43b64129b402c4b88e); 
S70b2735b04ec5685acee01caaa5b19d0; S70b2735b04ec5685acee01caaa5b19d0 = S7c31fff989baa54512c7556e096a5ece->S8959a4733efe0c4c3118fe29974fb7a2(Scc2faae6b412ac43b64129b402c4b88e)) 
{ const char *name = S70b2735b04ec5685acee01caaa5b19d0->S50725c229541d49fe591346687d603e6();   bool 
Se94bf7fff5e961775db6402a381caaab = false; if (Sebff2b8a1db37bc3d06c5e6f5d316682->S84b49969ced69fcd76f788e837449ba5("numerical_fields") 
&& Sebff2b8a1db37bc3d06c5e6f5d316682->S6c7d84bb91509e8c72e7dd25a6eed444("numerical_fields")->S84b49969ced69fcd76f788e837449ba5(name) 
&& Sebff2b8a1db37bc3d06c5e6f5d316682->S6c7d84bb91509e8c72e7dd25a6eed444("numerical_fields")->S83ee3acc3a0531260fecbeac7973e9cc(name)) 
Se94bf7fff5e961775db6402a381caaab = true; if (S248801904e5b5d0ad7107a910f51cfac.find(name) != S248801904e5b5d0ad7107a910f51cfac.end()) 
Se94bf7fff5e961775db6402a381caaab = true; if (Se94bf7fff5e961775db6402a381caaab) { S6d6cbe6673721b1104d6dcb8de7beb6a 
Sc22377b5b326edb2bea57e372f1c01af;  bool S77e857f042720de7d0c6ec033cd743b2 = S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("label"); 
if (S77e857f042720de7d0c6ec033cd743b2) { Sc22377b5b326edb2bea57e372f1c01af = S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("label"); 
}  else if (Sc941708ac716c7d0748240bb3fb43cce("lang_stats.field_labels")->S84b49969ced69fcd76f788e837449ba5(name)) 
{  Sc22377b5b326edb2bea57e372f1c01af = Sbdc70c498cd54d91c938377bbdbd2897(Scc2faae6b412ac43b64129b402c4b88e, 
"$lang_stats.field_labels.", name); }  else Sc22377b5b326edb2bea57e372f1c01af = name;  if (!S77e857f042720de7d0c6ec033cd743b2 
&& S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("aggregation_method")) {    
 if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("aggregation_method"), 
"max")) Sc22377b5b326edb2bea57e372f1c01af += " $lang_stats.field_labels.max_tag"; else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("aggregation_method"), 
"min")) Sc22377b5b326edb2bea57e372f1c01af += " $lang_stats.field_labels.min_tag"; }   if (!S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("type")) 
S70b2735b04ec5685acee01caaa5b19d0->S339ec4ebc6f2f5e7fc68e895ded32ae7("type", "int"); S6d6cbe6673721b1104d6dcb8de7beb6a 
Sf67e8dafb94dc766559634006a45dcee = S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("type"); 
 if (!S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("display_format_type")) S70b2735b04ec5685acee01caaa5b19d0->S339ec4ebc6f2f5e7fc68e895ded32ae7("display_format_type", 
"integer");  bool S65c6e7a1178da657941c869529da437c = false; if (Sf67e8dafb94dc766559634006a45dcee == 
"unique") { S6d6cbe6673721b1104d6dcb8de7beb6a S40e24fe2e0d5e86037231c09239a9d49 = S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("log_field") 
? S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log_field") : S70b2735b04ec5685acee01caaa5b19d0->S50725c229541d49fe591346687d603e6(); 
if (Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(S40e24fe2e0d5e86037231c09239a9d49.c_str())) 
S65c6e7a1178da657941c869529da437c = true; }  else if (S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("log_field") 
&& Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log_field"))) 
{ S65c6e7a1178da657941c869529da437c = true; }     else if (!S70b2735b04ec5685acee01caaa5b19d0->S84b49969ced69fcd76f788e837449ba5("requires_log_field")) 
{ if (Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(S70b2735b04ec5685acee01caaa5b19d0->S50725c229541d49fe591346687d603e6())) 
S65c6e7a1178da657941c869529da437c = true; } else if (S70b2735b04ec5685acee01caaa5b19d0->S83ee3acc3a0531260fecbeac7973e9cc("requires_log_field")) 
{ if (Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(name)) S65c6e7a1178da657941c869529da437c 
= true; }   else { if (!Sd88999e2476dbfd316b0d0689530380b("log.fields")->S84b49969ced69fcd76f788e837449ba5(name)) 
{ S6d6cbe6673721b1104d6dcb8de7beb6a Sb993daf4b8499b13a909c689d0a8d301 = S999e848df86282b2352ca41cfe6347e7("log.format.omit_database_fields") 
? S303ebfc6eeaf1c153a3882a61471ac48("log.format.omit_database_fields") : ""; S1438a87766a9cade8f1f312277c84f51("log.format.omit_database_fields", 
name); Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, name, "flat", 0, 0, "", 
false, false, false); S1438a87766a9cade8f1f312277c84f51("log.format.omit_database_fields", Sb993daf4b8499b13a909c689d0a8d301.c_str()); 
} S65c6e7a1178da657941c869529da437c = true; }   if (S65c6e7a1178da657941c869529da437c) { const char 
*S8c4ce22cb8fcad79d81f1499da387f4c; if (Sf67e8dafb94dc766559634006a45dcee == "unique") S8c4ce22cb8fcad79d81f1499da387f4c 
= S70b2735b04ec5685acee01caaa5b19d0->S8a2ed7aca5cd2ae18fad1952bfe6c14b("log_field"); else S8c4ce22cb8fcad79d81f1499da387f4c 
= name; S7157e6ca201d1ff834bc586a8d9a0a75(Scc2faae6b412ac43b64129b402c4b88e, name, Sc22377b5b326edb2bea57e372f1c01af.c_str(), 
S8c4ce22cb8fcad79d81f1499da387f4c, Sf67e8dafb94dc766559634006a45dcee.c_str(), NULL, 0, 0, false); S7ca5d44c3992eca4f11ed4ee768968cd 
*S9f3294758e681a860d867ea1574f419c = Sd88999e2476dbfd316b0d0689530380b("database.fields")->S6c7d84bb91509e8c72e7dd25a6eed444(name); 
 for (S7ca5d44c3992eca4f11ed4ee768968cd *S2f2ee89f4899d085bcf7a3c0fc10ef65 = S70b2735b04ec5685acee01caaa5b19d0->Scf9a08b96fbb10815617bd2a33d4e51b(Scc2faae6b412ac43b64129b402c4b88e); 
S2f2ee89f4899d085bcf7a3c0fc10ef65; S2f2ee89f4899d085bcf7a3c0fc10ef65 = S70b2735b04ec5685acee01caaa5b19d0->S8959a4733efe0c4c3118fe29974fb7a2(Scc2faae6b412ac43b64129b402c4b88e)) 
{ if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S2f2ee89f4899d085bcf7a3c0fc10ef65->S50725c229541d49fe591346687d603e6(), 
"sessions_event_field")) { Sd88999e2476dbfd316b0d0689530380b("log.fields")->S6c7d84bb91509e8c72e7dd25a6eed444(S8c4ce22cb8fcad79d81f1499da387f4c)->Sbd5bb2da8370e42b52d874c38ec0e60d("sessions_event_field", 
true); } else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S2f2ee89f4899d085bcf7a3c0fc10ef65->S50725c229541d49fe591346687d603e6(), 
"requires_log_field")) { } else if (Sbea6e228a47bc141f76fa54e2c8ba1b9(S2f2ee89f4899d085bcf7a3c0fc10ef65->S50725c229541d49fe591346687d603e6(), 
"default")) { } else { S9f3294758e681a860d867ea1574f419c->S339ec4ebc6f2f5e7fc68e895ded32ae7(S2f2ee89f4899d085bcf7a3c0fc10ef65->S50725c229541d49fe591346687d603e6(), 
S2f2ee89f4899d085bcf7a3c0fc10ef65->S0d28196c1afaa22170ff1ac37a9dd9c1(Scc2faae6b412ac43b64129b402c4b88e)); 
} } }  }  }  }   bool S6f9ac2906a30d3083cbb7b887b2d09a5 = Sebff2b8a1db37bc3d06c5e6f5d316682->S84b49969ced69fcd76f788e837449ba5("track_host") 
&& Sbea6e228a47bc141f76fa54e2c8ba1b9(Sebff2b8a1db37bc3d06c5e6f5d316682->S8a2ed7aca5cd2ae18fad1952bfe6c14b("track_host"), 
"individually"); if ((Sf3d402fb6121ed5b8a3da5206059010a->S50e3386f844be5af68e929171fe4cb64 != -1) && 
S6f9ac2906a30d3083cbb7b887b2d09a5) { S7ca5d44c3992eca4f11ed4ee768968cd *S209396eccb5e28ac9ddcaff1b5a0555d 
= Sf3d402fb6121ed5b8a3da5206059010a->Sf0befb38b7fa6ef48281f983ac0bf5e8(Scc2faae6b412ac43b64129b402c4b88e, 
Sf3d402fb6121ed5b8a3da5206059010a->S50e3386f844be5af68e929171fe4cb64)->S5b0e82868aa537533b57d81256af2cfa(); 
S209396eccb5e28ac9ddcaff1b5a0555d->Se27e37418da71e8d1108561dad91573b("suppress_top", 99); S209396eccb5e28ac9ddcaff1b5a0555d->Se27e37418da71e8d1108561dad91573b("suppress_bottom", 
99); S209396eccb5e28ac9ddcaff1b5a0555d->Sbd5bb2da8370e42b52d874c38ec0e60d("always_include_leaves", true); 
} }   void S06715a7f208e9a643d80eb64a583b213(Sc51497dedb5c0712f20ccaa9831c0365 &Scc2faae6b412ac43b64129b402c4b88e) 
{  if (Scc2faae6b412ac43b64129b402c4b88e.Scae613df5f8d33d29ffa329e57180663) { for (mint S413a37d4b34cc0215a41e782fed855df 
= 0; S413a37d4b34cc0215a41e782fed855df < S85459fb9b577cfc38dabb71affe9fc7a(); S413a37d4b34cc0215a41e782fed855df++) 
delete(Scc2faae6b412ac43b64129b402c4b88e.Scae613df5f8d33d29ffa329e57180663[S413a37d4b34cc0215a41e782fed855df]); 
Sbf77df85ecaba2fb69a3728a80f84b0b(Scc2faae6b412ac43b64129b402c4b88e.Scae613df5f8d33d29ffa329e57180663); 
}   
#if 0
 if (S6d9b0f0a8f5c6afe82a10301fb5a05b7("database.structure.track_session_information")) { bool Sc973d809cceed89217ea1a856067debb 
= false;   if (S1411e5cdf69ee5c7bae55eda056360bd->Sc4222d932bcf71de49a03f7e8425e1d7 == -1) {  S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"page", "page", 99999, 0, "/?", true, true, true)); Sc973d809cceed89217ea1a856067debb = true; }  if 
(S1411e5cdf69ee5c7bae55eda056360bd->Sfe0b9f9860b45df4187dd66db3297cc7 == -1) {  S709f8a104a477b9e6883c170d8a6a334(Sd5d0b11267d13e242aa775ef7a48dead(Scc2faae6b412ac43b64129b402c4b88e, 
"date_time", "date_time", 99999, 0, "", true, true, false)); Sc973d809cceed89217ea1a856067debb = true; 
} if (Sc973d809cceed89217ea1a856067debb) { S709f8a104a477b9e6883c170d8a6a334(Sc465009e942ae2f258f97bcf78292d65(Scc2faae6b412ac43b64129b402c4b88e)); 
} } 
#endif
        } 

