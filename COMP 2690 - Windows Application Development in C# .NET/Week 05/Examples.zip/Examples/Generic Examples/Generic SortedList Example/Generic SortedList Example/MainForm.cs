using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Generic_SortedList_Example
{
	public partial class MainForm : Form
	{
		// When declaring a SortedList generic collection, you must 
		// specify the type of the key followed by the type of the data.
		private SortedList<string, Student> students;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			createSomeStudents();
			populateStudentList();
			updateStudentIdDisplay();
			lstStudents.SelectedIndex = 0;
		}

		private void lstStudents_SelectedIndexChanged(object sender, EventArgs e)
		{
			updateStudentIdDisplay();
		}

		private void createSomeStudents()
		{
			// When instantiating a SortedList generic collection, you must 
			// specify the type of the key followed by the type of the data.
			students = new SortedList<string, Student>();

			// Create two students and add them to the collection, using their
			// student ID as the key.

			Student tempStudent;

			tempStudent = new Student("A00123456", "Hardeep");
			students.Add(tempStudent.ID, tempStudent);

			tempStudent = new Student("A00372728", "Ming");
			students.Add(tempStudent.ID, tempStudent);
		}

		private void populateStudentList()
		{
			// Since SortedList does not implement the IList interface, we cannot
			// use it as a DataSource.  Instead, we can loop through each of its
			// items, adding them one-by-one to the collection.  However, item
			// item is actually a KeyValuePair object.

			lstStudents.Items.Clear();

			foreach (KeyValuePair<string, Student> kvp in students)
			{
				lstStudents.Items.Add(kvp.Value);
			}

			lstStudents.DisplayMember = "Name";
		}

		private void updateStudentIdDisplay()
		{
			// Is something in the ListBox selected?
			if (lstStudents.SelectedItem != null)
			{
				// Get a reference to the business object corresponding to the 
				// selected ListBox item.  Use the 'as' operator to do two things:
				// 1) downcast it from object to Student and 2) avoid a crash if 
				// the object is not a Student type ('as' returns null if it cannot
				// cast).
				Student selectedStudent = lstStudents.SelectedItem as Student;

				// Test the result of the 'as' operation.
				Debug.Assert(selectedStudent != null, "Only Student objects should be in the ListBox");

				// Update the Label.
				lblStudentId.Text = selectedStudent.ID;
			}
			else
			{
				lblStudentId.Text = "";
			}
		}
	}

	class Student
	{
		private string id;
		private string name;

		public Student(string id, string name)
		{
			this.id = id;
			this.name = name;
		}

		public string ID { get { return id; } }
		public string Name { get { return name; } }
	}

}